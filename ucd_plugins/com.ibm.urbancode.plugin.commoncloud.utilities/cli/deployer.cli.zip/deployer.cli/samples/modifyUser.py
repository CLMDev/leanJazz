"""
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2012. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
"""
# Modifies a user on the appliance
#
# This script is called as follows:
#
# deployer <deployer_options> -f samples/modifyUser.py <username>
#     [-e|--email <email>] [-f|--fullname <fullname>]
#     [-p|--password <password>]
#     [--addrole <role>] [--removerole <role>]
#     [--addgroup <group>] [--removegroup <group>]
#
# Where:
#
# <username>
#     specifies the current username of the user to be modified
#
# --addgroup <group>
#     adds the user to the specified group
#
# --addrole <role>
#     adds a role to the user, <role> must be one of:  CLOUD_USER,
#     CLOUD_ADMIN, APPLIANCE_ADMIN, CATALOG_CREATOR, PATTERN_CREATOR
#
# -e|--email <email>
#     specifies a new email address for the user
#
# -f|--fullname <full_name>
#     specifies a new full name for the user
#
# -p|--password <password>
#     specifies a new password for the user
#
# --removegroup <group>
#     removes the user from the specified group
#
# --removerole <role>
#     removes a role from the user, <role> must be one of:  CLOUD_USER,
#     CLOUD_ADMIN, APPLIANCE_ADMIN, CATALOG_CREATOR, PATTERN_CREATOR

import getopt
import sys


# print help and exit
def help():
    import os.path
    execfile(os.path.join(os.path.split(sys.argv[0])[0], '_showCommandHelp.py'))


if len(sys.argv) < 2:
    help()


# find the specified user
users = deployer.users[sys.argv[1]]
if len(users) < 1 or users[0].username != sys.argv[1]:
    raise 'username %s not found' % sys.argv[1]

user = users[0]


# parse command line arguments
try:
    (options, args) = getopt.getopt(sys.argv[2:], 'e:f:p:', ['addgroup=', 'addrole=', 'email=', 'fullname=', 'password=', 'removegroup=', 'removerole='])
except getopt.GetoptError:
    help()


if len(args) != 0:
    help()


# perform the requested updates
for option in options:
    if option[0] == '--addgroup':
        groups = deployer.groups[option[1]]
        if len(groups) < 1 or groups[0].name != option[1]:
            raise 'group %s not found' % option[1]

        print 'adding user to group...',
        user.groups.add(groups[0])
        print 'done'
        
    elif option[0] == '--addrole':
        print 'adding role...',
        user.roles += option[1]
        print 'done'
        
    elif option[0] == '-e' or option[0] == '--email':
        print 'modifying email address...',
        user.email = option[1]
        print 'done'

    elif option[0] == '-f' or option[0] == '--fullname':
        print 'modifying full name...',
        user.fullname = option[1]
        print 'done'

    elif option[0] == '-p' or option[0] == '--password':
        print 'modifying password...',
        user.password = option[1]
        print 'done'

    elif option[0] == '--removegroup':
        groups = deployer.groups[option[1]]
        if len(groups) < 1 or groups[0].name != option[1]:
            raise 'group %s not found' % option[1]

        print 'removing user from group...',
        user.groups.remove(groups[0])
        print 'done'

    elif option[0] == '--removerole':
        print 'removing role...',
        user.roles -= option[1]
        print 'done'
