#!/bin/bash
#
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2012. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
#
#
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer samples (7199-72X)
#* Copyright IBM Corporation 2009, 2012. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#* DISCLAIMER:
#* 
#* The following source code is sample code created by IBM Corporation.  
#* This sample code is provided to you solely for the purpose of assisting you in the  use of  the product.  
#* The code is provided 'AS IS', without warranty or condition of any kind.  
#* IBM shall not be liable for any damages arising out of your use of the sample code, 
#* even if IBM has been advised of the possibility of such damages.
#*
#*===================================================================
#

if [ $# -lt 4 ]
then
  echo
  echo "Example script to demonstrate the deletion of security audit records from the IWD server via REST API"
  echo "This requires that the files produced by auditFetch.sh (or audit-events.zip run through ExtractZipdata)"
  echo "be present for use by this script"
  echo
  echo "Required parameters:"
  echo
  echo "  [username=<user ID>]"
  echo "  [password=<user password>]"
  echo "  [keyfile=<path name of a file that contains user keys json objects>]"
  echo "  [IWD=<hostname or IP address of the IWD appliance>]"
  echo
  echo "Optional parameters:"
  echo
  echo "  [map=file name of record IDs within the audit-events.zip file]"
  echo "  [hash=file name of signed record IDs within the audit-events.zip file]"
  echo
  echo "  If these parameters are omitted they will default to the names in the zip file delivered via GET."
  echo "  This zip file *MUST* be input to ExtractZipData, which produces the following:"                  
  echo
  echo "     audit-events-record-IDs"
  echo "     audit-events-signed-record-IDs"
  echo
  echo "Example: ./auditDelete.sh username=auditadmin password=auditadminpswd keyfile=userkeys.json IWD=172.16.65.210"
  echo
  echo "This requires cscurl.sh"
  echo "  cscurl.sh requires create_basicauth_header.py."
  echo "This script is written with the assumption that these files are in the same directory as this script."
  echo "This script is for reference use only and contains no error recovery logic."
  echo
  echo "Please note that prior to running this, you must download the user keys:"
  echo
  echo "Example: https://172.16.65.210/resources/userKeys/"
  echo
  echo "This will prompt you for user and password and a location to save the file."
  echo "This file is a required parameter (above)."
  echo
  echo "The steps in the process are:"
  echo
  echo "  1. Download and save the user keys file."
  echo "  2. Retrieve the data from the REST API and save it in a file."
  echo "     a. an example URL would be: https://172.16.65.210:9444/audit/archiver/events"
  echo "     b. required HTTP headers are: Accept:application/octet-stream"
  echo "  3. Unzip the saved data file."
  echo "  4. Provide access for this script to the files audit-events-record-IDs and audit-events-signed-record-IDs"
  echo
  exit
fi

# ----------------------------------------------------------
# Parse the input params and set env variables for later use
# ----------------------------------------------------------

for arg in "$@"; do
    param=${arg%%=*}
    value=${arg##*=}
    case $param in
        username) export USERNAME="$param=$value"; shift 1;;
        password) export PASSWORD="$param=$value"; shift 1;;
        keyfile) export KEYSFILE="$param=$value"; shift 1;;
        IWD) export IWD=$value; shift 1;;
        map) export MAP=$value; shift 1;;
        hash) export HASH=$value; shift 1;;
    esac
done

# ----------------------------------------------------------
# Now go back through them and make sure they are all there. 
# ----------------------------------------------------------

if [ -z $USERNAME ]; then
    echo "A required parameter username=<user ID> is missing"
    exit 
fi

if [ -z $PASSWORD ]; then
    echo "A required parameter password=<user password> is missing"
    exit 
fi

if [ -z $KEYSFILE ]; then
    echo "A required parameter keyfile=<path name of a file contains cbadmin keys json object> is missing"
    exit 
fi

if [ -z $IWD ]; then
    echo "A required parameter IWD=<hostname or IP address of the IWD appliance> is missing"
    exit 
fi

if [ -z $MAP ]; then
     export MAP="audit-events-record-IDs"
fi

if [ -z $HASH ]; then
     export HASH="audit-events-signed-record-IDs"
fi

# ----------------------------------------------------------
# Display the params that were submitted.                    
# ----------------------------------------------------------

echo Constructed params follow:
echo
echo $USERNAME
echo $PASSWORD
echo $KEYSFILE
echo $IWD
echo $MAP
echo $HASH
echo

# ----------------------------------------------------------
# Construct the URL                                          
# ----------------------------------------------------------

urlString=https://$IWD:9444/audit/archiver/events
echo Constructed url is $urlString
echo

# ----------------------------------------------------------
# Fetch the encoded files we need                   
# ----------------------------------------------------------

echo Fetching the encoded files
echo -----------------------------
b64map=$(cat $MAP)
b64hash=$(cat $HASH)
echo -----------------------------
echo
echo encoded Map follows
echo -------------------
echo $b64map
echo -------------------
echo
echo encoded Hash follows
echo -------------------
echo $b64hash
echo -------------------
echo 

# ----------------------------------------------------------
# Construct the POST string from the two files
# ----------------------------------------------------------
initdata={\"eventIDList\":\"$b64map\",\"eventIDListSignature\":\"$b64hash\"}

echo 
echo constructed initial data string follows
echo ---------------------------------------
echo $initdata
echo ---------------------------------------
echo 
echo constructed final data string follows
echo -------------------------------------
postdata=$initdata
echo $postdata
echo -------------------------------------
echo

# ----------------------------------------------------------
# Issue the cscurl command to fetch the archived audit log.  
# Save the results into a file.  Note that this does not     
# save any extraneous http info, just the data.              
# ----------------------------------------------------------

./cscurl.sh $USERNAME $PASSWORD $KEYSFILE -v -k -H "Accept:application/json" -H "Content-Type:application/json" -X POST -d $postdata $urlString 
echo cscurl.sh returned exit code $?

exit $?
