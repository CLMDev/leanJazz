"""
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2012. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
"""
import time
from deployer import utils

def inputOrQuit(prompt):
    x = raw_input(prompt)
    if x == 'q':
        sys.exit()
    return x
  

createParms = {}

# get name for new virtual system
createParms['name'] = inputOrQuit('new virtual system name, or q to quit: ')


# select pattern to deploy
pattern = None
while not pattern:
    i = 1
    for p in deployer.patterns:
        print '%d. %s' % (i, utils.utos(p.name))
        i = i + 1

    x = inputOrQuit('select a pattern to deploy, or q to quit: ')
    try:
        pattern = deployer.patterns[int(x) - 1]
    except:
        # try again
        pass

createParms['pattern'] = pattern


# select a cloud in which to deploy
cloud = None
while not cloud:
    i = 1
    for c in deployer.clouds:
        print '%d. %s' % (i, utils.utos(c.name))
        i = i + 1

    x = inputOrQuit('select a cloud, or q to quit: ')
    try:
        cloud = deployer.clouds[int(x) - 1]
    except:
        # try again
        pass

createParms['cloud'] = cloud


# select a start time
starttime = inputOrQuit('number of seconds to delay start (default=no delay), or q to quit: ')
if starttime:
    createParms['starttime'] = time.time() + long(starttime)


# select an end time
endtime = inputOrQuit('number of seconds until stop (default=no scheduled stop), or q to quit: ')
if endtime:
    createParms['endtime'] = time.time() + long(endtime)
    

# get passwords
createParms['*.ConfigPWD_ROOT.password'] = inputOrQuit('root password for virtual machines, or q to quit: ')
createParms['*.ConfigPWD_USER.password'] = inputOrQuit('user password for virtual machines, or q to quit: ')


# loop to let user enter additional property/parameter values
virtualSystem = None
while not virtualSystem:
    try:
        virtualSystem = deployer.virtualsystems << createParms
    except ValueError, ve:
        print str(ve)
        key = inputOrQuit('additional property/parameter key, or q to quit: ')
        createParms[key] = inputOrQuit('value for \'%s\', or q to quit: ' % key)

print 'virtual system created:\n%s' % virtualSystem
