"""
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2012. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
"""
# lists the part properties and script parameters for a pattern
#
# This script accepts an arbitrary number of arguments, each of which
# can be either a search string used to identify pattern(s) or the
# index of a pattern.  If no arguments are given, the current list of
# patterns is printed and the user is prompted for a selection.  For
# each pattern specified, the part properties and script parameters,
# along with their default values, are printed.

import sys

def listPatternProperties(pattern):
    partIndex = 0
    for part in pattern.parts:
        for prop in part.properties:
            if prop['value']:
                print utils.utos('part-%d.%s.%s (default=%s)' % (partIndex, prop['pclass'], prop['key'], prop['value']))
            else:
                print utils.utos('part-%d.%s.%s' % (partIndex, prop['pclass'], prop['key']))

        scriptIndex = 0
        for script in part.scripts:
            for param in script.parameters:
                if param['defaultvalue']:
                    print utils.utos('part-%d.script-%d.%s (default=%s)' % (partIndex, scriptIndex, param['key'], param['defaultvalue']))
                else:
                    print utils.utos('part-%d.script-%d.%s' % (partIndex, scriptIndex, param['key']))

            scriptIndex = scriptIndex + 1

        partIndex = partIndex + 1


def findPatterns(s):
    # pattern specified by index
    try:
        return [ deployer.patterns[int(s)] ]

    # search on string
    except ValueError:
        return deployer.patterns[s]


if len(sys.argv) > 1:
    args = sys.argv[1:]
    
else:
    i = 1
    for p in deployer.patterns:
        print '%d. %s' % (i, utils.utos(p.name))
        i = i + 1

    x = raw_input('select a pattern: ')
    try:
        args = [ int(x) - 1 ]
    except ValueError:
        args = [ x ]

for arg in args:
    for pattern in findPatterns(arg):
        print 'part properties/script parameters for %s' % utils.utos(pattern.name)
        listPatternProperties(pattern)
        print
