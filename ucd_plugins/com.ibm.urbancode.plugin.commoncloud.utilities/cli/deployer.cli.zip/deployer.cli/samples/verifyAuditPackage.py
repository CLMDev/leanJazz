#!/usr/bin/env python

#
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2012. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
#

import base64
import subprocess
import os
import sys

def readFileAndDecode(filename):
	f = open(filename, 'r')
	data = f.readline()
	f.close()
	return base64.b64decode(data)

def writeToFile(filename, data):
	f = open(filename, 'w')
	f.write(data)
	f.close()

def verifyCheckSum(keyFile, checkSumFile, messageFile):
	decoded_data = readFileAndDecode(checkSumFile)
	decodedFileName = checkSumFile + "_decoded"
	writeToFile(decodedFileName, decoded_data)
	proc = subprocess.Popen(['openssl', 'dgst', '-sha1', '-verify', keyFile, '-signature', decodedFileName, messageFile], stdin=subprocess.PIPE, stdout=subprocess.PIPE)
	output = proc.communicate()[0]
	num=1
	while True:
		rc = proc.poll()
		if rc is not None:
			break
		sleep(0.1)
		if num < 200:
			num+=1
		else:
			break
	os.remove(decodedFileName)
	return output

def verifyAuditPackage() :
	pubKey='verificationPublicKey'
	args = sys.argv

	return verifyCheckSum(pubKey, args[1], args[2])

if __name__ == "__main__":
    print verifyAuditPackage()
