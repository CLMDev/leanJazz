#!/usr/bin/env deployer
"""
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2012. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
"""
# Displays and modifies the trace specification currently set on the
# appliance.
#
# This script is called as follows:
#
# deployer <deployer_options> -f samples/traceSpec.py
#     [ <logger_name> | <logger_name>= | <logger_name>=<level> ]...
#
# Where:
#
# <logger_name>
#     displays the current trace specification for the specified logger; for
#     example:
#
#         com.ibm.foo.bar=FINER
#
# <logger_name>=
#     removes the specified logger from the current trace specification
#
# <logger_name>=<level>
#     sets the logging level for the specified logger; <level> must be one of:
#     OFF, SEVERE, WARNING, CONFIG, INFO, FINE, FINER, FINEST
#
# If no arguments are given, the current trace specification is displayed, one
# logger per line.  For example:
#
#     com.ibm.foo.bar=FINER
#     com.ibm.xyz=INFO

import sys

# print help and exit
def help():
    import os.path
    execfile(os.path.join(os.path.split(sys.argv[0])[0], '_showCommandHelp.py'))


if len(sys.argv) > 1 and (sys.argv[1] == 'help' or sys.argv[1].startswith('-')):
    help()


traceSpec = deployer.trace.spec()

for arg in sys.argv[1:]:
    split = arg.split('=')

    if len(split) == 1:
        print "%s=%s" % (split[0], traceSpec[split[0]])

    elif len(split[1]) == 0:
        deployer.trace.remove(split[0])

    else:
        deployer.trace.set(split[0], split[1])


if len(sys.argv) == 1:
    for logger in sorted(traceSpec.keys()):
        print "%s=%s" % (logger, traceSpec[logger])
