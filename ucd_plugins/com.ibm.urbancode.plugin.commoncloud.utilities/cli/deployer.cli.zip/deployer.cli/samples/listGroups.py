"""
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2012. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
"""
# Lists the groups on the appliance
#
# This script is called as follows:
#
# deployer <deployer_options> -f samples/listGroups.py
#     [-x|--exact] [-v|--verbose] [-r|--roles] [-u|--users]
#     <search_str>*
#
# Where:
#
# -u|--users
#     additionally displays the names of the users to which the group
#     contains
#
# -r|--roles
#     additionally displays the roles assigned to the group
#
# -v|--verbose
#     displays the full set of information for each group rather than
#     just the group's name
#
# -x|--exact
#     indicates that only groups whose name exactly matches search_str
#     should be displayed
#
# <search_str>
#     groups whose name contains this string will be shown; if no search
#     string is specified, all groups will be shown; if more than one search
#     string is specified, searches are done in the order specified

import getopt
import sys


# print help and exit
def help():
    import os.path
    execfile(os.path.join(os.path.split(sys.argv[0])[0], '_showCommandHelp.py'))


# parse command line arguments
try:
    (options, args) = getopt.getopt(sys.argv[1:], 'urvx', ['users', 'roles', 'verbose', 'exact'])
except getopt.GetoptError:
    help()

users = False
roles = False
verbose = False
exact = False

for option in options:
    if option[0] == '-u' or option[0] == '--users':
        users = True

    elif option[0] == '-r' or option[0] == '--roles':
        roles = True

    elif option[0] == '-v' or option[0] == '--verbose':
        verbose = True

    elif option[0] == '-x' or option[0] == '--exact':
        exact = True


# force one iteration of loop if no search strings specified
if not args:
    args.append(None)

# iterate through search strings
for searchstr in args:
    # no search string given, get all groups
    if not searchstr:
        groups = list(deployer.groups)

    # find groups matching given string
    else:
        groups = deployer.groups[searchstr]

    # throw out non-matching names if -x was specified
    if exact:
        groups = filter(lambda group: group.name == searchstr, groups)


    # iterate through all the groups that were found
    for group in groups:
        # print detailed information if -v was specified
        if verbose:
            print utils.utos(group)
        # otherwise just show the group's name
        else:
            print utils.utos(group.name)

        # show group's roles if -r was specified
        if roles:
            print 'group roles: %s' % group.roles

        # show names of users if -m was specified
        if users:
            print 'group contains users: %s' % ', '.join([ u.fullname for u in group.users ])
