#!/bin/bash
#
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2012. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
#
#
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer samples (7199-72X)
#* Copyright IBM Corporation 2009, 2012. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#* DISCLAIMER:
#* 
#* The following source code is sample code created by IBM Corporation.  
#* This sample code is provided to you solely for the purpose of assisting you in the  use of  the product.  
#* The code is provided 'AS IS', without warranty or condition of any kind.  
#* IBM shall not be liable for any damages arising out of your use of the sample code, 
#* even if IBM has been advised of the possibility of such damages.
#*
#*===================================================================
#

# Default max record count
MAXCOUNT=20000

if [ $# -lt 4 ]
then
  echo
  echo "Example script to demonstrate the retrieval of security audit records from the IWD server via REST API"
  echo
  echo "Required parameters:"
  echo
  echo "  [username=<user ID>]"
  echo "  [password=<user password>]"
  echo "  [keyfile=<path name of a file that contains user keys json objects>]"
  echo "  [IWD=<hostname or IP address of the IWD appliance>]"
  echo
  echo "Optional parameters:"
  echo
  echo "  [startTime=<UTC time value for filtering results, e.g. 1321666620000 >]"
  echo "  [endTime=<UTC time value for filtering results>]"
  echo "                 The above are entered as a group."
  echo "                 Use an epoch calculator to generate the time values in UTC without any timezone conversion"
  echo "  [tz=<time zone, e.g. EST. The UTC times will be converted in the CSV files to this timezone.>]"
  echo "                 If omitted they will display as UTC"
  echo "  [size=<maximum number of audit records to download. Defaults (and limited) to $MAXCOUNT>]"
  echo "  [uuid=<audit record identifier)>]"
  echo
  echo "Example: ./auditFetch.sh username=auditadmin password=auditadminpswd keyfile=userkeys.json IWD=172.16.65.210"
  echo "         ./auditFetch.sh username=auditadmin password=auditadminpswd keyfile=userkeys.json IWD=172.16.65.210 uuid=999"
  echo "         ./auditFetch.sh username=auditadmin password=auditadminpswd keyfile=userkeys.json IWD=172.16.65.210 size=1000"
  echo "         ./auditFetch.sh username=auditadmin password=auditadminpswd keyfile=userkeys.json IWD=172.16.65.210 startTime=1321666620000"
  echo "         ./auditFetch.sh username=auditadmin password=auditadminpswd keyfile=userkeys.json IWD=172.16.65.210 startTime=1321666620000 tz=EST"
  echo "         ./auditFetch.sh username=auditadmin password=auditadminpswd keyfile=userkeys.json IWD=172.16.65.210 startTime=1321666620000 endTime=1321666800000 tz=JST"
  echo
  echo "Note:    The uuid parameter is mutually exclusive with the size and time parameters."
  echo
  echo "This requires cscurl.sh and AuditArchiveRecordDisplay.class."
  echo "  cscurl.sh requires create_basicauth_header.py."
  echo "This script is written with the assumption that these files are in the same directory as this script."
  echo "This script is for reference use only and contains no error recovery logic."
  echo
  echo "Please note that prior to running this, you must download the user keys:"
  echo
  echo "Example: https://172.16.65.210/resources/userKeys/"
  echo
  echo "This will prompt you for user and password and a location to save the file."
  echo "This file is a required parameter (above)."
  echo
  echo "The steps in the process are:"
  echo
  echo "  1. Download and save the user keys file."
  echo "  2. Retrieve the data from the REST API and save it in a file."
  echo "     a. an example URL would be: https://172.16.65.210:9444/audit/archiver/events"
  echo "     b. required HTTP headers are: Accept:application/octet-stream"
  echo "  3. Unzip the saved data file."
  echo "  4. Process the inflated file which contains a Java serialized TreeMap."
  echo
  exit
fi

# ----------------------------------------------------------
# Parse the input params and set env variables for later use
# ----------------------------------------------------------

for arg in "$@"; do
    param=${arg%%=*}
    value=${arg##*=}
    case $param in
        username) export USERNAME="$param=$value"; shift 1;;
        password) export PASSWORD="$param=$value"; shift 1;;
        keyfile) export KEYSFILE="$param=$value"; shift 1;;
        IWD) export IWD=$value; shift 1;;
        startTime) export STARTTIME="$param=$value"; shift 1;;
        endTime) export ENDTIME="$param=$value"; shift 1;;
        tz) export TIMEZONE="$param=$value"; shift 1;;
        size) export REQSIZE=$value; shift 1;;
        # uuid) export UUID="$param=$value"; shift 1;;
        uuid) export UUID=$value; shift 1;;
    esac
done

# ----------------------------------------------------------
# Now go back through them and make sure they are all there. 
# ----------------------------------------------------------

if [ -z $USERNAME ]; then
    echo "A required parameter username=<user ID> is missing"
    exit 
fi

if [ -z $PASSWORD ]; then
    echo "A required parameter password=<user password> is missing"
    exit 
fi

if [ -z $KEYSFILE ]; then
    echo "A required parameter keyfile=<path name of a file contains cbadmin keys json object> is missing"
    exit 
fi

if [ -z $IWD ]; then
    echo "A required parameter IWD=<hostname or IP address of the IWD appliance> is missing"
    exit 
fi

if [ -z $REQSIZE ]; then
    export REQSIZE=$MAXCOUNT
fi

# ----------------------------------------------------------
# Display the params that were submitted.                    
# ----------------------------------------------------------

echo Constructed params follow:
echo
echo $USERNAME
echo $PASSWORD
echo $KEYSFILE
echo $IWD
echo

# ----------------------------------------------------------
# If UUID is not present then we will assume the normal path 
# through here.                                          
# ----------------------------------------------------------

if [ -z $UUID ]; then
	echo Requesting multiple audit records

# ----------------------------------------------------------
# Set the requested record count.  Limit it if necessary.    
# N.B. If zero is specified it will be set to the default
#      max on the server.
# ----------------------------------------------------------

	if [[ $REQSIZE -gt $MAXCOUNT ]]
	then 
    		 SIZE="size=$MAXCOUNT"
	else
     		SIZE="size=$REQSIZE"
	fi
  
# ----------------------------------------------------------
# Construct the URL                                          
# ----------------------------------------------------------

	if [ -z $STARTTIME ] ; 
	then
		urlString=https://$IWD:9444/audit/resources/records?$SIZE
	else
		if [ -z $TIMEZONE ] ; 
		then
     			TIMEZONE='tz=UTC'
		fi
		if [ -z $ENDTIME ] ; 
		then
     			ENDTIME='endTime=-1'
		fi
		urlString="https://$IWD:9444/audit/resources/records?$STARTTIME&$ENDTIME&$TIMEZONE&$SIZE"
	fi

# ----------------------------------------------------------
# Alternate path: request one log record by uuid             
# ----------------------------------------------------------

else
	echo Requesting a single audit record
	urlString="https://$IWD:9444/audit/resources/records/$UUID"
fi

echo Constructed url is $urlString
echo
	
# ----------------------------------------------------------
# Issue the cscurl command to fetch the archived audit log.  
# Save the results into a file.  Note that this does not     
# save any extraneous http info, just the data.              
# ----------------------------------------------------------

outputFile=ArchiveFetchTempFile
./cscurl.sh $USERNAME $PASSWORD $KEYSFILE -k -H "Accept:application/octet-stream" $urlString > $outputFile
echo cscurl.sh returned exit code $?

# ----------------------------------------------------------
# The file saved is zipped.  Unzip it.  
# ----------------------------------------------------------

fileName=`unzip ArchiveFetchTempFile | grep -in inflating: | cut -d ":" -f 3`
echo unzipping returned exit code $?
echo unzipped file name is $outputFile

exit $?
