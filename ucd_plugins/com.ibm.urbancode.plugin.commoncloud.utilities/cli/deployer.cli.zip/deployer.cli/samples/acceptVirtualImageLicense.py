#!/usr/bin/env deployer
"""
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2012. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
"""
# Lists, displays and accepts the license for a virtual image on the
# appliance.
#
# This script is called as follows:
#
# deployer <deployer_options> -f samples/acceptVirtualImageLicense.py

import getopt
import sys


# print help and exit
def help():
    import os.path
    execfile(os.path.join(os.path.split(sys.argv[0])[0], '_showCommandHelp.py'))


if len(sys.argv) != 1:
    help()


# select virtual image
virtimg = None

while not virtimg:
    print 'Retrieving virtual image information...'

    linebreak = '\n'

    i = 1
    for vi in deployer.virtualimages:
        print '%s%d. %s' % (linebreak, i, vi.name)
        i = i + 1
        linebreak = ''

    x = raw_input('\nselect a virtual image: ')

    try:
        virtimg = deployer.virtualimages[int(x) - 1]
    except:
        # try again
        pass


# display/accept licenses
print '\nRetrieving virtual image license information...'

linebreak = '\n'
vilicenses = virtimg.license
accepted = {}

while True:
    done = True
    selectable = []

    for collection in vilicenses.items():

        collection_id = collection[0]
        collection_data = collection[1]

        if accepted.has_key(collection_id):
            x = 'x'
        else:
            x = ' '
            done = False

        print '%s(%s) %s' % (linebreak, x, collection_data['label'])
        linebreak = ''

        for license in collection_data['licenses']:
            selectable.append((collection_id, license))

            if accepted.get(collection_id, None) == license['licenseid']:
                print '   (x) %d. %s' % (len(selectable), license['label'])
            else:
                print '   ( ) %d. %s' % (len(selectable), license['label'])

    if done:
        prompt = '\nselect license to view, enter to accept selected licenses: '
    else:
        prompt = '\nselect a license to view: '
    x = raw_input(prompt)

    try:
        if x == '' and done:
            break

        selected = selectable[int(x) - 1]
        collection_id = selected[0]
        license = selected[1]

        print license['text'].replace('<br/>', '\n')

        x = raw_input('\naccept license (y/n) [y]: ')

        if x == 'Y' or x == 'y' or x == '':
            accepted[collection_id] = license['licenseid']

        elif accepted[collection_id] == license['licenseid']:
            del accepted[collection_id]

        print ''

    except:
        # try again
        pass


# accept licenses
print '\nAccepting virtual image license...'
virtimg.acceptLicense(accepted)
print ''
