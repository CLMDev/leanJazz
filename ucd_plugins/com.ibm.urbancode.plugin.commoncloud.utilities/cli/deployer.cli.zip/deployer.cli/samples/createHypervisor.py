"""
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2012. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
"""
# Defines a new hypervisor to Workload Deployer
#
# This script is called as follows:
#
# deployer <deployer_options> -f samples/createHypervisor.py
#     [<name> <type> <address> <userid> <password>]
#
# Where:
#
# <name>
#     specifies a name for the new hypervisor
#
# <type>
#     specifies the type of the hypervisor, for example 'ESX'
#
# <address>
#     specifies the hostname or IP address of the hypervisor
#
# <userid>
#     specifies the userid to access the hypervisor
#
# <password>
#     specifies the password to access the hypervisor
# 
# If any of the 5 parameters are omitted, the hypervisor create wizard
# is run.

import sys

if len(sys.argv) < 6:
    print deployer.hypervisors.create(deployer.wizard)

else:
    print deployer.hypervisors.create({
        'name': sys.argv[1],    # hypervisor name
        'type': sys.argv[2],    # hypervisor type ('ESX')
        'address': sys.argv[3], # IP address or host name of hypervisor
        'userid': sys.argv[4],  # userid used to log on to the hypervisor
        'password': sys.argv[5] # password used to log on to the hypervisor
    })
