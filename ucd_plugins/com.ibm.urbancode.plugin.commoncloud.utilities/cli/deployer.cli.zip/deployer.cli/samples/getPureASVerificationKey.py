#!/usr/bin/env python

#
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2012. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
#

import sys
import json
import subprocess
from verifyAuditPackage import writeToFile
from getDataAndProcessJSON import formatPublicKey

def getPureASVerificationKey() :
	args = sys.argv

	username=args[1]
	password=args[2]
	urlString=args[3]

	outputfilename=args[4]

	proc = subprocess.Popen(['curl', '-u', username + ':' + password, '-k', urlString], stdin=subprocess.PIPE, stdout=subprocess.PIPE)
	output = proc.communicate()[0]
	num=1
	while True:
		rc = proc.poll()
		if rc is not None:
			break
		sleep(0.1)
		if num < 200:
			num+=1
		else:
			break

	output = output[1:-1]

	formatPublicKey(outputfilename, output)
	return True

if __name__ == "__main__":
    print getPureASVerificationKey()
