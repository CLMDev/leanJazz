"""
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2012. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
"""
# lists hypervisors defined to the appliance

import sys

# no search string specified, show all hypervisors
if len(sys.argv) < 2:
    print deployer.hypervisors

# show hypervisors whose name matches the given string
else:
    print deployer.hypervisors[sys.argv[1]]
