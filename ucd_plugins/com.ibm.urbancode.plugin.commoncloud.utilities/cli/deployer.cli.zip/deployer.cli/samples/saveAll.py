"""
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2012. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
"""

import sys
import os
import string

from deployer import http, utils, prettify

# 
# This script reads all of the data from an appliance's cloud and catalog 
# and generates two artifacts:
# 
# 1) a text report with the details of the cloud and catalog
# 2) a CLI script that can be used to recreate all of the data
# 
# Running this script can help you learn how to use the CLI. If you have 
# performed all of your appliance setup through the web console, running 
# this script will generate Jython code that does the exact same tasks, 
# and you can see how you would have done it via command line.
# 
# If you use this script to recreate script packages and virtual images, 
# you must first export those archives (zip/tar.gz for script packages, 
# .ova for images) to the machine that will be used to run the generated 
# Jython code. The generated code will ask you for local paths to those 
# archives so it can import them into the appliance.
# 
# This script does not process patterns - to save patterns as CLI code, 
# you can use the patternToPython.py sample script.
# 

def getAllAttributes(resource):
    attrnames = {}
     
    if hasattr(resource, '_RESTNAMES_') :
       attrnames = resource._RESTNAMES_
    elif hasattr(resource, '_LOCALNAMES_'):
       attrnames = resource._LOCALNAMES_
   
    visible = getattr(resource, "_VISIBLE_", {})
       
    return [key for key in attrnames if utils.all(visible.get(key, []), lambda visCheck: visCheck(resource))]
        
            
    
def asText(resource, ignore = [], indent = '    '):    
    ignoreAll = ['id', 'created', 'updated', 'ownerid', 'currentstatus', 'currentmessage', 'desiredstatus', 'password']
    ignoreAll.extend(ignore)
    
    text = []
    
    attrnames = getAllAttributes(resource)
    
    for key in attrnames:
        if key not in ignoreAll:
            text.append('%s%s: %s' % (indent, key, getattr(resource, key) or '(none)'))
    
    return '\n'.join(text)


def asJython(collection, variable, resource, ignore = [], variables = []): 
    ignoreAll = ['id', 'created', 'updated', 'ownerid', 'currentstatus', 'currentmessage', 'desiredstatus', 'password']
    ignoreAll.extend(ignore)
    
    json = {}
    
    attrnames = getAllAttributes(resource)
    
    for key in attrnames:
        if key not in ignoreAll:
            value = getattr(resource, key)
            if value == None:
                 continue  
            if collection == 'users' and key == 'name':
                json['fullname'] = value
            
            if collection == 'ipgroups' and key == 'address':
                json['subnetaddress'] = value
            
            json[key] = value
    
    for key in variables:
        json[key] = '%s_placeholder' % key
    
    code = '\n%s = deployer.%s << %s\n' % (variable, collection, prettify.prettify(json))
    
    for key in variables:
        code = code.replace('\"%s_placeholder\"' % key, key)
    
    return code

def writeHypervisor(manager, vendor, hyp, ignore, jython, indent):
    if not manager:
        jython.write('\nprint \"    Adding hypervisor %s...\"\n' % hyp.name)
        
        variables = []
        
        if vendor == 'ESX':
            jython.write('password = raw_input(\'ESX password: \')\n')
            variables.append('password')
        
        jython.write(asJython('hypervisors', 'hyp', hyp, ignore, variables))
        jython.write('cloud.hypervisors << hyp\n')
        jython.write('%shyp.certificate\n' % indent)
        jython.write('%shyp.acceptCertificate()\n' % indent)
    
    jython.write('%shyp.discover()\n' % indent)
    jython.write('\n%shyp.waitFor(lambda hv: hv.networks, 60)\n' % indent)
    jython.write('\n%sif hyp.networks:\n' % indent)    
    
    for network in hyp.networks:
        if network.ipgroup:
            jython.write('    %shyp.networks[\"%s\"][0].ipgroup = deployer.ipgroups[\"%s\"][0]\n' % (indent, network.name, network.ipgroup.name))
    
    jython.write('\n')

#
# script starts here!
#

hostName = http.host.replace('.', '_')

#
# create new files for text report and jython code
#

reportName = '%s.txt' % hostName
jythonName = '%s.py' % hostName

report = open(reportName, 'w')
report.write('\nappliance:\n')
report.write('\n    %s\n' % http.host)

jython = open(jythonName, 'w')
jython.write('\n# This script can be used to create the data found on %s.\n' % http.host)

print 'Generating report in %s...' % reportName
print 'Generating script in %s...' % jythonName

#
# read all appliance settings data: ethernet, dns, etc.
#

print 'Reading ethernet data...'

report.write('\nethernet:\n\n')

for eth in deployer.ethernet.interfaces:
    report.write('    %s\n' % (eth.ipaddress or '(none)'))

print 'Reading DNS data...'

report.write('\ndns:\n\n')

for dns in deployer.dns.servers:
    report.write('    %s\n' % dns.ipaddress)

print 'Reading NTP data...'

report.write('\nntp:\n\n')

for ntp in deployer.dateandtime.ntpservers:
    report.write('    %s\n' % ntp)


#
# find all users and groups
#

print 'Reading user data...'

report.write('\nusers:\n\n')

for user in deployer.users:
    report.write(asText(user))
    report.write('\n\n')
    
    if user.username != 'cbadmin':
        jython.write('\nprint \"Adding user %s...\"\n' % user.username)
        jython.write(asJython('users', 'user', user))

print 'Reading user group data...'

report.write('user groups:\n\n')

for group in deployer.groups:
    report.write(asText(group))
    report.write('\n    users: %s' % '\n           '.join(utils.map(group.users, lambda user: user.username)))
    report.write('\n\n')
    
    if group.name != 'Everyone':
        print '    Reading group membership data for %s...' % group.name
        
        jython.write('\nprint \"Adding group %s...\"\n' % group.name)
        jython.write(asJython('groups', 'group', group))
        
        jython.write('\nprint \"    Adding members of group %s...\"\n' % group.name)
        
        for user in group.users:
            jython.write('group.users << deployer.users[\'%s\'][0]\n' % user.username)

#
# find all cloud data - IPs, clouds, hypervisors
#

print 'Reading IP group data...'

report.write('ip groups:\n\n')

for ipg in deployer.ipgroups:
    ipList = utils.map(ipg.ips, lambda ip: ip.ipaddress)
    
    report.write(asText(ipg))
    report.write('\n    range: %s' % '\n           '.join(ipList))
    report.write('\n\n')
    
    jython.write('\nprint \"Adding IP group %s...\"\n' % ipg.name)
    jython.write(asJython('ipgroups', 'ipg', ipg, ['protocol']))
    jython.write('ipg.ips << %s\n' % prettify.prettify(ipList))

print 'Reading cloud group data...'

report.write('cloud groups:\n\n')

for cg in deployer.clouds:
    cgIgnore = ['defaultcloud', 'certified', 'password', 'ospassword']
    hypIgnore = ['auxrecordid', 'cloudid', 'certified', 'ismanager']
    
    cgVariables = []
    
    jython.write('\nprint \"Adding cloud group %s...\"\n' % cg.name)
    
    #
    # managed clouds have special requirements - Virtual Center and VMControl
    #
    
    if cg.type == 'manager':
        if cg.vendor == 'ESX':
            jython.write('\npassword = raw_input(\'Virtual Center password: \')\n')
            cgVariables.append('password')
        
        else:
            jython.write('\npassword = raw_input(\'VMControl password: \')\n')
            jython.write('ospassword = raw_input(\'OS password: \')\n')
            cgVariables.extend(['password', 'ospassword'])
    
    jython.write(asJython('clouds', 'cloud', cg, cgIgnore, cgVariables))
    
    #
    # discovery stage needed for cloud group if it's managed
    #
    if cg.type == 'manager':
        jython.write('cloud.certificate\n')
        jython.write('cloud.acceptCertificate()\n')
        jython.write('cloud.discover()\n')
        jython.write('cloud.waitFor()\n')
    
    report.write(asText(cg, cgIgnore))
    
    print '    Reading hypervisor data for %s...' % cg.name
    
    report.write('\n    hypervisors:\n\n')
    
    indent = ''
    
    if cg.type == 'manager':
        jython.write('\nfor hyp in cloud.hypervisors:\n')
        writeHypervisor(True, cg.vendor, cg.hypervisors[0], hypIgnore, jython, '    ')
    
    for hyp in cg.hypervisors:
        report.write(asText(hyp, hypIgnore, '        '))
        report.write('\n\n')
        
        #
        # unmanaged cloud groups require us to create hypervisors explicitly
        #
        if cg.type != 'manager':
            writeHypervisor(False, 'ESX', hyp, hypIgnore, jython, '')

#
# find all catalog data - scripts and images
#

print 'Reading script package data...'

report.write('script packages:\n\n')

for script in deployer.scripts:
    if script.id <= 10:
        continue
    
    ignore = ['maintenance', 'resourcetype', 'type', 'label', 'ispublic', 'version', 'currenteditionid']
    
    report.write(asText(script, ignore))
    report.write('\n\n')
    
    jython.write('\nprint \"Adding script %s...\"\n' % script.name)
    
    ignore.extend(['filename'])
    ignore.extend(['id', 'created', 'updated', 'ownerid', 'currentstatus', 'currentmessage', 'desiredstatus', 'password'])
    
    #jython.write('\nscript = deployer.scripts << { \"name\": \"%s\" }\n' % script.name)
    
    #for key in script.attrs:
    #   if key not in ignore and script.attrs[key]:
    #      jython.write('script.%s = \"%s\"\n' % (key, script.attrs[key]))
    jython.write(asJython('scripts', 'script', script, ignore))
    
    jython.write('\npath = raw_input(\"Archive file for %s: \")\n' % script.name)
    jython.write('\nif path:\n')
    jython.write('    script.archive << path\n')

print 'Reading virtual image data...'
        
report.write('virtual images:\n\n')

for vi in deployer.virtualimages:
    ignore = ['parenttemplateid', 'parenttemplateeditionid', 'currenteditionid', 'editionstatus', 'servicelevel', 'build', 'hardware']
    
    report.write(asText(vi, ignore))
    report.write('\n\n')
    
    jython.write('\nprint \"Adding virtual image %s...\"\n' % vi.name)
    jython.write('\npath = raw_input(\'OVA file for %s: \')\n' % vi.name)
    jython.write('\nif path:\n')
    jython.write('    vi = deployer.virtualimages << path\n')
    
    if vi.licenseaccepted == 'T':
        jython.write('    vi.waitFor()\n')
        jython.write('    vi.acceptLicense()\n')

report.close()
jython.close()

print 'Saved report to %s.' % reportName
print 'Saved script to %s.' % jythonName
