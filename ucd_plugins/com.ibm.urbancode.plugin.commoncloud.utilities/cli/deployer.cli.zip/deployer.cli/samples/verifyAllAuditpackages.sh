#!/bin/bash
#
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2012. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
#
#
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer samples (7199-72X)
#* Copyright IBM Corporation 2009, 2012. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#* DISCLAIMER:
#* 
#* The following source code is sample code created by IBM Corporation.  
#* This sample code is provided to you solely for the purpose of assisting you in the  use of  the product.  
#* The code is provided 'AS IS', without warranty or condition of any kind.  
#* IBM shall not be liable for any damages arising out of your use of the sample code, 
#* even if IBM has been advised of the possibility of such damages.
#*
#*===================================================================
#
logger() {
	filename=`basename $0`
	logdate=`date '+%Y-%m-%d'`
	logtime=`date '+%H:%M:%S.'`$(expr `date +%N` / 1000000)
	logfile=$(getLogFile)

	logheader="${logdate} ${logtime}: ${filename}:"
	if [ $# -eq 0 ]; then
		logmessage="$logheader NO MESSAGE PASSED"
	elif [ $# -eq 1 ]; then
		logmessage="$logheader $1"
	else
		lineno=$1
		shift 1
		logmessage="$logheader line=$lineno $@"
	fi

	echo ${logmessage} |tee -a ${logfile}
}
getLogFile() {
	directory=./
	filename=`basename $0`
	logdate=`date '+%Y-%m-%d'`
	echo ${directory}`basename $0 .sh`_${logdate}.log
}

type_IWD=IWD
type_PureAS=PureAS

if [ $# -lt 3 ]
then
  echo
  echo "Example script to demonstrate the management of security audit records from the PureAS server via REST API"
  echo
  echo "Required parameters:"
  echo "  [username=<user ID>]"
  echo "  [password=<user password>]"
  echo "  [server=<hostname or IP address of the IBM Workload Deployer Server or PureApplication System server>]"
  echo "  [targetdir=<the directory audit package files exist>]"
  echo "  [type=$type_IWD or $type_PureAS]"
  echo
  echo "Example: ./verifyAllAuditpackages.sh username=auditadmin password=auditadminpswd server=172.16.65.210 targetdir=/home/test/Downloads"
  echo
  echo "This requires cscurl.sh"
  echo "  cscurl.sh requires create_basicauth_header.py."
  echo "This script is for reference use only and contains no error recovery logic."
  echo
  exit
fi

for arg in "$@"; do
    param=${arg%%=*}
    value=${arg##*=}
    case $param in
        username) export USERNAME="$param=$value"; export UNAME=$value; shift 1;;
        password) export PASSWORD="$param=$value"; export PWORD=$value; shift 1;;
        server) export SERVER=$value; shift 1;;
        targetdir) export targetdir=$value; shift 1;;
        type) export type=$value; shift 1;;
    esac
done

if [ -z $USERNAME ]; then
    logger $LINENO "A required parameter username=<user ID> is missing"
    exit 
fi

if [ -z $PASSWORD ]; then
    logger $LINENO "A required parameter password=<user password> is missing"
    exit 
fi

if [ -z $SERVER ]; then
    logger $LINENO "A required parameter PureAS=<hostname or IP address of the IWD or PureAS appliance> is missing"
    exit 
fi

if [ -z $targetdir ]; then
    logger $LINENO "A required parameter targetdir=<the directory audit package files exist> is missing"
    exit 
fi

if [ -z $type ]; then
    logger $LINENO "A required parameter type=<$type_IWD or $type_PureAS> is missing"
    exit 
fi

if [ "$type" != "$type_IWD" -a "$type" != "$type_PureAS" ]; then
	logger $LINENO "The value of type: " $type " is not valid and the default value $type_IWD will be used."
	type=$type_IWD
fi

VERIFY_SUCCESS="Verified OK"
verificationKeyFile=verificationPublicKey

# get verification key
if [ "$type" = "$type_IWD" ]; then
	KEYSFILE=userKey.json
	urlString=https://$SERVER/resources/userKeys
	# get user key
	curl -u $UNAME:$PWORD -H "User-Agent:IBM-Workload-Deployer-CLI-Bootstrap" -H "X-IBM-Workload-Deployer-API-Session:NONE" -k $urlString > $KEYSFILE
	# get verification key
	urlString=https://$SERVER:9444/audit/archiver/verificationpublickey
	keyresult=$(${0%%verifyAllAuditpackages.sh}getDataAndProcessJSON.py $USERNAME $PASSWORD keyfile=$KEYSFILE $urlString publicKey $verificationKeyFile)
	rm $KEYSFILE
else
	urlString=https://$SERVER/audit/resources/recordpackages?server_public_key
	keyresult=$(${0%%verifyAllAuditpackages.sh}getPureASVerificationKey.py $UNAME $PWORD $urlString $verificationKeyFile)
fi

files="${targetdir}/*.zip"
for filepath in ${files}
do
	logger $LINENO "--- Start to verify ${filepath} ---"
	dirname=`echo $filepath | sed 's/.zip//'`
	mkdir $dirname
	unzip $filepath -d $dirname

	childfiles="$dirname/*.zip"
	for cfile in ${childfiles}
	do
		unzip $cfile -d $dirname
	done

	# verify package
	if [ "$type" = "$type_IWD" ]; then
		verifyAudit=$(${0%%verifyAllAuditpackages.sh}verifyAuditPackage.py ${dirname}/audit-events-signed-events-checksum ${dirname}/audit-events.csv)
		verifyIDList=$(${0%%verifyAllAuditpackages.sh}verifyAuditPackage.py ${dirname}/audit-events-signed-record-IDs ${dirname}/audit-events-record-IDs)

		logger $LINENO "The verification result of audit records: $verifyAudit"
		logger $LINENO "The verification result of audit ID list: $verifyIDList"
		if [ "$verifyAudit" != "$VERIFY_SUCCESS" -o "$verifyIDList" != "$VERIFY_SUCCESS" ]; then
			logger $LINENO "Verification failed: audit record: " $verifyAudit ", ID list: " $verifyIDList;
		fi
	else
		verifyAudit=$(${0%%verifyAllAuditpackages.sh}verifyAuditPackage.py ${dirname}/puresystems-audit-*.checksum ${dirname}/puresystems-audit-*.csv)

		if [ "$verifyAudit" != "$VERIFY_SUCCESS" ]; then
			logger $LINENO "Verification failed: audit record: " $verifyAudit;
		else
			logger $LINENO "Verification success: audit record: " $verifyAudit;
		fi
	fi

	rm -fr $dirname
	logger $LINENO "--- End to verify ${filepath} ---"
done

# cleanup files
rm $verificationKeyFile
