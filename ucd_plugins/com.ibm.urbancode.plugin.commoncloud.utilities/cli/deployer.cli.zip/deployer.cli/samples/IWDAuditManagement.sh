#!/bin/bash
#
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2012. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
#
#
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer samples (7199-72X)
#* Copyright IBM Corporation 2009, 2012. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#* DISCLAIMER:
#* 
#* The following source code is sample code created by IBM Corporation.  
#* This sample code is provided to you solely for the purpose of assisting you in the  use of  the product.  
#* The code is provided 'AS IS', without warranty or condition of any kind.  
#* IBM shall not be liable for any damages arising out of your use of the sample code, 
#* even if IBM has been advised of the possibility of such damages.
#*
#*===================================================================
#
logger() {
	filename=`basename $0`
	logdate=`date '+%Y-%m-%d'`
	logtime=`date '+%H:%M:%S.'`$(expr `date +%N` / 1000000)
	logfile=$(getLogFile)

	logheader="${logdate} ${logtime}: ${filename}:"
	if [ $# -eq 0 ]; then
		logmessage="$logheader NO MESSAGE PASSED"
	elif [ $# -eq 1 ]; then
		logmessage="$logheader $1"
	else
		lineno=$1
		shift 1
		logmessage="$logheader line=$lineno $@"
	fi

	echo ${logmessage} |tee -a ${logfile}
}
getLogFile() {
	directory=./
	filename=`basename $0`
	logdate=`date '+%Y-%m-%d'`
	echo ${directory}`basename $0 .sh`_${logdate}.log
}

if [ $# -lt 3 ]
then
  echo
  echo "Example script to demonstrate the management of security audit records from the IWD server via REST API"
  echo
  echo "Required parameters:"
  echo "  [username=<user ID>]"
  echo "  [password=<user password>]"
  echo "  [IWD=<hostname or IP address of the IWD appliance>]"
  echo
  echo "Optional parameters:"
  echo "  [startThreshold=<The cycle to download, verify and delete audit records is started when the utilization reaches this value, e.g. 80 (%). Defaults to 0 (%)>]"
  echo "  [endThreshold=<The cycle to download, verify and delete audit records is ended when the utilization is decreased to this value, e.g. 30 (%). Defaults to 0 (%) >]"
  echo "  [size=<maximum number of audit records to download. Defaults (and limited) to $MAXCOUNT in auditFetch.sh>]"
  echo
  echo "Example: ./IWDAuditManagement.sh username=auditadmin password=auditadminpswd IWD=172.16.65.210"
  echo "         ./IWDAuditManagement.sh username=auditadmin password=auditadminpswd IWD=172.16.65.210 size=1000"
  echo "         ./IWDAuditManagement.sh username=auditadmin password=auditadminpswd IWD=172.16.65.210 startThreshold=80"
  echo "         ./IWDAuditManagement.sh username=auditadmin password=auditadminpswd IWD=172.16.65.210 startThreshold=80 endThreshold=50"
  echo "         ./IWDAuditManagement.sh username=auditadmin password=auditadminpswd IWD=172.16.65.210 startThreshold=80 endThreshold=50 size=1000"
  echo
  echo "This requires cscurl.sh, auditFetch.sh and auditDelete.sh."
  echo "  cscurl.sh requires create_basicauth_header.py."
  echo "This script is written with the assumption that these files are in the same directory as this script."
  echo "This script is for reference use only and contains no error recovery logic."
  echo
  exit
fi

for arg in "$@"; do
    param=${arg%%=*}
    value=${arg##*=}
    case $param in
        username) export USERNAME="$param=$value"; export UNAME=$value; shift 1;;
        password) export PASSWORD="$param=$value"; export PWORD=$value; shift 1;;
        IWD) export IWD=$value; shift 1;;
        size) export REQSIZE=$value; shift 1;;
        startThreshold) export STARTTHRESHOLD=$value; shift 1;;
        endThreshold) export ENDTHRESHOLD=$value; shift 1;;
    esac
done

if [ -z $USERNAME ]; then
    logger $LINENO "A required parameter username=<user ID> is missing"
    exit 
fi

if [ -z $PASSWORD ]; then
    logger $LINENO "A required parameter password=<user password> is missing"
    exit 
fi

if [ -z $IWD ]; then
    logger $LINENO "A required parameter IWD=<hostname or IP address of the IWD appliance> is missing"
    exit 
fi

if [ -z $STARTTHRESHOLD ]; then
	export STARTTHRESHOLD=0
fi

if [ -z $ENDTHRESHOLD ]; then
	export ENDTHRESHOLD=0
fi

if [ -z $REQSIZE ]; then
	REQSIZE=-1
fi

if [[ $REQSIZE -gt 0 ]]
	then 
		SIZE="size=$REQSIZE"
	else
		SIZE=""
fi


KEYSFILE=userKey.json
urlString=https://$IWD/resources/userKeys

VERIFY_SUCCESS="Verified OK"

# get user key
curl -u $UNAME:$PWORD -H "User-Agent:IBM-Workload-Deployer-CLI-Bootstrap" -H "X-IBM-Workload-Deployer-API-Session:NONE" -k $urlString > $KEYSFILE

# get verification key
verificationKeyFile=verificationPublicKey
urlString=https://$IWD:9444/audit/archiver/verificationpublickey
keyresult=$(${0%%IWDAuditManagement.sh}getDataAndProcessJSON.py $USERNAME $PASSWORD keyfile=$KEYSFILE $urlString publicKey $verificationKeyFile)

# get utilization
utilizationFile=auditDBUtilization
urlString=https://$IWD:9444/audit/archiver/utilization
utilization=$(${0%%IWDAuditManagement.sh}getDataAndProcessJSON.py $USERNAME $PASSWORD keyfile=$KEYSFILE $urlString utilization $utilizationFile)
logger $LINENO "utilization=$utilization (%)"

if [ $utilization -ge $STARTTHRESHOLD ]; then
	while true
	do
		# download package
		logger $LINENO "Start auditFetch"
		./auditFetch.sh $USERNAME $PASSWORD keyfile=$KEYSFILE IWD=$IWD $SIZE >> $(getLogFile)
		logger $LINENO "End auditFetch"

		first=""
		while read csv; do
			data=`echo ${csv} | cut -d"," -f2`
			if [ "$first" = "" -a "$data" != "Timestamp" ]; then
				first=$data
			fi
		done < audit-events.csv
		last=$data

		newfilename="audit_"$first"_"$last".zip"
		mv ArchiveFetchTempFile "$newfilename"
		logger $LINENO "The downloaded audit package file name: $newfilename"

		# verify package
		verifyAudit=$(${0%%IWDAuditManagement.sh}verifyAuditPackage.py audit-events-signed-events-checksum audit-events.csv)
		verifyIDList=$(${0%%IWDAuditManagement.sh}verifyAuditPackage.py audit-events-signed-record-IDs audit-events-record-IDs)

		logger $LINENO "The verification result of audit records: $verifyAudit"
		logger $LINENO "The verification result of audit ID list: $verifyIDList"
		if [ "$verifyAudit" != "$VERIFY_SUCCESS" -o "$verifyIDList" != "$VERIFY_SUCCESS" ]; then
			logger $LINENO "Verification failed: audit record: " $verifyAudit ", ID list: " $verifyIDList;
			break;
		fi

		# delete audit records
		logger $LINENO "Start auditDelete"
		./auditDelete.sh $USERNAME $PASSWORD keyfile=$KEYSFILE IWD=$IWD >> $(getLogFile)
		logger $LINENO "End auditDelete"

		urlString=https://$IWD:9444/audit/archiver/utilization
		utilization=$(${0%%IWDAuditManagement.sh}getDataAndProcessJSON.py $USERNAME $PASSWORD keyfile=$KEYSFILE $urlString utilization $utilizationFile)
		logger $LINENO "utilization=$utilization (%)"

		# cleanup files
		rm audit-events.csv
		rm audit-events-signed-record-IDs
		rm audit-events-signed-events-checksum
		rm audit-events-record-IDs
		rm $utilizationFile

		if [ $utilization -le $ENDTHRESHOLD ]; then
			break;
		fi
	done
fi

# cleanup files
rm $verificationKeyFile
rm $KEYSFILE
