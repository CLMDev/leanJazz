IBM Workload Deployer Command-Line Interface README

This file contains additional information about the Workload
Deployer command-line interface that is not included in the online
documentation.

For a complete set of documentation, please refer to the online
documentation available when the command-line interface is run in
interactive mode:

   $ bin/deployer
   >>> help

or:

   C:\> bin\deployer.bat
   >>> help

or visit the online documentation at:

   http://publib.boulder.ibm.com/infocenter/worlodep/v3r0m0/index.jsp



Known issues

Issue:
   The command-line interface reports various SSL or HTTPS exceptions
   when trying to connect to a Workload Deployer appliance.

Cause:
   The SSL mechanisms that the command-line interface uses to communicate
   securely with the appliance were not available in older versions of
   the Java Runtime Environment (JRE).

Resolution:
   Be sure you are using a current version of the JRE to run the
   command-line interface.  If you are using a JRE provided by IBM, it
   must be Java 6 SR3 or later to properly support SSL communications
   with the appliance.  You can determine the level of your JRE by
   executing the following command:

      java -version
