"""
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2012. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
"""

from commonattrs import CommonAttributes
from deployer import utils, validators
from relationships import RelatedResource, RelatedResourceCollection


@utils.classinit
class IPGroup(RelatedResource, CommonAttributes):
    'RM09110'


    @classmethod
    def _classinit(cls):
        cls._registerURI(r'\A/resources/subnets/(?P<id>\d+)\Z')

        cls._defineRESTAttribute('created', 'RM09245', readonly=True)
        cls._defineRESTAttribute('id', 'RM09246', readonly=True)
        cls._defineRESTAttribute('gateway', 'RM09247', validator=validators.allipaddress)
        cls._defineRESTAttribute('name', 'RM09248', validator=validators.string)
        cls._defineRESTAttribute('netmask', 'RM09249', visible= [lambda ipgroup: ipgroup.netmask != ""])
        cls._defineRESTAttribute('primarydns', 'RM09250', validator=validators.allipaddress)
        # protocol - hidden
        cls._defineRESTAttribute('secondarydns', 'RM09252', validator=validators.optionalipaddress)
        cls._defineRESTAttribute('subnetaddress', 'RM09244', restname='address', validator=validators.allipaddress)
        cls._defineRESTAttribute('updated', 'RM09253', readonly=True)
        cls._defineRESTAttribute('version', 'RM09635', values=('IPv4','IPv6'))

        cls._methodHelp('__contains__', '__delattr__', 'delete', '__eq__',
                        '__hash__', 'isStatusTransient', '__nonzero__',
                        'refresh', '__repr__', '__str__', '__unicode__',
                        'waitFor')


    @classmethod
    def _restname(cls):
        return 'subnet'




@utils.classinit
class IPGroups(RelatedResourceCollection):
    'RM09044'


    @classmethod
    def _classinit(cls):
        cls._contains(IPGroup)
        cls._methodHelp('__contains__', 'create', 'delete', '__delitem__',
                        '__getattr__', '__getitem__', '__iter__',
                        '__len__', 'list', '__lshift__', '__repr__',
                        '__rshift__', '__str__', '__unicode__')


    CREATE_ATTRIBUTES = [
        IPGroup._wizardStep('name', optional=True),
        IPGroup._wizardStep('version'),
        IPGroup._wizardStep('subnetaddress'),
        IPGroup._wizardStep('netmask'),
        IPGroup._wizardStep('gateway'),
        IPGroup._wizardStep('primarydns'),
        IPGroup._wizardStep('secondarydns', optional=True),
    ]



    @classmethod
    def _restname(cls):
        return 'subnets'


    def _create(self, dict):
        # validate subnetaddress ahead of time since we're about to
        # rename it
        ca = utils.find(lambda ca: ca['name'] == 'subnetaddress', self.CREATE_ATTRIBUTES)
        if ca and ca.has_key('validator'):
            ca['validator'](dict['subnetaddress'], 'subnetaddress')

        dict['address'] = dict['subnetaddress']
        del dict['subnetaddress']

        # Support down-level scripts by supplying required version field
        if not dict.has_key('version'):
            dict['version'] = 'IPv4'
        #if no netmask, REST will throw an error (inner database error)
        if dict['version'] == 'IPv6':
           dict['netmask'] = ""
        return super(IPGroups, self)._create(dict, ['address','subnetaddress'])
