"""
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2012. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
"""

from deployer import http, logging, utils
from deployer.messages import message
from deployer.utils import utos
import re
import resource
from   restdict import RESTBackedDict
import urllib


class RESTResource(resource.Resource):
    """A subclass of Resource based on a REST API that sends/receives JSON data.

    A RESTResource is a Resource that stores and retrieves values by
    exchanging JSON maps with a REST API.  It assumes that attribute
    values can be retrieved by sending an HTTP GET to a particular URI
    and that attribute values can be updated by sending an HTTP PUT
    with the changed keys/values to the same URI.
    """


    _URIMAPPINGS_ = {}

    @classmethod
    def classForURI(cls, uri):
        """Returns the subclass of RESTResource associated with a URI.

        If the given URI does not map to any registered class, None is
        returned.
        """

        for regex, reclass in cls._URIMAPPINGS_.iteritems():
            if regex.match(uri):
                return reclass


    @classmethod
    def resourceForURI(cls, uri, attrs=None):
        """Instantiates a subclass of RESTResource for the given URI.

        If attrs are supplied, the resource will be seeded with the provided
        attribute values.
        """

        resClass = cls.classForURI(uri)
        if not resClass:
            logging.debug('ERROR: could not find resource for %s, %s' % (uri, attrs))
            raise ValueError(uri)

        return resClass(uri, attrs)



    _IDGROUPRE = re.compile(r'(.*)\(\?P<id>[^)]*\)(.*)')

    @classmethod
    def _resourceForId(cls, rescls, id, attrs=None):
        """Instantiates a subclass of RESTResource with the given id.
        If attrs are supplied, the resource will be seeded with the provided
        attribute values.
        """

        for k,v in cls._URIMAPPINGS_.iteritems():
            if rescls == v:
                m = cls._IDGROUPRE.match(k.pattern.lstrip('\\A').rstrip('\\Z'))
                if m:
                    return rescls(m.group(1) + str(id) + m.group(2), attrs)

        logging.debug('ERROR: no regular expression to generate %s from id %s, attrs %s' % (rescls, id, attrs))
        raise ValueError(rescls.__name__)


    _DEFAULTRESTATTRS_ = []

    # TODO - get rid of boolean semantics, they suck
    @classmethod
    def _defaultRESTAttrs(cls, allow):
        """Lets subclasses indicate that missing REST attributes
        should be silently defaulted to None rather than raising
        exceptions.

        Arguments

        allow - One of the following values:
           True - attempting to access a missing REST attribute
              will return None.  Deprecated, do not use!
           False - attempting to access a missing REST attribute
              will raise an exception.  Deprecated, do not use!
           <string> - attempting to access a missing REST attribute
              with the specified name will return None.
           [<string>,...] - attempting to access a missing REST attribute
              with any of the specified names will return None.

           Passing strings or lists of strings is cumulative.  Default
           value is False (exception if attribute is missing).
        """

        if isinstance(allow, bool):
            # True -> True, False -> []
            cls._DEFAULTRESTATTRS_ = allow and True or []

        elif isinstance(allow, str):
            cls._defaultRESTAttrs([ allow ])

        elif isinstance(allow, list):
            cls._DEFAULTRESTATTRS_.extend(allow)


    @classmethod
    def _registerURI(cls, regex):
        """Registers a URI-matching regular expression.

        Subclasses should call this method to register regular expressions
        for URIs that they can represent.
        """

        if isinstance(regex, str):
            regex = re.compile(regex)

        cls._URIMAPPINGS_[regex] = cls


    @classmethod
    def _defineRESTAttribute(cls, name, doc, **options):
        """Defines an attribute based on REST data

        The parameters for this method are the same as
        Resource._defineAttribute except as noted below.

        This method accepts the following keyword arguments in
        addition to those accepted by Resource._defineAttribute:

        defaultToNone - indicates if None should be returned if the
           REST attribute is not defined.  Default is False, which
           causes an exception to be raised if the attribute is not
           defined.

        restname - name used for the attribute on the REST API.  Default
           is to use attribute's name.
        """

        if options.has_key('fget'):
            pass
        elif options.get('writeonly', False):
            pass
        elif hasattr(cls, '_get' + utils.capitalize(name)):
            pass
        else:
            options['fget'] = utils.curryMethod(cls._restGetAttr, name)

        if options.has_key('fset'):
            pass
        elif options.get('readonly', False):
            pass
        elif hasattr(cls, '_set' + utils.capitalize(name)):
            pass
        else:
            options['fset'] = utils.curryMethod(cls._restSetAttr, name)

        if options.has_key('fdel'):
            pass
        elif options.get('readonly', False):
            pass
        elif hasattr(cls, '_del' + name.capitalize()):
            pass
        else:
            options['fdel'] = utils.curryMethod(cls._restDelAttr, name)


        if options.get('defaultToNone', False):
            cls._defaultRESTAttrs(name)

        # remember restname for later
        restname = options.get('restname', name)
        try:
            cls._RESTNAMES_[name] = restname
        except AttributeError:
            cls._RESTNAMES_ = { name: restname }


        cls._defineAttribute(name, doc, **options)



    def _restGetAttr(self, name):
        if self.__class__._DEFAULTRESTATTRS_ == True or name in self.__class__._DEFAULTRESTATTRS_:
            return self._restattrs.get(self.__class__._RESTNAMES_[name])
        else:
            return self._restattrs[self.__class__._RESTNAMES_[name]]


    def _restSetAttr(self, name, value):
        self._validate(name, value)
        self._restattrs[self.__class__._RESTNAMES_[name]] = value


    def _restDelAttr(self, name):
        self._restSetAttr(name, None)


    @classmethod
    def _getParams(cls, getparams):
        """Sets additional query parameters to be included on HTTP GET
        operations for this RESTResource class.
        """

        cls._GETPARAMS_ = '?' + urllib.urlencode(getparams)


    @classmethod
    def _restname(cls):
        """Returns the identifier used for this type of resource on
        the REST API.  Return value will be singular and lowercase.
        """

        return utils.englishlc(cls.__name__)



    # public methods

    def __init__(self, uri, attrs=None, munge=None):
        super(RESTResource, self).__init__()
        self.uri = uri

        if hasattr(self.__class__, '_GETPARAMS_'):
            uri += self.__class__._GETPARAMS_

        self._restattrs = RESTBackedDict(uri, initial=attrs, munge=munge)


    def __delattr__(self, name):
        'RM09052'
        super(RESTResource, self).__delattr__(name)


    def delete(self):
        'RM09053'
        http.delete(self.uri)


    def __eq__(self, other):
        'RM09054'
        return isinstance(other, RESTResource) and self.uri == other.uri


    def __hash__(self):
        'RM09055'
        return hash(self.uri)


    def isStatusTransient(self):
        'RM09056'

        ingStates = [
            'RM01000', # Status.INITIALIZING
            'RM01002', # Status.PROCESSING
            'RM01003', # Status.TRANSFERING
            'RM01004', # Status.TRANSFERRED
            'RM01005', # Status.STARTING
            'RM01008', # Status.QUIESCING
            'RM01010', # Status.STOPPING
            'RM01018', # Status.PACKAGING
            'RM01019', # Status.UNPACKAGING
            'RM01024', # Status.DELETING
            'RM01026', # Status.EXPORTING
            'RM01029', # Status.CAPTURING
            'RM01031', # Status.PAUSING
            'RM01032', # Status.RESUMING
            'RM01033', # Status.RESETTING
            'RM01035', # Status.QUEUEING
            'RM01036', # Status.QUEUED
            'RM01037', # Status.DEPLOYING
            'RM01039', # Status.SERVICING
            'RM01042', # Status.TRANSFERING_SERVICE
            'RM01044', # Status.APPLYING_SERVICE
            'RM01047', # Status.ROLLINGBACK_SERVICE
            'RM01049', # Status.COMMITTING_SERVICE
            'RM01052', # Status.EXECUTING_SCRIPTS
            'RM01053'  # Status.TRANSFERING_APPLYING_SERVICE
        ]

        # currentstatus == desiredstatus is never transient
        if hasattr(self, 'desiredstatus') and self.currentstatus == self.desiredstatus:
            return False
        else:
            return self.currentstatus in ingStates

    def isStatusTransientWithDebug(self, debug=False):
        
        if debug and hasattr(self, self._statusField()):
           print getattr(self, self._statusField())
                
        return self.isStatusTransient()
    
    def _statusField(self):
        return 'currentstatus_text'

    def __ne__(self, other):
        return not self.__eq__(other)


    def __nonzero__(self):
        'RM09057'
        return True


    def refresh(self):
        'RM09058'
        self._restattrs.refresh()
        return self


    def waitFor(self, condition=None, maxWait=-1, interval=10, debug=False):
        'RM09374'
        waitForFunc = None
        if not condition:
            condition = utils.waitForCondition
            waitForFunc = utils.curryFunction(condition, self, debug)
        else:
             waitForFunc = utils.curryFunction(condition, self)
            
        utils.waitFor(waitForFunc, maxWait, interval)



class RESTResourceCollection(resource.ResourceCollection):

    def __init__(self, uri=None, **options):
        """Initializes a RESTResourceCollection.

        Arguments

        uri - URI associated with this collection of resources.  Defaults
           to "/resources/<lowercase_class_name>".


        Keyword arguments

        useListAttrs - Boolean value indicating whether attributes
           from a list operation should be used when creating
           resources.  Default is True.
        """

        self.uri = uri or '%s/resources/%s' % (self.__class__._restPrefix(), self.__class__._restname())
        self.options = { 'useListAttrs': True }
        self.options.update(options)



    # private methods

    def _create(self, d, suppressCheck=[]):
        self._checkCreateAttributes(d, suppressCheck)
        json = http.postJSON(self.uri, d)
        return RESTResource.resourceForURI(self._uriForResource(json))

    def _checkCreateAttributes(self, d, suppressCheck=[]):
        if hasattr(self.__class__, 'CREATE_ATTRIBUTES'):
            cas = self.__class__.CREATE_ATTRIBUTES

            for ca in cas:
                if not isinstance(ca, dict):
                    continue

                if ca['name'] in suppressCheck:
                    continue

                if not d.has_key(ca['name']):
                    conditions = ca.get('conditions', [])
                    skipped = utils.any(conditions, lambda condition: not condition(d))
                    if skipped or ca.get('optional', False):
                        continue
                    else:
                        raise ValueError(utils.utos(message('RM09366', ca['name'])))


                if ca.has_key('validator'):
                    ca['validator'](d[ca['name']], ca['name'])

            for k in d:
                if k in suppressCheck:
                    continue

                if not utils.find(lambda ca: ca['name'] == k, cas):
                    raise ValueError(utils.utos(message('RM09367', k)))
    
    def _delete(self, id):
        return self._get(id).delete()


    def _get(self, id):
        return RESTResource.resourceForURI('%s/%s' % (self.uri, id))


    def _list(self, filt = {}):

        # logging.debug(str(utf8filt))
        if filt:
            filt = '?' + utils.objectToQuery(filt)
        else:
            filt = ''

        if self.options['useListAttrs']:
            return [ RESTResource.resourceForURI(self._uriForResource(json), json) for json in http.get('%s%s' % (self.uri, filt)) ]
        else:
            return [ RESTResource.resourceForURI(self._uriForResource(json)) for json in http.get('%s%s' % (self.uri, filt)) ]


    @classmethod
    def _restname(cls):
        """Returns the identifier used for this resource collection on
        the REST API.  Return value will be plural and lowercase.
        """

        return utils.englishlc(cls.__name__)
     
    @classmethod
    def _restPrefix(cls):
        """ return the prefix string before /resources/
        """
        return ""


    def _uriForResource(self, attrs):
        '''Given a set of attributes returned from the server, return the
        URI of the corresponding resource from this collection.
        '''

        return '%s/%s' % (self.uri, attrs['id'])


    def waitFor(self, condition=None, maxWait=-1, interval=10):
        'RM09374'
        # TODO - translate docstring

        if not condition:
            condition = lambda r: not r.isStatusTransient()

        def check():
            return utils.all(self, condition)

        utils.waitFor(check, maxWait, interval)
