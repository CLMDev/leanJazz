#
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2012. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
#
from deployer import http, messages, prettify, utils, validators
from deployer.resources.restresource import RESTResource


@utils.classinit
class Ethernet(object):
    '''RM09388'''
   
    _PROPERTYHELP_ = ['interfaces', 'interface']
     
    @utils.classinit
    class Interface(RESTResource):
        '''RM09389'''
        
        URI = '/resources/appliance/ethernetInterface/%s'


        @classmethod        
        def _classinit(cls):
            cls._defineRESTAttribute('defaultgateway', 'RM09393')
            cls._defineRESTAttribute('defaultipv6gateway', 'RM09393')
            cls._defineAttribute('enabled', 'RM09391')
            cls._defineAttribute('id', 'RM09390', readonly=True)
            cls._defineRESTAttribute('ipaddress', 'RM09392')
            cls._defineRESTAttribute('ipv6address', 'RM09392')
            cls._defineRESTAttribute('mtu', 'RM09394')
            cls._defineRESTAttribute('mode', 'RM09395')


        # defaultgateway attribute

        def _getDefaultgateway(self):
            try:
                return self._restGetAttr('defaultgateway')
            except KeyError:
                return ''
                
        def _getDefaultipv6gateway(self):
            try:
                return self._restGetAttr('defaultipv6gateway')
            except KeyError:
                return ''

        # enabled attribute

        def _getEnabled(self):
            return self._restattrs.get('madminstate') == 'enabled'

        
        def _setEnabled(self, value):
            if self._id.lower() == "mgmt":
                print messages.message('RM09432')
            else:
                self._restattrs['madminstate'] = value and 'enabled' or 'disabled'


        # id attribute

        def _getId(self):
            return self._id


        # ipaddress attribute

        def _getIpaddress(self):
            try:
                return self._restGetAttr('ipaddress')
            except KeyError:
                return ''
                
        def _getIpv6address(self):
            try:
                return self._restGetAttr('ipv6address')
            except KeyError:
                return ''


        def __init__(self, id):
            super(Ethernet.Interface, self).__init__(self.__class__.URI % id)
            self._id = id



    class Interfaces:
        '''RM09396'''
        
        URI = '/resources/appliance/ethernetInterfaces'

        __METHOD_HELP__ = [
            '__contains__', '__getattr__', '__getitem__', '__iter__',
            '__len__', '__repr__', '__str__', '__unicode__'
        ]
        

        def __init__(self):
            self._ifs = [ Ethernet.Interface(i) for i in http.get(self.URI) ]

            
        def __contains__(self, item):
            'RM09013'
            return utils.any(self._ifs, lambda it: it == item)


        def __getattr__(self, name):
            'RM09018'
            if name.startswith('__') and name.endswith('__'):
                raise AttributeError(name)
            return utils.find(lambda intf: intf.id == name, self._ifs)


        def __getitem__(self, key):
            'RM09019'

            # int key -> get by index
            if isinstance(key, int) or isinstance(key, long):
                return self._ifs[key]

            # str key -> defer to __getattr__
            elif isinstance(key, str) or isinstance(key, unicode):
                return self.__getattr__(key)

            raise TypeError('unsupported operand type for __getitem__: %s' % type(key))


        def __iter__(self):
            'RM09020'
            return iter(self._ifs)


        def __len__(self):
            'RM09021'
            return len(self._ifs)


        def __repr__(self):
            'RM09027'
            return utils.utos(unicode(self))


        def __str__(self):
            'RM09026'
            return repr(self)


        def __unicode__(self):
            'RM09026'

            if prettify.enabled:
                return prettify.prettify(self._ifs)
            else:
                return unicode(self._ifs)


    # TODO - suspect this is dead code & the property is what really gets used?
    def interfaces_(self):
        '''RM09396'''
        pass


    @classmethod
    def _classinit(cls):
        cls.interface = cls.Interface
        cls.interfaces = property(cls._getInterfaces, doc=messages.message('RM09396'))


    _interfaces = None

    def _getInterfaces(self):
        if not self._interfaces:
            self._interfaces = Ethernet.Interfaces()
        return self._interfaces
