#
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2012. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
#
"""
Licensed Materials - Property of IBM
IBM WebSphere CloudBurst Appliance (9235-72X)
Copyright IBM Corporation 2011. All Rights Reserved.
US Government Users Restricted Rights - Use, duplication or disclosure
restricted by GSA ADP Schedule Contract with IBM Corp.
"""

import deployer.http as http
import deployer.prettify as prettify
import deployer.utils as utils
import deployer.validators as validators
from   commonattrs import CommonAttributes
from   relationships import RelatedResource, RelatedResourceCollection
from   restresource import RESTResource
import urllib
import purescaleutils

@utils.classinit
class PSInstance(RelatedResource, CommonAttributes):
    'RM31021'
    @classmethod
    def _classinit(cls):
        cls._registerURI(r'\A/resources/pSInstances/(?P<id>[a-zA-Z0-9\.\-\_\/]+)\Z')
        cls._defineRESTAttribute('id', 'RM31024', readonly=True)
        cls._defineRESTAttribute('pureScaleInstanceName', 'RM31025', readonly=True, visible=[ lambda application: application._restattrs.has_key('pureScaleInstanceName') ])
        cls._defineRESTAttribute('pureScaleInstanceDescription', 'RM31026', readonly=True, visible=[ lambda application: application._restattrs.has_key('pureScaleInstanceDescription') ])
        cls._defineRESTAttribute('db2Level', 'RM31027', readonly=True, visible=[ lambda application: application._restattrs.has_key('db2Level') ])
        cls._defineRESTAttribute('pureScaleInstanceSqlType', 'RM31028', readonly=True, visible=[ lambda application: application._restattrs.has_key('pureScaleInstanceSqlType') ])
        cls._defineRESTAttribute('pureScaleInstanceSize', 'RM31029', readonly=True, visible=[ lambda application: application._restattrs.has_key('pureScaleInstanceSize') ])
        cls._defineRESTAttribute('status', 'RM31030', readonly=True, visible=[ lambda application: application._restattrs.has_key('status') ])
        cls._defineRESTAttribute('pureScaleInstanceComposition', 'RM31061', readonly=True, visible=[ lambda application: application._restattrs.has_key('pureScaleInstanceComposition') ])
        cls._defineRESTAttribute('pureScaleInstanceDBQuota', 'RM31062', readonly=True, visible=[ lambda application: application._restattrs.has_key('pureScaleInstanceDBQuota') ])
        cls._methodHelp('__contains__', '__delattr__', '__eq__',
                        '__hash__', 'isStatusTransient', '__nonzero__',
                        'refresh', '__repr__', '__str__', '__unicode__')

    def __init__(self, uri, attrs):
        super(PSInstance, self).__init__(uri, attrs)        


@utils.classinit
class PSInstances(RelatedResourceCollection):
    'RM31022'

    @classmethod
    def _classinit(cls):
        cls._contains(PSInstance)
        cls._methodHelp('list')

    @classmethod
    def _restname(cls):
        return 'pSInstances'