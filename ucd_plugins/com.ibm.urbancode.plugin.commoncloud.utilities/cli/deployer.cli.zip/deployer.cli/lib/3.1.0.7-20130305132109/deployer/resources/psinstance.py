#
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2012. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
#
"""
Licensed Materials - Property of IBM
IBM WebSphere CloudBurst Appliance (9235-72X)
Copyright IBM Corporation 2011. All Rights Reserved.
US Government Users Restricted Rights - Use, duplication or disclosure
restricted by GSA ADP Schedule Contract with IBM Corp.
"""

from deployer import utils, validators, messages,http
from restresource import RESTResource, RESTResourceCollection
from relationships import RelatedResource, RelatedResourceCollection
from envprofile import EnvironmentProfile
from cloud import Cloud
from ipgroup import IPGroup
from commonattrs import CommonAttributes
import deployer
import os
import sys
import urllib
import deployer.http as http
import deployer.prettify as prettify
import purescaleutils

@utils.classinit
class pureScaleInstance(RelatedResource, CommonAttributes):
    'RM32048'
    @classmethod
    def _classinit(cls):
        cls._registerURI(r'\A/resources/pureScaleInstances/(?P<id>[a-zA-Z0-9\.\-\_\/]+)\Z')    
        cls._defaultRESTAttrs(True)
        cls._defineRESTAttribute('pureScaleInstanceSqlType', '', readonly=True, visible=[ lambda application: application._restattrs.has_key('pureScaleInstanceSqlType') ])
        cls._defineRESTAttribute('pureScaleInstanceComposition', 'RM32067', readonly=True, visible=[ lambda application: application._restattrs.has_key('pureScaleInstanceComposition') ])
        cls._defineRESTAttribute('deployment_name', '', readonly=True, visible=[ lambda application: application._restattrs.has_key('deployment_name') ])
        cls._defineRESTAttribute('deployment', 'RM09718', readonly=True, visible=[ lambda application: application._restattrs.has_key('deployment') ])
        cls._defineRESTAttribute('service_registry', '', readonly=True, visible=[ lambda application: application._restattrs.has_key('deployment') ])
        cls._defineRESTAttribute('pureScaleInstanceSize', '', readonly=True, visible=[ lambda application: application._restattrs.has_key('pureScaleInstanceSize') ])
        cls._defineRESTAttribute('start_time', 'RM09722', readonly=True, visible=[ lambda application: application._restattrs.has_key('start_time') ])
        cls._defineRESTAttribute('patterntype', 'RM09887', readonly=True, visible=[ lambda application: application._restattrs.has_key('patterntype') ])
        cls._defineRESTAttribute('maintenance_mode', 'RM09887', readonly=True, visible=[ lambda application: application._restattrs.has_key('maintenance_mode') ])
        cls._defineRESTAttribute('access_rights', 'RM09740', readonly=True, visible=[ lambda application: application._restattrs.has_key('access_rights') ])
        cls._defineRESTAttribute('pureScaleInstanceName', 'RM32066', readonly=True, visible=[ lambda application: application._restattrs.has_key('pureScaleInstanceName') ])
        cls._defineRESTAttribute('pureScaleInstanceDBQuota', '', readonly=True, visible=[ lambda application: application._restattrs.has_key('pureScaleInstanceDBQuota') ])
        cls._defineRESTAttribute('pureScaleInstanceDescription', 'RM32069', readonly=True, visible=[ lambda application: application._restattrs.has_key('pureScaleInstanceDescription') ])
        cls._defineRESTAttribute('databases', '', readonly=True, visible=[ lambda application: application._restattrs.has_key('databases') ])
        cls._defineRESTAttribute('version', '', readonly=True, visible=[ lambda application: application._restattrs.has_key('version') ])
        cls._defineRESTAttribute('app_type', '', readonly=True, visible=[ lambda application: application._restattrs.has_key('app_type') ])
        cls._defineRESTAttribute('MEMBER', '', readonly=True, visible=[ lambda application: application._restattrs.has_key('MEMBER') ])
        cls._defineRESTAttribute('id', 'RM32073', readonly=True, visible=[ lambda application: application._restattrs.has_key('id') ])
        cls._defineRESTAttribute('health', '', readonly=True, visible=[ lambda application: application._restattrs.has_key('health') ])
        cls._defineRESTAttribute('can_restart', '', readonly=True, visible=[ lambda application: application._restattrs.has_key('can_restart') ])
        cls._defineRESTAttribute('CF', '', readonly=True, visible=[ lambda application: application._restattrs.has_key('CF') ])
        cls._defineRESTAttribute('virtual_system', '', readonly=True, visible=[ lambda application: application._restattrs.has_key('virtual_system') ])
        cls._defineRESTAttribute('referenced_services', '', readonly=True, visible=[ lambda application: application._restattrs.has_key('referenced_services') ])
        cls._defineRESTAttribute('appmodel', 'RM09719', readonly=True, visible=[ lambda application: application._restattrs.has_key('appmodel') ])
        cls._defineRESTAttribute('creator', 'RM09705', readonly=True, visible=[ lambda application: application._restattrs.has_key('creator') ])
        cls._defineRESTAttribute('topology', 'RM09725', readonly=True, visible=[ lambda application: application._restattrs.has_key('topology') ])
        cls._defineRESTAttribute('db2Level', '', readonly=True, visible=[ lambda application: application._restattrs.has_key('db2Level') ])
        cls._defineRESTAttribute('leaderIP', '', readonly=True, visible=[ lambda application: application._restattrs.has_key('leaderIP') ])
        cls._defineRESTAttribute('create_time', '', readonly=True, visible=[ lambda application: application._restattrs.has_key('create_time') ])
        cls._defineRESTAttribute('status', 'RM32068', readonly=True, visible=[ lambda application: application._restattrs.has_key('status') ])
        cls._defineRESTAttribute('updatable', 'RM32072', readonly=True, visible=[ lambda application: application._restattrs.has_key('updatable') ])
        cls._defineRESTAttribute('pS_access_rights', '', readonly=True, visible=[ lambda application: application._restattrs.has_key('pS_access_rights') ])
        cls._defineRESTAttribute('app_id', 'RM09721', readonly=True, visible=[ lambda application: application._restattrs.has_key('app_id') ])        
        cls._defineRESTAttribute('can_resume', 'RM32071', readonly=True, visible=[ lambda application: application._restattrs.has_key('can_resume') ])
        cls._defineRESTAttribute('roles', '', readonly=True, visible=[ lambda application: application._restattrs.has_key('roles') ])   
        cls._defineRESTAttribute('instances', '',readonly=True, visible=[ lambda application: application._restattrs.has_key('instances') ])   
        cls._defineRESTAttribute('creator_name', '',readonly=True, visible=[ lambda application: application._restattrs.has_key('creator_name') ]) 
        cls._defineRESTAttribute('role_error', 'RM09717', readonly=True, visible=[ lambda application: application._restattrs.has_key('role_error') ])
        cls._defineRESTAttribute('wldfixpacks', '', readonly=True, visible=[ lambda application: application._restattrs.has_key('wldfixpacks') ]) 
        cls._methodHelp('__contains__', '__delattr__', 'delete', '__eq__',
                        '__hash__', 'isStatusTransient', '__nonzero__',
                        'refresh', '__repr__', '__str__', '__unicode__',
                        'waitFor')

    def __init__(self, uri, attrs):
        super(pureScaleInstance, self).__init__(uri, attrs)

    def delete(self):
       uri = self.uri + "?deleteHistory=true"
       json = http.delete(uri)
       return utils.utos(json)
 
@utils.classinit
class pureScaleInstances(RelatedResourceCollection):
    'RM32048'

    @classmethod
    def _classinit(cls):
        cls._contains(pureScaleInstance)
        cls._methodHelp('create','list', 'get','getpureScaleInstance','maintain','upgrade','resume','wldfixpacks')

    @classmethod
    def _restname(cls):
        return 'pureScaleInstances'

    def _uriForResource(self, attrs):
        return '%s/%s' % (self.uri, attrs['id'])

    def list(self, filt = {}):                            
        'RM32057'                            
        json=http.get('%s' % self.uri) 
        return self._list(utils.stou(filt))                                       
                                        
    def get(self, id):                  
        'RM32052'                              
        return self._get(id)
          
    def create(self, app_id, d):
        'RM32049'
        uri = '/resources/sharedServices/' + app_id + '/pureScaleInstances/'
        if isinstance(d, dict):
           json = http.postJSON(uri, d)
           return utils.utos(json)
        else:
           purescaleutils.inputTypeErrorIndicator()

        if isinstance(d, str): 
            doclose = False
            d = purescaleutils.userInputChecker(d, 'file')
            d = file(d, 'rb')
            doclose = True
            uploadType = purescaleutils.getFileExt(d)
                
            if uploadType == 'json':
                json = http.restChunked(uri, d, 'POST', 'application/json')
                return utils.utos(json)
            else:
                purescaleutils.fileTypeErrorIndicator()
            if doclose:
                d.close()
        else:
            purescaleutils.inputTypeErrorIndicator()
        
    def maintain(self, id):
        'RM32056'
        json = http.putJSON('%s/%s' % (self.uri, id), {"operation": "maintain"})
        return utils.utos(json)        

    def upgrade(self, id):
        'RM32055'
        json = http.putJSON('%s/%s' % (self.uri, id), {"operation":"upgrade"})
        return utils.utos(json)        
        
    def resume(self, id):
        'RM32051'
        json = http.putJSON('%s/%s' % (self.uri, id), {"operation":"resume"})
        return utils.utos(json)    

    def start(self, id):
        ''
        json = http.putJSON('%s/%s' % (self.uri, id), {"type":"instanceStart"})
        return utils.utos(json)  
    
    def stop(self, id):
        ''
        json = http.putJSON('%s/%s' % (self.uri, id), {"type":"instanceStop"})
        return utils.utos(json)          