#
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2012. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
#
"""
Licensed Materials - Property of IBM
IBM WebSphere CloudBurst Appliance (9235-72X)
Copyright IBM Corporation 2011. All Rights Reserved.
US Government Users Restricted Rights - Use, duplication or disclosure
restricted by GSA ADP Schedule Contract with IBM Corp.
"""

import deployer
from deployer import utils, validators, http
from restresource import RESTResource, RESTResourceCollection
from relationships import RelatedResource, RelatedResourceCollection
from commonattrs import CommonAttributes
from deployer.messages import Helpable
import deployer.prettify as prettify
import purescaleutils

@utils.classinit
class MonitoringRole(RelatedResource, CommonAttributes):
    @classmethod
    def _classinit(cls):
        cls._registerURI(r'\A/resources/virtualApplications/[\dabcdef\-]+/monitoring/roles/(?P<id>[\d\w\.\-]+)\Z')
        cls._defineRESTAttribute('role_name', '', readonly=True, visible=[ lambda role: role.role_name != None ])
        cls._defineRESTAttribute('server_name', '', readonly=True, visible=[ lambda role: role.server_name != None ])
        cls._defineRESTAttribute('state', '', readonly=True, visible=[ lambda role: role.state != None ])
        cls._defineRESTAttribute('role_type', '', readonly=True, visible=[ lambda role: role.role_type != None ])
        cls._defineRESTAttribute('pattern_type', '', readonly=True, visible=[ lambda role: role.pattern_type != None ])
        cls._defineRESTAttribute('pattern_version', '', readonly=True, visible=[ lambda role: role.pattern_version != None ])
        cls._defineRESTAttribute('private_ip', '', readonly=True, visible=[ lambda role: role.private_ip != None ])
        cls._methodHelp('getMetrics')
    
    def getMetrics(self, metricType = "all"):
        'RM09777'
        metricType = purescaleutils.userInputChecker(metricType, 'str')
        json = http.get("%s/metrics/%s" % (self.uri, metricType))
        return utils.utos(json)
        
@utils.classinit       
class MonitoringServer(RelatedResource, CommonAttributes): 
    @classmethod
    def _classinit(cls):
        cls._registerURI(r'\A/resources/virtualApplications/[\dabcdef\-]+/monitoring/servers/(?P<id>[\d\w\.\-]+)\Z')
        cls._defineRESTAttribute('deployment_id', '', readonly=True, visible=[ lambda server: server.deployment_id != None ])
        cls._defineRESTAttribute('public_ip', '', readonly=True, visible=[ lambda server: server.public_ip != None ])
        cls._defineRESTAttribute('private_ip', '', readonly=True, visible=[ lambda server: server.private_ip != None ])
        cls._defineRESTAttribute('state', '', readonly=True, visible=[ lambda server: server.state != None ])
        cls._defineRESTAttribute('server_name', '', readonly=True, visible=[ lambda server: server.server_name != None ])
        cls._defineRESTAttribute('availability', '', readonly=True, visible=[ lambda server: server.availability != None ])
        cls._methodHelp('getMetrics')
    
    def getMetrics(self, metricType = "all"):
        'RM09778'
        metricType = purescaleutils.userInputChecker(metricType, 'str')
        json = http.get("%s/metrics/%s" % (self.uri, metricType))
        return utils.utos(json)
      
@utils.classinit
class Monitoring(RelatedResource, CommonAttributes):
    'RM09772'

    @classmethod
    def _classinit(cls):
        cls._registerURI(r'\A/resources/virtualApplications/(?P<id>[\dabcdef\-]+)/monitoring\Z')
        cls._defineRESTAttribute('servers', 'RM09774',   readonly=True, visible=[ lambda monitoring: monitoring.servers != None ])
        cls._defineRESTAttribute('roles', 'RM09775',  readonly=True, visible=[ lambda monitoring: monitoring.roles != None ])
    
    def _getServers(self):
        return [ RESTResource.resourceForURI('%s/servers/%s' % (self.uri, json['server_name']), json) for json in self._restattrs['SERVERS'] ]
    
    def _getRoles(self):
        return [ RESTResource.resourceForURI('%s/roles/%s' % (self.uri, json['role_name']), json) for json in self._restattrs['ROLES'] ]
    
