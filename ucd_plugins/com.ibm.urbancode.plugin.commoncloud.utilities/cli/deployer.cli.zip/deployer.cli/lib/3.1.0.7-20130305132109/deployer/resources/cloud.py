"""
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2012. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
"""

from deployer import http, utils, validators
from commonattrs import CommonAttributes
from relationships import RelatedResource, RelatedResourceCollection
from deployer.messages import message
import sys


@utils.classinit
class Cloud(RelatedResource, CommonAttributes):
    'RM09072'

    @classmethod
    def _classinit(cls):
        cls._registerURI(r'\A/resources/clouds/(?P<id>\d+)\Z')

        cls._defineAttribute('acl', 'RM09456', readonly=True, readonlydoc=False)
        cls._defineRESTAttribute('address', 'RM09469', validator=validators.string, visible=[ lambda cloud: cloud.type == 'manager' ])
        cls._defineAttribute('certificate', 'RM09480', readonly=True, elided=True)
        cls._defineRESTAttribute('certified', 'RM09470', values=('T','F','I'), visible=[ lambda cloud: cloud.type == 'manager' ])
        cls._defineRESTAttribute('created', 'RM09128', readonly=True)
        cls._defineRESTAttribute('currentstatus', 'RM09471', readonly=True)
        cls._defineRESTAttribute('currentstatus_text', 'RM09471', readonly=True)
        cls._defineRESTAttribute('defaultcloud', 'RM09130', readonly=True)
        cls._defineRESTAttribute('deploymentlimit', 'RM09531', validator=validators.nonnegativeinteger, visible=[ lambda cloud: cloud.vendor == 'PowerVM' ])
        cls._defineRESTAttribute('description', 'RM09139', validator=validators.string)
        cls._defineRESTAttribute('id', 'RM09140', readonly=True)
        cls._defineAttribute('linkedclones', 'RM09510', values=(True, False), visible=[ lambda cloud: cloud.vendor == 'ESX' ])
        cls._defineRESTAttribute('name', 'RM09141', validator=validators.string)
        cls._defineAttribute('ospassword', 'RM09472', validator=validators.string, visible=[ lambda cloud: False ])
        cls._defineAttribute('osuserid', 'RM09473', validator=validators.string, visible=[ lambda cloud: False ])
        cls._defineRESTAttribute('overcommitby', 'RM09531', restname='diskovercommit', validator=validators.nonnegativeinteger, visible=[ lambda cloud: cloud.vendor == 'ESX' ])
        cls._defineRESTAttribute('password', 'RM09474', validator=validators.string, visible=[ lambda cloud: cloud.type == 'manager' ])
        cls._defineAttribute('sharedminidisks', 'RM09511', values=(True, False), visible=[ lambda cloud: cloud.vendor == 'zVM' ])
        cls._defineRESTAttribute('type', 'RM09475', readonly=True, readonlydoc=False, values=('manager', None))
        cls._defineRESTAttribute('updated', 'RM09142', readonly=True)
        cls._defineRESTAttribute('userid', 'RM09476', validator=validators.string, visible=[ lambda cloud: cloud.type == 'manager' ])
        cls._defineRESTAttribute('userversion', 'RM09565', validator=validators.version, visible=[ lambda cloud: False ])
        cls._defineRESTAttribute('vendor', 'RM09143', values=('ESX','PowerVM','zVM'))
        cls._defineAttribute('attachvolumes', 'RM09970', readonly=True, values=(True, False))
        cls._defineAttribute('useinternalreserveip', 'RM09971', readonly=True, values=(True, False))
        cls._defineAttribute('useinternalplacement', 'RM09972', readonly=True, values=(True, False))
        cls._defineAttribute('version', 'RM09546', readonly=True, elided=True)

        cls._methodHelp('__contains__', '__delattr__', 'delete', '__eq__',
                        '__hash__', 'isStatusTransient', '__nonzero__',
                        'refresh', '__repr__', '__str__', '__unicode__',
                        'waitFor',
                        'acceptCertificate', 'discover')


    def _create(self, dict):
        # Remove deprecated fields
        del dict['osuserid']
        del dict['ospassword']
        del dict['userversion']

        return super(Cloud, self)._create(dict)


    def _getCertificate(self):
        json = http.get('%s?certificate=true' % self.uri)
        return '\n'.join(json['certificates'])


    def _getDefaultcloud(self):
        return self._restattrs['defaultcloud'] == 'T'


    def _getLinkedclones(self):
        return self._restattrs['thinservers'] == 'T'


    def _setLinkedclones(self, enabled):
        self._restattrs['thinservers'] = enabled and 'T' or 'F'

    def _getAttachvolumes(self):
        return self._restattrs['attachvolumes'] == 'T'

    def _getUseinternalreserveip(self):
        return self._restattrs.get('useinternalreserveip') == 'T'

    def _getUseinternalplacement(self):
        return self._restattrs.get('useinternalplacement') == 'T'

    def _getDeploymentlimit(self):
        return self._restattrs['deploymentlimit']


    def _setDeploymentlimit(self, limit):
        self._restattrs['deploymentlimit'] = limit


    def _getOspassword(self):
        # attribute deprecated in 2.0.0.2.  Return replacing attribute
        print >>sys.stderr, utils.utos(message('RM09617', 'ospassword', 'cloud', '2.0.0.2'))
        return self._restattrs['password']


    def _setOspassword(self, passwd):
        # attribute deprecated in 2.0.0.2, ignore it
        print >>sys.stderr, utils.utos(message('RM09617', 'ospassword', 'cloud', '2.0.0.2'))
        print >>sys.stderr, utils.utos(message('RM09618', 'ospassword', 'cloud'))


    def _getOsuserid(self):
        # attribute deprecated in 2.0.0.2.  Return replacing attribute
        print >>sys.stderr, utils.utos(message('RM09617', 'osuserid', 'cloud', '2.0.0.2'))
        return self._restattrs['userid']


    def _setOsuserid(self, user):
        # attribute deprecated in 2.0.0.2, ignore it
        print >>sys.stderr, utils.utos(message('RM09617', 'osuserid', 'cloud', '2.0.0.2'))
        print >>sys.stderr, utils.utos(message('RM09618', 'osuserid', 'cloud'))


    def _getUserversion(self):
        # attribute deprecated in 3.0.0.0.  Return replacing attribute
        print >>sys.stderr, utils.utos(message('RM09617', 'userversion', 'cloud', '3.0.0.0'))


    def _setUserversion(self, user):
        # attribute deprecated in 3.0.0.0, ignore it
        print >>sys.stderr, utils.utos(message('RM09617', 'userversion', 'cloud', '3.0.0.0'))
        print >>sys.stderr, utils.utos(message('RM09618', 'userversion', 'cloud'))


    def _getSharedminidisks(self):
        return self._restattrs['thinservers'] == 'T'


    def _setSharedminidisks(self, enabled):
        self._restattrs['thinservers'] = enabled and 'T' or 'F'


    def _getVersion(self):
        ver = http.get('/resources/clouds/%s/cloudversion' % self.id)
        if (len(ver) > 0):
            return ver
        else:
            return


    def acceptCertificate(self,  optin='T'):
        'RM09743'
        if optin == 'T':
            http.putJSON(self.uri, { 'certified': 'T' })
        else:
            http.putJSON(self.uri, { 'certified': 'T', 'nooptin': 'T' })

        self.refresh()


    def discover(self, optin='T'):
        # TODO - help text borrowed from Hypervisor.discover, replace
        'RM09076'
        if optin == 'T':
            http.get(self.uri + '?discover=true')
        else:
            http.get(self.uri + '?discover=true&nooptin=true')




@utils.classinit
class Clouds(RelatedResourceCollection):
    'RM09028'

    @classmethod
    def _classinit(cls):
        cls._contains(Cloud)
        cls._methodHelp('__contains__', 'create', 'delete', '__delitem__',
                        '__getattr__', '__getitem__', '__iter__',
                        '__len__', 'list', '__lshift__', '__repr__',
                        '__rshift__', '__str__', '__unicode__')


    def _forceTypeForPowerVM(answers):
        if answers['vendor'] == 'PowerVM':
            answers['type'] = 'manager'
            return False
        else:
            return True


    CREATE_ATTRIBUTES = [
        Cloud._wizardStep('name'),
        Cloud._wizardStep('description', optional=True),
        Cloud._wizardStep('vendor'),
        Cloud._wizardStep('type', optional=True, conditions=[ _forceTypeForPowerVM, lambda answers: answers['vendor'] == 'ESX' ]),
        Cloud._wizardStep('address', conditions=[ lambda answers: answers.get('type', None) == 'manager' ]),
        Cloud._wizardStep('userid', conditions=[ lambda answers: answers.get('type', None) == 'manager' ]),
        Cloud._wizardStep('password', conditions=[ lambda answers: answers.get('type', None) == 'manager' ])
    ]
