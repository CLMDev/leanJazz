"""
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2012. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
"""

import restresource
from deployer.utils import isSparta

# dummy placeholder for docstring, not used by real code
class Resource(restresource.RESTResource):
    'RM09137'
    pass

# dummy placeholder for docstring, not used by real code
class ResourceCollection(restresource.RESTResourceCollection):
    'RM09138'
    pass

from addon_ui import ADDON_UI
from acl import ACL
from addon import AddOn, AddOns
from cloud import Cloud, Clouds
from envprofile import EnvironmentProfile, EnvironmentProfiles
from epclouds import EnvironmentProfileCloud, EnvironmentProfileClouds, EnvironmentProfileCloudIPGroup, EnvironmentProfileCloudIPGroups
from fix import Fix, Fixes
from group import Group, Groups
from hypervisor import Hypervisor, Hypervisors
from ip import IP, IPs
from ipgroup import IPGroup, IPGroups
from maintenance import Maintenance, Maintenances
from network import Network, Networks
from part import Part, Parts
from pattern import Pattern, Patterns
from ppart import Ppart, Pparts
from pscript import Pscript, Pscripts
from script import Script, Scripts
from snapshot import Snapshot, Snapshots
from storage import Storage, Storages
from task import Task, Tasks
from user import User, Users
from virtualimage import VirtualImage, VirtualImages
from virtualappliance import VirtualAppliance, VirtualAppliances
from virtualapplianceinstance import VirtualApplianceInstance, VirtualApplianceInstances
from virtualmachine import VirtualMachine, VirtualMachines
from virtualsystem import VirtualSystem, VirtualSystems
from virtualsystem import VirtualSystem, VirtualSystems
from tsam import Tsam, Tsams


# relationships

# cloud resources
Cloud._hasMany(Hypervisors, doc='RM09300')
Cloud._belongsTo(User, attrname='owner', readonly=True, doc='RM09478')
# TODO - VirtualSystem/VirtualMachine nesting prevents this from working
# Cloud._hasMany(VirtualMachines)

Hypervisor._belongsTo(Cloud, doc='RM09301')
Hypervisor._hasMany(Networks, doc='RM09303')
Hypervisor._manyManyLinksTo(Storages, attrname='storage', doc='RM09302')
# TODO - VirtualSystem/VirtualMachine nesting prevents this from working
# Hypervisior._hasMany(VirtualMachines)

IP._containedBy(IPGroup, doc='RM09304')
# TODO - VirtualSystem/VirtualMachine nesting prevents this from working
# IP._hasMany(VirtualMachines)

IPGroup._hasMany(Networks, doc='RM09309')
IPGroup._contains(IPs, doc='RM09308')

Network._belongsTo(Hypervisor, doc='RM09305')
Network._belongsTo(IPGroup, restattrname='subnet', doc='RM09306')

Storage._manyManyLinksTo(Hypervisors, doc='RM09307')

# catalog resources

AddOn._belongsTo(User, attrname='owner', readonly=True, doc='RM09671')

EnvironmentProfile._belongsTo(User, attrname='owner', readonly=True, doc='RM09559')

# TODO - this is NOT a hasmany relationship...suspect Maintenance needs a
# special attribute to list the fixes in it and their status
# define fixes attribute in Maintenance class
#Maintenance._hasMany(Fixes, doc='RM09464')

Part._belongsTo(VirtualImage, restattrname='template', readonly=True, doc='RM09315')
#Part._belongsTo(User, attrname='owner', readonly=True, doc='RM09316')

Pattern._contains(Pparts, attrname='parts', doc='RM09317')
Pattern._belongsTo(User, attrname='owner', readonly=True, doc='RM09319')
Pattern._hasMany(VirtualSystems, doc='RM09318')

Ppart._containedBy(Pattern, doc='RM09320')
Ppart._contains(Pscripts, attrname='scripts', doc='RM09321')
# done with custom logic to handle constraints data structure
# Ppart._belongsTo(VirtualImage, doc='RM09455')

Pscript._containedBy(Ppart, attrname='part', doc='RM09322')

Script._belongsTo(User, attrname='owner', readonly=True, doc='RM09313')

# done with custom attribute logic
# VirtualImage._hasMany(Parts, doc='RM09310')

VirtualImage._belongsTo(User, attrname='owner', readonly=True, doc='RM09311')
VirtualAppliance._belongsTo(User, attrname='owner', readonly=True, doc='RM09311')
VirtualApplianceInstance._belongsTo(User, attrname='owner', readonly=True, doc='RM09311')

# TODO - lack of searchable templateid attribute in pattern prevents this
# from working
# VirtualImage._hasMany(Patterns)?

# TODO - VirtualSystem/VirtualMachine nesting prevents this from working
# VirtualImage._hasMany(VirtualMachines)

# TODO - Ppart <-> Part?
# TODO - Pattern <-> Script


# virtual system resources

Snapshot._containedBy(VirtualSystem, doc='RM09323')

VirtualMachine._containedBy(VirtualSystem, doc='RM09328')
VirtualMachine._belongsTo(Cloud, doc='RM09329')
VirtualMachine._belongsTo(Hypervisor, doc='RM09852')
VirtualMachine._belongsTo(VirtualImage, restattrname='template', doc='RM09332')

VirtualSystem._belongsTo(EnvironmentProfile, doc='RM09562')
VirtualSystem._contains(Maintenances, doc='RM09466')
VirtualSystem._belongsTo(Pattern, doc='RM09324')
VirtualSystem._contains(Snapshots, doc='RM09325')
VirtualSystem._belongsTo(User, attrname='owner', readonly=True, doc='RM09327')
VirtualSystem._contains(VirtualMachines, doc='RM09326')


# appliance resources


Group._manyManyLinksTo(Users, doc='RM09339', listfilter=lambda user: user._restattrs['isinternal'] == 0)
Group._belongsTo(User, attrname='owner', readonly=True, doc='RM09340')

User._hasMany(AddOns, ownedattrname='owner', doc='RM09672')
User._hasMany(Clouds, ownedattrname='owner', doc='RM09479')
User._hasMany(EnvironmentProfiles, ownedattrname='owner', doc='RM09558')
User._hasMany(Groups, attrname='groupsowned', ownedattrname='owner', doc='RM09639')
User._manyManyLinksTo(Groups, doc='RM09338')
#User._hasMany(Parts, ownedattrname='owner', doc='RM09333')
User._hasMany(Patterns, ownedattrname='owner', doc='RM09334')
User._hasMany(Scripts, ownedattrname='owner', doc='RM09335')
User._hasMany(VirtualImages, ownedattrname='owner', doc='RM09336')
User._hasMany(VirtualAppliances, ownedattrname='owner', doc='RM09336')
User._hasMany(VirtualApplianceInstances, ownedattrname='owner', doc='RM09336')
User._hasMany(VirtualSystems, ownedattrname='owner', doc='RM09337')

#*===================================================================
# purescale additions
#*===================================================================
if isSparta():
    from dbapplication import DBApplication, DBApplications
    from dboperation import DBOperation, DBOperations
    from dbgroup import Dbgroup , Dbgroups
    from psinstance import pureScaleInstance, pureScaleInstances
    from instgroup import instgroup, instgroups
    from instuser import instuser, instusers

from application import Application, Applications
from artifact import Artifact, Artifacts
from virtualapplication import VirtualApplication, VirtualApplications
from plugin import Plugin, Plugins
from operation import Operation, Operations
from monitoring import Monitoring
from logging import Logging
from sharedservice import SharedService, SharedServices
from component import Component, Components
from database import Database, Databases
from dbimage import Dbimage , Dbimages
from dbuser import Dbuser , Dbusers
from dbworkload import DatabaseWorkload, DatabaseWorkloads
from workloadfile import WorkloadFile, WorkloadFiles
from patterntype import PatternType, PatternTypes
from deploysetting import DeploySettings
if not isSparta():
    from db2fixpack import DB2FixPack, DB2FixPacks
    from db2fixpackfile import DB2FixpackFile, DB2FixpackFiles
from psdbimage import PSDatabaseImage, PSDatabaseImages
from psdbworkload import PSDatabaseWorkload, PSDatabaseWorkloads
from psinstanceforas import PSInstance, PSInstances
from psdatabase import PSDatabase, PSDatabases

# pureScale resources
if isSparta():
    Database._contains(DBOperations, attrname='dboperations', doc='RM09890')
    DBOperation._containedBy(Database, doc='RM09891')
    Database._contains(Dbgroups, attrname='dbgroups', doc='RM09733')
    Dbgroup._containedBy(Database, doc='RM09734')
    pureScaleInstance._contains(instgroups, attrname='instgroups', doc='RM09733')
    instgroup._containedBy(pureScaleInstance, doc='RM09734')
    pureScaleInstance._contains(instusers, attrname='instusers', doc='RM09733')
    instuser._containedBy(pureScaleInstance, doc='RM09734')
    

Application._contains(Artifacts, attrname='artifacts', doc='RM09733')
Artifact._containedBy(Application, doc='RM09734')
SharedService._contains(Artifacts, attrname='artifacts', doc='RM09888')
Artifact._containedBy(SharedService, doc='RM09889')
VirtualApplication._contains(Operations, attrname='operations', doc='RM09890')
Operation._containedBy(VirtualApplication, doc='RM09891')

DatabaseWorkload._contains(WorkloadFiles, attrname='workloadfiles', doc='RM09733')
WorkloadFile._containedBy(DatabaseWorkload, doc='RM09734')

if not isSparta():
    DB2FixPack._contains(DB2FixpackFiles, attrname='db2fixpackfiles', doc='RM09733')
    DB2FixpackFile._containedBy(DB2FixPack, doc='RM09734')

if isSparta():
    Database._contains(Dbusers, attrname='dbusers', doc='RM09733')
    Dbuser._containedBy(Database, doc='RM09734')
else:
    VirtualApplication._contains(Dbusers, attrname='dbusers', doc='RM09733')
    Dbuser._containedBy(VirtualApplication, doc='RM09734')