#
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2012. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
#
from deployer.resources.restresource import RESTResource
from deployer.resources.relationships import RelatedResource, RelatedResourceCollection
from deployer import utils, http, validators
from community import Community, Communities
from snmp import SNMP

snmp = SNMP()

@utils.classinit
class TrapSubscriber(RelatedResource):
    'RM10018'
    
    URI = '/resources/appliance/trapSubscribers'
    @classmethod
    def _classinit(cls):
         cls._registerURI(r'\A/resources/appliance/trapSubscribers/(?P<name>.+)\Z')
         cls._defineRESTAttribute('Host', 'RM10020', readonly=True)
         cls._defineRESTAttribute('Port', 'RM10021', readonly=True)
         cls._defineRESTAttribute('Community', 'RM10022', readonly=True)
         cls._defineRESTAttribute('TrapVersion', 'RM10023', readonly=True, values=('1', '2c'))
    
    def delete(self):
        subscribers = http.get(self.URI)
        json = utils.findAll(lambda r: r['Host'] != self.Host or r['Port'] != self.Port or r['Community'] != self._restattrs['Community'] , subscribers)
        http.putJSON(self.URI, json)
        #Restart the SNMP agent so that it knows the change
        enabled = snmp.enabled
        if enabled:
            snmp.enabled = True
        
    def _getCommunity(self):
        return Communities()[self._restattrs['Community']][0]
          
   
         
         
@utils.classinit
class TrapSubscribers(RelatedResourceCollection):
    'RM10019'
    CREATE_ATTRIBUTES = [
        TrapSubscriber._wizardStep('Host'),
        TrapSubscriber._wizardStep('Port'),
        TrapSubscriber._wizardStep('Community', validator=lambda x, y: validators.instance(Community, x, y)),
        TrapSubscriber._wizardStep('TrapVersion', values=['1', '2c'])
    ]
    
    #change the return codes, since there is no REST for GET /resources/communities/<name>
    def _create(self, d, suppressCheck=[]):
       
        self._checkCreateAttributes(d, suppressCheck)
        d['Community'] = d['Community'].name
        
        subscribers = http.get(self.uri)
        subscribers.append(d)
        result = http.putJSON(self.uri, subscribers)
        json = utils.find(lambda r: r['Host'] == d['Host'] and r['Port'] == d['Port'] and r['Community'] == d['Community'] , result)
        #Restart the SNMP agent so that subscriber is immediately usable
        enabled = snmp.enabled
        if enabled:
            snmp.enabled = True
        return RESTResource.resourceForURI(self._uriForResource(json), json)
    
    @classmethod
    def _restname(cls):
        return "appliance/trapSubscribers"
    
    def _defaultSearch(self, s):
        result = self._list()
        result = utils.findAll(lambda subscriber: subscriber.Host == s, result)
        return result 
    
    @classmethod
    def _classinit(cls):
        cls._contains(TrapSubscriber)
        cls._methodHelp('create')
        
    def _uriForResource(self, attrs):
        return '%s/%s' % (self.uri, attrs['Host'] + "#" + attrs['Port'] + "#" + attrs['Community'])  