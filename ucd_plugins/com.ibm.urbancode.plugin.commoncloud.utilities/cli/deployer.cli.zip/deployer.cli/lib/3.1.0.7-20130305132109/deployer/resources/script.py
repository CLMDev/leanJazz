"""
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2012. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
"""

import deployer
from deployer import http, prettify, utils, validators
from deployer.messages import Helpable
from deployer.utils import utos
from commonattrs import CommonAttributes
import os
from relationships import RelatedResource, RelatedResourceCollection
from scriptutil import ScriptLike


@utils.classinit
class Script(RelatedResource, CommonAttributes, ScriptLike):
    'RM09097'


    @classmethod
    def _classinit(cls):
        cls._registerURI(r'\A/resources/scripts/(?P<id>\d+)\Z')

        cls._defineAttribute('acl', 'RM09214', readonly=True, readonlydoc=False)
        cls._defineAttribute('archive', cls.Archive.__doc__, readonly=True)
        cls._defineRESTAttribute('command', 'RM09215', validator=validators.string)
        cls._defineRESTAttribute('commandargs', 'RM09216', validator=validators.string)
        cls._defineRESTAttribute('created', 'RM09217', readonly=True)
        # currenteditionid - hidden
        # currentmessage - hidden
        cls._defineRESTAttribute('currentstatus', 'RM09220', values=('RM01027','RM01028'))
        cls._defineAttribute('currentstatus_text', 'RM09156', readonly=True)
        cls._defineRESTAttribute('description', 'RM09221', validator=validators.string)
        cls._defineAttribute('environment', cls.Environment.__doc__, readonly=True)
        cls._defineRESTAttribute('execmode', 'RM09564', values=(0,1,2))
        cls._defineRESTAttribute('id', 'RM09222', readonly=True)
        # ispublic - hidden
        cls._defineRESTAttribute('label', 'RM09503', readonly=True)
        cls._defineRESTAttribute('location', 'RM09224', validator=validators.string)
        cls._defineRESTAttribute('log', 'RM09225', validator=validators.string)
        # maintenance - hidden
        cls._defineRESTAttribute('name', 'RM09227', validator=validators.noop)
        # resourcetype - hidden
        cls._defineRESTAttribute('timeout', 'RM09229', validator=validators.nonnegativeinteger)
        # type - hidden
        cls._defineRESTAttribute('updated', 'RM09231', readonly=True)
        cls._defineRESTAttribute('version', 'RM09982', readonly=True, defaultToNone=True)
        cls._defineRESTAttribute('filename', 'RM09156', readonly=True, defaultToNone=True)

        cls._methodHelp('__contains__', '__delattr__', 'delete', '__eq__',
                        '__hash__', 'isStatusTransient', '__nonzero__',
                        'refresh', '__repr__', '__str__', '__unicode__',
                        'waitFor',
                        'clone', 'isDraft', 'isReadOnly', 'makeReadOnly')


    VIRTUAL_SYSTEM_CREATION_EXECMODE = 0
    VIRTUAL_SYSTEM_DELETION_EXECMODE = 1
    USER_INITIATED_EXECMODE = 2


    @utils.classinit
    class Archive(ScriptLike._Archive):
        'RM09098'


        @classmethod
        def _classinit(cls):
            # really should use super() here, but can't because this class
            # won't have a name until Script is defined
            ScriptLike._Archive._subclassinit(cls)

            cls._methodHelp('__lshift__', '__rshift__')


        def get(self, f):
            'RM09099'
            super(Script.Archive, self).get(f)


        def __lshift__(self, other):
            'RM09100'
            return self.set(other)


        def __rshift__(self, other):
            'RM09101'
            return self.get(other)


        def set(self, f):
            'RM09102'
            super(Script.Archive, self).set(f)



    class Environment(ScriptLike._Environment):
        'RM09191'




    def isDraft(self):
        'RM09103'
        return self.currentstatus == 'RM01027'


    def isReadOnly(self):
        'RM09104'
        return self.currentstatus == 'RM01028'


    def makeReadOnly(self):
        'RM09105'
        self.currentstatus = 'RM01028'


    def clone(self, name):
        'RM09513'
        return deployer.scripts._create({"name": name, "originalid": self.id})




@utils.classinit
class Scripts(RelatedResourceCollection):
    'RM09041'


    @classmethod
    def _classinit(cls):
        cls._contains(Script)
        cls._methodHelp('__contains__', 'create', 'delete', '__delitem__',
                        '__getattr__', '__getitem__', '__iter__',
                        '__len__', 'list', '__lshift__', '__repr__',
                        '__rshift__', '__str__', '__unicode__')


    CREATE_ATTRIBUTES = [
        Script._wizardStep('name')
    ]


    def _create(self, dict):
        return super(Scripts, self)._create(dict, ['resourcetype', 'type', 'originalid'])
