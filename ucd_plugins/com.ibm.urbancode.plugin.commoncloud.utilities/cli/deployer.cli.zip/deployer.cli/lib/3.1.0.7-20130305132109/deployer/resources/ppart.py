"""
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2012. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
"""

from commonattrs import CommonAttributes
import deployer
from deployer import http, utils, validators
from deployer.messages import message, Helpable
from pattern import Patterns
from relationships import RelatedResource, RelatedResourceCollection
from restresource import RESTResource


@utils.classinit
class Ppart(RelatedResource, CommonAttributes):
    'RM09091'


    @classmethod
    def _classinit(cls):
        cls._registerURI(r'\A/resources/patterns/\d+/pparts/(?P<id>\d+)\Z')
        cls._getParams({ 'properties': 'true' })

        # info verified with Michael Kalantar/Bill Arnold, 2009Apr03 2:40pm
        cls._defineRESTAttribute('count', 'RM09353', restname='memberCount', validator=validators.positiveinteger)
        cls._defineRESTAttribute('countLocked', 'RM09454', restname='elasticDisabled', validator=validators.boolean)
        cls._defineRESTAttribute('description', 'RM09202', validator=validators.string)
        # hypervisorType - hidden for now, semantics are different than other similar attrs
        cls._defineRESTAttribute('id', 'RM09203', readonly=True)
        # links - hidden
        cls._defineRESTAttribute('partCaption', 'RM09204', readonly=True)
        # partType - hidden until we identify a use for it
        # partDescriptiveName - hidden
        # possibleLinks - hidden
        cls._defineAttribute('properties', 'RM09205', readonly=True)
        cls._defineAttribute('startsafter', 'RM09792', elided=True)
        cls._defineRESTAttribute('startuporder', 'RM09206', validator=validators.integer)
        cls._defineAttribute('validations', 'RM09538', readonly=True)
        cls._defineAttribute('virtualimage', 'RM09455', elided=True)
        cls._defineAttribute('imagepart', 'RM09984', readonly=True, elided=True)
        #TODO: add messages
        cls._defineRESTAttribute('partType', '', readonly=True, defaultToNone = True)
        cls._defineRESTAttribute('concreteKey', '', readonly=True, restname='key', defaultToNone=True)
        cls._defineRESTAttribute('conceptualKey', '', readonly=True, defaultToNone=True)
        
        cls._methodHelp('__contains__', '__delattr__', 'delete', '__eq__',
                        '__hash__', 'isStatusTransient', '__nonzero__',
                        'refresh', '__repr__', '__str__', '__unicode__',
                        'waitFor',
                        'getProperty', 'setProperty')

   
    def _getImagepart(self):
        partType = self._restattrs.get('partType')
        image = self.virtualimage
        if partType and image:
           return utils.find(lambda r: r.name == partType, image.parts.list({"name": partType}))
        return None

    # count attribute

    def _getCount(self):
        if not self._restattrs.has_key('memberCount'):
            return None

        return self._restGetAttr('count')


    def _setCount(self, value):
        if not self._restattrs.has_key('memberCount'):
            raise AttributeError('count')

        self._restSetAttr('count', value)


    # countlocked attribute

    def _getCountlocked(self):
        if not self._restattrs.has_key('memberCount'):
            return None

        return self._restGetAttr('countLocked')


    def _setCountlocked(self, value):
        if not self._restattrs.has_key('memberCount'):
            raise AttributeError('countLocked')

        self._restSetAttr('countLocked', value)


    # properties attribute

    def _getProperties(self):
        result = []
        for prop in self._restattrs['properties']:
            if prop['propSrc'] == None and (prop['userConfigurable'] == 'true' or prop['locked'] == 'false'):
                # fix string/boolean mismatch
                copy = prop.copy()
                copy['userConfigurable'] = copy['userConfigurable'] == 'true'
                copy['locked'] = copy['locked'] == 'true'
                result.append(copy)

        return result


    # startsAfter attribute
    @utils.classinit
    class StartsAfter(Helpable):
        'RM09791'

        @classmethod
        def _classinit(cls):
            cls._methodHelp('__contains__', '__delitem__', '__getitem__',
                            '__iadd__', 'isDeletable', '__isub__',
                            '__iter__', '__len__',
                            '__lshift__', '__repr__', '__rshift__',
                            '__str__', '__unicode__')


        def __init__(self, ppart):
            self.ppart = ppart

        # private methods

        def _anyLink(self, l):
            return utils.any(self._links(), l) or utils.any(self._oclinks(), l)

 
        def _checkPpart(self, pp):
            return isinstance(pp, Ppart) and pp.pattern == self.ppart.pattern

        #ignore these links whose impliesOrder is false
        def _links(self):
            return [link for link in self.ppart._restattrs['links'] if link.get('impliesOrder', True) != False]


        def _oclinks(self):
            return self.ppart._restattrs['orderingConstraintlinks']


        def _ppart(self, id):
            return RESTResource.resourceForURI('%s/%d' % (self.ppart.uri[:self.ppart.uri.rfind('/')], id))


        # public methods

        def __contains__(self, item):
            'RM09798'

            if not self._checkPpart(item):
                return False

            return self._anyLink(lambda link: link['targetPartId'] == item.id)


        def __delitem__(self, key):
            'RM09799'

            validators.integerrange(len(self._links()), len(self._links()) + len(self._oclinks()) - 1, key, 'key')

            newoclinks = list(self._oclinks())
            del newoclinks[key - len(self._links())]
            http.putJSON(self.ppart.uri, { 'orderingConstraintlinks': newoclinks })
            self.ppart._restattrs.markdirty()


        def __getitem__(self, key):
            'RM09800'

            links = self._links()
            validators.integerrange(0, len(links) + len(self._oclinks()), key, 'key')

            if key < len(links):
                return self._ppart(links[key]['targetPartId'])
            else:
                return self._ppart(self._oclinks()[key - len(links)]['targetPartId'])


        def __iadd__(self, other):
            'RM09785'

            if isinstance(other, list):
                for r in other:
                    self.__iadd__(r)

            else:
                if not self._checkPpart(other):
                    raise ValueError(other)

                if not self._anyLink(lambda link: link['targetPartId'] == other.id):
                    http.putJSON(self.ppart.uri, { 'orderingConstraintlinks': self._oclinks() + [ { 'targetPartId': other.id } ] })
                    self.ppart._restattrs.markdirty()

            return self


        def isDeletable(self, other):
            'RM09795'

            if not self._checkPpart(other):
                raise ValueError(other)

            return utils.any(self._oclinks(), lambda link: link['targetPartId'] == other.id)


        def __isub__(self, other):
            'RM09786'

            if isinstance(other, list):
                for r in other:
                    self.__isub__(r)

            else:
                if not self._checkPpart(other):
                    raise ValueError(other)

                newoclinks = [ link for link in self._oclinks() if link['targetPartId'] != other.id ]
                if len(newoclinks) == len(self._oclinks()):
                    raise ValueError(other)

                http.putJSON(self.ppart.uri, { 'orderingConstraintlinks': newoclinks })
                self.ppart._restattrs.markdirty()

            return self


        def __iter__(self):
            'RM09787'

            uriRoot = self.ppart.uri[:self.ppart.uri.rfind('/')]
            result = [ RESTResource.resourceForURI('%s/%d' % (uriRoot, link['targetPartId'])) for link in self._links() + self._oclinks()]

            return iter(result)


        def __len__(self):
            'RM09801'
            return len(self._links()) + len(self._oclinks())


        def __lshift__(self, other):
            'RM09788'
            return self.__iadd__(other)


        def __repr__(self):
            'RM09790'
            return utils.utos(unicode(self))


        def __rshift__(self, other):
            'RM09789'
            return self.__isub__(other)


        def __str__(self):
            'RM09790'
            return repr(self)


        def __unicode__(self):
            'RM09790'
            return unicode(list(self))


    def _getStartsafter(self):
        try:
            return self._startsAfter
        except AttributeError:
            self._startsAfter = Ppart.StartsAfter(self)
            return self._startsAfter


    def _setStartsafter(self, value):
        if value != self._startsAfter:
            raise AttributeError("can't set attribute")


    # validations attribute

    def _getValidations(self):
        validations = self._restattrs['validation']

        for validation in validations:
            validation['status_text'] = message(validation['status'])
            validation['message_text'] = message(validation['message'])

        return validations


    # virtualimage attribute

    def _getVirtualimage(self):
        constraint = utils.find(lambda c: c['type'] == 'VirtualImageEditionIdConstraint', self._restattrs['constraints'])

        if constraint:
            return RESTResource.resourceForURI('/resources/templates/%s' % constraint['virtualImageEditionId'])
        else:
            templateid = self._restattrs.get('templateid', None)
            if templateid:
                return RESTResource.resourceForURI('/resources/templates/%s' % templateid)
            else:
                return None


    def _setVirtualimage(self, vi):
        validators.instance(deployer.virtualimage, vi, 'virtualimage')

        constraints = self._restattrs['constraints'] or []
        constraint = utils.find(lambda c: c['type'] == 'VirtualImageEditionIdConstraint', constraints)

        if constraint:
            constraint['virtualImageEditionId'] = vi.id
        else:
            constraints.append({ 'type': 'VirtualImageEditionIdConstraint', 'virtualImageEditionId': vi.id })

        self._restattrs['constraints'] = constraints


    # public methods

    def getProperty(self, pclass, key, wantMetadata=False):
        'RM09092'

        prop = utils.find(lambda p: p['pclass'] == pclass and p['key'] == key, self._getProperties())

        if wantMetadata:
            return prop
        else:
            return prop['value']


    def setProperty(self, pclass, key, value=None, **metadata):
        'RM09093'

        prop = self.getProperty(pclass, key, True)

        metadata = metadata.copy()

        metadata['pclass'] = pclass
        metadata['key'] = key
        metadata['id'] = prop['id']

        if not metadata.has_key('value'):
            metadata['value'] = value

        # this is just sad...
        if metadata.has_key('userConfigurable'):
            if metadata['userConfigurable']:
                metadata['userConfigurable'] = 'true'
            else:
                metadata['userConfigurable'] = 'false'

        if metadata.has_key('locked'):
            if metadata['locked']:
                metadata['locked'] = 'true'
            else:
                metadata['locked'] = 'false'

        http.putJSON(self.uri, { 'properties': [ metadata ] })
        self.refresh()




def _partChoices(wizard, answers, attrs):
    i = 1
    result = []
    for part in Parts():
        # MJB - fix this
        if part.isConceptual():
            result.append((unicode(i), part.name, part.id))
            i = i + 1

    return result



@utils.classinit
class Pparts(RelatedResourceCollection):
    'RM09037'


    @classmethod
    def _classinit(cls):
        cls._contains(Ppart)
        cls._methodHelp('__contains__', 'create', 'delete', '__delitem__',
                        '__getattr__', '__getitem__', '__iter__',
                        '__len__', 'list', '__lshift__', '__repr__',
                        '__rshift__', '__str__', '__unicode__')


    CREATE_ATTRIBUTES = [
        { 'name': 'id', 'prompt': 'part', 'required': True, 'help': message('RM09219'), 'choices': _partChoices }
    ]


    def _defaultSearch(self, s):
        '''Performs the default search for resources in this collection.'''
        all = self._list()
        value = s.upper()
        result = utils.findAll(lambda p: p.partCaption.upper().find(value) >= 0, all)
        result.sort(lambda p1, p2: utils.exactMatchCmp(p1.partCaption.upper(), p2.partCaption.upper(), value))
        return result


    def _list(self, filt = {}):
        filt['properties'] = 'true'
        return super(Pparts, self)._list(filt)


    def create(self, other):
        'RM09038'

        if isinstance(other, int) or isinstance(other, long):
            return self.create({ 'id': other })

        #support to specify key when creating a ppart
        elif isinstance(other, dict):
            return super(Pparts, self)._create(utils.stou(other), ['key', 'conceptualKey'])
        
        elif isinstance(other, deployer.part):
            # map conceptual part to concrete part
            if other.isConceptual():
                vi = Patterns._getCachedVI(int(self.uri.split('/')[3]))

                # no cached virtual image for pattern
                if vi is None:
                    raise ValueError(message('RM09536'))

                other = vi._findConcretePart(other)

                # virtual image does not realize conceptual part
                if other is None:
                    raise ValueError(message('RM09536'))

            return self.create({ 'id': other.id })

        else:
            return super(Pparts, self).create(other)
