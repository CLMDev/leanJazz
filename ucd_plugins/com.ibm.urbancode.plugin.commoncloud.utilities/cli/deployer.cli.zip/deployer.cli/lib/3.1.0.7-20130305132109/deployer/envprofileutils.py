"""
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2012. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
"""
import matcher
import deployer

def applyEnvironmentProfileToPattern(pattern, ep, d):
    '''Applies a set of environment-profile-related settings to the pparts of a pattern.  Note that pattern is a deserialized JSON object, NOT a Pattern object.'''

    noValueFor = []

    epData = []
    for k in d:
        if isinstance(k, str) or isinstance(k, unicode):
            split = k.split('.')
            epData.append((split, d[k]))

    mpm = matcher.MultiPartMatcher(epData)

    for part in pattern['parts']:
        check = ('part-%d' % part['id'], 'cloud')
        cloud = mpm.valueFor(check)
        if cloud:
            cloud = deployer.mappingutils.getMappingResource(cloud)
            part['cloudid'] = cloud.id
        else:
            noValueFor.append(check)

        numvms = part.get('memberCount', 1)
        numnics = 1 + len([ scr for scr in part['scripts'] if scr['type'] == 'ADDON_NIC' ])

        part['nics'] = []

        for vmnum in xrange(1, numvms+1):
            vmnics = []

            for nicnum in xrange(1, numnics+1):
                nic = {}

                check = ('part-%d' % part['id'], 'vm-%d' % vmnum, 'nic-%d' % nicnum, 'ipgroup')
                ipgroup = mpm.valueFor(check)

                # try legacy part-1.ipgroup = <ipgroup> for built-in nics
                if not ipgroup and nicnum == 1:
                    ipgroup = mpm.valueFor(('part-%d' % part['id'], 'ipgroup'))

                if ipgroup:
                    ipgroup = deployer.mappingutils.getMappingResource(ipgroup)
                    nic['ipgroupid'] = ipgroup.id
                else:
                    noValueFor.append(check)

                if ep.ipsource == 1:
                    check = ('part-%d' % part['id'], 'vm-%d' % vmnum, 'nic-%d' % nicnum, 'ipaddress')
                    ipaddress = mpm.valueFor(check)

                    # try legacy part-1.ipaddress = "1.2.3.4" or
                    # part-1.ipaddress = ["1.2.3.4",...] for built-in nics
                    if not ipaddress and nicnum == 1:
                        x = mpm.valueFor(('part-%d' % part['id'], 'ipaddress'))
                        if x and (isinstance(x, str) or isinstance(x, unicode)):
                            x = [ x ]

                        if x and len(x) >= vmnum:
                            ipaddress = x[vmnum-1]

                    if ipaddress:
                        nic['ipaddress'] = ipaddress
                    else:
                        noValueFor.append(check)

                    check = ('part-%d' % part['id'], 'vm-%d' % vmnum, 'nic-%d' % nicnum, 'hostname')
                    hostname = mpm.valueFor(check)

                    # try legacy part-1.hostname = "foo" or
                    # part-1.hostname = ["foo",...] for built-in nics
                    if not hostname and nicnum == 1:
                        x = mpm.valueFor(('part-%d' % part['id'], 'hostname'))
                        if x and (isinstance(x, str) or isinstance(x, unicode)):
                            x = [ x ]

                        if x and len(x) >= vmnum:
                            hostname = x[vmnum-1]

                    if hostname:
                        nic['hostname'] = hostname

                    # hostname not required

                vmnics.append(nic)

            ipgids = []
            for nic in vmnics:
                if nic.has_key('ipgroupid'):
                    if nic['ipgroupid'] in ipgids:
                        # raise ValueError, "same ipgroup used for multiple NICs in VM"
                        pass
                    ipgids.append(nic['ipgroupid'])

            part['nics'].append(vmnics)

    return noValueFor
