'RM09004'
"""
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2012. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
"""

from climessageresolver import CLIMessageResolver, ExtMessageResolver
import messages

messages.resolvers.append(CLIMessageResolver())
messages.resolvers.append(ExtMessageResolver())


import deployer.cliversion as cliversionx
import deployer.firmware
import deployer.http
import deployer.logging
import deployer.messages
import deployer.resources
import deployer.settings
import deployer.monitoring
import deployer.troubleshooting
import deployer.version as versionx
import java

from deployer.messages import message
from deployer.utils import utos
from deployer.utils import isSparta

# hooks for conceptual doc
from deployer.resources import Resource as resource
from deployer.resources import ResourceCollection as resourcecollection

# profiles
environmentprofile = deployer.resources.EnvironmentProfile
environmentprofiles = deployer.resources.EnvironmentProfiles()
environmentprofilecloud = deployer.resources.EnvironmentProfileCloud
environmentprofileclouds = deployer.resources.EnvironmentProfileClouds
environmentprofilecloudipgroup = deployer.resources.EnvironmentProfileCloudIPGroup
environmentprofilecloudipgroups = deployer.resources.EnvironmentProfileCloudIPGroups

# virtual systems
virtualsystem = deployer.resources.VirtualSystem
virtualsystems = deployer.resources.VirtualSystems()
virtualmachine = deployer.resources.VirtualMachine
virtualmachines = deployer.resources.VirtualMachines
snapshot = deployer.resources.Snapshot
snapshots = deployer.resources.Snapshots

# patterns
pattern = deployer.resources.Pattern
patterns = deployer.resources.Patterns()
part = deployer.resources.Part
parts = deployer.resources.Parts(type='conceptual')
pattern_part = deployer.resources.Ppart
pattern_parts = deployer.resources.Pparts
pattern_script = deployer.resources.Pscript
pattern_scripts = deployer.resources.Pscripts
addon_ui = deployer.resources.ADDON_UI()

# catalog resources
virtualimage = deployer.resources.VirtualImage
virtualimages = deployer.resources.VirtualImages()
virtualappliance = deployer.resources.VirtualAppliance
virtualappliances = deployer.resources.VirtualAppliances()
virtualapplianceinstance = deployer.resources.VirtualApplianceInstance
virtualapplianceinstances = deployer.resources.VirtualApplianceInstances()
script = deployer.resources.Script
scripts = deployer.resources.Scripts()
addon = deployer.resources.AddOn
addons = deployer.resources.AddOns()
fix = deployer.resources.Fix
fixes = deployer.resources.Fixes()
maintenance = deployer.resources.Maintenance
maintenances = deployer.resources.Maintenances()

# cloud resources
ipgroup = deployer.resources.IPGroup
ipgroups = deployer.resources.IPGroups()
ip = deployer.resources.IP
ips = deployer.resources.IPs
hypervisor = deployer.resources.Hypervisor
hypervisors = deployer.resources.Hypervisors()
cloud = deployer.resources.Cloud
clouds = deployer.resources.Clouds()
network = deployer.resources.Network
networks = deployer.resources.Networks()
storage_ = deployer.resources.Storage
storage = deployer.resources.Storages()

# appliance stuff
firmware = deployer.firmware.Firmware()
user = deployer.resources.User
users = deployer.resources.Users()
group = deployer.resources.Group
groups = deployer.resources.Groups()
task = deployer.resources.Task
tasks = deployer.resources.Tasks()
tsam = deployer.resources.Tsam

tsams = deployer.resources.Tsams()

# pd stuff
diagnostics = deployer.troubleshooting.Diagnostics()
trace = deployer.troubleshooting.TraceFile()
errors = deployer.troubleshooting.ErrorFile()
audit = deployer.troubleshooting.Audit()
licpvu = deployer.troubleshooting.LicPVU()
# auditpkg = deployer.troubleshooting.AuditPkg()

security = deployer.settings.security
ilmt = deployer.settings.ilmt
mail = deployer.settings.mail
#backup = bar.Backup
#backups = bar.Backups()
#restore = bar.restore
power = deployer.settings.power
dateandtime = deployer.settings.dateandtime
ethernet = deployer.settings.ethernet
dns = deployer.settings.dns
licenseawareness = deployer.settings.licenseawareness
snmp = deployer.monitoring.snmp
community = deployer.monitoring.community
communities = deployer.monitoring.communities
trapsubscriber =  deployer.monitoring.trapsubscriber
trapsubscribers = deployer.monitoring.trapsubscribers
trap = deployer.monitoring.trap
traps = deployer.monitoring.traps
# wizard
from deployer.wizard import Wizard as wizard

# ACL constants
acl = deployer.resources.ACL
NO_PERMISSIONS = deployer.resources.ACL.NO_PERMISSIONS
READ_PERMISSION = deployer.resources.ACL.READ_PERMISSION
UPDATE_PERMISSION = deployer.resources.ACL.UPDATE_PERMISSION
CREATE_PERMISSION = deployer.resources.ACL.CREATE_PERMISSION
DELETE_PERMISSION = deployer.resources.ACL.DELETE_PERMISSION
ALL_PERMISSIONS = deployer.resources.ACL.ALL_PERMISSIONS

# role constants
CLOUD_USER_ROLE = 'CLOUD_USER'
CLOUD_ADMIN_ROLE = 'CLOUD_ADMIN'
APPLIANCE_ADMIN_ROLE = 'APPLIANCE_ADMIN'
CATALOG_CREATOR_ROLE = 'CATALOG_CREATOR'
PATTERN_CREATOR_ROLE = 'PATTERN_CREATOR'
ILMT_USER_ROLE = 'ILMT_USER'
CLOUD_ADMIN_READONLY_ROLE = 'CLOUD_ADMIN_READONLY'
APPLIANCE_ADMIN_READONLY_ROLE = 'APPLIANCE_ADMIN_READONLY'
PROFILE_CREATOR_ROLE = 'PROFILE_CREATOR'
REPORT_READONLY_ROLE = 'REPORT_READONLY'
AUDIT_READONLY_ROLE = 'AUDIT_READONLY'
AUDIT_ROLE = 'AUDIT'
HARDWARE_ROLE = 'HARDWARE'

# addon type constants
DISK_ADDON = deployer.resources.AddOn.DISK_ADDON
NIC_ADDON = deployer.resources.AddOn.NIC_ADDON
USER_ADDON = deployer.resources.AddOn.USER_ADDON

# convenience method to get current user
_self = None

def self():
    'RM09006'

    global _self

    if not _self:
        _self = users.self()

    return _self


# convenience method to get admin user
_admin = None

def admin():
    'RM09342'

    global _admin

    if not _admin:
        _admin = users.admin()

    return _admin


# convenience method to get Everyone group
_everyone = None

def everyone():
    'RM09007'

    global _everyone

    if not _everyone:
        _everyone = groups.everyone()

    return _everyone


# utility method to wait for things to happen
from deployer.utils import waitFor



# shortcuts
from deployer.shortcuts import exit, help



# CLI version
class _CLIVersioner(object):
    'RM09373'

    def __repr__(self):
        return utos(unicode(self))


    def __unicode__(self):
        return cliversionx.CLI_VERSION

cliversion = _CLIVersioner()



# server version
class _Versioner(object):
    'RM09011'

    def __repr__(self):
        return utos(unicode(self))


    def __unicode__(self):
        try:
            host = deployer.http.host
        except AttributeError:
            host = message('RM09133')

        try:
            version = versionx.getVersion()['version']
        except Exception, e:
            version = message('RM09134')

        return message('RM09135', host, version)

version = _Versioner()



# make data printable
def printable(o):
    """Converts a Python string or unicode object to an equivalent
    object that can be passed to the Python print command.
    """

    return utos(o)

#*===================================================================
# purescale additions
#*===================================================================
if isSparta():
    dbapplication = deployer.resources.DBApplication
    dbapplications = deployer.resources.DBApplications()
    database_operation = deployer.resources.DBOperation
    database_operations = deployer.resources.DBOperations
    dboperation = deployer.resources.DBOperation
    dboperations = deployer.resources.DBOperations()
    dbgroup = deployer.resources.Dbgroup
    dbgroups = deployer.resources.Dbgroups() 
    pureScaleInstance = deployer.resources.pureScaleInstance
    pureScaleInstances = deployer.resources.pureScaleInstances()
    instgroup = deployer.resources.instgroup
    instgroups = deployer.resources.instgroups()
    instuser = deployer.resources.instuser
    instusers = deployer.resources.instusers()


application = deployer.resources.Application
applications = deployer.resources.Applications()
application_artifact = deployer.resources.Artifact
application_artifacts = deployer.resources.Artifacts
virtualapplication = deployer.resources.VirtualApplication
virtualapplications = deployer.resources.VirtualApplications()
plugin = deployer.resources.Plugin
plugins = deployer.resources.Plugins()
monitoring = deployer.resources.Monitoring
#logging = deployer.resources.Logging
virtualapplication_operation = deployer.resources.Operation
virtualapplication_operations = deployer.resources.Operations
sharedservice = deployer.resources.SharedService
sharedservices = deployer.resources.SharedServices()
sharedservice_artifact = deployer.resources.Artifact
sharedservice_artifacts = deployer.resources.Artifacts
component = deployer.resources.Component
components = deployer.resources.Components()
database = deployer.resources.Database
databases = deployer.resources.Databases()
dbimage = deployer.resources.Dbimage
dbimages = deployer.resources.Dbimages()
dbuser = deployer.resources.Dbuser
dbusers = deployer.resources.Dbusers()
dbworkload = deployer.resources.DatabaseWorkload
dbworkloads = deployer.resources.DatabaseWorkloads()
dbworkload_workloadfile = deployer.resources.WorkloadFile
dbworkload_workloadfiles = deployer.resources.WorkloadFiles
if not isSparta():
  db2fixpack = deployer.resources.DB2FixPack
  db2fixpacks = deployer.resources.DB2FixPacks()
  #db2fixpack_db2fixpackfile = deployer.resources.DB2FixpackFile
  #db2fixpack_db2fixpackfiles = deployer.resources.DB2FixpackFiles
patterntype = deployer.resources.PatternType
patterntypes = deployer.resources.PatternTypes()
psdbimage = deployer.resources.PSDatabaseImage
psdbimages = deployer.resources.PSDatabaseImages()
psdbworkload = deployer.resources.PSDatabaseWorkload
psdbworkloads = deployer.resources.PSDatabaseWorkloads()
psinstance = deployer.resources.PSInstance
psinstances = deployer.resources.PSInstances()
psdatabase = deployer.resources.PSDatabase
psdatabases = deployer.resources.PSDatabases()
deploysettings = deployer.resources.DeploySettings()
