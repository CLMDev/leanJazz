"""
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2012. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
"""

from cloud import Cloud
from commonattrs import CommonAttributes
import deployer
from deployer import envprofileutils, http, patternutils, utils, validators
from deployer.messages import message
from deployer.utils import stou, utos
from ipgroup import IPGroup
from relationships import RelatedResource, RelatedResourceCollection
from restresource import RESTResource
from deployer import mappingutils

@utils.classinit
class VirtualSystem(RelatedResource, CommonAttributes):
    'RM09122'


    @classmethod
    def _classinit(cls):
        cls._registerURI(r'\A/resources/instances/(?P<id>\d+)\Z')

        cls._defineAttribute('acl', 'RM09291', readonly=True, readonlydoc=False, elided=True)
        cls._defineRESTAttribute('created', 'RM09292', readonly=True)
        # currentmaintenanceid - hidden
        cls._defineRESTAttribute('currentmessage', 'RM09293', readonly=True)
        cls._defineAttribute('currentmessage_text', 'RM09154', readonly=True)
        cls._defineRESTAttribute('currentstatus', 'RM09294', readonly=True)
        cls._defineAttribute('currentstatus_text', 'RM09156', readonly=True)
        # description - hidden
        cls._defineRESTAttribute('desiredstatus', 'RM09296', values=('RM01006','RM01011','RM01020','RM01030','RM01040','RM01043','RM01058'))
        cls._defineAttribute('desiredstatus_text', 'RM09158', readonly=True)
        cls._defineRESTAttribute('id', 'RM09297', readonly=True)
        # mode -hidden
        cls._defineRESTAttribute('name', 'RM09298', readonly=True, readonlydoc=False)
        # stage -hidden
        cls._defineRESTAttribute('updated', 'RM09299', readonly=True)
        
        if utils.isIPAS():
            cls._defineRESTAttribute('priority', 'IWD12224', readonly=True)

        cls._methodHelp('__contains__', '__delattr__', 'delete', '__eq__',
                        '__hash__', 'isStatusTransient', '__nonzero__',
                        'refresh', '__repr__', '__str__', '__unicode__',
                        'waitFor',
                        'applyFixes', 'applyUpgrade', 'createSnapshot', 
                        'findFixes', 'findUpgrades', 'start', 'stop', 'store')


    @classmethod
    def _restname(cls):
        return 'instance'


    def _findAvailableService(self, type):
        return http.get('%s/fixes' % self.uri)[type]


    # public methods

    def applyFixes(self, fixes, start=0, **options):
        'RM09492'
        
        dict = { 'starttime': start, 'fixes': fixes, 'images': [] }
        if options.has_key('adminusername') and options.has_key('adminpassword'):
            dict.update({'adminusername': options.get('adminusername'), 'adminpassword': options.get('adminpassword')})

        return self.maintenances.create(dict)


    def applyUpgrade(self, image, start=0, **options):
        'RM09493'

        dict = { 'starttime': start, 'images': [image], 'fixes': [] }
        if options.has_key('adminusername') and options.has_key('adminpassword'):
            dict.update({'adminusername': options.get('adminusername'), 'adminpassword': options.get('adminpassword')})
        return self.maintenances.create(dict)


    def createSnapshot(self, dict={}):
        'RM09123'
        return self.snapshots.create(dict)


    def delete(self, deleteRecord=True, ignoreErrors=False):
        'RM09634'

        deleteRecordParam = deleteRecord and 'true' or 'false'
        if utils.isIPAS(): 
            ignoreErrorsParam = ignoreErrors and 'true' or 'false'
        else:
            ignoreErrorsParam = 'false'
        http.delete('%s?delete-virtual-system-record=%s&delete-virtual-system-force=%s' % (self.uri, deleteRecordParam, ignoreErrorsParam))


    def findFixes(self):
        'RM09490'
        return self._findAvailableService('fixes')


    def findUpgrades(self):
        'RM09491'
        return self._findAvailableService('images')


    def start(self):
        'RM09124'
        self.desiredstatus = 'RM01006' # Status.STARTED


    def stop(self):
        'RM09125'
        self.desiredstatus = 'RM01011' # Status.STOPPED


    def store(self):
        'RM09126'
        self.desiredstatus = 'RM01058' # Status.ARCHIVED


def _priorityChoices(wizard, answers, attrs):
    result = [ message('IWD12223') ]
    result.append((unicode(1), 'high', 'high'));
    result.append((unicode(2), 'medium', 'medium'));
    result.append((unicode(3), 'low', 'low'));
    return result

def _patternChoices(wizard, answers, attrs):
    i = 1
    result = []
    for pattern in http.get('/resources/patterns'):
        result.append((unicode(i), pattern['name'], RESTResource.resourceForURI('/resources/patterns/%s' % pattern['id'])))
        i = i + 1

    return result


def _cloudOrEPChoices(wizard, answers, attrs):
    i = 1
    if utils.isIPAS():
        result = [ message('RM09625') ]
    
        header = message('RM09625')
        for ep in deployer.environmentprofiles:
            if ep.currentstatus == 'RM01001':
                result.append((unicode(i), ep.name, ep))
                i = i + 1
    
        return result
    
    # IWD
    result = [ message('RM09561') ]
    vendor = None

    for cloud in http.get('/resources/clouds?patternid=%s' % answers['pattern'].id):
        result.append((unicode(i), cloud['name'], RESTResource.resourceForURI('/resources/clouds/%s' % cloud['id'])))
        vendor = cloud['vendor']
        i = i + 1

    header = message('RM09625')
    for ep in deployer.environmentprofiles:
        if not vendor or ep.platform == vendor:
            if header:
                result.append(header)
                header = None
            if ep.currentstatus == 'RM01001':
                result.append((unicode(i), ep.name, ep))
                i = i + 1

    return result


def _cloudOrEPResolver(wizard, answers):
    if utils.isIPAS():
        answers['environmentprofile'] = answers['cloudorep']
        answers['patternjson'] = patternutils.getPattern(answers['pattern'].uri)
        return
    
    if isinstance(answers['cloudorep'], deployer.cloud):
        answers['cloud'] = answers['cloudorep']
    else:
        answers['environmentprofile'] = answers['cloudorep']

    answers['patternjson'] = patternutils.getPattern(answers['pattern'].uri)


def _epConfigStep(wizard, answers):
    if not answers.has_key('environmentprofile'):
        return

    ep = answers['environmentprofile']

    for part in answers['patternjson']['parts']:
        partid = 'part-%d' % part['id']
        vms = part.get('memberCount', 1)
        nicspervm = 1 + len([ scr for scr in part['scripts'] if scr['type'] == 'ADDON_NIC' ])


        def _epCloudChoices(wizard, answers, attrs):
            i = 1
            result = []

            for cloud in ep.clouds:
                result.append((unicode(i), cloud.name, cloud))
                i = i + 1

            return result


        def _epIPGroupChoices(wizard, answers, attrs):
            i = 1
            result = []

            for ipgroup in ep.clouds[answers['%s.cloud' % partid]].ipgroups:
                result.append((unicode(i), ipgroup.name, ipgroup))
                i = i + 1

            return result


        def _ipGroupFromString(s):
            ipgs = deployer.ipgroups[s]
            
            if len(ipgs) != 1:
                raise ValueError(message('RM09690', s))

            return ipgs[0]


        def _validateIPAddress(o, name):
            try:
                validators.ipaddress(o, name)
            except ValueError:
                validators.ip6address(o, name)


        steps = [
            { 'name': '%s.cloud' % partid,
              'prompt': message('RM09627', partid),
              'help': message('RM09628'),
              'choices': _epCloudChoices,
              #'validator': utils.curryFunction(validators.instance, Cloud)
            }
        ]

        for vm in xrange(0, vms):
            for nic in xrange(0, nicspervm):
                if vms == 1 and nicspervm == 1:
                    insert = partid
                else:
                    insert = message('RM09687', partid, vm+1, vms, nic+1, nicspervm)

                steps.append({
                    'name': '%s.vm-%d.nic-%d.ipgroup' % (partid, vm+1, nic+1),
                    'prompt': message('RM09629', insert),
                    'help': message('RM09630'),
                    'choices': _epIPGroupChoices,
                    #'validator': utils.curryFunction(validators.instance, IPGroup),
                    'fromString': _ipGroupFromString
                })

                if ep.ipsource == 1:
                    steps.append({
                        'name': '%s.vm-%d.nic-%d.ipaddress' % (partid, vm+1, nic+1),
                        'prompt': message('RM09631', insert),
                        'help': message('RM09632'),
                        'validator': _validateIPAddress
                    })
                    steps.append({
                        'name': '%s.vm-%d.nic-%d.hostname' % (partid, vm+1, nic+1),
                        'prompt': message('RM09688', insert),
                        'help': message('RM09689'),
                        'optional': True
                    })

        w = deployer.wizard(suppressWizardHelp=True)
        answers.update(w(*steps))


def _patternConfigStep(wizard, answers):
    pattern = answers['patternjson']

    cfg = {}

    while True:
        remaining = patternutils.listConfig(pattern, cfg)

        rkeys = filter(lambda k: remaining[k] is None, remaining)
        rkeys.sort()

        canProceed = True
        
        if rkeys:
            print utos(message('RM09236'))

            i = 1
            for rkey in rkeys:
                # TODO - this is ugly
                sa = rkey.split('.')
                part = utils.find(lambda p: p['id'] == int(sa[0][5:]), pattern['parts'])

                if sa[1].startswith('script-'):
                    script = utils.find(lambda s: s['id'] == int(sa[1][7:]), part['scripts'])
                    prop = utils.find(lambda s: s['key'] == sa[2], script['parameters'])

                else:
                    prop = utils.find(lambda p: p['pclass'] == sa[1] and p['key'] == sa[2], part['properties'])

                if prop['requiredForDeployment']:
                    print utos(message('RM09233', unicode(i), rkey))
                    canProceed = False
                else:
                    print utos(message('RM09233', unicode(i), rkey) + u'(' + message('RM09354') + u')')

                i = i + 1


            print

        if canProceed:
            prompt = message('RM09274')
        else:
            prompt = message('RM09237')

        try:
            s = stou(raw_input(utos(prompt)).strip())
        except EOFError, e:
            print
            raise e

        if s == '-':
            if not cfg:
                continue

            cfgkeys = cfg.keys()
            cfgkeys.sort()

            print utos(message('RM09235'))
            i = 1
            for k in cfgkeys:
                print utos(message('RM09376', unicode(i), k, cfg[k]))
                i = i + 1
            print

            try:
                s = stou(raw_input(utos(message('RM09375'))).strip())
            except EOFError, e:
                print
                raise e

            try:
                del cfg[cfgkeys[int(s)-1]]
            except:
                print utos(message('RM09234', s))

        elif s == '*':
            if cfg:
                print utos(message('RM09235'))
                for k in cfg:
                    print utos(message('RM09282', k, cfg[k]))
                print

            print utos(message('RM09286'))
            all = patternutils.listConfig(pattern, cfg)
            for k in all:
                if all[k]:
                    print utos(message('RM09282', k, str(all[k])))
                else:
                    print utos(message('RM09282', k, ''))
            print

        elif s == '?':
            print utos(message('RM09238'))

        elif s == '??':
            print utos(message('RM09360'))

        elif s == '!':
            raise EOFError(utos(message('RM09361')))

        elif s:
            try:
                key = rkeys[int(s)-1]
            except:
                key = s

            try:
                s = stou(raw_input(utos(message('RM09288', key))).strip())
            except EOFError, e:
                print
                raise e

            if s:
                cfg[key] = s

        elif canProceed:
            break

    answers.update(cfg)


def _cleanupStep(wizard, answers):
    del answers['cloudorep']
    del answers['patternjson']



@utils.classinit
class VirtualSystems(RelatedResourceCollection):
    'RM09050'


    @classmethod
    def _classinit(cls):
        cls._contains(VirtualSystem)
        cls._methodHelp('__contains__', 'create', 'delete', '__delitem__',
                        '__getattr__', '__getitem__', '__iter__',
                        '__len__', 'list', '__lshift__', '__repr__',
                        '__rshift__', '__str__', '__unicode__')

    if utils.isIPAS():
        CREATE_ATTRIBUTES = [
            VirtualSystem._wizardStep('name'),
            { 'name': 'pattern', 'required': True, 'help': message('RM09290'), 'choices': _patternChoices },
            { 'name': 'cloudorep', 'prompt': message('RM09626'), 'required': True, 'help': message('RM09295'), 'choices': _cloudOrEPChoices },
            { 'name': 'priority', 'prompt': message('IWD12224'), 'required': False, 'help': message('IWD12225'), 'choices': _priorityChoices },
            _cloudOrEPResolver,
            # starttime
            # endtime
            _epConfigStep,
            _patternConfigStep,
            _cleanupStep
        ]
    else:
        CREATE_ATTRIBUTES = [
            VirtualSystem._wizardStep('name'),
            { 'name': 'pattern', 'required': True, 'help': message('RM09290'), 'choices': _patternChoices },
            { 'name': 'cloudorep', 'prompt': message('RM09626'), 'required': True, 'help': message('RM09295'), 'choices': _cloudOrEPChoices },
            _cloudOrEPResolver,
            # starttime
            # endtime
            _epConfigStep,
            _patternConfigStep,
            _cleanupStep
        ]


    @classmethod
    def _restname(cls):
        return 'instances'


    def _create(self, dict):
        dict = mappingutils.getMappingResource(dict)
        pattern = patternutils.getPattern(dict['pattern'].uri)
        pattern['patternid'] = pattern['id']
        pattern['name'] = dict['name']

        if dict.has_key('starttime'):
            pattern['starttime'] = long(dict['starttime'] * 1000)

        if dict.has_key('endtime'):
            pattern['endtime'] = long(dict['endtime'] * 1000)

        if dict.has_key('iptype'):
            pattern['iptype'] = dict['iptype']
        else:
            pattern['iptype'] = 'IPv4'

        if utils.isIPAS():
            if dict.has_key('environmentprofile'):
                pattern['environmentprofileid'] = dict['environmentprofile'].id
    
                missing = envprofileutils.applyEnvironmentProfileToPattern(pattern, dict['environmentprofile'], dict)
    
                if missing:
                    def msgFor(x):
                        return u'environment profile value %s' % '.'.join(x)
    
                    raise ValueError('missing values for:\n  ' + '\n  '.join(map(msgFor, missing)))
                
                if dict.has_key('cloud'):
                    pattern['cloudid'] = dict['cloud'].id
                
                if dict.has_key('priority'):
                    pattern['priority'] = dict['priority']
                else:
                    pattern['priority'] = 'low'
                
            else:
                raise ValueError(message('IWD12221', 'environmentprofile'))

        else:
            if dict.has_key('cloud'):
                pattern['cloudid'] = dict['cloud'].id
    
            elif dict.has_key('environmentprofile'):
                pattern['environmentprofileid'] = dict['environmentprofile'].id
    
                missing = envprofileutils.applyEnvironmentProfileToPattern(pattern, dict['environmentprofile'], dict)
    
                if missing:
                    def msgFor(x):
                        return u'environment profile value %s' % '.'.join(x)
    
                    raise ValueError('missing values for:\n  ' + '\n  '.join(map(msgFor, missing)))
            else:
                raise ValueError(message('RM09623', 'cloud', 'environmentprofile'))

        missing = patternutils.applyPropertiesToPattern(pattern, dict)
        if missing:
            def msgFor(x):
                if len(x) == 2:
                    return u'part-%s.%s.%s' % ( x[0]['id'], x[1]['pclass'], x[1]['key'])
                else:
                    return u'parameter %s of script %s in part %s' % (x[2]['key'], x[1]['id'], x[0]['id'])

            raise ValueError('missing property/parameter values for:\n  ' + '\n  '.join(map(msgFor, missing)))

        if dict.get('dryrun', False):
            return pattern

        elif dict.get('genjson', False):
            return http._toJSON4J(pattern).serialize()

        vs = http.postJSON(self.uri, pattern)
        return RESTResource.resourceForURI('%s/%s' % (self.uri, vs['id']))


    def create(self, other):
        'RM09352'
        return super(VirtualSystems, self).create(other)
