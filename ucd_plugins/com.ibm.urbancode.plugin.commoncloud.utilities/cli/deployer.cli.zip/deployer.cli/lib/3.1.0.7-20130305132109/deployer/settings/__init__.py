"""
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2012. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
"""

import dateAndTime
import dns
import ethernetInterfaces
import licenseManagement
import mailDelivery
import power
import security
import licenseAwareness

dateandtime = dateAndTime.DateAndTime()
dns         = dns.Dns()
ethernet    = ethernetInterfaces.Ethernet()
ilmt        = licenseManagement.LicenseManagement(licenseManagement.LicenseManagement.URI)
mail        = mailDelivery.MailDelivery()
power       = power.Power()
security    = security.Security()
licenseawareness = licenseAwareness.LicenseAwareness()