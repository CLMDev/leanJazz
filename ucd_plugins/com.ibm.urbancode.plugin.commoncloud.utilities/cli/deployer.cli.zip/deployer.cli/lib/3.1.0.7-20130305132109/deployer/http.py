"""
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2012. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
"""

import base64
import com.ibm.json.java.JSONArray
import com.ibm.json.java.JSONObject
import consoleio
import httplib
import jarray
import java.util
import logging
import os
import re
import urllib
import utils

from java.lang import System
from java.net import HttpCookie, URL
from javax.net.ssl import HostnameVerifier
from javax.net.ssl import HttpsURLConnection
from messages import message
from prettify import prettify
from utils import utos

userid = None
password = None
port = 443

zsessionid = None
simpletoken = None

reauthenticate = False
if os.environ.get('PURE_REAUTHENTICATE') or os.environ.get('DEPLOYER_REAUTHENTICATE'):
    reauthenticate = True


class DeployerHostnameVerifier(HostnameVerifier):
    def verify(self, urlHostName, session):
        # you would think the built-in verifier could check this...
        if not urlHostName.startswith('[') and ':' in urlHostName:
            urlHostName = '[' + urlHostName + ']'
        return urlHostName == session.getPeerHost()

HttpsURLConnection.setDefaultHostnameVerifier(DeployerHostnameVerifier())


# request headers

def _acceptHeader(dict = None):
    dict = dict or {}
    dict['Accept'] = 'application/json'
    return dict


l = java.util.Locale.getDefault()
_acceptLanguage = [ l.getLanguage() ]
if l.getCountry():
    _acceptLanguage[0] += ';q=0.5'
    _acceptLanguage.insert(0, '%s_%s' % (l.getLanguage(), l.getCountry()))

def _acceptLanguageHeader(dict = None):
    dict = dict or {}
    dict['Accept-Language'] = ','.join(_acceptLanguage)
    return dict


def _authHeader(dict = None):
    global zsessionid, simpletoken, reauthenticate
    
    dict = dict or {}

    if zsessionid and simpletoken:
        dict['Cookie'] = 'zsessionid=%s; SimpleToken=%s' % (zsessionid.getValue(), simpletoken.getValue())

    if userid and password:
        # Zero appears to use cookies first, then fallback to authentication if
        # the cookies are expired
        dict['Authorization'] = 'Basic ' + base64.encodestring('%s:%s' % (userid.encode('utf-8'), password.encode('utf-8'))).rstrip()

    return dict


def _defaultHeaders(dict = None):
    return _acceptLanguageHeader(_acceptHeader(_useragentHeader(dict or {})))


def _jsonHeader(dict = None):
    dict = dict or {}
    dict['Content-Type'] = 'application/json; charset=utf-8'
    return dict


def _useragentHeader(dict = None):
    dict = dict or {}
    dict['User-Agent'] = 'IBM-Workload-Deployer-CLI/3.1.0'
    return dict
    


# request/response logic

def _decodeResponseBody(bytes, contentType):
    contentType = contentType or ''
    
    if contentType.startswith('text/') or contentType == 'application/json':
        parameters = {}
        for p in contentType.split(';')[1:]:
            (attr, value) = p.split('=', 1)
            parameters[attr.strip()] = value.strip()

        # HTTP says default to ISO-8859-1, but our server doesn't
        charset = parameters.get('charset', 'utf-8')

        bytes = unicode(bytes, charset)

    return bytes

    
def _defaultResponseHandler(resp):
    read = _decodeResponseBody(resp.read(), resp.getheader('Content-Type'))
    logging.debug('HTTP response: %d %s\n---------[body]---------\n%s\n\n' % (resp.status, resp.reason, utos(read.strip())))

    if resp.getheader('Content-Type', '').find('json') >= 0:
        read = _parseJSON(read)

    if resp.status > 299:
        if isinstance(read, dict):
            #for IPAS
            if read.has_key('messages'):
                messages = read.get('messages')
                if isinstance(messages, dict):
                    raise IOError(resp.status, utos(messages.get('message', resp.reason)))
            #for IWD
            else:
                raise IOError(resp.status, utos(read.get('message', resp.reason)))
        else:
            raise IOError(resp.status, utos(resp.reason))

    return read

        
def getLocationHandler(resp):
    return resp.getheader('Location')


ZERO_DATE = re.compile(r'^(.*[Ee]xpires=\w+, )(\d+) (\w+) (\d+)( \d\d:\d\d:\d\d \w\w\w.*$)')

def _httpCookie(cookie):
    
    # Zero sets Expires= rather than Max-Age=, but their Expires=
    # has the date in the wrong format for java.net.HttpCookie, so correct it
    m = ZERO_DATE.match(cookie)
    if m:
        cookie = '%s%s-%s-%s%s' % (m.group(1), m.group(2), m.group(3), m.group(4), m.group(5))
    else:
        parts = [ s.strip() for s in cookie.split(';') ]
        if "HttpOnly" in parts:
            parts.remove("HttpOnly")
            cookie = ";".join(parts)

    return HttpCookie.parse(cookie)[0]

    
def _httpRequest(uri, method, body = None, headers = None, responseHandler = _defaultResponseHandler, externalServer = None):
    global zsessionid, simpletoken, userid, password

    targetHost = host
    targetPort = int(port)
    targetHeaders = _authHeader(headers)
    https = True
    
    if externalServer:    # This will only affect the initial request, not session expiration or bad password handling (below)
        targetHost = externalServer.get('host')
        https = externalServer.get('https') or False
        targetPort = externalServer.get('port') or (https and 443 or 80)
        targetHeaders = {}
        
        logging.debug('Next HTTP request being sent to external server: %s://%s:%d\n' % ((https and 'https' or 'http'), targetHost, targetPort))
        
    if body:
        logging.debug('HTTP request: %s %s\n%s\n---------[body]---------\n%s\n(%d bytes)\n' % (method, uri, prettify(targetHeaders), prettify(body), len(body)))
    else:
        logging.debug('HTTP request: %s %s\n%s\n' % (method, uri, prettify(targetHeaders)))
    
    conn = None
    
    if https:
        conn = httplib.HTTPSConnection(targetHost, targetPort)
    
    else:
        conn = httplib.HTTPConnection(targetHost, targetPort)
        
    try:
        if isinstance(uri, unicode):
            uri = uri.encode('utf-8')
            
        conn.request(method, uri, body, targetHeaders)
        resp = conn.getresponse()

        # session expired or credentials bad, prompt for new credentials
        if resp.status == 401:
            if userid:
                prompt = message('RM09357("RM09540","RM09355' + urllib.quote_plus('("' + userid + '")') + '")')
                newuserid = consoleio.promptForUserid(prompt)
                
                if not newuserid:
                    newuserid = userid
            else:
                newuserid = consoleio.promptForUserid()
                
            newpassword = consoleio.promptForPassword()

            if newuserid and newpassword:
                userid = newuserid
                password = newpassword
                zsessionid = None
                simpletoken = None

                logging.debug('Prompted for userid/password, resending request')
                conn.close()
                conn = httplib.HTTPSConnection(host, int(port))
                conn.request(method, uri, body, _authHeader(headers))
                resp = conn.getresponse()
        #support auto redirection
        if resp.status == 302:
            #before sending another request, must read current content according by Python documentation
            resp.read()
            redirectUrl = resp.getheader("Location")
            
            logging.debug('redirect request url %s to new url: %s' % (uri, redirectUrl))
            conn.request(method, redirectUrl, body, targetHeaders)
            logging.debug('HTTP request: %s %s\n%s\n' % (method, redirectUrl, prettify(headers)))
            resp = conn.getresponse()
            
        for cookie in resp.msg.getheaders('Set-Cookie'):
            cookie = cookie.strip()

            if cookie.startswith('zsessionid='):
                zsessionid = _httpCookie(cookie)

            elif cookie.startswith('SimpleToken='):
                simpletoken = _httpCookie(cookie)

        # clear password to force prompting when cookie expires
        if zsessionid and simpletoken and not reauthenticate:
            password = None

        return responseHandler(resp)

    finally:
        conn.close()



# Jython <-> JSON

def _parseJSON(s):
    s = s.lstrip()

    if len(s) == 0:
	return None

    if s[0] == '[':
        return _toJython(com.ibm.json.java.JSONArray.parse(s))

    elif s[0] == '{':
        return _toJython(com.ibm.json.java.JSONObject.parse(s))

    else:
        # JSON4J has no mechanism to parse JSON primitive types, so wrap in
        # an array, parse, then unwrap
        return com.ibm.json.java.JSONArray.parse('[' + s + ']').get(0)


def _toJSON4J(jython):
    if isinstance(jython, dict):
        json = com.ibm.json.java.JSONObject()

        for k in jython:
            json.put(k, _toJSON4J(jython[k]))

        return json

    elif isinstance(jython, list) or isinstance(jython, tuple):
        json = com.ibm.json.java.JSONArray()

        for x in jython:
            json.add(_toJSON4J(x))

        return json

    elif com.ibm.json.java.JSONObject.isValidObject(jython):
        return jython

    else:
        raise TypeError(type(jython))
    
    
def _toJython(json4j):
    if json4j.__class__ == com.ibm.json.java.JSONObject:
        jython = {}
        for attr in json4j.keySet():
            jython[attr] = _toJython(json4j.get(attr))

        return jython

    elif json4j.__class__ == com.ibm.json.java.JSONArray:
        return map(_toJython, json4j)

    else:
        return json4j



# public functions

def delete(uri):
    _httpRequest(uri, 'DELETE', headers=_defaultHeaders())


def get(uri, responseHandler = _defaultResponseHandler, externalServer = None):
    return _httpRequest(uri, 'GET', headers = _defaultHeaders(), responseHandler = responseHandler, externalServer = externalServer)


def getWithSpecHeader(uri, headerSpecs = {}, responseHandler = _defaultResponseHandler, externalServer = None):
    customizedHeader = _defaultHeaders()
    if headerSpecs != {}:
        for key in headerSpecs.iterkeys():
            customizedHeader[key] = headerSpecs[key]
    return _httpRequest(uri, 'GET', headers = customizedHeader , responseHandler = responseHandler, externalServer = externalServer)


def postNoContent(uri):
    return _httpRequest(uri, 'POST', headers=_defaultHeaders(), responseHandler=getLocationHandler)


def postJSON(uri, o):
    postBody = _toJSON4J(o)

    if o == "":
        postBody = str(o)
    else:

        if isinstance(postBody, com.ibm.json.java.JSONObject) or isinstance(postBody, com.ibm.json.java.JSONArray):
            postBody = postBody.serialize()
        else:
            postBody = str(postBody)

    postBody = postBody.encode('utf-8')

    return _httpRequest(uri, 'POST', postBody, headers=_jsonHeader(_defaultHeaders()))

def postChunked(uri, f, contentType='application/octet-stream'):
    logging.debug('postChunked: POST %s' % uri)

    # harmless request to force reauthentication if needed
    get('/resources/status')
    
    # Python libraries are easier to use, but they don't do chunking, so
    # drop back to Java for this
    # java.net.URI indicates that it handles UTF-8 encoding, assuming that
    # java.net.URL does likewise...
    u = URL('https', host, int(port), uri)

    # TODO - proxy support would go here
    huc = u.openConnection()

    # TODO - bigger chunk size would probably be useful, but we seem to hit
    # an ArrayIndexOutOfBoundsException in ChunkedOutputStream.java
    # (Sun bug 6631048?).
    huc.setChunkedStreamingMode(9999)
    huc.setRequestMethod('POST')
    huc.setRequestProperty('Content-Type', contentType)

    headers = _authHeader(_defaultHeaders())
    for h in headers:
        huc.setRequestProperty(h, headers[h])

    huc.setDoOutput(True)
    huc.setDoInput(True)

    ostream = huc.getOutputStream()

    postlen = 0
    s = f.read(100000)

    while s:
        postlen += len(s)
        ostream.write(s)
        s = f.read(100000)

    ostream.close()

    logging.debug('postChunked: POSTED %d bytes' % postlen)
    

    # repeat _defaultResponseHandler logic
    read = ''
    istream = huc.getInputStream()
    buff = jarray.zeros(2000, 'b')

    resplen = huc.getContentLength()
    readlen = istream.read(buff, 0, min(resplen, len(buff)))

    while readlen > 0 and resplen > 0:
        read += buff[:readlen].tostring()
        resplen -= readlen
        readlen = istream.read(buff, 0, min(resplen, len(buff)))

    istream.close()

    read = _decodeResponseBody(read, huc.getContentType())
    logging.debug('postChunked: HTTP response: %d %s\n---------[body]---------\n%s\n\n' % (huc.getResponseCode(), huc.getResponseMessage(), read))

    if huc.getResponseCode() > 299:
        raise IOError(huc.getResponseMessage().toString())

    if huc.getContentType() and huc.getContentType().find('json') >= 0:
        return _parseJSON(read)
    else:
        return read

        
def putJSON(uri, o):
    
    putBody = _toJSON4J(o)
    # PUT "" doesn't work
    #if o == "":
    #    putBody = str(o)
    #else:

    if isinstance(putBody, com.ibm.json.java.JSONObject) or isinstance(putBody, com.ibm.json.java.JSONArray):
        putBody = putBody.serialize()
    else:
        putBody = '"%s"' % str(putBody)

    putBody = putBody.encode('utf-8')
        
    return _httpRequest(uri, 'PUT', putBody, _jsonHeader(_defaultHeaders()))

def restChunked(uri, f, method, contentType='application/octet-stream'):

    logging.debug('restChunked: %s %s' % (method, uri))

    # harmless request to force reauthentication if needed
    get('/resources/status')

    u = URL('https', host, int(port), uri)

    huc = u.openConnection()

    huc.setChunkedStreamingMode(9999)
    huc.setRequestMethod(method)
    huc.setRequestProperty('Content-Type', contentType)
    huc.setRequestProperty('File-Name', utils.stou(os.path.basename(f.name)))

    headers = _authHeader(_defaultHeaders())
    for h in headers:
        huc.setRequestProperty(h, headers[h])

    huc.setDoOutput(True)
    huc.setDoInput(True)

    ostream = huc.getOutputStream()

    postlen = 0
    s = f.read(100000)

    while s:
        postlen += len(s)
        ostream.write(s)
        s = f.read(100000)

    ostream.close()

    logging.debug('restChunked: %s %d bytes' % (method, postlen))

    # repeat _defaultResponseHandler logic
    read = ''
    if huc.getResponseCode() >= 400:
        istream = huc.getErrorStream()
    else:
        istream = huc.getInputStream()
    
    buff = jarray.zeros(2000, 'b')

    readlen = istream.read(buff, 0, len(buff))
    while readlen > 0:
        read += buff[:readlen].tostring()
        readlen = istream.read(buff, 0, len(buff))

    istream.close()

    read = _decodeResponseBody(read, huc.getContentType())
    logging.debug('restChunked: HTTP response: %d %s\n---------[body]---------\n%s\n\n' % (huc.getResponseCode(), huc.getResponseMessage(), read))

    if huc.getResponseCode() > 299:
        read = _parseJSON(read)
        if isinstance(read, dict):
            raise IOError(utos(read.get('message')))
        else:
            raise IOError(utos(huc.getResponseMessage()))
        exit(0)

    if huc.getContentType() and huc.getContentType().find('json') >= 0:
        return _parseJSON(read)
    else:
        return read

