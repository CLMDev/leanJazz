#
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2012. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
#
from deployer import http, messages

class Power:
    '''RM09404'''
    
    URI = '/resources/appliance/power'
    _PROPERTYHELP_ = [
        'shutdown','shutdownnow','restart','restartnow'
    ]


    # placeholder for docstring
    def shutdown_(self):
        '''RM09405'''
        pass
    
    def _shutdown(self, when='graceful'):
        params = {'mode': 'halt', 'when': when}
        try:
            http.putJSON(self.URI, params)
            print messages.message('RM09407')
        except:
            print messages.message('RM09406')
    
    # placeholder for docstring
    def shutdownnow_(self):
        '''RM09408'''
        pass
    
    def _shutdownnow(self):
        self._shutdown('immediate')
    
    # placeholder for docstring
    def restart_(self):
        '''RM09409'''
        pass
    
    def _restart(self, when='graceful'):
        params = {'mode': 'reboot', 'when': when}
        try:
            http.putJSON(self.URI, params)
            print messages.message('RM09411')
        except:
            print messages.message('RM09410')
    
    # placeholder for docstring
    def restartnow_(self):
        '''RM09412'''
        pass
    
    def _restartnow(self):
        self._restart('immediate')
    
    shutdown = property(_shutdown)
    shutdownnow = property(_shutdownnow)
    restart = property(_restart)
    restartnow = property(_restartnow)
