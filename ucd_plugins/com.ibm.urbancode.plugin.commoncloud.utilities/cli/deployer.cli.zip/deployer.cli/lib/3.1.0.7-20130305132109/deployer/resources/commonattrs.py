"""
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2012. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
"""

from deployer.messages import localize as localize
from restresource import RESTResource
import acl

class CommonAttributes(RESTResource):
    """Property methods for common attributes.
    """

    def _getAcl(self):
        try:
            return self._acl
        except AttributeError:

            self._acl = acl.ACL(self)
            return self._acl


    def _getCreated(self):
        return self._restattrs['created'] / 1000.0


    @localize
    def _getCurrentmessage_text(self):
        return self._restattrs['currentmessage']


    @localize
    def _getCurrentstatus_text(self):
        return self._restattrs['currentstatus']


    @localize
    def _getDesiredstatus_text(self):
        return self._restattrs['desiredstatus']


    def _getUpdated(self):
        return self._restattrs['updated'] / 1000.0


    @localize
    def _getValidationmessage_text(self):
        return self._restattrs['validationmessage']


    @localize
    def _getValidationstatus_text(self):
        return self._restattrs['validationstatus']
