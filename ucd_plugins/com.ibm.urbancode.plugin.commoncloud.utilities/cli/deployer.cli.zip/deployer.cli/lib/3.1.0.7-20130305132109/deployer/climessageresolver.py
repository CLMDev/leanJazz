"""
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2012. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
"""

import java
import os.path
import utils


class MessageResolver(object):
    def __init__(self, basePath, prefix, defaultFile):
        self.messages = {}
        self.locale = None
        self.basePath = basePath
        if len(prefix) > 0:
            self.prefix = ('' + prefix + '_')
        else:
            self.prefix= ''
        self.defaultFile = defaultFile

    def getFileName(self, locale):
        return self.prefix + locale + '.properties'
        
    def resolve(self, key, locale=None):
        l = locale or java.util.Locale.getDefault()
        if not self.messages or not l.equals(self.locale):
            locales = [ self.getFileName(l.getLanguage())]
            if l.getCountry():
                locales.append(self.getFileName('%s_%s' % (l.getLanguage(), l.getCountry())))
            if l.getVariant():
                locales.append(self.getFileName('%s_%s_%s' % (l.getLanguage(), l.getCountry(), l.getVariant())))
            
            #Add the default file to the list
            if (locales.count(self.defaultFile) == 0):
                locales.insert(0, self.defaultFile)
            
            for locale in locales:
                try:
                    p = java.util.Properties()
                    istrm = java.io.FileInputStream(os.path.join(self.basePath, locale))
                    p.load(istrm)
                    istrm.close()

                    for k in p.keySet():
                        self.messages[k] = p.getProperty(k) + u''

                except java.lang.Exception,e:
                    # .properties file missing
                    pass

            self.locale = l
    
        return self.messages.get(key)

class CLIMessageResolver(MessageResolver):
    def __init__(self):
        MessageResolver.__init__(self, os.path.join(utils.libDir(), 'deployer', 'messages'), '', 'en.properties')
        
class ExtMessageResolver(MessageResolver):
    def __init__(self):
        MessageResolver.__init__(self, os.path.join(utils.libDir(), 'deployer', 'messages', 'ext'), '', 'en.properties')

                        