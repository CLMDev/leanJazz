#
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2012. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
#
from deployer import http
from deployer.utils import stou

class DateAndTime(object):
    'RM10006'

    NTP_SERVERS_URI = '/resources/appliance/ntpServers'
    TIME_ZONE_URI = '/resources/appliance/timeZone'
    TIME_ZONES_URI = '/resources/appliance/timeZones'
    
    _PROPERTYHELP_ = [ 'ntpservers', 'timezone', 'timezones']
    
    def ntpservers_(self):
        '''RM09377'''
        pass
    
    def _setNtpServers(self, servers):
        unicodeServers = [stou(s) for s in servers]
        http.putJSON(self.NTP_SERVERS_URI, unicodeServers)
        
    def _getNtpServers(self):
        return http.get(self.NTP_SERVERS_URI)
    
    def timezone_(self):
        '''RM09378'''
        pass
    
    def _setTimeZone(self, timezone):
        http.putJSON(self.TIME_ZONE_URI, {'localtimezone': stou(timezone)})
    
    def _getTimeZone(self):
        return http.get(self.TIME_ZONE_URI)
    
    def timezones_(self):
        '''RM09379'''
        pass
    
    def _getTimeZones(self):
        return http.get(self.TIME_ZONES_URI)
    
    ntpservers = property(_getNtpServers, _setNtpServers)
    timezone = property(_getTimeZone, _setTimeZone)
    timezones = property(_getTimeZones)
