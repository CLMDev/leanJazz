#!/bin/bash
#
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2012. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
#

function checkPythonCMD {
    if [ -z "$PYTHON_CMD" ]; then
        if [ -f '/opt/python-2.6.4/bin/python' ]; then
            PYTHON_CMD='/opt/python-2.6.4/bin/python'
        else
            PYTHON_CMD=$(which python)
        fi
    fi

    if [ -z "$PYTHON_CMD" ]; then
        echo "Please set PYTHON_CMD to your python home"
        exit 1
    fi
}


checkPythonCMD


if [ $# -lt 3 ]
then
  echo "Wrong number of arguments"
  echo "$0 [cscurl parameters] [followed by curl parameters]"
  echo "Required cscurl parameters are:"
  echo "  [username=<user ID>]"
  echo "  [password=<user password>]"
  echo "  [keyfile=<path name of a file contains user keys json object>]"
  echo "Optional cscurl parameter:"
  echo "  [keyname=<AES256 or AES128> default to AES256]"
  echo "curl parameters follows"
  echo "Example: ./cscurl.sh username=auditadmin password=auditadminpswd keyfile=userkeys.json  -v -k -X GET --url https://hostname:9444/storehouse/admin/users/"
  exit
fi


for arg in "$@"; do
    param=${arg%%=*}
    value=${arg##*=}
    case $param in
        username) export USERNAME=$value; shift 1;;
        password) export PASSWORD=$value; shift 1;;
        keyfile) export KEYSFILE=$value; shift 1;;
        keyname) export KEYNAME=$value; shift 1;;
    esac
done

if [ -z $USERNAME ]; then
    echo "A required parameter username=<user ID> is missing"
    exit 
fi

if [ -z $PASSWORD ]; then
    echo "A required parameter password=<user password> is missing"
    exit 
fi

if [ -z $KEYSFILE ]; then
    echo "A required parameter keyfile=<path name of a file contains cbadmin keys json object> is missing"
    exit 
fi

if [ -z $KEYNAME ]; then
    export KEYNAME="AES256"
fi

security_header=$(${PYTHON_CMD} ${0%%cscurl.sh}create_basicauth_header.py)
curl -H "X-IWD-BasicAuth : ${security_header}"  "$@"
cec=$?
echo    

exit $cec
