"""
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2012. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
"""

from deployer import http, prettify, utils, validators
from deployer.messages import Helpable
from deployer.utils import utos
import os
import urllib


class ScriptLike(object):

    class _Archive(Helpable):
        '''Common archive handling for script-like resources.
        '''

        # subclasses need to arrange for this to be called as part of
        # their class initialization
        @staticmethod
        def _subclassinit(subcls):
            subcls._methodHelp('get', 'set')


        def __init__(self, scripturi):
            self.uri = '%s/scriptArchive.zip' % scripturi


        def _getResponseHandler(self, f, resp):
            if resp.status > 299:
                raise IOError(utos(resp.reason))

            s = resp.read(100000)

            while s:
                f.write(s)
                s = resp.read(100000)


        def get(self, f):
            doclose = False

            if isinstance(f, str) or isinstance(f, unicode):
                f = file(f, 'wb')
                doclose = True

            http.get(self.uri, responseHandler=utils.curryMethod(self._getResponseHandler, f))

            if doclose:
                f.close()


        def set(self, f):
            doclose = False

            if isinstance(f, str) or isinstance(f, unicode):
                f = file(f, 'rb')
                doclose = True

            http.postChunked('%s/%s' % (self.uri, utils.stou(urllib.quote(os.path.basename(f.name)))), f)

            if doclose:
                f.close()


    class _Environment(object):

        def __init__(self, scripturi):
            self.uri = '%s/scriptKeys' % scripturi


        def _getKeys(self):
            return http.get(self.uri)


        def __delitem__(self, key):
            for k in self._getKeys():
                if k['scriptkey'] == key:
                    http.delete('%s/%s' % (self.uri, k['id']))


        def __getitem__(self, key):
            for k in self._getKeys():
                if k['scriptkey'] == key:
                    return k['scriptdefaultvalue']


        def __iter__(self):
            return iter([ k['scriptkey'] for k in self._getKeys() ])


        def __repr__(self):
            return utos(unicode(self))


        def __setitem__(self, key, value):
            validators.string(key, 'key')
            validators.string(value, 'value')

            self.__delitem__(key)
            http.postJSON(self.uri, {
                'scriptid': int(self.uri.split('/')[-2]),
                'scriptkey': key,
                'scriptdefaultvalue': value,
                'scriptvalue': value
            })


        def __str__(self):
            return repr(self)

        def getEntries(self):
            d = {}
            for k in self._getKeys():
                d[k['scriptkey']] = k['scriptdefaultvalue']
            return d
        
        def __unicode__(self):
            d = self.getEntries()
         
            if prettify.enabled:
                return prettify.prettify(d)
            else:
                return unicode(d)


    def _getArchive(self):
        try:
            return self._archive
        except AttributeError:
            self._archive = self.__class__.Archive(self.uri)
            return self._archive


    def _getEnvironment(self):
        try:
            return self._environment
        except AttributeError:
            self._environment = self.__class__.Environment(self.uri)
            return self._environment
