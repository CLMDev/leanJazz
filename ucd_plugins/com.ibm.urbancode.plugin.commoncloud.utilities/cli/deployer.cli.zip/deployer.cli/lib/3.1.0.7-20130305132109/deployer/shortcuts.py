"""
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2012. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
"""

import messages
import sys

from utils import utos

# CLI exit
class _Exitter(object):
    'RM09009'
    
    def __call__(self, *args):
        sys.exit(*args)


    def __repr__(self):
        self()

exit = _Exitter()



# CLI help
class _Helper(object):
    'RM09010'
    
    def __call__(self, arg=None):
        print utos(messages.docstring(arg))
        print ''


    def __repr__(self):
        print utos(messages.docstring(None))
        return ''

help = _Helper()

