"""
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2012. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
"""

import atexit
import cliversion
import codecs
import os
import os.path
import time
import utils

_logDir = os.path.join(utils.libDir(), '..', '..', 'logs')
if not os.path.isdir(_logDir):
    os.makedirs(_logDir)
    
_logFile = codecs.open(os.path.join(_logDir, 'cli.log'), 'wt', 'utf-8')
_logFile.write(time.ctime() + ' CLI_VERSION: %s\n' % cliversion.CLI_VERSION)

debugToStdout = False
#debugToStdout = True

def debug(u):
    try:
        _logFile.write(time.ctime() + ' DEBUG:\n' + u + '\n')
        _logFile.flush()
    except:
        pass
    if debugToStdout:
        print utils.utos(u) + '\n'


def _closeLogs():
    _logFile.close()
    

atexit.register(_closeLogs)

