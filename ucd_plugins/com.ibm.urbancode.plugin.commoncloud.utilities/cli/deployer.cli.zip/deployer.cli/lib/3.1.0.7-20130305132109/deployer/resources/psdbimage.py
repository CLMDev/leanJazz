#
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2012. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
#
"""
Licensed Materials - Property of IBM
IBM WebSphere CloudBurst Appliance (9235-72X)
Copyright IBM Corporation 2011. All Rights Reserved.
US Government Users Restricted Rights - Use, duplication or disclosure
restricted by GSA ADP Schedule Contract with IBM Corp.
"""

import deployer.http as http
import deployer.prettify as prettify
import deployer.utils as utils
import deployer.validators as validators
from   commonattrs import CommonAttributes
from   relationships import RelatedResource, RelatedResourceCollection
from   restresource import RESTResource, RESTResourceCollection 
from   deployer.messages import message
from   deployer.utils import utos
import urllib


@utils.classinit
class PSDatabaseImage(RelatedResource, CommonAttributes):
    'RM31041'
    @classmethod
    def _classinit(cls):
        cls._registerURI(r'\A/resources/pSDatabaseImages/(?P<id>[a-zA-Z0-9\.\-\_\/]+)\Z')
        cls._defineRESTAttribute('id', 'RM31044', readonly=True)
        cls._defineRESTAttribute('imagename', 'RM31045', readonly=True, visible=[ lambda application: application._restattrs.has_key('imagename') ])
        cls._defineRESTAttribute('imagedescription', 'RM31046', readonly=True, visible=[ lambda application: application._restattrs.has_key('imagedescription') ])
        cls._defineRESTAttribute('timestamp', 'RM31047', readonly=True, visible=[ lambda application: application._restattrs.has_key('timestamp') ])
        cls._defineRESTAttribute('imageflag', 'RM31048', readonly=True, visible=[ lambda application: application._restattrs.has_key('imageflag') ])
        cls._defineRESTAttribute('tsmnodename', 'RM31049', readonly=True, visible=[ lambda application: application._restattrs.has_key('tsmnodename') ])
        cls._defineRESTAttribute('platformtype', 'RM31050', readonly=True, visible=[ lambda application: application._restattrs.has_key('platformtype') ])
        cls._defineRESTAttribute('ostype', 'RM31051', readonly=True, visible=[ lambda application: application._restattrs.has_key('ostype') ])
        cls._defineRESTAttribute('dbname', 'RM31052', readonly=True, visible=[ lambda application: application._restattrs.has_key('dbname') ])
        cls._defineRESTAttribute('host', 'RM31053', readonly=True, visible=[ lambda application: application._restattrs.has_key('host') ])
        cls._methodHelp('__contains__', '__delattr__', '__eq__',
                        '__hash__', 'isStatusTransient', '__nonzero__',
                        'refresh', '__repr__', '__str__', '__unicode__')        
        
    def __init__(self, uri, attrs):
        super(PSDatabaseImage, self).__init__(uri, attrs)        
        
@utils.classinit
class PSDatabaseImages(RelatedResourceCollection):
    'RM31042'

    @classmethod
    def _classinit(cls):
        cls._contains(PSDatabaseImage)
        cls._methodHelp('list')

    @classmethod
    def _restname(cls):
        return 'pSDatabaseImages'