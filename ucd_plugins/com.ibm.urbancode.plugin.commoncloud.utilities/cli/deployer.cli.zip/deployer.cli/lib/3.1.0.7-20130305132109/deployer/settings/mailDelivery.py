#
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2012. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
#
from deployer import http, utils

class MailDelivery(object):
    # TODO - message is useless
    '''RM09401'''

    _PROPERTYHELP_ = [ 'replytoaddress', 'smtpserver' ]

    SMTP_URI = '/resources/smtp'
    REPLY_URI = '/resources/mailSender'
    
    def smtpserver_(self):
        '''RM09402'''
        pass
    
    def _getSmtp(self):
        return http.get(self.SMTP_URI)
    
    def _setSmtp(self, serverName):
        http.putJSON(self.SMTP_URI, utils.stou(serverName.strip()))
        
    def replytoaddress_(self):
        '''RM09403'''
        pass
    
    def _getReplyToAddress(self):
        return http.get(self.REPLY_URI)
    
    def _setReplyToAddress(self, address):
        http.putJSON(self.REPLY_URI, utils.stou(address.strip()))
    
    smtpserver = property(_getSmtp, _setSmtp)
    replytoaddress = property(_getReplyToAddress, _setReplyToAddress)
 
