"""
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2012. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
"""

import java
import re
import base64
import codecs
import os
import sys
import traceback
import deployer
import com.ibm.json.java.JSONArray
import com.ibm.json.java.JSONObject

from messages import message
from deployer import prettify, utils
from http import _toJSON4J, _parseJSON
from time import time, sleep
from climessageresolver import MessageResolver

MSGINSERTRE = re.compile(r'(.*?)\$\{(\d+)\}(.*)')
PASSWORDRE = re.compile(r'(?i)(\A|[^A-Za-z])(p(w|wd|word))|(pass(w|wd|word)?)(\Z|[^A-Za-z])')


# Constants
ADD_ONS = "add_ons"
VIRTUAL_IMAGES = "virtual_images"
SCRIPT_PACKAGES = "script_packages"
REFERENCES = "references"
PARTS = "parts"

VIRTUAL_IMAGE_REF = "virtual_image_ref"
SCRIPT_PACKAGE_REF = "script_package_ref"
ADD_ON_REF = "add_on_ref"
PART_REF = "part_ref"
SCRIPT_REF = 'script_ref'

NAME = "name"
FILE = "file"
URL = "url"
USER = "user"
PASSWORD = "password"
PROPERTIES = "properties"
DESCRIPTION = "description"
CLASS = "class"
PCLASS = "pclass"
KEY = "key"
VALUE = "value"
LOCKED = "locked"
PARAMETERS = "parameters"
ADVANCED_OPTIONS = "advanced_options"
CONFIGURATIONS = "configurations"
OBJ = "obj"
REFERENCE = "reference"
COUNT = "count"
STARTS_AFTER = "starts_after"
BUILD = "build"
VERSION = "version"
READ_ONLY = "read_only"
#Scripts Types
CONFIGURATION = "CONFIGURATION"
APPLICATION = "APPLICATION"
LICENSE_ACCEPTED = "license_accpeted"
STATUS_NOT_ACCEPTED = 'RM01057'
TYPE="type"
CONCRETE_KEY = 'concreteKey'
CONCEPTUAL_KEY = 'conceptualKey'

DEFAULT_VALUE = 'defaultvalue'
USER_CONFIGURABLE = 'userConfigurable'
UTF_8="utf-8"

ADVANCED_OPTIONS_ACCEPTED = 'advancedoptionsaccepted'
EXEC_MODE = 'execmode'
COMMAND = 'command'
COMMAND_ARGS = 'commandargs'
TIMEOUT = 'timeout'
ENVIRONMENT = 'environment'
LOCATION = 'location'
LOG = 'log'

def _findScriptByPartScript(patternPart, label):
    scripts = filter(lambda script: script.label == label, deployer.scripts)
    assert len(scripts) == 1, utils.utos(message('IWD00018') % ({"1": patternPart.partCaption, "2": patternPart.id, "3": label}))
    return scripts[0]

def _findPartAddOn(patternPart, label):
    addons = filter(lambda addon: addon.label == label, deployer.addons)
    assert len(addons) == 1, utils.utos(message('IWD00019') % ({"1": patternPart.partCaption, "2": patternPart.id, "3": label}))
    return addons[0]

def _findPartScript(patternPart, label, type = APPLICATION, version=None, key=None):
    patternScripts = filter(lambda ps: ps.type == type and (ps.label == label or ps.key == key), patternPart.scripts)
    
    if len(patternScripts) == 0:
        scriptObj = _findScriptByName(label, CONFIGURATION, version) 
        pscript = (patternPart.scripts << scriptObj)
        patternScripts.append(pscript)
    
    return patternScripts[0]

def _findScriptByName(name, type=APPLICATION, version=None):
    params = {TYPE: type, NAME: name}
    if version is None:
        scripts = filter(lambda script: script.name == name, deployer.scripts.list(params))
    else:
        scripts = filter(lambda script: (script.name == name and script.version == version), deployer.scripts.list(params))
    assert len(scripts) == 1, utils.utos(message('IWD00020') % ({"1": type, "2": name}))
    return scripts[0]

def _findAddOnByName(name):
    addons = filter(lambda addon: addon.name == name, deployer.addons[name])
    assert len(addons) == 1, utils.utos(message('IWD00021') % (name))
    return addons[0]


def _getFilePath(dest, path):
    return os.path.join(dest, path)

def _findVirtualImageByName(name, version, build):
    matches = filter(lambda vi: vi.build == build and vi.version == version and vi.name == name, deployer.virtualimages[name])
    assert len(matches) == 1, utils.utos(message('IWD00023') % (name))
    return matches[0]

def _waitForVirtualImageImport(virtualImage):
    status_queued = 'RM01036'
    status_processing = 'RM01002' 
    
    if virtualImage.currentstatus == status_queued:
        print utils.utos(message('IWD00034'))
        
    i = 0
    while virtualImage.currentstatus == status_queued or virtualImage.currentstatus == status_processing:
        for var in range(1, 13):
            print utils.utos(message('IWD00035') % (i))
            sleep(5)
        i=i+1
        virtualImage.refresh()
            
    virtualImage.refresh()

def _findVirtualImage(virtuaImage, dest):
    name = virtuaImage[NAME]
    version = virtuaImage.get(VERSION, None)
    build = virtuaImage.get(BUILD, None)
    advOptionsEnabled = virtuaImage.get(ADVANCED_OPTIONS_ACCEPTED, None)
    
    matches = filter(lambda vi: (build == None or vi.build == build) and (version == None or vi.version == version), deployer.virtualimages[name])
    #Support import Virtual Image
    if len(matches) == 0:
        file = virtuaImage.get(FILE, None)
        deployer.virtualimages.progressIndicators = True
        if not file is None:
            path = _getFilePath(dest, file)
            print utils.utos(message('IWD00022') % ({"1": name, "2": path}))
            virtualImage = deployer.virtualimages.create(path)
            _waitForVirtualImageImport(virtualImage)
            # image is in failed status
            if virtualImage.currentstatus != 'RM01013':
               matches.append(virtualImage)
               print utils.utos(message('IWD00046') % (name))
        else:
            url = virtuaImage.get(URL, None)
            if not url is None:
                parms = {URL : url}
                user = virtuaImage.get(USER, None)
                if not user is None:
                    parms['userid'] = user
                password = virtuaImage.get(PASSWORD, None)
                if not password is None:
                    parms[PASSWORD] = password
                print utils.utos(message('IWD00022') % ({"1": name, "2": url}))
                virtualImage = deployer.virtualimages.create(parms)
                _waitForVirtualImageImport(virtualImage)
                if virtualImage.currentstatus != 'RM01013':
                   matches.append(virtualImage)
                   print utils.utos(message('IWD00046') % (name))
            
    assert len(matches) == 1 and matches[0].name == name, utils.utos(message('IWD00023') % (name))
    #enable/disable Intelligent Management Package (If not exist, update doesn't throw exception)
    if advOptionsEnabled != None and matches[0].advancedoptionsaccepted != advOptionsEnabled:
       matches[0].advancedoptionsaccepted = advOptionsEnabled
    
    return matches[0]

def _findScript(scriptPackage, dest):
    name = scriptPackage[NAME]
    execmode = scriptPackage.get(EXEC_MODE, None)

    scripts = filter(lambda script: script.name == name, deployer.scripts[name])
    #Support import
    if len(scripts) == 0:
        
        script = deployer.scripts << {NAME: name}
        scripts.append(script)
        
        file = scriptPackage.get(FILE, None)
        if not file is None:
            path = _getFilePath(dest, file)
            print utils.utos(message('IWD00025') % ({"1": name, "2": path}))
            script.archive.set(path)
            
    assert len(scripts) == 1, utils.utos(message('IWD00032') % (name))
    #set execution mode
    if execmode != None and scripts[0].execmode != execmode:
        scripts[0].execmode = execmode
    
    _loadScriptAttributes(scriptPackage, scripts[0])
       
    return scripts[0]

def _findAddOn(addonJson, dest):
    name = addonJson[NAME]
    type = addonJson[TYPE]
    
    addons = filter(lambda a: a.name == name, deployer.addons[name])
    #Support import
    if len(addons) == 0:
        file = addonJson.get(FILE, None)
        #without type, addon will be considered as script package
        addon = deployer.addons << {NAME: name, TYPE: type}
        addons.append(addon)
        if not file is None:
            path = _getFilePath(dest, file)
            print utils.utos(message('IWD00026') % ({"1": name, "2": path}))
            addon.archive.set(path)
            
    assert len(addons) == 1, utils.utos(message('IWD00027') % (name))
    _loadScriptAttributes(addonJson, addons[0])
        
    return addons[0]

def _findPart(virtualImage, label, type):
    parts = filter(lambda part: part.name == type or part.label == label, virtualImage.parts)
    assert len(parts) == 1, utils.utos(message('IWD00028') % ({"1": label, "2": virtualImage.name}))
    return parts[0]

def _createDir(dir):
    if (not os.path.exists(dir)):
        os.makedirs(dir)
    
    elif (not os.path.isdir(dir)):
        print >>sys.stderr, utils.utos(message('IWD00029') % dest)
        sys.exit(1)

def _findProperty(patternPart, pclass, key):
    property = patternPart.getProperty(pclass, key, True)
    assert property, utils.utos(message('IWD00030') % ({"1": patternPart.partCaption, "2": patternPart.id, "3": pclass, "4": key}))
    return property

def _findParameter(patternPart, partScript, key):
    parameter = partScript.getParameter(key, True)
    assert parameter, utils.utos(message('IWD00031') % ({"1": patternPart.partCaption, "2": patternPart.id, "3": partScript.label, "4": key}))
    return parameter

def _updateProperty(patternPart, property):
    userConfigurable = not property.get(LOCKED, False)
    pclass = property.get(PCLASS, property.get('class', None))
    key = property[KEY]
    value = property[VALUE]
    if PASSWORDRE.search(key) and value != None and value != '':
        value = base64.b64decode(value)                    

    ppproperty = _findProperty(patternPart, pclass, key)
    
    if (userConfigurable and not ppproperty[USER_CONFIGURABLE]) or \
       (not userConfigurable and ppproperty[USER_CONFIGURABLE]) or \
       ppproperty[VALUE] != value:
       patternPart.setProperty(pclass, key, value, userConfigurable=userConfigurable)

def _updateParameter(patternPart, partScript, param):
    key = param[KEY]
    value = param[VALUE]
    userConfigurable = not param.get(LOCKED, False)
    if PASSWORDRE.search(key) and value != None and value != '':
        value = base64.b64decode(value)
    
    parameter = _findParameter(patternPart, partScript, key)

    if (userConfigurable and not parameter[USER_CONFIGURABLE]) or \
       (not userConfigurable and parameter[USER_CONFIGURABLE]) or \
       parameter[DEFAULT_VALUE] != value:
       partScript.setParameter(key, value, userConfigurable=userConfigurable)

def _getPatternsFilePath(dest):
    return _getFilePath(dest, 'patterns.json')

def _matchItem(item, list):
    for it in list:
        value = item.get(NAME, None)
        value1 = it.get(NAME, None)
        if (value == value1):
            return True
                
    return False

def _export(references, dest, downloadJSON, downloadAll):
    
    SCRIPT_PACKAGE_DIR = 'script_packages'
    ADD_ONS_DIR = 'add_ons'
    IMAGES_DIR = 'images'
    
    scrtipsDir = _getFilePath(dest, SCRIPT_PACKAGE_DIR)
    
    _createDir(scrtipsDir)
    
    if downloadJSON is None:
        virtualImages = []
        addOns = []
        scriptPackages = []
    else:
        virtualImages = downloadJSON.get(VIRTUAL_IMAGES, [])
        addOns = downloadJSON.get(ADD_ONS, [])
        scriptPackages = downloadJSON.get(SCRIPT_PACKAGES, [])
    
    for item in references[SCRIPT_PACKAGES]:
        if downloadAll or downloadJSON is None or _matchItem(item, scriptPackages):
            script = _findScriptByName(item[NAME])
            filename = script.filename
            if (filename is not None and len(filename) > 0):
                file = SCRIPT_PACKAGE_DIR + '/' + filename
                print utils.utos(message('IWD00016') % ({"1": item[NAME], "2": file}))
                script.archive.get(_getFilePath(dest, file))
                item[FILE] = file

    
    addonDir = _getFilePath(dest, ADD_ONS_DIR)
    
    _createDir(addonDir)

    for item in references[ADD_ONS]:
        if downloadAll or downloadJSON is None or _matchItem(item, addOns):
            addon = _findAddOnByName(item[NAME])
            if (addon.filename is not None and len(addon.filename) > 0):
                file = ADD_ONS_DIR + '/' + addon.filename
                print utils.utos(message('IWD00017') % ({"1": item[NAME], "2": file}))
                addon.archive.get(_getFilePath(dest, file))
                item[FILE] = file

    imageDir = _getFilePath(dest, IMAGES_DIR)
    
    _createDir(imageDir)
    
    for item in references[VIRTUAL_IMAGES]:
        if downloadAll or _matchItem(item, virtualImages):
            image = _findVirtualImageByName(item[NAME], item[VERSION], item[BUILD])
            print utils.utos(message('IWD00047') % ({"1": item[NAME], "2": imageDir}))
            file = image.export(imageDir)
            item[FILE] = IMAGES_DIR + '/' + file
            print utils.utos(message('IWD00048') % ({"1": item[NAME], "2": item[FILE]}))                


def _findPartIndex(parts, part): 
    result = 0;
    for p in parts:
        if (p.id == part.id):
            return result;
        result += 1

def _findScriptIndex(part, script): 
    result = 0;
    for s in part.scripts:
        if s.type != APPLICATION:
           continue
        if (s.id == script.id):
            return result;
        result += 1

        
def _recordScriptAttributes(scriptObj, script):
        if script.command != None:
            scriptObj[COMMAND] = script.command  
        if script.commandargs != None:
            scriptObj[COMMAND_ARGS] = script.commandargs
        envEntries = script.environment.getEntries()
        if envEntries:
            scriptObj[ENVIRONMENT] = envEntries
        if script.location != None:
            scriptObj[LOCATION] = script.location
        if script.timeout != None:
            scriptObj[TIMEOUT] = script.timeout
        if script.log != None:
            scriptObj[LOG] = script.log
        return scriptObj

def _loadScriptAttributes(scriptPackage, script):
        readonly = scriptPackage.get(READ_ONLY, False)
        environment = scriptPackage.get(ENVIRONMENT, None)
        command = scriptPackage.get(COMMAND, None)
        commandargs = scriptPackage.get(COMMAND_ARGS, None)
        location = scriptPackage.get(LOCATION, None)
        timeout = scriptPackage.get(TIMEOUT, None)
        log = scriptPackage.get(LOG, None)

        try:            
            if command != None and command != script.command:
                script.command = command
            
            if commandargs != None and commandargs != script.commandargs:
                script.commandargs = commandargs
            
            if location != None and location != script.location:
                script.location = location
            
            if timeout != None and timeout != script.timeout:
                script.timeout = timeout
            
            if log != None and log != script.log:
                script.log = log

            if environment != None:
                entries = script.environment.getEntries()
                for key in environment:
                    try:
                       if entries.get(key) != environment.get(key):
                          script.environment[key] = environment.get(key)
                    except Exception, e1:
                        print e1
    
                # remove keys in the script, but not in patterns.json
                for key in entries:
                    try:
                        if not environment.has_key(key):
                          del script.environment[key]
                    except Exception, e2:
                        print e2
                    
            if readonly and script.isReadOnly() != readonly:
                script.makeReadOnly()

        except Exception, e3:
            print e3

def _localizePattern(dest, pattern):
    messagesPath = _getFilePath(dest, 'locales');
    if (os.path.exists(messagesPath)):
        resolver = MessageResolver(messagesPath, 'messages', 'messages.properties')

        name = pattern.get(NAME, None)
        if not name is None:
            name = resolver.resolve(name)
            if not name is None:
                pattern[NAME] = name

        description = pattern.get(DESCRIPTION, None)
        if not description is None:
            description = resolver.resolve(description)
            if not description is None:
                pattern[DESCRIPTION] = description
            
def patternToJSON(p, dest, **options):
    includePasswords = options.get('includePasswords', False)
    download = options.get('download', None)
    downloadAll = options.get('downloadAll', False)
    
    print utils.utos(message('IWD00043') % (p.name))
    
    downloadJSON = None
    
    if not download is None:
        f = codecs.open(download, 'r', UTF_8)
        downloadJSON = _parseJSON(f.read());
        f.close()
    
    result = {
        REFERENCES: {
            VIRTUAL_IMAGES: [],
            ADD_ONS: [],
            SCRIPT_PACKAGES: [],
        },
        PARTS:[]
    }
    result[NAME] = p.name
    
    if  not p.description is None:
        result[DESCRIPTION] = p.description


    vis = []
    scripts = []
    addons = []

    parts = p.parts
    for ppart in parts:
        # process virtual images
        vi = ppart.virtualimage
        if vi is None:
            print >>sys.stderr, utils.utos(message('IWD00036') % ppart.partCaption)
            sys.exit(1)
        
        if vi not in vis:
            vis.append(vi)
            result[REFERENCES][VIRTUAL_IMAGES].append({NAME: vi.name, VERSION: vi.version, BUILD: vi.build, ADVANCED_OPTIONS_ACCEPTED: vi.advancedoptionsaccepted})

        part = {
            VIRTUAL_IMAGE_REF: vis.index(vi),
            NAME: ppart.partCaption,
            TYPE: ppart.partType,
            CONCRETE_KEY: ppart.concreteKey,
            CONCEPTUAL_KEY: ppart.conceptualKey,
            PROPERTIES: [],
            SCRIPT_PACKAGES: [],
            ADD_ONS: [],
            CONFIGURATIONS: []
        }
        
        if ppart.count > 0:
            part[COUNT] = ppart.count

        # process properties
        for prop in ppart.properties:

            value = prop[VALUE]
            locked = prop[USER_CONFIGURABLE] == False 

            # skip passwords
            if PASSWORDRE.search(prop[KEY]):
                if includePasswords:
                    if value != None and value != '':
                       value = base64.b64encode(value)
                else:
                    value = ''
                    locked = False

            property = {
                PCLASS: prop[PCLASS],
                KEY: prop[KEY],
                VALUE: value
            }
            if locked:
                property[LOCKED] = True

            part[PROPERTIES].append(property)

        # set advanced options
        if p.advancedoptions is not None:
            result[ADVANCED_OPTIONS] = list(p.advancedoptions)

        # set publish status
        if p.isReadOnly():
            result[READ_ONLY] = True


        # process script packages and add ons
        for pscript in ppart.scripts:
            item = {PARAMETERS: []}
            # application scripts
            if pscript.type == APPLICATION:
                script = _findScriptByPartScript(ppart, pscript.label)
                if script not in scripts:
                    scripts.append(script)
                    scriptObj = {NAME: script.name, EXEC_MODE: script.execmode, READ_ONLY: script.isReadOnly()}
                    _recordScriptAttributes(scriptObj, script)
                    result[REFERENCES][SCRIPT_PACKAGES].append(scriptObj)
                item[SCRIPT_PACKAGE_REF] = scripts.index(script)
                startsAfter = [ {PART_REF: _findPartIndex(parts, otherscript.part), SCRIPT_REF: _findScriptIndex(otherscript.part, otherscript)} for otherscript in pscript.startsafter ]
                if len(startsAfter) > 0:
                    item[STARTS_AFTER] = startsAfter
                part[SCRIPT_PACKAGES].append(item);


            # addon scripts
            elif pscript.type.startswith('ADDON_'):
                addon = _findPartAddOn(ppart, pscript.label)
                if addon not in addons:
                    addons.append(addon)
                    addonObj = {NAME: addon.name, TYPE: addon.type, READ_ONLY: addon.isReadOnly()}
                    _recordScriptAttributes(addonObj, addon)
                    result[REFERENCES][ADD_ONS].append(addonObj)
                item[ADD_ON_REF] = addons.index(addon)
                part[ADD_ONS].append(item);

            elif pscript.type == CONFIGURATION:
                item[NAME] = pscript.label
                item[KEY] = pscript.key
                part[CONFIGURATIONS].append(item)
            else:
                continue


            # process parameters
            for parm in pscript.parameters:
                value = parm[DEFAULT_VALUE]
                locked = parm[USER_CONFIGURABLE] == False
                
                # skip passwords
                if PASSWORDRE.search(parm[KEY]):
                    if includePasswords:
                        if value != None and value != '':
                           value = base64.b64encode(value)
                    else:
                        value = ''
                        locked = False

                parameter = {
                    KEY: parm[KEY],
                    VALUE: value
                }
                if locked:
                    parameter[LOCKED] = True

                item[PARAMETERS].append(parameter)

        startsAfterTemp = [ _findPartIndex(parts, otherpart) for otherpart in ppart.startsafter ]
        
        #remove duplications
        startsAfter = []
        
        if len(startsAfterTemp) > 0:
            for id in startsAfterTemp:
                if not (id in startsAfter): 
                    startsAfter.append(id)
            part[STARTS_AFTER] = startsAfter

        result[PARTS].append(part)

    _export(result[REFERENCES], dest, downloadJSON, downloadAll)
    
    f = codecs.open(_getPatternsFilePath(dest), 'wb', UTF_8)
    try:
        f.write(str(_toJSON4J([result]).serialize(True)))
    finally:
        f.close()
        
    print utils.utos(message('IWD00044') % (p.name))


def _validateReferences(patterns):
    BAD_REF_MSG_ID = 'RM10054'
    
    for pattern in patterns:
        references = pattern.get(REFERENCES, {})        
        availableAddonReferences  = references.get(ADD_ONS, [])
        availableScriptReferences = references.get(SCRIPT_PACKAGES, [])
        availableViReferences     = references.get(VIRTUAL_IMAGES, []);
    
        parts = pattern.get(PARTS, [])
        for part in parts:
            partAddons = part.get(ADD_ONS, [])
            for partAddon in partAddons:
                addonReference = partAddon[ADD_ON_REF]
                if (addonReference >= len(availableAddonReferences)):
                    badRef = ADD_ON_REF + " : " + str(addonReference)            
                    print utils.utos( message(BAD_REF_MSG_ID) % ({"1": badRef, "2": part.get(NAME)}) )
                    return False              

            scripts = part.get(SCRIPT_PACKAGES, [])
            for script in scripts:
                scriptReference = script[SCRIPT_PACKAGE_REF]
                if (scriptReference >= len(availableScriptReferences)):
                    badRef = SCRIPT_PACKAGE_REF + ":" + str(scriptReference)
                    print utils.utos( message(BAD_REF_MSG_ID) % ({"1": badRef, "2": part.get(NAME)}) )
                    return False

            viReference = part[VIRTUAL_IMAGE_REF]
            if (viReference >= len(availableViReferences)):
                badRef = VIRTUAL_IMAGE_REF + " : " + str(viReference)            
                print utils.utos( message(BAD_REF_MSG_ID) % ({"1": badRef, "2": part.get(NAME)}) )
                return False              

    return True


def JSONtoPattern(patternsObj, dest):
    f = codecs.open(_getPatternsFilePath(dest), 'r', UTF_8)
    patterns = _parseJSON(f.read());
    f.close()
    
    virtuaImages = []
    
    if not _validateReferences(patterns):
        sys.exit(1)
    
    for pattern in patterns:
        try:
            _localizePattern(dest, pattern)
            
            # process references
            references = pattern.get(REFERENCES, { VIRTUAL_IMAGES: [], ADD_ONS: [], SCRIPT_PACKAGES: []})    
            
            virtuaImages = references.get(VIRTUAL_IMAGES, [])
            
            addons = references.get(ADD_ONS, [])
            
            scriptPackages = references.get(SCRIPT_PACKAGES, [])
            
            #Checking reference    
            for virtuaImage in virtuaImages:
                obj = _findVirtualImage(virtuaImage, dest)
                virtuaImage[REFERENCE] = obj
            
            for addon in addons:
                obj = _findAddOn(addon, dest)
                addon[REFERENCE] = obj
            
            for scriptPackage in scriptPackages:
                obj = _findScript(scriptPackage, dest)
                scriptPackage[REFERENCE] = obj
            
            #Enable all the Virtual Images before creation        
            for virtuaImage in virtuaImages:
                vi = virtuaImage[REFERENCE]; 
                if vi.licenseaccepted != 'T':
                    virtuaImage[LICENSE_ACCEPTED] = False
                    vi.acceptLicense()
                else:
                    virtuaImage[LICENSE_ACCEPTED] = True
            
            # process parts
            newPattern = {}
            
            name = pattern.get(NAME, None)
            
            if name is None:
                continue
            else:
                newPattern[NAME] = name
            
            description = pattern.get(DESCRIPTION, None)
            
            if not description is None:
                newPattern[DESCRIPTION] = description
            
            print utils.utos(message('IWD00033') % pattern[NAME])
            
            patternObj = deployer.patterns << newPattern
            
            parts = pattern.get(PARTS, [])
            for part in parts:
                vi = virtuaImages[part[VIRTUAL_IMAGE_REF]][REFERENCE]
                partObj = _findPart(vi, part[NAME], part.get('type'))
                partDict = {'id': partObj.id}
                if part.get(CONCRETE_KEY):
                    partDict[KEY] = part.get(CONCRETE_KEY)
                if part.get(CONCEPTUAL_KEY):
                    partDict[CONCEPTUAL_KEY] = part.get(CONCEPTUAL_KEY)
                ppart = patternObj.parts << partDict;
                part[OBJ] = ppart
                
                count = part.get(COUNT, 0)
                if (count > 0):
                    ppart.count = part[COUNT]
                
                properties = part.get(PROPERTIES, [])
                
                for property in properties:
                    try:
                       _updateProperty(ppart, property)
                    except Exception,e:
                        print e
                    
                scripts = part.get(SCRIPT_PACKAGES, [])
                for script in scripts:
                    scriptObj = scriptPackages[script[SCRIPT_PACKAGE_REF]][REFERENCE]
                    pscript = ppart.scripts << scriptObj
                    script[OBJ] = pscript
            
                    parameters = script.get(PARAMETERS, [])
            
                    for parameter in parameters:
                        try:
                            _updateParameter(ppart, pscript, parameter)
                        except Exception, e:
                            print e
                
                partAddons = part.get(ADD_ONS, [])
                for partAddon in partAddons:
                    addonObj = addons[partAddon[ADD_ON_REF]][REFERENCE]
                    paddon = ppart.scripts << addonObj
                    partAddon[OBJ] = paddon
            
                    parameters = partAddon.get(PARAMETERS, [])
            
                    for parameter in parameters:
                        try:
                            _updateParameter(ppart, paddon, parameter)
                        except Exception, e:
                             print e
            
            # process advanced options
            advancedOptions = pattern.get(ADVANCED_OPTIONS, [])
             
            if (not advancedOptions is None) and len(advancedOptions) > 0:                
                patternObj.advancedoptions = advancedOptions
            
            for part in parts:
                ppart = part[OBJ]
                
                # process startsA_after
                startsAfterParts = part.get(STARTS_AFTER, []);
                startsAfterPartObjs = []
                for partRef in startsAfterParts:
                    startsAfterPartObjs.append(parts[partRef][OBJ])
                    
                if len(startsAfterParts) > 0:
                    try:
                        ppart.startsafter += startsAfterPartObjs
                    except Exception, e:
                        print e
                
                scripts = part.get(SCRIPT_PACKAGES, [])
                for script in scripts:
                    pscript = script[OBJ]
                    startsAfterScripts = script.get(STARTS_AFTER, []);
                    startsAfterScriptObjs = [];
                    for scriptRef in startsAfterScripts:
                        startsAfterScriptObjs.append(parts[scriptRef[PART_REF]][SCRIPT_PACKAGES][scriptRef[SCRIPT_REF]][OBJ])
                        
                    if len(startsAfterScripts) > 0:
                        try:
                            pscript.startsafter += startsAfterScriptObjs
                        except Exception, e:
                            print e
                            
                
                configurations = part.get(CONFIGURATIONS, [])
                
                for configuration in configurations:
                    version = virtuaImages[part[VIRTUAL_IMAGE_REF]][BUILD]
                    
                    pscript = _findPartScript(ppart, configuration[NAME], CONFIGURATION, version, configuration.get(KEY))
                    
                    parameters = configuration.get(PARAMETERS, [])
            
                    for parameter in parameters:
                        try:
                            _updateParameter(ppart, pscript, parameter)
                        except Exception, e:
                            print e
            
            if pattern.get(READ_ONLY, False):
                patternObj.makeReadOnly()
                                  
            print utils.utos(message('IWD00045') % pattern[NAME])
        except:
            traceback.print_exc()
        
        #Reset the status of license accepted for Virtual Images         
        for virtuaImage in virtuaImages:
            if not virtuaImage.get(LICENSE_ACCEPTED, True):
                try:
                    vi = virtuaImage[REFERENCE]
                    vi.acceptLicense(accept='F')
                except:
                    traceback.print_exc()
