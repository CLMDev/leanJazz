"""
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2012. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
"""

from deployer import http, prettify, readonly, utils, validators
from deployer.messages import message
from commonattrs import CommonAttributes
from relationships import RelatedResource, RelatedResourceCollection
from restresource import RESTResource
import os

@utils.classinit
class VirtualMachine(RelatedResource, CommonAttributes):
    'RM09121'


    @classmethod
    def _classinit(cls):
        cls._registerURI(r'\A/resources/instances/\d+/virtualMachines/(?P<id>\d+)\Z')

        # config - hidden
        cls._defineRESTAttribute('cpucount', 'RM09275', readonly=True)
        cls._defineRESTAttribute('created', 'RM09276', readonly=True)
        cls._defineRESTAttribute('currentmessage', 'RM09277', readonly=True)
        cls._defineAttribute('currentmessage_text', 'RM09154', readonly=True)
        cls._defineRESTAttribute('currentstatus', 'RM09278', readonly=True)
        cls._defineAttribute('currentstatus_text', 'RM09156', readonly=True)
        cls._defineRESTAttribute('desiredstatus', 'RM09296', writeonly=True, values=('RM01006','RM01011','RM01020','RM01030','RM01040','RM01043','RM01058'))
        cls._defineRESTAttribute('displayname', 'RM09279', readonly=True)
        cls._defineAttribute('environment', 'RM09218', readonly=True, elided=True)
        cls._defineAttribute('hardware', 'RM09483', readonly=True, elided=True)
        cls._defineRESTAttribute('hypervisormachineid', 'RM09280', readonly=True)
        cls._defineRESTAttribute('id', 'RM09281', readonly=True)
        cls._defineAttribute('ip', 'RM09331', readonly=True, elided=True)
        cls._defineAttribute('ips', 'RM09692', readonly=True, elided=True)
        # location - hidden
        cls._defineRESTAttribute('memory', 'RM09283', readonly=True)
        cls._defineAttribute('migrationtargets', 'RM09851', readonly=True, elided=True)
        cls._defineRESTAttribute('name', 'RM09284', readonly=True)
        # poolid - hidden
        cls._defineRESTAttribute('runtimeid', 'RM09285', readonly=True)
        cls._defineAttribute('scripts', 'RM09567', readonly=True, elided=True)
        # startuporder - hidden
        cls._defineRESTAttribute('storageid', 'RM09287', readonly=True)
        # type - hidden
        cls._defineRESTAttribute('updated', 'RM09289', readonly=True)
        cls._defineRESTAttribute('patternpart', 'RM09983', readonly=True, elided=True)
        cls._defineRESTAttribute('scripthistory', '', readonly=True, elided=True)
        # virtualservergroupid - hidden
        # virtualsystemid - hidden

        cls._methodHelp('__contains__', '__delattr__', 'delete', '__eq__',
                        '__hash__', 'isStatusTransient', '__nonzero__',
                        'refresh', '__repr__', '__str__', '__unicode__',
                        'waitFor',
                        'clone', 'start', 'stop', 'executeScript')


    # environment attribute

    def _getEnvironment(self):
        return prettify.PrettyDict(http.get('%s/virtualMachineReports' % self.uri))

    def _getPatternpart(self):
        partid = self._restattrs.get('partid')
        pattern = self.virtualsystem.pattern
        if partid and pattern:
            return utils.find(lambda r: r._restattrs.get('resid') == partid, pattern.parts)
        return None

    # hardware attribute

    class Hardware(readonly.ReadOnlyDict):
        _keymap = {
            'RM07207': 'pcpu',
            'RM10182': 'ipaddress',
            'RM10426': 'vcpu',
            'RM10427': 'memory',
            'RM10732': 'publickey',
            'RM10981': 'hostcpuconsumed',
            'RM10982': 'hostcpu',
            'RM26140': 'nics',
            'mac': 'mac'
        }


        def update(self, d):
            for k,v in d.items():
                k = self.__class__._keymap.get(k)
                if k:
                    if k == 'nics':
                        for nic in v:
                            nic['ipaddress'] = nic['RM10182']
                            del nic['RM10182']

                    readonly.ReadOnlyDict.__setitem__(self, k, v)


    def _getHardware(self):
        hw = VirtualMachine.Hardware()
        hw.update(http.get("%s/hardware" % self.uri))
        hw.lock(message('RM09482'))

        return hw


    # hypervisor attribute

    def _setHypervisor(self):
        self.hypervisor._migrateVirtualMachines({ self: hypervisor })


    # ip(s) attributes

    def _getIp(self):
       #find the public nic
       nic = utils.find(lambda x: x.get('ismanagement') == 0, self._restattrs['nics'])
       if nic:
          return RESTResource.resourceForURI('/resources/subnets/%d/ips/%d' % (nic['subnetid'], nic['ipaddressid']))
       else:
          return self._getIps()[0]
      
    def _getIps(self):
		return tuple([ RESTResource.resourceForURI('/resources/subnets/%d/ips/%d' % (nic['subnetid'], nic['ipaddressid'])) for nic in self._restattrs['nics'] if nic['ipaddressid'] ])


    # migrationtargets attribute

    def _getMigrationtargets(self):
        return self.hypervisor._getMigrationTargets().get(str(self.id))


    # scripts attribute

    def _getScripts(self):
        scripts = http.get('%s/virtualMachineScripts' % self.uri)
        return utils.map(scripts, lambda s: prettify.PrettyDict(s))
    
    def _getScripthistory(self):
        scripts = http.get('%s/virtualMachineScriptStatus' % self.uri)
        for script in scripts:
            scriptStatus = script.get('scriptstatus', [])
            for temp in scriptStatus:
                logs = temp.get('logs', [])
                temp['logs'] = [RESTResource.resourceForURI('/resources/scriptLogDownload/%s/%s' % (temp['id'],  log['logfile']), log) for log in logs]
        return utils.map(scripts, lambda s: prettify.PrettyDict(s))
    

    @classmethod
    def _restname(cls):
        return 'virtualMachine'
    

    # public methods

    def clone(self, count=1, **options):
        'RM09624'

        dict =  {"clonevmid": self.id, "desiredcount": count}

        if options.has_key('password'):
            dict.update({'password':options.get('password')})

        ipaddress = options.get('ipaddress')
        if isinstance(ipaddress, str) or isinstance(ipaddress, unicode):
            ipaddress = [ ipaddress ]

        if ipaddress:
            dict['addresses'] = [ { 'ipaddress': ipaddr } for ipaddr in ipaddress ]

            hostname = options.get('hostname')
            if isinstance(hostname, str) or isinstance(hostname, unicode):
                hostname = [ hostname ]

            if hostname:
                for addr in dict['addresses']:
                    if len(hostname) > 0:
                        addr['hostname'] = hostname.pop(0)
            
        uri = self.uri[0:self.uri.rfind('/')]
        resp = http.postJSON(uri, dict)
        return [ RESTResource.resourceForURI('%s/%s' % (uri, vmid)) for vmid in resp ]

    def delete(self):
        'RM09053'
        http.delete(self.uri)


    def start(self):
        'RM09124'
        self.desiredstatus = 'RM01006' # Status.STARTED


    def stop(self):
        'RM09125'
        self.desiredstatus = 'RM01011' # Status.STOPPED
        
    def executeScript(self, d):
        'RM10034'
        scriptId = d.get('script').get('scriptId')
        username = d.get('username')
        password = d.get('password')
        parameters = d.get('parameters', {})
        if username:
           validators.string(username, 'usernmame')
           parameters['adminusername'] = username
        if password:
           validators.string(password, 'password')
           parameters['adminpassword'] = password
        url = "%s/virtualMachineScripts/%s" %(self.uri, scriptId)
        return utils.utos(http.postJSON(url, parameters))
        
@utils.classinit      
class ScriptLog(CommonAttributes):
    
    @classmethod
    def _classinit(cls):
        cls._registerURI(r'\A/resources/scriptLogDownload/(?P<id>\d+)/(?P<name>[\w\d\.\_\-]+)\Z')
        
        cls._defineRESTAttribute('logfile', '', readonly=True)
        cls._defineRESTAttribute('created', '', readonly=True)
        cls._defineRESTAttribute('updated', '', readonly=True)
        cls._methodHelp('download')
    #TODO: need a message
    def download(self, path = None):
        doclose = False
        if not path:
            f = self.logfile
        else:
            if not os.path.isdir(path):
                os.mkdir(path)
            f = os.path.join(path, self.logfile)
        
        f = file(f, 'wb')
        doclose = True
        http.get(self.uri, responseHandler = utils.curryFunction(utils.getResponseHandler, f))
        if doclose:
            f.close()
        return self.logfile

@utils.classinit
class VirtualMachines(RelatedResourceCollection):
    'RM09049'


    @classmethod
    def _classinit(cls):
        cls._contains(VirtualMachine)
        cls._methodHelp('__contains__', 'delete', '__delitem__',
                        '__getattr__', '__getitem__', '__iter__',
                        '__len__', 'list', '__repr__',
                        '__rshift__', '__str__', '__unicode__')


    def _create(self, dict):
        raise TypeError('virtual machines cannot be manually defined')


    @classmethod
    def _restname(cls):
        return 'virtualMachines'
