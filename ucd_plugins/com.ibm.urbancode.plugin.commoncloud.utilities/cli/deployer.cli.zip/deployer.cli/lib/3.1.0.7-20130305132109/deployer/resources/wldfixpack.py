"""
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2012. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication odr disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
"""

# this is the workload maintenance code added for use in Sparta (tier1db, pureData)


from deployer import utils, validators, messages, http, prettify
from relationships import RelatedResource, RelatedResourceCollection
from commonattrs import CommonAttributes
from deployer.messages import message
from deployer.resources.restresource import RESTResource

################################################################
#
################################################################        
@utils.classinit
class wldFixPack(RelatedResource, CommonAttributes):
    'RM32100'
    @classmethod
    def _classinit(cls):
        cls._registerURI(r'\A/admin/resources/all_fixpacks/')    
        cls._defaultRESTAttrs(True)
        cls._defineRESTAttribute('id', 'RM32102', readonly=True, visible=[ lambda application: application._restattrs.has_key('id') ])
        cls._defineRESTAttribute('fix_pack_type', 'RM32103', readonly=True, visible=[ lambda application: application._restattrs.has_key('fix_pack_type') ])
        cls._defineRESTAttribute('url', 'RM32090', restname='id', readonly=True)
        cls._defineRESTAttribute('description', 'RM32091', restname='description_text', readonly=True)
        cls._defineRESTAttribute('short_description', 'RM32092', restname='short_description_text', readonly=True)
        cls._defineRESTAttribute('size', 'RM32093', readonly=True)
        cls._defineRESTAttribute('unique_size', 'RM32094', readonly=True)
        cls._defineRESTAttribute('state', 'RM32095', readonly=True)
        cls._defineRESTAttribute('created_time', 'RM32096', readonly=True)
        cls._defineRESTAttribute('updated_time', 'RM32097', readonly=True)
        cls._defineRESTAttribute('version', 'RM32098', readonly=True)
        cls._defineRESTAttribute('components', 'RM32099', readonly=True, elided=True)
        cls._methodHelp('apply', 'retry', 'check', 'rollback');

    def __init__(self, uri, attrs):
        super(wldFixPack, self).__init__(uri, attrs)   

    @classmethod
    def _restname(cls):
        return 'all_fixpacks/?fix_pack_type=ifw'      

    @classmethod
    def _restPrefix(cls):
        return "/admin"

    def apply(self, f):
        'RM32140'
        required_parameters = ['pureScaleInstanceName','components_list']
        missing = []
        for parameter in required_parameters:
            if not parameter in f:
                missing.append(parameter)
        if missing:
            raise ValueError(utils.utos(message('RM09366', missing)))
        if 'outage_time' not in f:
            outage_time = 0
        else:
            outage_time = f.get('outage_time')
        if 'option' not in f:
            option = 'parallel'
        else:
            option = f.get('option')   

        found = 0
        db2instance_name = f.get('pureScaleInstanceName')
        inst_list = http.get('/resources/pureScaleInstances/')
        for obj in inst_list:
            if (obj.get("pureScaleInstanceName") == db2instance_name) :
                db2instance_id = obj.get('id')
                found = 1
                break
        
        if not found:
            raise ValueError(utils.utos(message('RM32150', db2instance_name)))

        json = {
                "db2instance_id": db2instance_id, 
                "fixpack_id": self.id.split('/')[-1],
                "components_list": f.get('components_list'),
                "outage_time": outage_time,
                "option": option
            }

        return utils.utos(prettify.PrettyDict(http.postJSON('/admin/resources/wlr_fixpack_job', json)))
        
    @staticmethod
    def retry(f):
        'RM32141'
        return utils.utos(prettify.PrettyDict(http.putJSON('/admin/resources/wlr_fixpack_job/%s' % f, {'id':f} )))

    
    @staticmethod
    def check(db2instance_name):
        'RM32142'

        found = 0
        inst_list = http.get('/resources/pureScaleInstances/')
        for obj in inst_list:
            if (obj.get("pureScaleInstanceName") == db2instance_name) :
                db2instance_id = obj.get('id')
                found = 1
                break
        
        if not found:
            raise ValueError(utils.utos(message('RM32150', db2instance_name)))
        
        json = http.get('/admin/resources/db2inst_info/?db2instance_id=%s' % db2instance_id)
        #result = []
        #result['Instance Overall States'] = json.get('db2inst_overall_states')
        #json.pop('Instance Overall States')
        #result['Fixpack Update Info']=json.get('wl_fixpack_updateinfo')
        print utils.utos(prettify.prettify(json))
        
    @staticmethod
    def rollback(db2instance_name):
        'RM32146'
        
        inst_get = http.get('/resources/pureScaleInstances/')
        instances = []
        for obj in inst_get:
            instances.append(obj.get("pureScaleInstanceName"))
        if not db2instance_name in instances:
            raise ValueError(utils.utos(message('RM32150', db2instance_name)))

        json = http.postJSON('/admin/resources/instance_rollback',{'instance' : db2instance_name} )
        print utils.utos(prettify.prettify(json))

    def delete(self):
        'RM09053'
        componentURI = '/admin/resources/wl_fixpacks/%s' % self.id.split('/')[-1]
        http.delete('%s' % (componentURI))

    @staticmethod
    def fixPackDelete(id):
        'RM32143'
        json = http.delete('/admin/resources/wl_fixpacks/%s' % id)
        print utils.utos(prettify.prettify(json))

    @staticmethod
    def upload(d):
        'RM32144'
        if not isinstance(d, dict):
            raise ValueException(utils.utos(message('RM32110', d)))
        else: 
            d = utils.stou(d)

            if not d.has_key('access_type'):
                d['access_type'] = 'scp'             

            validators.enum(['scp', 'url'], d.get('access_type'), 'access_type')
            validators.string(d.get('remote_username'), 'remote_username')
            validators.string(d.get('remote_password'), 'remote_password')

            if d['access_type'] == 'scp':
               validators.string(d.get('remote_ipaddress'), 'remote_ipaddress')
               validators.string(d.get('remote_path'), 'remote_path')

               json = http.postJSON("/admin/resources/wl_fixpacks/",{"remote_ipaddress": d['remote_ipaddress'],"remote_port":d['remote_port'],"remote_username":d['remote_username'],"remote_password":d['remote_password'],"remote_path":d['remote_path'],"access_type":"scp"})

            else:
               validators.string(d.get('remote_url'), 'remote_url')
               json = http.postJSON("/admin/resources/wl_fixpacks/", {"remote_url": d['remote_url'],"remote_username":d['remote_username'],"remote_password":d['remote_password'],"access_type":"url"})

            print utils.utos(prettify.prettify(json))
            
    def _getComponents(self):
        'RM32111'                     
        if self._restattrs.has_key('fix_pack_type') and (self._restattrs['fix_pack_type'] == 'ifw'):
            componentURI = '/admin/resources/wl_fixpacks/%s?resolvechildren=2' % self.id.split('/')[-1]
            #componentURI=self.id
            comp = http.get(componentURI)
            #return utils.utos(comp);
            instances = comp.get('wl_fixpack_detail')
            print utils.utos(prettify.prettify(instances[0].get('wl_fixpack_components')))
            #[RESTResource.resourceForURI(json['wl_fixpack_detail'], json) for json in instances]
        else:
            print None
            
################################################################
#
################################################################        
@utils.classinit
class wldFixPacks(RelatedResourceCollection):
    'RM32101'

    @classmethod
    def _classinit(cls):
        cls._contains(wldFixPack)
        cls._methodHelp('listApplicable')

    @classmethod
    def _restname(cls):
        return 'all_fixpacks'      

    @classmethod
    def _restPrefix(cls):
        return "/admin"

    def _list(self, filter={}):
        filter['fix_pack_type'] = "ifw"
        return super(wldFixPacks, self)._list(filter)
 

    @staticmethod
    def listApplicable(db2instance_name):                            
        'RM32109'                     
        found = 0
        inst_list = http.get('/resources/pureScaleInstances/')
        for obj in inst_list:
            if (obj.get("pureScaleInstanceName") == db2instance_name) :
                db2instance_id = obj.get('id')
                found = 1
                break
        
        if not found:
            raise ValueError(utils.utos(message('RM32150', db2instance_name)))
        
        json=http.get('/admin/resources/wl_applicable_fixpacks/?db2instance_id=' + db2instance_id) 
        return utils.utos(json)     
                
            
