#
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2012. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
#
"""
Licensed Materials - Property of IBM
IBM WebSphere CloudBurst Appliance (9235-72X)
Copyright IBM Corporation 2011. All Rights Reserved.
US Government Users Restricted Rights - Use, duplication or disclosure
restricted by GSA ADP Schedule Contract with IBM Corp.
"""

import deployer
from cloud import Cloud
from deployer import utils, validators, http, prettify, applicationutils
from restresource import RESTResource, RESTResourceCollection
from relationships import RelatedResource, RelatedResourceCollection
from commonattrs import CommonAttributes
from deployer.messages import Helpable
import urllib
import purescaleutils
from deployer import mappingutils
import os

@utils.classinit
class Application(RelatedResource, CommonAttributes):
    'RM09697'

    @classmethod
    def _classinit(cls):
        cls._registerURI(r'\A/resources/applicationPatterns/(?P<app_id>[\dabcdef\-]+)\Z')
        cls._defaultRESTAttrs(True)
        cls._getParams({ 'details': True })

        cls._defineAttribute('acl', 'RM09830', readonly=True, readonlydoc=False, elided=True)
        cls._defineRESTAttribute('app_name', 'RM09700', readonly=True, visible=[ lambda application: application.app_name != None ])
        cls._defineRESTAttribute('app_id', 'RM09701', readonly=True, visible=[ lambda application: application.app_id != None ])
        cls._defineRESTAttribute('content_md5', 'RM09702', readonly=True, visible=[ lambda application: application.content_md5 != None ])
        cls._defineRESTAttribute('content_type', 'RM09703', readonly=True, visible=[ lambda application: application.content_type != None ])
        cls._defineRESTAttribute('create_time', 'RM09704', readonly=True, visible=[ lambda application: application.create_time != None ])
        cls._defineRESTAttribute('creator', 'RM09705', readonly=True, visible=[ lambda application: application.creator != None ])
        cls._defineRESTAttribute('last_modifier', 'RM09706', readonly=True, visible=[ lambda application: application.last_modifier != None ])
        cls._defineRESTAttribute('last_modified', 'RM09707', readonly=True, visible=[ lambda application: application.last_modified != None ])
        cls._defineRESTAttribute('app_type', 'RM09783', readonly=True, visible=[ lambda application: application.app_type != None ])
        cls._defineRESTAttribute('access_rights', 'RM09740', readonly=True, visible=[ lambda application: application.access_rights != None ])
        cls._defineRESTAttribute('version', 'RM09836', readonly=True, visible=[ lambda application: application.version != None ])
        cls._defineRESTAttribute('patterntype', 'RM09887', readonly=True, visible=[ lambda application: application.patterntype != None ])

        cls._methodHelp('__contains__', '__delattr__', 'delete', '__eq__',
                        '__hash__', 'isStatusTransient', '__nonzero__',
                        'refresh', '__repr__', '__str__', '__unicode__',
                        'clone','shareuser', 'sharegroup', 'update', 'download', 'deploy', 'listConfig')

    @classmethod
    def _restname(cls):
        return 'applicationPattern'
    
    def listConfig(self):
        'RM09994'
        return applicationutils.listConfig(self.uri)

    def clone(self, app_name, app_type='application'): 
        'RM09745'     
        app_name = purescaleutils.userInputChecker(app_name, 'str')
        app_type = purescaleutils.userInputChecker(app_type, 'str')
        newApp = 'app_name=%s&app_type=%s' % (urllib.quote(app_name), app_type)
        applicationsURI = self.uri[0:self.uri.rfind('/')]
        json = http.postJSON('%s/?source=%s&%s' % (applicationsURI, self.app_id, newApp), "")
        return RESTResource.resourceForURI('%s/%s' % (applicationsURI, json['app_id']))

    def shareuser(self, accessID, accessRights):
        'RM09746'
        accessID = purescaleutils.userInputChecker(accessID, 'str')
        accessRights = purescaleutils.userInputChecker(accessRights, 'str')
        http.putJSON('%s/accessRights/%s?user' % (self.uri, accessID), {'accessRights': accessRights})
        
    def sharegroup(self, accessID, accessRights):
        'RM09747'
        accessID = purescaleutils.userInputChecker(accessID, 'str')
        accessRights = purescaleutils.userInputChecker(accessRights, 'str')
        http.putJSON('%s/accessRights/%s?group' % (self.uri, accessID), {'accessRights': accessRights})

    def update(self, f):
        'RM09748'
        if isinstance(f, unicode) or isinstance(f, str) and os.path.isfile(f):
            lowerFileName = f.lower()
            
            if lowerFileName.endswith('.zip'):
                contentType = 'application/zip'
            elif lowerFileName.endswith('.json'):
                contentType = 'application/json'
            else:
                purescaleutils.fileTypeErrorIndicator()
            f = file(f, 'rb')
            try:
                http.restChunked(self.uri, f, 'PUT', contentType)
            finally:
                f.close()
            return self.refresh()
        else:
            purescaleutils.fileTypeErrorIndicator()

    def deploy(self, depl_name, cloudGroupObj, certFile = None, params = None):
        'RM09751'
        depl_name = purescaleutils.userInputChecker(depl_name, 'str')
        resourceUrl = '%s/virtualApplications' % (self.uri)
        deploymentOptions = {'deployment_name':depl_name,'cloud_group':'','ssh_keys':[''] }
        
        if utils.isIPAS():
            if isinstance(cloudGroupObj, dict):
                options = purescaleutils.extractDeployOptions(cloudGroupObj)
                deploymentOptions.update(options)
            else:
                purescaleutils.objTypeErrorIndicator()
        else:
            cloudGroupObj = mappingutils.getMappingResource(cloudGroupObj)
        
            if isinstance(cloudGroupObj, Cloud):
                cloudGroupID = str(cloudGroupObj.id)
                deploymentOptions['cloud_group'] = cloudGroupID
                
            elif isinstance(cloudGroupObj, dict):
                options = purescaleutils.extractDeployOptions(cloudGroupObj)
                deploymentOptions.update(options)
                
            else:
                purescaleutils.objTypeErrorIndicator()

       
        if certFile != None:
            deploymentOptions['ssh_keys'] = purescaleutils.getSSHKeys(certFile)
        
        if params != None and isinstance(params, dict):
            deploymentOptions['parameters'] = params
            
        json = http.postJSON(resourceUrl, deploymentOptions)
        return purescaleutils.JSON2VirtualAppObj(json)
        
            
    def _deployResponse(self, json):
        depl_id = json["deployment_id"]
        single_depl_uri = '/resources/virtualApplications/?id=%s' % (depl_id)
        depl_json = http.get(single_depl_uri)[0]
        depl_uri = '/resources/virtualApplications/%s' % (depl_id)
        return RESTResource.resourceForURI(depl_uri, depl_json)

    def download(self, f):
        'RM09749'
        if isinstance(f, unicode) or isinstance(f, str):
            lowerFileName = f.lower()
            if lowerFileName.endswith('.zip'):
                uri = '%s?zip' % self.uri
            elif lowerFileName.endswith('.json'):
                uri = '%s?model' % self.uri
            else:
                purescaleutils.fileTypeErrorIndicator()
            f = file(f, 'wb')
            try:
                http.get(uri, responseHandler=utils.curryFunction(utils.getResponseHandler, f))
            finally:
                f.close()
        else:
            purescaleutils.fileTypeErrorIndicator()
            

    def getFixes(self):
        'RM10053'
        json = http.get('%s/fixes' % self.uri)
        return utils.utos(json)
            

@utils.classinit
class Applications(RelatedResourceCollection):
    'RM09693'

    @classmethod
    def _classinit(cls):
        cls._contains(Application)
        cls._methodHelp('__contains__', 'create', 'delete', '__delitem__',
                        '__getattr__', '__getitem__', '__iter__',
                        '__len__', 'list', '__lshift__', '__repr__',
                        '__rshift__', '__str__', '__unicode__',
                        'get')

    @classmethod
    def _restname(cls):
        return 'applicationPatterns'

    def delete(self, app_id):
        'RM09016'
        app_id = purescaleutils.userInputChecker(app_id, 'str')
        http.delete('%s/%s' % (self.uri, app_id))

    def create(self, d, name = None):
        'RM09015'
        if isinstance(d, dict):
            utf8filt = d.copy()
            for k in utf8filt:
                if isinstance(utf8filt[k], str) or isinstance(utf8filt[k], unicode):
                    utf8filt[k] = utf8filt[k].encode('utf-8')

            customizedAttrs = '?' + urllib.urlencode(utf8filt)
            json = http.postJSON('%s/%s' % (self.uri, customizedAttrs), "")
            return RESTResource.resourceForURI(self._uriForResource(json))

        elif isinstance(d, unicode) or isinstance(d, str) and os.path.isfile(d):
            lowerFileName = d.lower()
            
            if lowerFileName.endswith('.zip'):
                contentType = 'application/zip'
            elif lowerFileName.endswith('.json'):
                contentType = 'application/json'
            else:
                purescaleutils.fileTypeErrorIndicator()
            uri = self.uri
            if name != None:
               uri += "?app_name=" + urllib.quote(name)
            f = file(d, 'rb')
            try:
                json = http.restChunked(uri, f, 'POST', contentType)
                return RESTResource.resourceForURI(self._uriForResource(json))
            finally:
                f.close()
        else:
            purescaleutils.inputTypeErrorIndicator()

    def get(self, app_id):
        'RM09750'
        app_id = purescaleutils.userInputChecker(app_id, 'str')
        return RESTResource.resourceForURI('%s/%s' % (self.uri, app_id))
    
    def getFixes(self, app_id):
        'RM10053'
        json = http.get('%s/%s/fixes' % (self.uri, app_id))
        return utils.utos(json)

    def _getDefaultSearchField(self):
        return 'app_name'

    def _uriForResource(self, attrs):
        return '%s/%s' % (self.uri, attrs['app_id'])
