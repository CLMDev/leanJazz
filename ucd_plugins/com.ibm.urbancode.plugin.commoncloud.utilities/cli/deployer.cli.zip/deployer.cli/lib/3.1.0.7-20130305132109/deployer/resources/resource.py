"""
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2012. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
"""

from deployer.messages import Helpable, message
from deployer import prettify, utils, validators, wizard
import inspect
import java
import java.text
import os


dateFormatter = java.text.DateFormat.getDateTimeInstance()


class Resource(Helpable):
    """A generic resource with attributes

    The Resource class defines basic behaviors of a resource with
    attributes.  Subclasses are expected to provide the actual
    storage and retrieval mechanisms for attribute values.
    """


    @classmethod
    def _defineAttribute(cls, name, doc, **options):
        """Define a new attribute for the class.

        A property is added to the class for the new attribute.  The
        getter function for the new property is determined as follows:

           1. the function supplied by the fget option, if supplied
           2. None if writeonly is True
           3. the _get<Name> method, if defined for the class

        The setter and deleter functions are determined similarly,
        except the fset and fdel options are considered in step 1, the
        readonly option is considered in step 2 and _set<Name> and
        _del<Name> are used in step 3.

        This method returns the name of the attribute.


        Arguments:

        name -- name for the new attribute
        doc -- docstring for the new attribute, if the value starts
           with 'RM' or 'IWD' it is assumed to be a message is localized


        Keyword arguments:

        elided - Boolean value indicating this the value for this
           attribute should be elided in the string representation of
           objects.  Default is False (value will be shown), although
           this is further refined by logic in __repr__.

        fdel - Specifies an instance method that can be used to
           delete this attribute.  See above for description of how
           value is deleted when fdel is not supplied.

        fget - Specifies an instance method that returns the value to
           be used for this attribute.  See above for description of
           how value is obtained when fget is not supplied.

        fset - Specifies an instance method that can be used to set a
           value for this attribute.  See above for description of how
           value is set when fset is not supplied.

        readonly - Boolean value indicating that the attribute is
           read-only. The docstring will be annotated to reflect this
           unless readonlydoc is False.  If not specified, defaults to
           False (attribute is read/write).

        readonlydoc - Boolean value indicating if the docstring for
           read-only attributes should be annotated.  Defaults to
           True.

        validator - A function to be used to validate values for this
           attribute.  When the attribute is set, the validator is
           invoked as validator(newvalue, name).  If newvalue is
           unacceptable, the validator should raise a ValueError that
           will be propagated back to the caller.  Default is no
           validation of values.

        values - A list of valid values for this attribute.  If
           supplied, a validator is automatically constructed that
           rejects attempts to set this attribute to any value not in
           the list.  Default is no list of valid values.

        visible - A list of functions that controls whether this
           attribute is displayed.  When instances of this class are
           displayed, each of the functions will be invoked as
           visible(self).  The attribute will be shown iff all
           functions in this list return a true value.  Default is an
           empty list (attribute is always visible).

        writeonly - Boolean value indicating the attribute is
           write-only.  The docstring will be annotated to reflect
           this.  Defaults to False (attribute is read/write).
        """

        if doc.startswith('RM') or doc.startswith('IWD'):
            doc = message(doc)
        if options.get('readonly', False):
            if options.get('readonlydoc', True):
                doc += message('RM09129')
        if options.get('writeonly', False):
            doc += message('RM09261')
        if options.has_key('fget'):
            fget = options.get('fget')
        elif options.get('writeonly', False):
            fget = None
        elif hasattr(cls, '_get' + utils.capitalize(name)):
            fget = getattr(cls, '_get' + utils.capitalize(name))
        else:
            raise SystemError, "no fget for attribute %s of class %s" % (name, cls.__name__)

        if options.has_key('fset'):
            fset = options.get('fset')
        elif options.get('readonly', False):
            fset = None
        elif hasattr(cls, '_set' + utils.capitalize(name)):
            fset = getattr(cls, '_set' + utils.capitalize(name))
        else:
            raise SystemError, "no fset for attribute %s of class %s" % (name, cls.__name__)

        if options.has_key('fdel'):
            fdel = options.get('fdel')
        elif options.get('readonly', False):
            fdel = None
        elif hasattr(cls, '_del' + utils.capitalize(name)):
            fdel = getattr(cls, '_del' + utils.capitalize(name))
        else:
            fdel = None

        setattr(cls, name, property(fget=fget, fset=fset, fdel=fdel, doc=doc))

        # add special property to retrieve doc
        setattr(cls, name + '_', property(fget=utils.curryMethod(cls._getClassProperty, name), doc=doc))


        # suppress getattr() and force ellipsis in __unicode__
        if options.get('elided', False):
            try:
                cls._ELIDEDINSTR_.append(name)
            except AttributeError:
                cls._ELIDEDINSTR_ = [ name ]


        # suppress getattr() and force write-only message in __unicode__
        if options.get('writeonly', False):
            try:
                cls._WRITEONLY_.append(name)
            except AttributeError:
                cls._WRITEONLY_ = [ name ]


        # add to list of properties shown by help logic
        cls._propertyHelp(name)


        if options.has_key('values'):
            # TODO - needed?  for wizard maybe?
            try:
                cls._VALUES_[name] = options['values']
            except AttributeError:
                cls._VALUES_ = { name: options['values'] }

            options['validator'] = utils.curryFunction(validators.enum, options['values'])


        if options.has_key('validator'):
            try:
                cls._VALIDATORS_[name] = options['validator']
            except AttributeError:
                cls._VALIDATORS_ = { name: options['validator'] }


        if options.has_key('visible'):
            try:
                cls._VISIBLE_[name] = options['visible']
            except AttributeError:
                cls._VISIBLE_ = { name: options['visible'] }


        return name
        
    # TODO - validatorName needed?
    def _validate(self, name, value, validatorName=None):
        """Runs any validator specified for the attr against value.

        name - name of the attribute
        value - value to be validated
        validatorName - attribute name to pass to validator, defaults to name
        """

        try:
            self.__class__._VALIDATORS_[name](value, validatorName or name)
        except AttributeError:
            pass
        except KeyError:
            pass


    @classmethod
    def _wizardStep(cls, attr, **options):
        """Generates a wizard step for the specified attribute
        """

        step = {
            'name': attr,
            'help': getattr(cls, attr).__doc__
        }

        try:
            step['validator'] = cls._VALIDATORS_[attr]
        except AttributeError:
            pass
        except KeyError:
            pass

        step.update(options)
        return step


    def _getClassProperty(self, name):
        return getattr(self.__class__, name)


    # public methods

    def __contains__(self, item):
        'RM09051'

        return isinstance(item, str) and hasattr(self.__class__, item) and isinstance(getattr(self.__class__, item), property)


    # TODO - this is technically wrong - repr should either be the
    # inverse of eval() or return a string of the form
    # "<...message...>" if that is not possible.  Unfortunatley this
    # implementation is what generates the pretty output for the
    # interactive CLI:
    #
    # >>> deployer.xxx()
    # {
    #    "attribute": "value",
    #    ...
    # }
    def __repr__(self):
        'RM09059'
        return utils.utos(unicode(self))


    def __str__(self):
        'RM09060'
        return utils.utos(unicode(self))


    def __unicode__(self):
        'RM09060'

        strattrs = {}
        elided = self.__class__.__dict__.get('_ELIDEDINSTR_', [])
        writeOnly = self.__class__.__dict__.get('_WRITEONLY_', [])
        visible = self.__class__.__dict__.get('_VISIBLE_', {})

        for (name, member) in inspect.getmembers(self.__class__):
            # skip everything that's not a property
            if not isinstance(member, property):
                continue

            # skip any properties whose visibility checks say to do so
            if not utils.all(visible.get(name, []), lambda visCheck: visCheck(self)):
                continue

            # skip special help properties
            if name.endswith('_'):
                continue

            # don't call getattr() if attr is elided
            if name in elided:
                strattrs[name] = prettify.NESTED_OBJECT

            # write-only attrs don't have readable values
            elif name in writeOnly:
                strattrs[name] = prettify.WRITE_ONLY

            else:
                value = getattr(self, name)

                # pretty strings for date/time
                if name == 'created' or name == 'updated':
                    strattrs[name] = prettify.UnquotedString(dateFormatter.format(value * 1000))

                # basic string representations for simple types
                elif value is None or isinstance(value, int) or isinstance(value, long) or isinstance(value, float) or isinstance(value, str) or isinstance(value, unicode):
                    strattrs[name] = value

                # '(nested object)' for more complex things
                else:
                    strattrs[name] = prettify.NESTED_OBJECT

        if prettify.enabled:
            return prettify.prettify(strattrs)
        else:
            return unicode(strattrs)



class ResourceCollection(Helpable):
    'RM09138'

    @classmethod
    def _contains(cls, contains):
        """Indicates the class associated with Resources in this collection.
        """
        cls._CONTAINS_ = contains


    # methods that need to be overridden by subclasses

    def _add(self, other):
        raise NotImplementedError('_add')


    def _create(self, dict):
        raise NotImplementedError('_create')


    def _delete(self, id):
        raise NotImplementedError('_delete')


    def _list(self, filt = None):
        raise NotImplementedError('_list')


    def _remove(self, id):
        raise NotImplementedError('_remove')


    # private methods

    # TODO - needed?  move to RESTResourceCollection?
    @classmethod
    def _cliname_going(cls):
        '''Returns the name of this type of resource collection as known in CLI-land.  Return value will be plural and lowercase.'''
        return java.lang.String(cls.__name__).toLowerCase(java.util.Locale.ENGLISH)


    def _defaultSearch(self, s):
        """Performs the default search for resources in this collection.
        """
        defaultField = self._getDefaultSearchField()
        result = self._list({ defaultField: s })
        result.sort(lambda r1, r2: utils.exactMatchCmp(getattr(r1, defaultField), getattr(r2, defaultField), s))
        return result

    def _getDefaultSearchField(self):
        return 'name'

    # TODO - used for what?
    @classmethod
    def _definePassthrough_going(cls, method, docstring=None):
        m = utils.curryMethod(method)
        if docstring:
            m.__doc__ = docstring
        cls.__dict__[method.__name__] = m


    @classmethod
    def _verifyResourceType(cls, res):
        """Raises a TypeError if res is not the correct type of resource
        for this collection.
        """

        if not isinstance(res, cls._CONTAINS_):
            raise TypeError(type(res))



    # public methods

    def add(self, other):
        'RM09014'

        # <rescoll>.add([ ... ])
        if isinstance(other, list):
            for o in other:
                self.add(o)

        else:
            self._verifyResourceType(other)
            self._add(utils.stou(other))


    def __contains__(self, item):
        'RM09013'
        return utils.any(self._list(), lambda it: it == item)


    def create(self, other):
        'RM09015'

        # <rescoll>.create({ ... })
        if isinstance(other, dict):
            return self._create(utils.stou(other))

        # <rescoll>.create([ ... ])
        elif isinstance(other, list):
            return [ self.create(o) for o in other ]

        # <rescoll>.create('<filename>')
        elif (isinstance(other, str) or isinstance(other, unicode)) and os.path.isfile(other):
            json = utils.readJSON(other)

            if (json):
                return self.create(json)

            return None

        # <rescoll>.create(deployer.wizard)
        elif inspect.isclass(other) and issubclass(other, wizard.Wizard):
            return self.create(other())

        # <rescoll>.create(<wizard>)
        elif isinstance(other, wizard.Wizard):
            try:
                return self.create(other(*self.__class__.CREATE_ATTRIBUTES))
            except EOFError, e:
                print e
                return None

        raise TypeError('unsupported operand type for create: %s' % type(other))


    def delete(self, other):
        'RM09017'

        # <rescoll>.delete(<number>)
        if isinstance(other, int) or isinstance(other, long):
            self._delete(other)

        # <rescoll>.delete(<Resource>)
        else:
            self._verifyResourceType(other)
            self._delete(other.id)

        return None


    def __delitem__(self, key):
        'RM09016'

        # if subclass defined _remove(), call that
        if self.__class__._remove != ResourceCollection._remove:
            return self.remove(key)

        # otherwise, pass to _delete()
        else:
            return self.delete(key)


    def __getattr__(self, name):
        'RM09018'

        if name.startswith('_') and name.endswith('_'):
            raise AttributeError(name)

        return self._defaultSearch(utils.stou(name))


    def __getitem__(self, key):
        'RM09019'

        # int key -> get by index
        if isinstance(key, int) or isinstance(key, long):
            if key >= 0:
                return self._list({ 'count': key + 1 })[key]
            else:
                return self._list()[key]

        # str key -> defer to __getattr__
        elif isinstance(key, str) or isinstance(key, unicode):
            return self.__getattr__(key)

        raise TypeError('unsupported operand type for __getitem__: %s' % type(key))


    def __iter__(self):
        'RM09020'
        return iter(self._list())


    def __len__(self):
        'RM09021'
        return len(self._list())


    def list(self, filt = {}):
        'RM09022'
        # logging.debug('ResourceCollection.list: %s' % str(filt))
        return self._list(utils.stou(filt))


    def __lshift__(self, other):
        'RM09023'

        # if subclass defined _add(), call that
        if self.__class__._add != ResourceCollection._add:
            return self.add(other)

        # otherwise, pass to _create()
        else:
            return self.create(other)


    def remove(self, other):
        'RM09024'

        # <rescoll>.remove(<number>)
        if isinstance(other, int) or isinstance(other, long):
            self._remove(other)

        # <rescoll>.remove(<Resource>)
        else:
            self._verifyResourceType(other)
            self._remove(other.id)

        return None


    def __repr__(self):
        'RM09027'
        return utils.utos(unicode(self))


    def __rshift__(self, other):
        'RM09025'
        return self.__delitem__(other)


    def __str__(self):
        'RM09026'
        return repr(self)


    def __unicode__(self):
        'RM09026'

        if prettify.enabled:
            return prettify.prettify(self._list())
        else:
            return unicode(self._list())
