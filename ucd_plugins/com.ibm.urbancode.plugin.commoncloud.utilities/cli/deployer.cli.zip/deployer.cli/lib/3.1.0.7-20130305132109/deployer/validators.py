"""
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2012. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
"""
import java
import re

from messages import message
from utils import utos


def boolean(o, name):
    if o is True or o is False or isinstance(o, java.lang.Boolean):
        return

    raise ValueError(utos(message('RM09436', name, repr(o))))


def enum(values, o, name):
    if o in values:
        return

    s = ','.join([repr(t) for t in values])
    raise ValueError(utos(message('RM09363', name, s, repr(o))))


def instance(cls, o, name):
    if isinstance(o, cls):
        return

    raise ValueError(utos(message('RM09364', name, cls.__name__)))


def integer(o, name):
    if isinstance(o, int) or isinstance(o, long):
        return

    raise ValueError(utos(message('RM09372', name, repr(o))))


def integerrange(min, max, o, name):
    if o in xrange(min, max+1):
        return

    raise ValueError(utos(message('RM09371', name, str(min), str(max + 1), repr(o))))


def floatrange(min, max, o, name):
    if isinstance(o, int) or isinstance(o, long) or isinstance(o, float):
        if o >= min and o <=max:
            return

    raise ValueError(utos(message('RM09371', name, str(min), str(max), repr(o))))


def ipaddress(o, name):
    if isinstance(o, str) or isinstance(o, unicode):
        m = re.compile(r'^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$').match(o)
        if m and int(m.group(1)) <= 255 and int(m.group(2)) <= 255 and int(m.group(3)) <= 255 and int(m.group(4)) <= 255:
            return

    raise ValueError(utos(message('RM09251', name, repr(o))))


def ip6address(o, name):
    if isinstance(o, str) or isinstance(o, unicode):
        # Crude test, allowing real validation to take place in REST call
        if o.count(":") > 1:
            return

    raise ValueError(utos(message('RM09638', name, repr(o))))

def allipaddress(o, name):
    ex = None
    try:
        ipaddress(o, name)
        return
    except ValueError, e:
        ip6address(o, name)
        return
        ex = e
    if ex != None:
        raise ex
        
def nonnegativeinteger(o, name):
    if isinstance(o, int) or isinstance(o, long):
        if o >= 0:
            return

    raise ValueError(utos(message('RM09190', name, repr(o))))


def noop(o, name):
    return


def optional(validator2, o, name):
    if o is None:
        return

    validator2(o, name)


def optionalipaddress(o, name):
    if o is None:
        return

    allipaddress(o, name)


def positiveinteger(o, name):
    if isinstance(o, int) or isinstance(o, long):
        if o > 0:
            return

    raise ValueError(utos(message('RM09365', name, repr(o))))


def string(o, name):
    if isinstance(o, str) or isinstance(o, unicode):
        return

    raise ValueError(utos(message('RM09362', name, repr(o))))

def version(o, name):
    if isinstance(o, str) or isinstance(o, unicode):
        m = re.compile(r'^((\d{1,})(\.{,1}))+(-\d{1,})?$').match(o)
        if m :
            return

    raise ValueError(utos(message('RM09566', name, repr(o))))
