"""
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2012. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
"""

from commonattrs import CommonAttributes
from deployer import utils, validators
from relationships import RelatedResource, RelatedResourceCollection
from restresource import RESTResource, RESTResourceCollection


@utils.classinit
class Maintenance(RelatedResource, CommonAttributes):
    'RM09468'


    @classmethod
    def _classinit(cls):
        cls._registerURI(r'\A/resources/instances/\d+/maintenances/(?P<id>\d+)\Z')

        cls._defineRESTAttribute('id', 'RM09462', readonly=True)
        cls._defineRESTAttribute('currentstatus', 'RM09487', readonly=True)
        cls._defineRESTAttribute('currentstatus_text', 'RM09156', readonly=True)
        cls._defineRESTAttribute('fixes', 'RM09464', readonly=True)

        cls._methodHelp('__contains__', '__delattr__', 'delete', '__eq__',
                        '__hash__', 'isStatusTransient', '__nonzero__',
                        'refresh', '__repr__', '__str__', '__unicode__',
                        'waitFor')
        
    def _getFixes(self):
        fixes = self._restattrs['fixes']
        return [RESTResource.resourceForURI('/resources/fixes/%d' % fix['fixid']) for fix in fixes]




@utils.classinit
class Maintenances(RelatedResourceCollection):
    'RM09465'


    @classmethod
    def _classinit(cls):
        cls._contains(Maintenance)
        cls._methodHelp('__contains__', 'create', 'delete', '__delitem__',
                        '__getattr__', '__getitem__', '__iter__',
                        '__len__', 'list', '__lshift__', '__repr__',
                        '__rshift__', '__str__', '__unicode__')


    # TODO - this is broken...
    # CREATE_ATTRIBUTES = [
    # ]


    def _create(self, dict):
        if dict.has_key('starttime'):
            dict['starttime'] = dict['starttime'] * 1000

        return super(Maintenances, self)._create(dict)
