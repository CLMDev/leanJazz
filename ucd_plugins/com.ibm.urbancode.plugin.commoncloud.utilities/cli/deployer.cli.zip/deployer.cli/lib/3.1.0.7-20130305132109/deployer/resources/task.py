"""
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2012. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
"""

from commonattrs import CommonAttributes
from deployer import utils, validators
from relationships import RelatedResource, RelatedResourceCollection


@utils.classinit
class Task(RelatedResource, CommonAttributes):
    'RM10001'


    @classmethod
    def _classinit(cls):
        cls._registerURI(r'\A/resources/tasks/(?P<id>\d+)\Z')

        cls._defineRESTAttribute('created', 'RM10002', readonly=True)
        cls._defineRESTAttribute('currentstatus', 'RM10003', readonly=True)
        cls._defineRESTAttribute('currentstatus_text', 'RM09156', readonly=True)
        #cls._defineRESTAttribute('event', 'RM09552', readonly=True)
        cls._defineRESTAttribute('id', 'RM10004', readonly=True)
        cls._defineRESTAttribute('name', 'RM10005', validator=validators.string)

        cls._methodHelp('__contains__', '__delattr__', 'delete', '__eq__',
                        '__hash__', 'isStatusTransient', '__nonzero__',
                        'refresh', '__repr__', '__str__', '__unicode__',
                        'waitFor')




@utils.classinit
class Tasks(RelatedResourceCollection):
    'RM10000'


    @classmethod
    def _classinit(cls):
        cls._contains(Task)
        cls._methodHelp('__contains__', 'delete', '__delitem__',
                        '__getattr__', '__getitem__', '__iter__',
                        '__len__', 'list', '__lshift__', '__repr__',
                        '__rshift__', '__str__', '__unicode__')


    def _create(self, other):
        raise TypeError(message('RM09652'))
