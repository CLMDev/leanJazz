#
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2012. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
#
from deployer import http, messages, utils, validators
from deployer.resources.localresource import LocalResource


class Dns(object):
    '''RM09380'''
   
    _PROPERTYHELP_ = ['servers', 'server']
    
    @utils.classinit
    class Server(LocalResource):
        '''RM09387'''


        @classmethod
        def _classinit(cls):
            cls._defineAttribute('ipaddress', 'RM09384', validator=validators.allipaddress)


        def _localSetAttr(self, name, value):
            super(Dns.Server, self)._localSetAttr(name, value)
            Dns.Servers().save()


    class _Servers(list):
        URI = '/resources/appliance/dnsServers'
        
        def __init__(self):
            self._initData()

        def _initData(self):
            while self:
                self.pop(ignore_save=True)
            if not self:
                self.extend(http.get(self.URI), ignore_save=True)
        
        def refresh(self):
            self._initData()

        def addSave(func):
            def newfunc(self, *args, **kw):
                l = []
                for ele in args:
                    if isinstance(ele, list):
                        newEle = utils.map(ele, lambda x: Dns.Server(x))
                    elif isinstance(ele, dict):
                        o = utils.find(lambda x: x.ipaddress == ele.get('ipaddress'), self)
                        newEle = o if o!= None else Dns.Server(ele)
                    elif isinstance(ele, Dns.Server) or isinstance(ele, int):
                        newEle = ele
                    else:
                        raise utils.utos(messages.message('RM09385'))
                    l.append(newEle)
                    
                func(self, *tuple(l))
                if not kw.get('ignore_save'):
                    self.save()
            return newfunc
        
        def save(self):
            http.putJSON(self.URI, utils.map(self, lambda server: server._localattrs))
                
        append = addSave(list.append)
        extend = addSave(list.extend)
        insert = addSave(list.insert)
        pop = addSave(list.pop)
        remove = addSave(list.remove)
        reverse = addSave(list.reverse)
        sort = addSave(list.sort)
        __setslice__ = addSave(list.__setslice__)
        __delslice__ = addSave(list.__delslice__)
        __setitem__ = addSave(list.__setitem__)
        __delitem__ = addSave(list.__delitem__)
    
    Servers = utils.MakeSingleton(_Servers)
    _servers = None    
    def _getDnsServers(self):
        if self._servers:
            self._servers.refresh()
        else:
            self._servers = Dns.Servers()
        return self._servers

    def servers_(self):
        '''RM09386'''
        pass

    server = Server
    servers = property(_getDnsServers)
