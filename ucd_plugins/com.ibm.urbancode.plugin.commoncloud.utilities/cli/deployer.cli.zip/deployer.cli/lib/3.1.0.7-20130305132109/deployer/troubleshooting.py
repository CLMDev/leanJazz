"""
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2012. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
"""
import com.ibm.json.java.JSONArray
import com.ibm.json.java.JSONObject
import consoleio
import logging
import os
import http
import java
import prettify
import time
import utils

from utils import utos

class Diagnostics(object):
    'RM09343'
    
    _METHODHELP_ = [
        'get'
    ]
    

    def _getResponseHandler(self, f, resp):
        if resp.status > 299:
            raise IOError(utos(resp.reason))

        s = resp.read(100000)

        while s:
            f.write(s)
            s = resp.read(100000)


    def get(self, path = 'trace.zip'):
        'RM09344'
        f = file(path, 'wb')
        http.get('/resources/trace.zip', responseHandler=utils.curryMethod(self._getResponseHandler, f))
        f.close()

    def getLatest(self, path = 'trace.zip'):
        'RM09344'
        f = file(path, 'wb')
        http.get('/resources/trace.zip?latest', responseHandler=utils.curryMethod(self._getResponseHandler, f))
        f.close()

class LogFile(object):

    def _tail(self, file, lines):
        uri = http.postNoContent('/resources/logViewerMgr?logfile=%s' % file)
        uri = uri.replace('^', '%5E')  # REST API returns log file name with caret as a path separator
        content = http.get('%s?standalone=true&lineCount=-%d' % (uri, lines))
        print utos(content['TAIL_CONTENT'])


class TraceFile(LogFile):
    'RM09345'
    
    _METHODHELP_ = [
        'add', 'remove', 'set', 'spec', 'tail'
    ]

    
    def add(self, package, level = 'OFF'):
        'RM09346'
        http.postJSON('/resources/traceSpec', {'logger': package})
        self.set(package, level)

    
    def remove(self, package):
        'RM09347'
        http.delete('/resources/traceSpec/%s' % package)

    
    def set(self, package, level):
        'RM09348'
        http.putJSON('/resources/traceSpec/%s' % package, {'level': level})

    
    def spec(self):
        'RM09349'
        return http.get('/resources/traceSpec')
    

    def tail(self, lines = 10):
        'RM09350'
        self._tail('trace/trace.log', lines)
    

class ErrorFile(LogFile):
    'RM09351'
    
    _METHODHELP_ = [
        'tail'
    ]

    def tail(self, lines = 10):
        'RM09350'
        self._tail('error/error.log', lines)


class Audit(object):
    'RM09484'
    
    _METHODHELP_ = [
        'get'
    ]
          
    def get(self, f, start=None, end=None, size=None, tz=None, uuid=None):
        'RM09485'
        
        doclose = False
            
        if isinstance(f, str) or isinstance(f, unicode):
            if not java.lang.String(f).toLowerCase(java.util.Locale.ENGLISH).endswith('.zip'):
                f = f + '.zip'
            f = file(f, 'wb')
            doclose = True
       
        defaultMaxSize = 20000
        if size is None or size > defaultMaxSize:
            size = defaultMaxSize

        parms = []

        if start:
            parms.append('utcstart=%d' % long(start * 1000))
        if end:
            parms.append('utcend=%d' % long(end * 1000))
        if size:
            parms.append('size=%d' % int(size))
        if tz:
            parms.append('timezone=%s' % str(tz))

        # If uuid is present it is mutually exclusive with time or size params
        if uuid:
            uri = '/resources/audit.zip/%s' % str(uuid)
        elif parms:
            uri = '/resources/audit.zip?%s' % '&'.join(parms)
        else:
            uri = '/resources/audit.zip'
            
        http.get(uri, responseHandler=utils.curryFunction(utils.getResponseHandler, f))
            
        if doclose:
            f.close()
            
    def post(self, map=None, hash=None):
        'RM09485'
        logging.debug('<<< audit.post: entered >>>')
        
        # N.B. params are order dependent, i.e. they need to be entered in the order above.
        # N.B. If you want Windows file names to work then specify them with forward slashes
        #      e.g. "C:/temp/audit-event-record-IDs"
        
        # Set the map file name
        if map is None: 
           map = 'audit-events-record-IDs'
           
        # Open the map file
        map = os.path.normpath(map)
        try:
            mapfile = open(map)
        except IOError:
            print 'Map file does not exist'
            
        # Set the hash file name
        if hash is None:
           hash = 'audit-events-signed-record-IDs'
           
        # Open the hash file
        hash = os.path.normpath(hash)
        try:
            hashfile = open(hash)
        except IOError:
            print 'Hash file does not exist'

        # Read both files
        recordIDs = mapfile.read()
        signature = hashfile.read()
        mapfile.close()
        hashfile.close()
        
        # Create the params for the http request
        logging.debug('<<< audit.post: creating json params >>>') 
        parms = {'eventIDList':recordIDs,'eventIDListSignature':signature} 
        
        # Set the URI
        self.uri = '/resources/audit.zip'
        
        # Call http.  Everything important will be in the log.
        logging.debug('<<< audit.post: calling http >>>') 
        json = http.postJSON(self.uri,parms)
        logging.debug('<<< audit.post: exiting >>>')

class LicPVU(object):
    'RM09545'
    
    _METHODHELP_ = [
        'get'
    ]
          
    def get(self, f, start=None, end=None, tz=None):
        'RM09485'
        
        doclose = False
            
        if isinstance(f, str) or isinstance(f, unicode):
            if not java.lang.String(f).toLowerCase(java.util.Locale.ENGLISH).endswith('.zip'):
                f = f + '.zip'
            f = file(f, 'wb')
            doclose = True

        parms = []

        if start:
            parms.append('utcstart=%d' % long(start * 1000))
        if end:
            parms.append('utcend=%d' % long(end * 1000))
        if tz:
            parms.append('timezone=%s' % str(tz))

        # If uuid is present it is mutually exclusive with time or size params
        if parms:
            uri = '/resources/licpvu.zip?%s' % '&'.join(parms)
        else:
            uri = '/resources/licpvu.zip'
            
        http.get(uri, responseHandler=utils.curryFunction(utils.getResponseHandler, f))
            
        if doclose:
            f.close()

    
#
#   F U T U R E 
#
#class AuditPkg(object):
#    'RM09484'
#    
#    _METHODHELP_ = [
#        'get'
#    ]
#          
#    def get(self, f, start=None, end=None, size=None, tz=None, uuid=None):
#        'RM09485'
#        
#        doclose = False
#            
#        if isinstance(f, str) or isinstance(f, unicode):
#            if not java.lang.String(f).toLowerCase(java.util.Locale.ENGLISH).endswith('.zip'):
#                f = f + '.zip'
#            f = file(f, 'wb')
#            doclose = True
#            
#        defaultMaxSize = 20000
#
#        parms = []
#
#        if start:
#            parms.append('utcstart=%d' % long(start * 1000))
#        if end:
#            parms.append('utcend=%d' % long(end * 1000))
#        if size:
#            parms.append('size=%d' % int(size))
#        if tz:
#            parms.append('timezone=%s' % str(tz))
#
        # If uuid is present it is mutually exclusive with time or size params
#        if uuid:
#            uri = '/resources/auditpkg.zip/%s' % str(uuid)
#        elif parms:
#            uri = '/resources/auditpkg.zip?%s' % '&'.join(parms)
#        else:
#            uri = '/resources/auditpkg.zip'
#            
#        http.get(uri, responseHandler=utils.curryFunction(utils.getResponseHandler, f))
#            
#        if doclose:
#            f.close()
#
#    _METHODHELP_ = [
#        'post'
#    ]
#            
#    def post(self):
#        'RM09485'
#        logging.debug('<<< auditpkg.post: entered >>>')
#        
#        # N.B. params are order dependent, i.e. they need to be entered in the order above. 
#        
#        parms = []
#        
#        # Set the URI
#        self.uri = '/resources/auditpkg.zip'
#        
#        # Call http.  Everything important will be in the log.
#        logging.debug('<<< auditpkg.post: calling http >>>') 
#        json = http.postJSON(self.uri,parms)
#        logging.debug('<<< auditpkg.post: exiting with returned value: %s >>>' % str(utos(json)))
#        uuid = json.get('result')
#        print '    UUID of audit record package is %s' % str(uuid)
#        
     