"""
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2012. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
"""

from addon import AddOn
from commonattrs import CommonAttributes
from deployer import http, utils, validators
from deployer.messages import message, Helpable
import java
from relationships import RelatedResource, RelatedResourceCollection
from restresource import RESTResource
from script import Script, Scripts


@utils.classinit
class Pscript(RelatedResource, CommonAttributes):
    'RM09094'


    @classmethod
    def _classinit(cls):
        cls._registerURI(r'\A/resources/patterns/\d+/pparts/\d+/pscripts/(?P<id>\d+)\Z')

        # info verified with Michael Kalantar/Bill Arnold, 2009Apr03 3pm
        cls._defineRESTAttribute('description', 'RM09207', validator=validators.string)
        cls._defineAttribute('executionOrder', 'RM09208')
        cls._defineRESTAttribute('id', 'RM09209', readonly=True)
        cls._defineRESTAttribute('isdeletable', 'RM09212', readonly=True)
        cls._defineRESTAttribute('label', 'RM09210', readonly=True)
        cls._defineAttribute('parameters', 'RM09211', readonly=True)
        # resourcetype - hidden
        cls._defineAttribute('startsafter', 'RM09802', elided=True)
        cls._defineRESTAttribute('type', 'RM09213', readonly=True)
        cls._defineRESTAttribute('key', 'RM10051', readonly=True, defaultToNone=True)

        cls._methodHelp('__contains__', '__delattr__', 'delete', '__eq__',
                        '__hash__', 'isStatusTransient', '__nonzero__',
                        'refresh', '__repr__', '__str__', '__unicode__',
                        'waitFor',
                        'getParameter', 'setParameter')


    # executionOrder attribute

    def _getExecutionorder(self):
        return int(self._restattrs['executionOrder'])


    def _setExecutionorder(self, value):
        validators.nonnegativeinteger(value, 'executionOrder')
        self._restattrs['executionOrder'] = unicode(value)


    # parameters attribute

    def _getParameters(self):
        result = []
        for param in self._restattrs['parameters']:
            if param['userConfigurable'] or not param['locked']:
                # fix string/boolean mismatch
                copy = param.copy()
                copy['isPropagated'] = copy['isPropagated'] == 'true'
                result.append(copy)

        return result


    # startsAfter attribute
    @utils.classinit
    class StartsAfter(Helpable):
        'RM09803'

        @classmethod
        def _classinit(cls):
            cls._methodHelp('__contains__', '__delitem__', '__getitem__',
                            '__iadd__', '__isub__', '__iter__', '__len__',
                            '__lshift__', '__repr__', '__rshift__',
                            '__str__', '__unicode__')


        def __init__(self, pscript):
            self.pscript = pscript

        # private methods

        def _anyLink(self, l):
            return utils.any(self._oclinks(), l)

 
        def _checkPscript(self, ps, verifyExecMode=False):
            result = isinstance(ps, Pscript) and ps.part.pattern == self.pscript.part.pattern and ps.type == 'APPLICATION'

            if result and verifyExecMode:
                result = RESTResource.resourceForURI('/resources/scripts/%s' % str(ps._restattrs['scriptId'])).execmode == Script.VIRTUAL_SYSTEM_CREATION_EXECMODE

            return result


        def _oclinks(self):
            return self.pscript._restattrs['orderingConstraintlinks']

        def _pscript(self, link):
            uriRoot = self.pscript.uri[:self.pscript.uri.rfind('/pparts/')]
            return RESTResource.resourceForURI('%s/pparts/%d/pscripts/%d' % (uriRoot, link['targetPartId'], link['targetScriptId']))


        # public methods

        def __contains__(self, item):
            'RM09804'

            if not self._checkPscript(item):
                return False

            return self._anyLink(lambda link: link['targetPartId'] == item.part.id and link['targetScriptId'] == item.id)


        def __delitem__(self, key):
            'RM09805'

            validators.integerrange(0, len(self._oclinks()) - 1, key, 'key')

            newoclinks = list(self._oclinks())
            del newoclinks[key]
            http.putJSON(self.pscript.uri, { 'orderingConstraintlinks': newoclinks })
            self.pscript._restattrs.markdirty()


        def __getitem__(self, key):
            'RM09806'

            validators.integerrange(0, len(self._oclinks()) - 1, key, 'key')
            return self._pscript(self._oclinks()[key])


        def __iadd__(self, other):
            'RM09807'

            if isinstance(other, list):
                for r in other:
                    self.__iadd__(r)

            else:
                if not self._checkPscript(other, True):
                    raise ValueError(other)

                if not self._anyLink(lambda link: link['targetPartId'] == other.part.id and link['targetScriptId'] == other.id):
                    http.putJSON(self.pscript.uri, { 'orderingConstraintlinks': self.pscript._restattrs['orderingConstraintlinks'] + [ { 'targetPartId': other.part.id, 'targetScriptId': other.id } ] })
                    self.pscript._restattrs.markdirty()

            return self


        def __isub__(self, other):
            'RM09808'

            if isinstance(other, list):
                for r in other:
                    self.__isub__(r)

            else:
                if not self._checkPscript(other):
                    raise ValueError(other)

                newoclinks = [ link for link in self._oclinks() if link['targetPartId'] != other.part.id or link['targetScriptId'] != other.id ]
                if len(newoclinks) == len(self._oclinks()):
                    raise ValueError(other)

                http.putJSON(self.pscript.uri, { 'orderingConstraintlinks': newoclinks })
                self.pscript._restattrs.markdirty()

            return self


        def __iter__(self):
            'RM09809'
            return iter([ self._pscript(link) for link in self._oclinks() ])


        def __len__(self):
            'RM09810'
            return len(self._oclinks())


        def __lshift__(self, other):
            'RM09811'
            return self.__iadd__(other)


        def __repr__(self):
            'RM09812'
            return utils.utos(unicode(self))


        def __rshift__(self, other):
            'RM09813'
            return self.__isub__(other)


        def __str__(self):
            'RM09812'
            return repr(self)


        def __unicode__(self):
            'RM09812'
            return unicode(list(self))


    def _getStartsafter(self):
        try:
            return self._startsAfter
        except AttributeError:
            self._startsAfter = Pscript.StartsAfter(self)
            return self._startsAfter


    def _setStartsafter(self, value):
        if value != self._startsAfter:
            raise AttributeError("can't set attribute")


    # public methods

    def getParameter(self, key, wantMetadata=False):
        'RM09095'

        param = utils.find(lambda p: p['key'] == key, self._getParameters())

        if wantMetadata:
            return param
        else:
            return param['defaultvalue']


    def setParameter(self, key, defaultvalue=None, **metadata):
        'RM09096'

        param = self.getParameter(key, True)

        metadata = metadata.copy()

        metadata['key'] = key

        if not metadata.has_key('defaultvalue'):
            metadata['defaultvalue'] = defaultvalue

        # this is just sad...
        if metadata.has_key('userConfigurable'):
            metadata['userConfigurable'] = java.lang.Boolean(metadata['userConfigurable'])

        if metadata.has_key('locked'):
            metadata['locked'] = java.lang.Boolean(metadata['locked'])

        if metadata.has_key('isPropagated'):
            if metadata['isPropagated']:
                metadata['isPropagated'] = 'true'
            else:
                metadata['isPropagated'] = 'false'

        http.putJSON(self.uri, { 'parameters': [ metadata ] })
        self.refresh()




def _scriptChoices(wizard, answers, attrs):
    i = 1
    result = []
    for script in Scripts():
        result.append((unicode(i), script.name, script.id))
        i = i + 1

    return result




@utils.classinit
class Pscripts(RelatedResourceCollection):
    'RM09039'


    @classmethod
    def _classinit(cls):
        cls._contains(Pscript)
        cls._methodHelp('__contains__', 'create', 'delete', '__delitem__',
                        '__getattr__', '__getitem__', '__iter__',
                        '__len__', 'list', '__lshift__', '__repr__',
                        '__rshift__', '__str__', '__unicode__')


    CREATE_ATTRIBUTES = [
        { 'name': 'id', 'prompt': 'script', 'required': True, 'help': message('RM09223'), 'choices': _scriptChoices }
    ]


    def create(self, other):
        'RM09040'

        if isinstance(other, int) or isinstance(other, long):
            return self.create({ 'id': other })

        elif isinstance(other, Script) or isinstance(other, AddOn):
            return self.create({ 'id': other.id })

        else:
            return super(Pscripts, self).create(other)
        
    def _list(self, filt = {}):
        result =  super(Pscripts, self)._list(filt)
        return utils.filterRestResult(result, filt)
    
    def _getDefaultSearchField(self):
        return 'label'
