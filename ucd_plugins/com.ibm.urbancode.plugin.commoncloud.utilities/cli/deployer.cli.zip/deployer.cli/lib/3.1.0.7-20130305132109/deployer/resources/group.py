"""
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2012. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
"""

from commonattrs import CommonAttributes
from deployer import http, utils, validators
from relationships import RelatedResource, RelatedResourceCollection
from restresource import RESTResource


@utils.classinit
class Group(RelatedResource, CommonAttributes):
    'RM09073'


    @classmethod
    def _classinit(cls):
        cls._registerURI(r'\A/resources/groups/(?P<id>\d+)\Z')

        cls._defineRESTAttribute('created', 'RM09144', readonly=True)
        cls._defineRESTAttribute('description', 'RM09145', validator=validators.string)
        cls._defineRESTAttribute('id', 'RM09146', readonly=True)
        cls._defineRESTAttribute('name', 'RM09147', validator=validators.string, readonly=True)
        cls._defineAttribute('roles', cls.Roles.__doc__, validator=validators.noop)
        cls._defineRESTAttribute('updated', 'RM09148', readonly=True)

        cls._methodHelp('__contains__', '__delattr__', 'delete', '__eq__',
                        '__hash__', 'isStatusTransient', '__nonzero__',
                        'refresh', '__repr__', '__str__', '__unicode__',
                        'waitFor')



    class Roles(object):
        'RM09424'

        ROLES = [ object(), object(), 'CLOUD_USER', 'CLOUD_ADMIN',
                  'APPLIANCE_ADMIN', 'CATALOG_CREATOR', 'PATTERN_CREATOR', 'ILMT_USER',
                  'CLOUD_ADMIN_READONLY', 'APPLIANCE_ADMIN_READONLY','PROFILE_CREATOR',
                  'REPORT_READONLY', object(), 'AUDIT_READONLY', 'AUDIT', 'HARDWARE']

        def __init__(self, group):
            self.group = group


        def __iadd__(self, other):
            'RM09425'

            if isinstance(other, list):
                for r in other:
                    self.__iadd__(r)

            else:
                try:
                    http.postJSON('%s/roles/%d' % (self.group.uri, self.ROLES.index(other)), {})
                except ValueError:
                    raise ValueError('%s not a recognized role' % other)

            return self


        def __isub__(self, other):
            'RM09426'

            if isinstance(other, list):
                for r in other:
                    self.__isub__(r)

            else:
                try:
                    http.delete('%s/roles/%d' % (self.group.uri, self.ROLES.index(other)))
                except ValueError:
                    raise ValueError('%s not a recognized role' % other)

            return self


        def __iter__(self):
            'RM09427'
            json = http.get('%s/roles' % self.group.uri)
            return iter([ self.ROLES[r] for r in range(0, len(self.ROLES)) if r in json and isinstance(self.ROLES[r], str)])


        def __lshift__(self, other):
            'RM09428'
            self.__iadd__(other)


        def __repr__(self):
            'RM09431'
            return utils.utos(unicode(self))


        def __rshift__(self, other):
            'RM09429'
            self.__isub__(other)


        def __str__(self):
            'RM09430'
            return repr(self)


        def __unicode__(self):
            'RM09430'
            return unicode(list(self))


    def __init__(self, uri, attrs = None):
        super(Group, self).__init__(uri, attrs)
        self._roles = self.__class__.Roles(self)


    def _getRoles(self):
        return self._roles


    def _setRoles(self, value):
        if value != self._roles:
            raise AttributeError("can't set attribute")



@utils.classinit
class Groups(RelatedResourceCollection):
    'RM09029'

    @classmethod
    def _classinit(cls):
        cls._contains(Group)
        cls._methodHelp('__contains__', 'create', 'delete', '__delitem__',
                        '__getattr__', '__getitem__', '__iter__',
                        '__len__', 'list', '__lshift__', '__repr__',
                        '__rshift__', '__str__', '__unicode__',
                        'everyone')


    CREATE_ATTRIBUTES = [
        Group._wizardStep('name'),
        Group._wizardStep('description')
    ]


    def everyone(self):
        'RM09030'
        return RESTResource.resourceForURI('%s/1' % self.uri)
