"""
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2012. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
"""

import codecs
import http
import java
import logging
import os.path
import utils
import version


class ServerMessageResolver(object):
    def __init__(self):
        self.messages = {}
        self.msgfilename = None

        
    def resolve(self, key, locale=None):
        l = locale or java.util.Locale.getDefault()
        
        pieces = [ l.getLanguage() ]
        if l.getCountry():
            pieces.append(l.getCountry())
        if l.getVariant():
            pieces.append(l.getVariant())
        msgfilename = version.getVersionAsIdentifier('server_%s_' % '_'.join(pieces))

        if self.msgfilename != msgfilename:
            try:
                p = java.util.Properties()
                istrm = java.io.FileInputStream(os.path.join(utils.libDir(), 'deployer', 'messages', msgfilename + '.properties'))
                p.load(istrm)
                istrm.close()

                for k in p.keySet():
                    self.messages[k] = p.getProperty(k) + u''

                self.msgfilename = msgfilename

            except java.lang.Exception,e:
                # .properties file missing, load from server

                msgs = http.get('/resources/messages')

                p = java.util.Properties()
                p.putAll(msgs)

                ostrm = java.io.FileOutputStream(os.path.join(utils.libDir(), 'deployer', 'messages', msgfilename + '.properties'))
                p.store(ostrm, '')
                ostrm.close()

                self.messages = {}
                self.messages.update(msgs)

                self.msgfilename = msgfilename


        return self.messages.get(key)
