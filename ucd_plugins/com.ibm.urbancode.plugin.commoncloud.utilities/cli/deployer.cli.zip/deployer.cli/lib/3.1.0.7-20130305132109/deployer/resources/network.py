"""
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2012. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
"""

from commonattrs import CommonAttributes
from deployer import http, utils, validators
from relationships import RelatedResource, RelatedResourceCollection


@utils.classinit
class Network(RelatedResource, CommonAttributes):
    'RM09082'


    @classmethod
    def _classinit(cls):
        cls._registerURI(r'\A/resources/networks/(?P<id>\d+)\Z')

        cls._defineRESTAttribute('created', 'RM09171', readonly=True)
        cls._defineRESTAttribute('currentmessage', 'RM09172', readonly=True)
        cls._defineRESTAttribute('currentmessage_text', 'RM09154', readonly=True)
        cls._defineRESTAttribute('id', 'RM09173', readonly=True)
        cls._defineRESTAttribute('name', 'RM09174', validator=validators.string)
        cls._defineRESTAttribute('updated', 'RM09175', readonly=True)
        cls._defineRESTAttribute('vlan', 'RM09176', validator=utils.curryFunction(validators.integerrange, 0, 4095))
        cls._defineRESTAttribute('currentstatus', 'RM09657', readonly=True)
        cls._defineRESTAttribute('currentstatus_text', 'RM09156', readonly=True)
       # cls._defineAttribute('inuse', 'RM09658', values=('T','F'))

        cls._methodHelp('__contains__', '__delattr__', 'delete', '__eq__',
                        '__hash__', 'isStatusTransient', '__nonzero__',
                        'refresh', '__repr__', '__str__', '__unicode__',
                        'waitFor')

@utils.classinit
class Networks(RelatedResourceCollection):
    'RM09034'


    @classmethod
    def _classinit(cls):
        cls._contains(Network)
        cls._methodHelp('__contains__', 'delete', '__delitem__',
                        '__getattr__', '__getitem__', '__iter__',
                        '__len__', 'list', '__lshift__', '__repr__',
                        '__rshift__', '__str__', '__unicode__')


    def _create(self, other):
        raise TypeError('networks cannot be manually defined')
