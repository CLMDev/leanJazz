#
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2012. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
#
import snmp
import community
import trapsubscriber
import trap

snmp = snmp.SNMP()
communities = community.Communities()
community = community.Community
trapsubscribers = trapsubscriber.TrapSubscribers()
trapsubscriber = trapsubscriber.TrapSubscriber
traps = trap.Traps()
trap = trap.Trap