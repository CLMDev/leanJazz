"""
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2012. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
"""

import jarray
import java
import os.path
import sys
import time
import inspect
import urllib

#in multi-thread environment, encode method  dynamically imports respective codec py file, 
#which may bring in race condition. Add some dummy codes to load required modules at startup.
try:
    "".encode(sys.registry.get('deployer.console.encoding') or sys.stdin.encoding)
except:
    pass

# json functions

def readJSON(path):
    file = open(path)
    
    json = '\n'.join(file.readlines())
    return eval(json)



# collection functions

def all(seq, func = lambda it: it):
    result = True
    
    for x in seq:
        result = func(x)
        if not result:
            return result

    return result


def any(seq, func = lambda it: it):
    result = None
    
    for x in seq:
        result = func(x)
        if result:
            return result

    return result


def map(seq, func = lambda it: it):
    result = []
    
    for x in seq:
        result.append(func(x))
    
    return result


def exactMatchCmp(s1, s2, value):
    if s1 == value:
        if s2 == value:
            return 0
        else:
            return -1
    elif s2 == value:
        return 1
    else:
        return cmp(s1, s2)

    
def find(func, seq):
    for x in seq:
        if func(x):
            return x

    return None

    
def findAll(func, seq):
    return [x for x in seq if func(x)]



# currying functions

def curryFunction(func, *curryargs):
    return lambda *callargs: func(*(curryargs + callargs))


def curryMethod(meth, *curryargs, **curryopts):
    if meth.im_self:
        # meth is already bound
        return lambda *callargs: meth(*(curryargs + callargs), **curryopts)
    else:
        # meth is unbound, assume self supplied on call
        return lambda self, *callargs: meth(self, *(curryargs + callargs), **curryopts)



# string functions

def englishlc(s):
    """Returns the string lowercased using English locale
    """

    return java.lang.String(s).toLowerCase(java.util.Locale.ENGLISH)


def singularize(s):
    if s.lower().endswith('s'):
        return s[0:-1]

    raise ValueError(s)


def pluralize(s):
    if s.lower() == 'storage':
        return s

    elif s.upper() == s:
        return s + 'S'

    else:
        return s + 's'


def stou(o):
    """Accepts an object with Python plain strings (bytes in locale-specific encoding) and returns the equivalent Python unicode object."""

    if isinstance(o, str):
        # let Java interpret bytes using native encoding
        return java.lang.String(jarray.array(o, 'b')).toString()

    elif isinstance(o, list):
        return [stou(item) for item in o]

    elif isinstance(o, dict):
        result = {}
        for k in o:
            result[stou(k)] = stou(o[k])
        return result

    else:
        return o


def utos(o):
    """Converts a object with Python unicode objects to the equivalent object with Python plain strings using the JVM's default encoding."""


    if isinstance(o, unicode):
        dce = sys.registry.get('deployer.console.encoding')

        try:
            # force correct codec since Jython is apparently braindead and
            # always tries to use a 7-bit ascii encoding, regardless of
            # user's locale
            # return o.encode(sys.stdout.encoding, 'replace')
            return o.encode(dce or sys.stdin.encoding, 'replace')
        except LookupError:
            # Jython sometimes sets sys.stdout.encoding to a codec it doesn't
            # actually have, so fallback is to let Java do the conversion
            # to bytes then stuff those bytes back into a Jython string
            if dce:
                return str(java.lang.String(java.lang.String(o).getBytes(dce), 0))
            else:
                return str(java.lang.String(java.lang.String(o).getBytes(), 0))

    elif isinstance(o, list):
        return [utos(item) for item in o]

    elif isinstance(o, dict):
        result = {}
        for k in o:
            result[utos(k)] = utos(o[k])
        return result

    else:
        return o



# waitFor

def waitFor(condition, maxWait=-1, interval=10):
    'RM09008'
    
    if maxWait < 0:
        stopTime = sys.maxint
    else:
        stopTime = time.time() + maxWait

    result = condition()

    while not result and time.time() < stopTime:
        # print 'waitFor: current time %d < stop time %d, condition false, sleeping %d seconds' % (time.time(), stopTime, interval)

        time.sleep(interval)

        result = condition()

    return result


def waitForCondition(r, debug):
    try:
        return not r.refresh().isStatusTransientWithDebug(debug)
    except IOError, e:
        #404 error should be ignored after being deleted.
        if 404 == e.errno:
            return True
        else:
            raise e

# miscellaneous functions

def libDir():
    'Returns the full path name of the lib directory from which the CLI is pulling our .py files.'
    return find(lambda dir: os.path.isfile(os.path.join(dir, 'deployer', 'utils.py')), sys.path)


HUMAN_SIZE_PREFIXES = ['', 'K', 'M', 'G', 'T', 'P', 'E', 'Z', 'Y']

def humanSize(x, units=''):
    idx = HUMAN_SIZE_PREFIXES.index(units)

    if x < 9999.5 and idx == 0:
        return ['%.0f' % x, units]

    elif x < 9.995:
        return ['%.2f' % x, units]

    elif x < 99.95:
        return ['%.1f' % x, units]

    elif x < 9999.5:
        return ['%.0f' % x, units]

    elif idx >= len(HUMAN_SIZE_PREFIXES) - 1:
        return [str(int(round(x))), units]

    else:
        return humanSize(x / 1024.0, HUMAN_SIZE_PREFIXES[idx + 1])


def humanSizeBytes(x):
    hs = humanSize(x)

    if hs[1] == '':
        hs[1] = ' bytes'
    else:
        hs[1] = hs[1] + 'B'

    return hs[0] + hs[1]

def getResponseHandler(f, resp):
    if resp.status > 299:
        raise IOError(utos(resp.reason))
    
    s = resp.read(100000)
        
    while s:
        f.write(s)
        s = resp.read(100000)
    
# TODO - do NOT use this, there are much simpler ways to accomplish
# what it does without the convolutedness
class MakeSingleton:
    def __init__(self, klass):
        self.klass = klass
        self.instance = None
        
    def __call__(self, *args, **kw):
        if self.instance is None:
            self.instance = apply(self.klass, args, kw)
        return self.instance


def dump_stack():
   

    print >>sys.stderr, 'call stack:'
    for frame in inspect.stack():
        print >>sys.stderr, '  %s: line %d' % (frame[1], frame[2])



# decorators

# class decorators

def classinit(cls):
    cls._classinit()
    return cls

def uuid(id):
    return id.split('/')[-1]

_isIPAS = None

def isIPAS():
    global _isIPAS
    
    if _isIPAS is None:
        _isIPAS = sys.registry.get('config.ipas') == "true"
    return  _isIPAS 

_isSparta = None

def isSparta():
    global _isSparta
    
    if _isSparta is None:
        _isSparta = sys.registry.get('config.sparta') == "true"
    return  _isSparta  

_isTurkish = None

def isTurkish():
    global _isTurkish
    if _isTurkish is None:
        language = java.util.Locale.getDefault().getLanguage()
        _isTurkish = ("tr" == language)
    return _isTurkish
    
                 
# In turkish, there are 4 kind of i characters. It cannot transform correctly with Python.
def capitalize(s):
    if isTurkish() and (s.startswith('i') or s.startswith('I')):
        return java.lang.String("I").toUpperCase(java.util.Locale.ENGLISH) + java.lang.String(s[1:]).toLowerCase(java.util.Locale.ENGLISH)
    return s.capitalize()

def isString(o):
    return isinstance(o, str) or isinstance(o, unicode)

def filterRestResult(restResult, filt):
    if filt.has_key('count'):
        del filt['count']
    
    if filt:
        def match(r, filt={}):
            isMatch = True
            for key in filt:
                value = getattr(r, key, None)
                filterValue = filt[key]
                if isString(value) and isString(filterValue):
                    isMatch =  filterValue in value
                else:
                    isMatch = filterValue == value
                if not isMatch:
                   return False
            return True
        restResult = findAll(lambda r: match(r, filt), restResult)
        
    return restResult 

def objectToQuery(filt = {}):
    utf8filt = filt.copy()
    for k in utf8filt:
        if isinstance(utf8filt[k], str) or isinstance(utf8filt[k], unicode):
            utf8filt[k] = utf8filt[k].encode('utf-8')
    return urllib.urlencode(utf8filt) 

#allow to specify different help messages for iwd and ipas
def docstring(iwd_doc, ipas_doc):
    def decorator(func):
         if isIPAS():
             func.__doc__ = ipas_doc
         else:
             func.__doc__ = iwd_doc
         return func
    return decorator