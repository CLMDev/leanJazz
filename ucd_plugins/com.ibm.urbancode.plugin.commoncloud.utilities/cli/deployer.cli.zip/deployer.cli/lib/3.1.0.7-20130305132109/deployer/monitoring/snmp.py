#
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2012. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
#

from deployer import http, messages, prettify, utils, validators


class SNMP(object):
    'RM10011'
    
    _PROPERTYHELP_ = ['enabled']
    
    _METHODHELP_ = ['getStatusMIB', 'getNotificationMIB']
    
    URI = '/resources/snmp'
    STATUS_MIB_URI = '/resources/DATAPOWER-STATUS-MIB.txt'
    NOTIFY_MIB_URI = '/resources/IBM-BR-NOTIFICATION-MIB.txt'
    
    def enabled_(self):
        '''RM10012'''
        pass
    
    def _getEnabled(self):
       return http.get(self.URI) != "-1"
       
    def _setEnabled(self, enabled):
       validators.boolean(enabled, "enabled")
       return http.putJSON(self.URI, { "port": 161, "run": enabled })
   
    def getStatusMIB(self, f):
        'RM10009'
        validators.string(f, 'f')
        f = file(f, 'wb')
        doclose = True
        http.get(self.STATUS_MIB_URI, responseHandler=utils.curryFunction(utils.getResponseHandler, f))
        if doclose:
            f.close()
   
    def getNotificationMIB(self, f):
        'RM10010'
        validators.string(f, 'f')
        f = file(f, 'wb')
        doclose = True
        http.get(self.NOTIFY_MIB_URI, responseHandler=utils.curryFunction(utils.getResponseHandler, f))
        if doclose:
            f.close()
            
    enabled = property(_getEnabled, _setEnabled)
#we only need a single instance    
SNMP = utils.MakeSingleton(SNMP)