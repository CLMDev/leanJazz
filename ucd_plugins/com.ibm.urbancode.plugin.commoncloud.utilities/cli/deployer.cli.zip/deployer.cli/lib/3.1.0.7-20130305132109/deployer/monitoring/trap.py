#
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2012. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
#
from deployer.resources.restresource import RESTResource
from deployer.resources.relationships import RelatedResource, RelatedResourceCollection
from deployer.resources.restdict import RESTBackedDict
from deployer import utils, http, validators
from community import Community, Communities
from snmp import SNMP

snmp = SNMP()

@utils.classinit
class Trap(RelatedResource):
    'RM10025'
    
    URI = '/resources/appliance/trapSubscriptions'
    @classmethod
    def _classinit(cls):
         cls._registerURI(r'\A/resources/appliance/trapSubscriptions/(?P<trapCode>.+)\Z')
         cls._defineRESTAttribute('trapCode', 'RM10027', readonly=True)
         cls._defineRESTAttribute('severity', 'RM10028', readonly=True, values=(''))
         cls._defineRESTAttribute('description', 'RM10029', readonly=True)
         cls._defineRESTAttribute('enabled', 'RM10030')
   
    def __init__(self, uri, attrs=None):
        json = {"trapCode": attrs[0], "severity": attrs[1], "description": attrs[2], "enabled": attrs[3]}
        super(Trap, self).__init__(uri, json)
    
    def _setEnabled(self, value):
        
        validators.boolean(value, 'value')
        if self.enabled == value:
           return
        #filterFunc = lambda t: t[0] != self.trapCode and t[3]
        #if value:
        filterFunc = (lambda t: t[3]) if value else (lambda t: t[0] != self.trapCode and t[3])
        traps = utils.findAll(filterFunc, http.get(self.URI))
        traps = utils.map(traps, lambda t: t[0])
        
        if value and self.trapCode not in traps:
           traps.append(self.trapCode)
        json = {"traps": traps, "severity": Traps().trapPriority}
        http.putJSON(self.URI, json)
        super(RESTBackedDict, self._restattrs).update({'enabled': value})
        
        enabled = snmp.enabled
        if enabled:
            snmp.enabled = True  
         
@utils.classinit
class Traps(RelatedResourceCollection):
    'RM10026'
    
    TRAP_SEVERITY_URI = '/resources/appliance/trapSeverity'
    CRITICAL = 'critical'
    ERROR = 'error'
    WARNING = 'warn'
    NOTICE = 'notice'
    INFO = 'info'
    
    _PROPERTYHELP_ = ['trapPriority']
    @classmethod
    def _restname(cls):
        return "appliance/trapSubscriptions"
    
    def _defaultSearch(self, s):
        
        result = self._list()
        result = utils.findAll(lambda sub: sub.trapCode == s, result)
        return result 
    
    @classmethod
    def _classinit(cls):
        cls._contains(Trap)
        
    def _uriForResource(self, attrs):
        return '%s/%s' % (self.uri, attrs[0])
    
    def _setTrapPriority(self, value):
        subscriptions = utils.findAll(lambda r: r[3], http.get(self.uri))
        subscriptions = utils.map(subscriptions, lambda x: x[0])
        json = {"traps": subscriptions, 'severity': value}
        http.putJSON(self.uri, json)
        enabled = snmp.enabled
        if enabled:
            snmp.enabled = True
    
    def _getTrapPriority(self):
        return http.get(self.TRAP_SEVERITY_URI)
    
    def trapPriority_(self):
        'RM10024'
        pass
    
    trapPriority = property(_getTrapPriority, _setTrapPriority)
