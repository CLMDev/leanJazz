"""
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2012. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
"""
import http
import os
from deployer.resources.restresource import RESTResource

class Firmware(object):
    'RM10007'
    _METHODHELP_ = [
        'upgrade'
    ]
    def __lshift__(self, other):
        # TODO - needs doc
        return self.upgrade(other)
    

    def upgrade(self, f):
        'RM10008'
        
        doclose = False

        if isinstance(f, str) or isinstance(f, unicode):
            f = file(f, 'rb')
            doclose = True
        try:
           resp = http.postChunked('/resources/firmware/%s' % os.path.basename(f.name), f)
           if isinstance(resp, dict):
              return RESTResource.resourceForURI('/resources/tasks/%d' % resp['id'])
        finally:
           if doclose:
             f.close()
