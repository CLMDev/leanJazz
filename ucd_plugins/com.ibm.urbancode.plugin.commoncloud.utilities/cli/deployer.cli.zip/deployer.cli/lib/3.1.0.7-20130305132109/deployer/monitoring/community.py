#
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2012. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
#
from deployer.resources.restresource import RESTResource
from deployer.resources.relationships import RelatedResource, RelatedResourceCollection
from deployer import utils, http
from snmp import SNMP

snmp = SNMP()

@utils.classinit
class Community(RelatedResource):
    'RM10013'
    @classmethod
    def _classinit(cls):
        
       cls._registerURI(r'\A/resources/communities/(?P<name>.+)\Z')
       cls._defineRESTAttribute('name', 'RM10015', readonly=True)
       cls._defineRESTAttribute('permissions', 'RM10016', readonly=True, values=('rocommunity','rwcommunity'))
       cls._defineRESTAttribute('network', 'RM10017', readonly=True)
       cls._methodHelp('delete')
       
    def delete(self):
        super(Community, self).delete()
         #If any communities remain and the agent is running, restart it so that the deleted community is no longer valid
        enabled = snmp.enabled
        if len(Communities()) > 0 and enabled:
            snmp.enabled = True
        #If no communities are left, stop the agent        
        elif enabled:
            snmp.enabled = False

 
@utils.classinit   
class Communities(RelatedResourceCollection):
    'RM10014'
    
    CREATE_ATTRIBUTES = [
        Community._wizardStep('name'),
        Community._wizardStep('permissions', values=['rocommunity', 'rwcommunity']),
        Community._wizardStep('network', optional=True)
    ]
    #change the return codes, since there is no REST for GET /resources/communities/<name>
    def _create(self, d, suppressCheck=[]):
        self._checkCreateAttributes(d, suppressCheck)
        json = http.postJSON(self.uri, d)
        #Restart the SNMP agent so that the new community is immediately usable
        snmp.enabled = True
        return RESTResource.resourceForURI(self._uriForResource(json), json)
    
    def _defaultSearch(self, s):
        result = self._list()
        result = utils.findAll(lambda community: community.name == s, result)
        return result 
    
    @classmethod
    def _classinit(cls):
        cls._contains(Community)
        cls._methodHelp('create')
        
    def _uriForResource(self, attrs):
        return '%s/%s' % (self.uri, attrs['name'])  