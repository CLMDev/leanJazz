#
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2012. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
#
import java

from deployer import http, utils
from deployer.resources.restresource import RESTResource

class Security(object):
    '''RM09413'''

    REGISTRATION_URI = '/resources/registration'
    ADMIN_RESET_URI = '/resources/adminReset'
    
    _PROPERTYHELP_ = ['registration', 'adminreset', 'ldap']
    
    def registration_(self):
        '''RM09414'''
        pass

    def _setRegistration(self, isAllowed):
        http.putJSON(self.REGISTRATION_URI, isAllowed)

    def _getRegistration(self):
        return http.get(self.REGISTRATION_URI)

    def adminreset_(self):
        '''RM09415'''
        pass

    def _setAdminReset(self, isAllowed):
        http.putJSON(self.ADMIN_RESET_URI, isAllowed)

    def _getAdminReset(self):
        return http.get(self.ADMIN_RESET_URI)
    
    def _writeResourceToFile(self, uri, f):
        doclose = False
        f = file(f, "wb")
        doclose = True
        http.get(uri, responseHandler=utils.curryFunction(utils.getResponseHandler, f))
        if doclose:
            f.close()

    def getRootCert(self, f=None):
        '''IWD00009'''
        if not f: f = "cert.pem"
        self._writeResourceToFile('/resources/rootcacertificate', f)
        
    def getUserKeys(self, f=None):
        '''IWD00008'''
        if not f: f = "keys.json"
        self._writeResourceToFile('/resources/userKeys', f)
        
    registration = property(_getRegistration, _setRegistration)
    adminreset = property(_getAdminReset, _setAdminReset)

    @utils.classinit
    class Ldap(RESTResource):
        '''RM09416'''

        URI = '/resources/ldap'

        @classmethod
        def _classinit(cls):
            cls._defaultRESTAttrs(True)

            cls._defineRESTAttribute('enabled', 'RM09417')
            cls._defineRESTAttribute('allowLocal', 'RM09636')
            cls._defineRESTAttribute('jndiProviderUrl', 'RM09418')
            cls._defineRESTAttribute('ldapUserIdBaseDn', 'RM09419')
            cls._defineRESTAttribute('ldapGroupBaseDn', 'RM09420')
            cls._defineRESTAttribute('ldapUserIdSearchFilterPattern', 'RM09421')
            cls._defineRESTAttribute('jndiSecurityPrincipal', 'RM09422')
            cls._defineRESTAttribute('jndiSecurityCredentials', 'RM09423', writeonly=True)

            cls._methodHelp('__contains__', '__delattr__', '__eq__', '__hash__',
                            '__nonzero__', 'refresh', '__repr__', '__str__',
                            '__unicode__')

        def __init__(self, uri, attrs = None):
            super(Security.Ldap, self).__init__(uri, attrs)

        def _setEnabled(self, value):
            return self._restSetAttr('enabled', java.lang.Boolean(value))

        def _setAllowlocal(self, value):
            return self._restSetAttr('allowLocal', java.lang.Boolean(value))


Security.ldap = Security.Ldap(Security.Ldap.URI)
