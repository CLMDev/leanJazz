"""
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2012. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
"""

from commonattrs import CommonAttributes
from deployer import http, utils, validators
from relationships import RelatedResource, RelatedResourceCollection
from restresource import RESTResource


@utils.classinit
class User(RelatedResource, CommonAttributes):
    'RM09111'


    @classmethod
    def _classinit(cls):
        cls._registerURI(r'\A/resources/users/(?P<id>\d+)\Z')

        cls._defineRESTAttribute('currentmessage', 'RM09254', readonly=True)
        cls._defineAttribute('currentmessage_text', 'RM09154', readonly=True)
        cls._defineRESTAttribute('currentstatus', 'RM09255', readonly=True)
        cls._defineAttribute('currentstatus_text', 'RM09156', readonly=True)
        cls._defineRESTAttribute('email', 'RM09256', validator=validators.string)
        cls._defineRESTAttribute('fullname', 'RM09258', restname='name', validator=validators.string)
        cls._defineRESTAttribute('id', 'RM09257', readonly=True)
        # name -> fullname
        cls._defineRESTAttribute('password', 'RM09259', writeonly=True, validator=validators.string)
        cls._defineAttribute('roles', cls.Roles.__doc__, validator=validators.noop)
        cls._defineRESTAttribute('username', 'RM09260', validator=validators.string)
        cls._defineRESTAttribute('deploymentoptions', 'RM09654', values=(0,1,2,3,4,5,6,7))
        cls._defineRESTAttribute('type', '', values=['LOCAL', 'LDAP'], defaultToNone=True)

        cls._methodHelp('__contains__', '__delattr__', 'delete', '__eq__',
                        '__hash__', 'isStatusTransient', '__nonzero__',
                        'refresh', '__repr__', '__str__', '__unicode__',
                        'waitFor')

    ALL_DEPLOYMENT_OPTIONS = 0
    CLOUD_ONLY_DEPLOYMENT_OPTION = 1
    ENVIRONMENT_PROFILE_ONLY_DEPLOYMENT_OPTION = 2

    class Roles(object):
        'RM09112'

        ROLES = [ object(), object(), 'CLOUD_USER', 'CLOUD_ADMIN',
                  'APPLIANCE_ADMIN', 'CATALOG_CREATOR', 'PATTERN_CREATOR', 'ILMT_USER',
                  'CLOUD_ADMIN_READONLY', 'APPLIANCE_ADMIN_READONLY' ,'PROFILE_CREATOR',
                  'REPORT_READONLY', object(), 'AUDIT_READONLY', 'AUDIT', 'HARDWARE']

        def __init__(self, user):
            self.user = user


        def __iadd__(self, other):
            'RM09113'

            if isinstance(other, list):
                for r in other:
                    self.__iadd__(r)

            else:
                try:
                    http.postJSON('%s/roles/%d' % (self.user.uri, self.ROLES.index(other)), {})
                except ValueError:
                    raise ValueError('%s not a recognized role' % other)

            return self


        def __isub__(self, other):
            'RM09114'

            if isinstance(other, list):
                for r in other:
                    self.__isub__(r)

            else:
                try:
                    http.delete('%s/roles/%d' % (self.user.uri, self.ROLES.index(other)))
                except ValueError:
                    raise ValueError('%s not a recognized role' % other)

            return self


        def __iter__(self):
            'RM09115'
            json = http.get('%s/roles' % self.user.uri)
            return iter([ self.ROLES[r] for r in range(0, len(self.ROLES)) if r in json and isinstance(self.ROLES[r], str)])


        def __lshift__(self, other):
            'RM09116'
            self.__iadd__(other)


        def __repr__(self):
            'RM09119'
            return utils.utos(unicode(self))


        def __rshift__(self, other):
            'RM09117'
            self.__isub__(other)


        def __str__(self):
            'RM09118'
            return repr(self)


        def __unicode__(self):
            'RM09118'
            return unicode(list(self))


    def __init__(self, uri, attrs):
        super(User, self).__init__(uri, attrs)
        self._roles = self.__class__.Roles(self)


    def _getRoles(self):
        return self._roles


    def _setRoles(self, value):
        if value != self._roles:
            raise AttributeError("can't set attribute")



@utils.classinit
class Users(RelatedResourceCollection):
    'RM09045'

    @classmethod
    def _classinit(cls):
        cls._contains(User)
        cls._methodHelp('__contains__', 'create', 'delete', '__delitem__',
                        '__getattr__', '__getitem__', '__iter__',
                        '__len__', 'list', '__lshift__', '__repr__',
                        '__rshift__', '__str__', '__unicode__',
                        'admin', 'self')


    CREATE_ATTRIBUTES = [
        User._wizardStep('username'),
        User._wizardStep('fullname'),
        User._wizardStep('password', optional=True, password=True),
        User._wizardStep('email'),
        User._wizardStep('type', optional=True)
    ]


    def _create(self, dict):
        # TODO - clean up this crap -- all this info is stored elsewhere

        # validate fullname ahead of time since we're about to rename it
        ca = utils.find(lambda ca: ca['name'] == 'fullname', self.CREATE_ATTRIBUTES)
        if ca and ca.has_key('validator'):
            ca['validator'](dict['fullname'], 'fullname')

        dict['name'] = dict['fullname']
        del dict['fullname']

        return super(Users, self)._create(dict, ['fullname','name'])


    def _defaultSearch(self, s):
        result = self._list({ 'username': s })
        result.sort(lambda r1, r2: utils.exactMatchCmp(r1.username, r2.username, s))
        return result


    def admin(self):
        'RM09341'
        return RESTResource.resourceForURI('%s/1' % self.uri)


    def self(self):
        'RM09046'

        json = http.get('%s/current' % self.uri)
        return RESTResource.resourceForURI('%s/%s' % (self.uri, json['id']), json)
