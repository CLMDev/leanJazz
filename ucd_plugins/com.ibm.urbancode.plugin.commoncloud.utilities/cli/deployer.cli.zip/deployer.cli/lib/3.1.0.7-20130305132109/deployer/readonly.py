"""
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2012. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
"""

class ReadOnlyDict(dict):

    def __init__(self, *args, **kwargs):
        dict.__init__(self, *args, **kwargs)

        self._locked = False
        self._msg = None


    def _attemptedWrite(self, k):
        if self._locked:
            raise AttributeError(self._msg or k)


    def __delitem__(self, key):
        self._attemptedWrite(key)
        dict.__delitem__(self, key)


    def lock(self, msg=None):
        self._msg = msg
        self._locked = True

        for k,v in self.items():
            if isinstance(v, ReadOnlyDict) or isinstance(v, ReadOnlyList):
                v.lock(msg)


    def __setitem__(self, key, value):
        self._attemptedWrite(key)
        dict.__setitem__(self, key, readOnly(value))


    def update(self, d):
        self._attemptedWrite(','.join(d.keys()))
        dict.update(self, readOnly(d))



class ReadOnlyList(list):

    def __init__(self, *args, **kwargs):
        list.__init__(self, *args, **kwargs)

        self._locked = False
        self._msg = None


    def _attemptedWrite(self, k):
        if self._locked:
            raise AttributeError(self._msg or k)


    def append(self, value):
        self._attemptedWrite(value)
        list.append(self, readOnly(value))


    def __delitem__(self, key):
        self._attemptedWrite(key)
        list.__delitem__(self, key)


    def lock(self, msg=None):
        self._msg = msg
        self._locked = True

        for o in self:
            if isinstance(o, ReadOnlyDict) or isinstance(o, ReadOnlyList):
                o.lock(msg)


    def __setitem__(self, key, value):
        self._attemptedWrite(key)
        list.__setitem__(self, key, readOnly(value))



def readOnly(o):
    if isinstance(o, list):
        rol = ReadOnlyList()

        for p in o:
            rol.append(readOnly(p))

        return rol

    elif isinstance(o, dict):
        rod = ReadOnlyDict()

        for k,v in o.items():
            rod[readOnly(k)] = readOnly(v)

        return rod

    else:
        return o
