"""
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2012. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
"""

from commonattrs import CommonAttributes
from deployer import http, utils, validators
from relationships import RelatedResource, RelatedResourceCollection
import os


@utils.classinit
class IP(RelatedResource, CommonAttributes):
    'RM09081'


    @classmethod
    def _classinit(cls):
        cls._registerURI(r'\A/resources/subnets/\d+/ips/(?P<id>\d+)\Z')

        cls._defineRESTAttribute('created', 'RM09165', readonly=True)
        cls._defineRESTAttribute('currentmessage', 'RM09166', readonly=True)
        cls._defineRESTAttribute('currentmessage_text', 'RM09154', readonly=True)
        cls._defineRESTAttribute('currentstatus', 'RM09167', readonly=True)
        cls._defineRESTAttribute('currentstatus_text', 'RM09156', readonly=True)
        cls._defineRESTAttribute('id', 'RM09168', readonly=True)
        cls._defineRESTAttribute('ipaddress', 'RM09169', readonly=True)
        cls._defineRESTAttribute('userhostname', 'RM09637', readonly=True)
        # type - hidden
        cls._defineRESTAttribute('updated', 'RM09170', readonly=True)

        cls._methodHelp('__contains__', '__delattr__', 'delete', '__eq__',
                        '__hash__', 'isStatusTransient', '__nonzero__',
                        'refresh', '__repr__', '__str__', '__unicode__',
                        'waitFor',
                        'reset')


    def reset(self):
        'RM09633'
        http.postJSON(self.uri + '?reset=true', {})




@utils.classinit
class IPs(RelatedResourceCollection):
    'RM09032'


    @classmethod
    def _classinit(cls):
        cls._contains(IP)
        cls._methodHelp('__contains__', 'create', 'delete', '__delitem__',
                        '__getattr__', '__getitem__', '__iter__',
                        '__len__', 'list', '__lshift__', '__repr__',
                        '__rshift__', '__str__', '__unicode__')


    CREATE_ATTRIBUTES = [
        IP._wizardStep('ipaddress')
    ]


    # private methods

    def _create(self, dict):
        newdict = dict.copy()

        address = newdict['ipaddress']

        # unfortunately, IP address create doesn't return anything useful,
        # so we have to search to find the addresses we just created
        http.postJSON(self.uri, { 'addresses': [ address ] })
        return self._defaultSearch(address)


    def _createMulti(self, ipaddrs):
        http.postJSON(self.uri, { 'addresses': ipaddrs })

        # yuck!  fetch list of addrs & search for matches
        ips = self._list()
        return [ utils.find(lambda ip: ip.ipaddress == s, ips) for s in ipaddrs ]

    def _createHostnames(self, hosts):
        http.postJSON(self.uri, { 'hostnames': ' '.join(hosts) })

        # yuck!  fetch list of addrs & search for matches
        ips = self._list()
        return [ utils.find(lambda ip: ip.userhostname == s, ips) for s in hosts ]


    def _defaultSearch(self, s):
        # IP REST API does not support filters
        return utils.find(lambda ip: ip.ipaddress == s, self._list())


    def _isIP(self, value):
        try:
            validators.ipaddress(value, value)
            return True
        except ValueError:
            try:
                validators.ip6address(value, value)
                return True
            except ValueError:
                return False


    # public methods

    def create(self, other):
        'RM09033'

        # <IPs>.create('1.2.3.4')
        if (isinstance(other, str) or isinstance(other, unicode)) and not os.path.isfile(other):
            return self.create({ 'ipaddress': other })

        # <IPs>.create([...])
        # shortcut normal create([...]) processing to make subsequent
        # lookups more efficient
        elif isinstance(other, list) and utils.all(other, lambda s: type(s) == str or type(s) == unicode) and self._isIP(other[0]):
            return self._createMulti(other)

        elif isinstance(other, list) and utils.all(other, lambda s: type(s) == str or type(s) == unicode):
            return self._createHostnames(other)

        else:
            return super(IPs, self).create(other)


    def delete(self, other):
        'RM09017'

        # TODO - need to allow delete of strings
        return super(IPs, self).delete(other)
