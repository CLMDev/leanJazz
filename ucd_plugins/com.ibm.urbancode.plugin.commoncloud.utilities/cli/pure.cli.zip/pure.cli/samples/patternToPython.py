"""
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2012. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
"""
# Converts a pattern from IBM Workload Deployer to a Python script.
# When this script is subsequently run using the Workload Deployer
# CLI, it will reconstruct the pattern on the same or a different IBM
# Workload Deployer.  The generated script requires that the virtual
# image and scripts needed for the pattern have been previously
# defined on the destination appliance.
#
# This script is called as follows:
#
# deployer <deployer_options> -f samples/patternToPython.py
#     [-p|--pattern <pattern>] [-f|--filename <filename>] [--passwords]
#
# Where:
#
# -p|--pattern <pattern>
#     Specifies the pattern to be converted.  The <pattern> string must
#     uniquely identify a pattern.  If this option is not specified, the
#     user is allowed to select from a list of patterns defined on the
#     appliance.
#
# -f|--filename <filename>
#     Specifies a file to which the Python code will be written.  If this
#     option is omitted, the Python script is written to stdout.
#
# --passwords
#     Include passwords in the Python code.  If not specified, password
#     values will be omitted.

import getopt
import sys

# print help and exit
def help():
    import os.path
    execfile(os.path.join(os.path.split(sys.argv[0])[0], '_showCommandHelp.py'))

def _utos(u):
    if isinstance(u, unicode):
        s = ''
        for b in java.lang.String(u).getBytes():
            s += chr(b & 0xff)
    else:
        s = str(u)
    return s

# parse command line arguments
try:
    (options, args) = getopt.getopt(sys.argv[1:], 'f:p:', ['filename=', 'pattern=', 'passwords'])
except getopt.GetoptError:
    help()


dest = sys.stdout
pattern = None
passwords = False

for option in options:
    if option[0] == '-f' or option[0] == '--filename':
        dest = option[1]

    elif option[0] == '-p' or option[0] == '--pattern':
        patterns = deployer.patterns[option[1]]

        if not patterns:
            print >>sys.stderr, '"%s" does not match any patterns' % option[1]
            sys.exit(1)

        elif len(patterns) == 1 or patterns[0].name == option[1]:
            pattern = patterns[0]

        else:
            print >>sys.stderr, '"%s" does not uniquely identify a pattern' % option[1]
            sys.exit(1)

    elif option[0] == '--passwords':
        passwords = True


# choose pattern if none specified
while not pattern:
    i = 1
    for p in deployer.patterns:
        print '%d. %s' % (i, _utos(p.name))
        i = i + 1

    x = raw_input('select a pattern to convert: ')
    try:
        pattern = deployer.patterns[int(x) - 1]
    except:
        # try again
        pass


print >>sys.stderr, 'converting pattern "%s"' % _utos(pattern.name)
pattern.toPython(dest, includePasswords=passwords)
