"""
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2012. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
"""
#
# Export a Virtual System pattern from IBM Workload Deployer.
#
# This script is called as follows:
#
# deployer <deployer_options> -f samples/exportPattern.py
#     -p|--pattern <pattern> -t|--target <dirname> [--passwords] [-d|-download <filterfile>] 
#
# Where:
#
# -p|--pattern <pattern>
#     Specifies the pattern to be converted.  The <pattern> string must
#     uniquely identify a pattern.  If this option is not specified, the
#     user is allowed to select from a list of patterns defined on the
#     appliance.
#
# -t|--target <dirname>
#     Specifies a dir or a .tgz/.tar.gz file for export
#
# --passwords
#     Include passwords in the Python code.  If not specified, password
#     values will be omitted.
#
# -d|--download <filterfile>
#     By default, only the archives of Script Packages of Pattern will
#     be exported. 
#     To export the associated Virtual Images, Script Packages and Add-ons
#     Only the artifacts in filterfile will be download.
#
# --downloadAll
#     All associated artifacts will be exported with pattern


import getopt
import sys
import shutil
import os
import tempfile
import zipfile
from deployer.messages import message
from deployer import ziputils
from deployer import utils
# print help and exit
def help():
    if utils.isIPAS():
        command = 'pure'
        option = 'RM09989'
    else:
        command = 'deployer'
        option = 'RM09988'  
    print utils.utos(message('IWD10056') % ({'1': command, '2': message(option)}))
    sys.exit(1)

def _utos(u):
    if isinstance(u, unicode):
        s = ''
        for b in java.lang.String(u).getBytes():
            s += chr(b & 0xff)
    else:
        s = str(u)
    return s

# parse command line arguments
try:
    (options, args) = getopt.getopt(sys.argv[1:], 't:p:d:', ['target=', 'pattern=', 'passwords', 'downloadAll', 'download='])
except getopt.GetoptError:
    help()

patternName = None
dest = None
pattern = None
passwords = False
download = None
downloadAll = False

for option in options:
    if option[0] == '-t' or option[0] == '--target':
        dest = option[1]

    elif option[0] == '-p' or option[0] == '--pattern':
        patternName = option[1]

    elif option[0] == '--passwords':
        passwords = True
        
    elif option[0] == '--downloadAll':
        downloadAll = True

    elif option[0] == '-d' or option[0] == '--download':
        download = option[1]
        if not os.path.exists(download):
            print >>sys.stderr, utils.utos(message('IWD10057') % download)
            sys.exit(1)

#if (patternName is None):
    #print >>sys.stderr, message('IWD10058')
    #help()
    #sys.exit(1)
if patternName:
    patterns = deployer.patterns[patternName]

    if not patterns:
        print >>sys.stderr, utils.utos(message('IWD10059') % patternName)
        sys.exit(1)

    elif len(patterns) == 1 or patterns[0].name == patternName:
        pattern = patterns[0]

    else:
        print >>sys.stderr, utils.utos(message('IWD10060') % patternName)
        sys.exit(1)
        
if (dest is None):
    print >>sys.stderr, utils.utos(message('IWD10061'))
    help()
    sys.exit(1)

#dest must be an existing directory or ends with '.tgz' or '.tar.gz'
zipped = (not os.path.isdir(dest))
if zipped and not dest.endswith('.tgz') and not dest.endswith('.tar.gz'):
        print >>sys.stderr, utils.utos(message('IWD10063') % str(dest))
        sys.exit(1)
   
# choose pattern if none specified
while not pattern:
    i = 1
    for p in deployer.patterns:
        print '%d. %s' % (i, _utos(p.name))
        i = i + 1

    x = raw_input(utils.utos(message('IWD10062')))
    try:
        pattern = deployer.patterns[int(x) - 1]
    except:
        # try again
        pass



if zipped:
    zippedFile = dest
    dest = tempfile.mkdtemp(prefix="export")
    print >>sys.stderr, utils.utos(message('IWD10064') % str(dest))

try:
    pattern.save(dest, includePasswords=passwords, download=download, downloadAll = downloadAll)

    if zipped:
        ziputils.compress(dest, zippedFile)
        
finally:
    if zipped:
        shutil.rmtree(dest)
