#
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2012. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
#
 
cachings = deployer.sharedservices.list({'servicename':'caching'})
caching = utils.find(lambda s: s.service_type != 'External',cachings)
cachingParams ={
        "sharedservice.cachingVMsMax": 6,
        "sharedservice.cachingVMSize": "8",
        "sharedservice.cachingVMs": 5,
        "sharedservice.cachingScalingTriggerTime": 700,
        "sharedservice.cachingAutoscalingRange": [20,70],
        "groups": {"sharedservice.cachingproduction": True,   "sharedservice.cachingAutoscalingEnable": True}
}
cachingVApp = caching.start(deployer.clouds[0], cachingParams)
cachingVApp.waitFor(maxWait=30*60)

#cachingVApp.refresh()
#print cachingVApp
#rsaPath = "E:\\id_rsa"
#env=deployer.environmentprofiles[0]
#cloud = env.clouds.keys()[0]
#ipgroup=env.clouds[cloud].ipgroups.keys()[0]


#deployOptions = {"environment_profile" : env, 
   #              "cloud_group": cloud, 
    #             'ip_group': ipgroup,
     #            'ip_version': 'IPv4'
      #           }
#cachingVApp2 = caching.start(deployOptions,cachingParams, rsaPath)
#print cachingVApp2 
