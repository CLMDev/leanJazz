"""
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2011. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
"""
# creates a new IP group and adds IP addresses to it

ten = admin.ipgroups << {
    'name': 'ten',
    'subnet': '10.0.0.0',
    'mask': '255.0.0.0',
    'gateway': '10.0.0.1',
    'dns': '10.0.0.2',
    'vlan_id': '633'
}

ten.ips.create(['10.1.2.3', '10.2.3.4', '10.3.4.5'])

print ten
print ten.ips
