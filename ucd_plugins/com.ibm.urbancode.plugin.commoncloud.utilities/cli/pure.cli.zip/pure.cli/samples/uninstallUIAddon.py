# Licensed Materials - Property of IBM
# (C) Copyright IBM Corporation 2012. All Rights Reserved.
# US Government Users Restricted Rights- Use, duplication or disclosure
# restricted by GSA ADP Schedule Contract with IBM Corp.
# Author: lixincdl@cn.ibm.com (Allen Li)

# Import ADP UI Package to IBM Workload Deployer
#
# This script is called as follows:
#
# deployer <deployer_options> -s importUIPackage.py
#     -s|--source <filename>
#
# Where:
#
# -s|--source <filename>
#     Specifies a .zip file for UI Package import
#

import getopt
import sys
import os
import shutil
import tempfile

options =[]
# parse command line arguments
try:
    (options, args) = getopt.getopt(sys.argv[1:], 'n:', ['name='])
except getopt.GetoptError:
    print 'usage error, please specify Addon with the parameter -n|--name <Addon name>'


name = None

for option in options:
    if option[0] == '-n' or option[0] == '--name':
        name = option[1]

if (name is None):
    print 'usage error, please specify Addon with the parameter -n|--name <Addon name>'
    sys.exit(1)

try:        
        deployer.addon_ui.uninstall(name)
        print 'Please reload your browser to see the changes'
finally:
    deployer.exit
