"""
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2012. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
"""
# This script displays help for another script.  It is not meant to
# be invoked directly.

import sys


foundhelp = False
indocstring = False

for line in open(sys.argv[0]):
    if line.strip().startswith('"""'):
        indocstring = not indocstring
    elif not indocstring and line.startswith('#') and not line.startswith('#!'):
        foundhelp = True
        print line[2:].rstrip()
    elif foundhelp:
        print ''
        sys.exit(1)

