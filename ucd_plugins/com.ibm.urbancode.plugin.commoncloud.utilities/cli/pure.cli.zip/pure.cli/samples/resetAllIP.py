#
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2012. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
#
ipgroups=deployer.ipgroups
total=0
inuse=0
reset=0
aval=0
for ipgroup in ipgroups:
    ips=ipgroup.ips
    for ip in ips:
        total = total+1
        if ip.currentstatus != "RM01017":
            print("reset " + ip.ipaddress + "......")
            try:
                reset = reset + 1
                ip.reset()
            except IOError:
                reset = reset - 1
                inuse = inuse +1
                print(IOError)
        else:
            aval=aval+1

print("total IP: " + str(total))
print("inactiv IP: " + str(aval))
print("inused IP: " + str(inuse))
print("reset IP: " + str(reset))