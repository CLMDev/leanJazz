#!/usr/bin/env pure
import csv
import os


custNet = admin.customernetwork
custNet.load()

mgtLan = admin.managementlan
mgtLan.load()

def lookupPorts(vlanID):
    for vlanRange in custNet.vlanRanges():
        if vlanRange._rangesOverlap(vlanID, vlanRange.id):
            for link in custNet.links('1'):
                if (vlanRange.id in link.vlanRangeIDs):
                    return link.portIDs
            for link in custNet.links('10'):
                if (vlanRange.id in link.vlanRangeIDs):
                    return link.portIDs
    return set([])


def formatPortList(ports):
    s = ''
    for port in ports:
        if (0 != len(s)):
            s += ' '
        s += str(port)
    return s 


#Vlan contains customer vlans of IP group and management vlans of cloud group
vlan_list = []
header = ['VLAN id','IP Group Name', "IP Group Id", 'Cloud Name', "Cloud Group Id", 'isMgmtVLAN', 'Port']
vlan_list.append(header)

print 'Reading vlans associated with ip groups...'
#find all vlans associated with ipgroups
for ipgroup in admin.ipgroups:
    
    cloudName = ""
    cloudId = ""
    
    cloud = ipgroup.cloud
    if cloud:
        cloudName = cloud.name
        cloudId = cloud.id
        
    vlan_ports = lookupPorts(ipgroup.vlan_id)
    vlan=(ipgroup.vlan_id, ipgroup.name, ipgroup.id, cloudName, cloudId, 'False', formatPortList(vlan_ports))
    vlan_list.append(list(vlan))


#find all management vlans of cloud group
print 'Reading management vlans of cloud groups...'
for cloud in admin.clouds:
        mgmt_vlan_id = cloud.mgmt_vlan_id       
        vlan = (mgmt_vlan_id, "", "", cloud.name, cloud.id,'True', mgtLan.portID)
        vlan_list.append(list(vlan))
        

csv_file= open("vlanSummary.csv","w+")
writer = csv.writer(csv_file, dialect = 'excel', delimiter=',')
writer.writerows(vlan_list)
csv_file.close()

consoleWriter = csv.writer(sys.stdout, dialect=csv.excel_tab)
consoleWriter.writerows(vlan_list)
    

print '-------------------------------------------------------'
print 'Data is saved into csv file:'+ os.path.abspath(os.path.join(os.getcwd(),csv_file.name))