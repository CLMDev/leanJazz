"""
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2011. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
"""
# Deletes a user on the system
#
# This script is called as follows:
#
# pure <pure_options> -f samples/deleteUser.py <username>*
#
# Where:
#
# <username>
#     specifies the username of a user to be deleted

import sys


# print help and exit
def help():
    import os.path
    execfile(os.path.join(os.path.split(sys.argv[0])[0], '_showCommandHelp.py'))


# parse command line arguments
try:
    (options, args) = getopt.getopt(sys.argv[1:], '', [])
except getopt.GetoptError:
    help()


# delete specified users
for username in args:
    # search for users with matching usernames
    users = admin.users[username]

    # verify search matched exact username
    if len(users) > 0 and users[0].user_id == username:
        users[0].delete()
        print 'deleted user %s' % username
    else:
        print 'user %s not found' % username
