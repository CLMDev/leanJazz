"""
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2012. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
"""
# creates a new pattern similar to the "WebSphere HV Cluster (Development)"
# pattern

import sys


# get name for new pattern
patternName = raw_input('pattern name: ')


# fail if pattern already exists
patterns = deployer.patterns[patternName]
if filter(lambda p: p.name == patternName, patterns):
    print 'Error: a pattern with that name already exists!'
    sys.exit()


# create pattern
pattern = deployer.patterns << {
    'name': patternName,
    'description': 'pattern created by createPattern.py'
}


# prompts the user to select a virtual image for the specified part
# and returns the part indicated by the user
def selectPart(part):
    candidates = []
    
    for vi in deployer.virtualimages:
        for vipart in vi.parts:
            if vipart.label == part:
                candidates.append([vi, vipart])
                break

    i = 1
    for imgpart in candidates:
        print '%d. %s' % (i, imgpart[0].name)
        i = i + 1

    x = raw_input('select virtual image for "%s": ' % part)
    try:
        return candidates[int(x) - 1][1]
    except:
        # try again
        pass


# add deployment manager part
dmgrPart = selectPart('Deployment manager')
dmgrPpart = pattern.parts << dmgrPart


# add script to deployment manager
addihsScript = deployer.scripts['Add IBM HTTP Server node'][0]
dmgrPpart.scripts << addihsScript


# add custom node
customNodePart = selectPart('Custom nodes')
customNodePpart = pattern.parts << customNodePart
customNodePpart.count = 2
