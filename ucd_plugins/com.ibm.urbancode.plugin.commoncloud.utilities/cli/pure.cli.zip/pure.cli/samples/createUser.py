"""
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2011. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
"""
# Defines a  new user on the system.
#
# This script is called as follows:
#
# pure <pure_options> -f samples/createUser.py
#     [-u|--username <username>] [-f|--fullname <full_name>]
#     [-p|--password <password] [-e|--email <email>]
#
# Where:
#
# -e|--email <email>
#     specifies an email address for the user
#
# -f|--fullname <full_name>
#     specifies the user's full name
#
# -p|--password <password>
#     specifies an optional password for the user; if no password is
#     supplied, the appliance generates a password
#
# -u|--username <username>
#     specifies the username for the new user
#
# The user will be prompted for any values not supplied on the command
# line.

import getopt
import sys


# print help and exit
def help():
    import os.path
    execfile(os.path.join(os.path.split(sys.argv[0])[0], '_showCommandHelp.py'))

    
# parse command line arguments
try:
    (options, args) = getopt.getopt(sys.argv[1:], 'e:f:p:u:', ['email=', 'fullname=', 'password=', 'username='])
except getopt.GetoptError:
    help()

parms = {}

for option in options:
    if option[0] == '-e' or option[0] == '--email':
        parms['email'] = option[1]

    elif option[0] == '-f' or option[0] == '--fullname':
        parms['name'] = option[1]

    elif option[0] == '-p' or option[0] == '--password':
        parms['password'] = option[1]

    elif option[0] == '-u' or option[0] == '--username':
        parms['user_id'] = option[1]


if len(parms) < 4:
    # collect missing values
    w = deployer.wizard(parms, silentlySkipDefaults=True)
    u = admin.users.create(w)

else:
    # use supplied values
    u = admin.users.create(parms)

print 'user created successfully:\n%s' % u
