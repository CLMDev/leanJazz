"""
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2011. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
"""

#get env
envs = deployer.environmentprofiles.list({"currentstatus": "RM01001", "ipsource":0})
if len(envs) > 0:
    env = envs[0]
    print("using environment profile:")
    print(env)
    #get app
    app = deployer.applications.list({"app_type":"application"})[0]
    selectIP = None
    selectCloud = None
    
    for cloud in env.clouds:
        for ip in env.clouds[cloud].ipgroups:
            print("using cloud group:")
            print(cloud)
            selectCloud = cloud

            print("using IP group:")
            print(ip)
            selectIP = ip
            break
        
        if selectCloud != None:
            break
    
    dep = app.deploy("deployment-test", {
        "environment_profile": env,
        "cloud_group": selectCloud,
        "ip_group": selectIP,
        "ip_version": selectIP.version,
        "priority": "high"
    })
    print(dep)
else:
    print("no available environment profiles")