#!/usr/bin/env python

#
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2012. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
#

import sys
import json
import subprocess
from verifyAuditPackage import writeToFile

def splitStr(str, num):
	lines = []
	for i in range(num):
		lines.append(str[i::num])
	lines = ["".join(i) for i in zip(*lines)]
	rem = len(str) % num
	if rem:
		lines.append(str[-rem:])
	return lines

def formatPublicKey(filename, str) :
	lines = splitStr(str, 64)
	f = open(filename, 'w')
	f.write("-----BEGIN PUBLIC KEY-----\n")
	for ll in lines:
		f.write(ll)
		f.write("\n")
	f.write("-----END PUBLIC KEY-----\n")
	f.close()

def getDataAndProcessJSON() :
	args = sys.argv

	username=args[1]
	password=args[2]
	keyFile=args[3]
	urlString=args[4]

	jsonkey=args[5]
	outputfilename=args[6]

	proc = subprocess.Popen(['./cscurl.sh', username, password, keyFile, '-k', '-H', '"Accept:application/json"', urlString], stdin=subprocess.PIPE, stdout=subprocess.PIPE)
	output = proc.communicate()[0]
	num=1
	while True:
		rc = proc.poll()
		if rc is not None:
			break
		sleep(0.1)
		if num < 200:
			num+=1
		else:
			break

	keys = json.loads(output)

	if jsonkey.lower() == 'publickey':
		formatPublicKey(outputfilename, keys[jsonkey])
		return True
	else:
		writeToFile(outputfilename, keys[jsonkey])
		return keys[jsonkey]

if __name__ == "__main__":
    print getDataAndProcessJSON()
