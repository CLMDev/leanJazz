"""
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2011. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
"""
# Lists the users on the system
#
# This script is called as follows:
#
# pure <pure_options> -f samples/listUsers.py
#     [-x|--exact] [-v|--verbose] [-r|--roles] [-g|--groups]
#     <search_str>*
#
# Where:
#
# -g|--groups
#     additionally displays the names of the groups to which the user
#     belongs
#
# -r|--roles
#     additionally displays the roles assigned to the user
#
# -v|--verbose
#     displays the full set of information for each user rather than
#     just the user's username
#
# -x|--exact
#     indicates that only users whose username exactly matches search_str
#     should be displayed
#
# <search_str>
#     users whose username contains this string will be shown; if no search
#     string is specified, all users will be shown; if more than one search
#     string is specified, searches are done in the order specified

import getopt
import sys


# print help and exit
def help():
    import os.path
    execfile(os.path.join(os.path.split(sys.argv[0])[0], '_showCommandHelp.py'))

    
# parse command line arguments
try:
    (options, args) = getopt.getopt(sys.argv[1:], 'grvx', ['groups', 'roles', 'verbose', 'exact'])
except getopt.GetoptError:
    help()

groups = False
roles = False
verbose = False
exact = False

for option in options:
    if option[0] == '-g' or option[0] == '--groups':
        groups = True

    elif option[0] == '-r' or option[0] == '--roles':
        roles = True

    elif option[0] == '-v' or option[0] == '--verbose':
        verbose = True

    elif option[0] == '-x' or option[0] == '--exact':
        exact = True


# force one iteration of loop if no search strings specified
if not args:
    args.append(None)
    
# iterate through search strings
for searchstr in args:
    # no search string given, get all users
    if not searchstr:
        users = list(admin.users)

    # find users matching given string
    else:
        users = admin.users[searchstr]

    # throw out non-matching names if -x was specified
    if exact:
        users = filter(lambda user: user.user_id == searchstr, users)


    # iterate through all the users that were found
    for user in users:
        # print detailed information if -v was specified
        if verbose:
            print user
        # otherwise just show the user's username
        else:
            print user.user_id

        # show user's roles if -r was specified
        if roles:
            print 'user roles: %s' % user.roles

        # show names of groups if -g was specified
        if groups:
            print 'user belongs to groups: %s' % ', '.join([ g.name for g in user.groups ])
