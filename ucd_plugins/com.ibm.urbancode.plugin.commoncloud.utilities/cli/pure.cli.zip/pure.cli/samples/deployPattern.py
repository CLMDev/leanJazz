"""
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2011. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
"""
import time
from deployer import utils

def inputOrQuit(prompt):
    x = raw_input(prompt)
    if x == 'q':
        sys.exit()
    return x
createParms = {}

# get name for new virtual system
createParms['name'] = inputOrQuit('new virtual system name, or q to quit: ')


# select pattern to deploy
patternNames = []
pattern = None
while not pattern:
    i = 1
    for p in deployer.patterns:
        print '%d. %s' % (i, utils.utos(p.name))
        patternNames.append(p.name)
        i = i + 1
    #endFor
    x = inputOrQuit('select a pattern to deploy, or q to quit: ')
    try:
        pattern = deployer.patterns.list({'name':patternNames[int(x) - 1]})[0]
    except:
        # try again
        pass
    #end try
#end while
createParms['pattern'] = pattern


# select an environment profile in which to deploy
profileNames = []
profile = None
while not profile:
    i = 1
    for p in deployer.environmentprofiles.list({"currentstatus": "RM01001", "ipsource":0}):
        print '%d. %s' % (i, utils.utos(p.name))
        profileNames.append(p.name)
        i = i + 1
    #end for
    x = inputOrQuit('select a profile, or q to quit: ')
    try:
        profile = deployer.environmentprofiles.list({'name':profileNames[int(x) - 1]})[0]
    except:
        # try again
        pass
    #end try
#end while
createParms['environmentprofile'] = profile

# select a cloud in which to deploy
cloudNames = []
cloud = None
if (profile.clouds.__len__() > 1):
    while not cloud:
        i = 1
        for c in profile.clouds:
            print '%d. %s' % (i, utils.utos(c.name))
            cloudNames.append(c.name)
            i = i + 1
        #end for
        x = inputOrQuit('select a cloud, or q to quit: ')
        try:
            cloud = deployer.clouds.list({'name':cloudNames[int(x) - 1]})[0]
        except:
            # try again
            pass
        #end try
    #end while
else:
    cloud = profile.clouds.keys()[0]
#endif

createParms['*.cloud'] = cloud


# select an ip group for deployment
ipgroupNames = []
ipgroup = None
if (profile.clouds[cloud].ipgroups.__len__() > 1):
    while not ipgroup:
        i = 1
        for ip in profile.clouds[cloud].ipgroups:
            print '%d. %s' % (i, utils.utos(ip.name))
            ipgroupNames.append(ip.name)
            i = i + 1
        #end for
        x = inputOrQuit('select an ipgroup, or q to quit: ')
        try:
            ipgroup = deployer.ipgroups.list({'name':ipgroupNames[int(x) - 1]})[0]
        except:
            # try again
            pass
        #end try
    #end while
else:
    ipgroup = profile.clouds[cloud].ipgroups.keys()[0]
#endif
createParms['*.*.*.ipgroup'] = ipgroup


# select a start time
starttime = inputOrQuit('number of seconds to delay start (default=no delay), or q to quit: ')
if starttime:
    createParms['starttime'] = time.time() + long(starttime)


# select an end time
endtime = inputOrQuit('number of seconds until stop (default=no scheduled stop), or q to quit: ')
if endtime:
    createParms['endtime'] = time.time() + long(endtime)
    

# get passwords
password = None
while not password:
    password = inputOrQuit('root password for virtual machines, or q to quit: ')
    if (not password):
        print "Password is required."
    #end if
#end while
createParms['*.ConfigPWD_ROOT.password'] = password
password = None
while not password:
    password = inputOrQuit('user password for virtual machines, or q to quit: ')
    if (not password):
        print "Password is required."
    #end if
#end while
createParms['*.ConfigPWD_USER.password'] = password

# loop to let user enter additional property/parameter values
virtualSystem = None
while not virtualSystem:
    try:
        virtualSystem = deployer.virtualsystems << createParms
    except ValueError, ve:
        print str(ve)
        key = inputOrQuit('additional property/parameter key, or q to quit: ')
        createParms[key] = inputOrQuit('value for \'%s\', or q to quit: ' % key)

print 'virtual system created:\n%s' % utils.utos(virtualSystem)
