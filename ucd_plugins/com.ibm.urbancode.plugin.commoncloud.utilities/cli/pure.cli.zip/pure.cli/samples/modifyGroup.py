"""
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2011. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
"""
# Modifies a group on the system
#
# This script is called as follows:
#
# pure <pure_options> -f samples/modifyGroup.py <groupname>
#     [--addrole <role>] [--removerole <role>]
#     [--adduser <user>] [--removeuser <user>]
#
# Where:
#
# <groupname>
#     specifies the current groupname of the group to be modified
#
# --adduser <user>
#     adds the user to the specified group
#
# --addrole <role>
#     adds a role to the group, <role> must be one of:  'CLOUD_ADMIN',
#     'APPLIANCE_ADMIN', 'CATALOG_CREATOR', 'PATTERN_CREATOR', 'ILMT_USER',
#     'CLOUD_ADMIN_READONLY', 'APPLIANCE_ADMIN_READONLY' ,'PROFILE_CREATOR',
#     'REPORT_READONLY','AUDIT_READONLY', 'AUDIT', 'HARDWARE_ADMIN','SECURITY_ADMIN', 
#     'SECURITY_ADMIN_READONLY', 'ROLE_ADMIN','HARDWARE_ADMIN_READONLY',
#     'CLOUDGROUP_ADMIN','CLOUDGROUP_ADMIN_READONLY', 'USER_ADMIN_READONLY'
#
# --removeuser <user>
#     removes the user from the specified group
#
# --removerole <role>
#     removes a role from the group, <role> must be one of:  'CLOUD_ADMIN',
#     'APPLIANCE_ADMIN', 'CATALOG_CREATOR', 'PATTERN_CREATOR', 'ILMT_USER',
#     'CLOUD_ADMIN_READONLY', 'APPLIANCE_ADMIN_READONLY' ,'PROFILE_CREATOR',
#     'REPORT_READONLY','AUDIT_READONLY', 'AUDIT', 'HARDWARE_ADMIN','SECURITY_ADMIN', 
#     'SECURITY_ADMIN_READONLY', 'ROLE_ADMIN','HARDWARE_ADMIN_READONLY',
#     'CLOUDGROUP_ADMIN','CLOUDGROUP_ADMIN_READONLY', 'USER_ADMIN_READONLY'
import getopt
import sys


# print help and exit
def help():
    import os.path
    execfile(os.path.join(os.path.split(sys.argv[0])[0], '_showCommandHelp.py'))


if len(sys.argv) < 2:
    help()


# find the specified group
groups = admin.groups[sys.argv[1]]
if len(groups) < 1 or groups[0].name != sys.argv[1]:
    raise 'groupname %s not found' % sys.argv[1]

group = groups[0]


# parse command line arguments
try:
    (options, args) = getopt.getopt(sys.argv[2:], '', ['adduser=', 'addrole=', 'removeuser=', 'removerole='])
except getopt.GetoptError:
    help()


if len(args) != 0:
    help()


# perform the requested updates
for option in options:
    if option[0] == '--adduser':
        users = admin.users[option[1]]
        if len(users) < 1 or users[0].user_id != option[1]:
            raise 'user %s not found' % option[1]

        print 'adding user to group...',
        group.users.add(users[0])
        print 'done'

    elif option[0] == '--addrole':
        print 'adding role...',
        group.roles += option[1]
        print 'done'

    elif option[0] == '--removeuser':
        users = admin.users[option[1]]
        if len(users) < 1 or users[0].user_id != option[1]:
            raise 'user %s not found' % option[1]

        print 'removing user from group...',
        group.users.remove(users[0])
        print 'done'

    elif option[0] == '--removerole':
        print 'removing role...',
        group.roles -= option[1]
        print 'done'
