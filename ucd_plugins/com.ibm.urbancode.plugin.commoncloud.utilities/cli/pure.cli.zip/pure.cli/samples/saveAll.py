"""
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2011. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
"""

import sys
import os
import string
import traceback

from deployer import http, utils, prettify

# 
# This script reads all of the data from an appliance's cloud and catalog 
# and generates two artifacts:
# 
# 1) a text report with the details of the cloud and catalog
# 2) a CLI script that can be used to recreate all of the data
# 
# Running this script can help you learn how to use the CLI. If you have 
# performed all of your appliance setup through the web console, running 
# this script will generate Jython code that does the exact same tasks, 
# and you can see how you would have done it via command line.
# 
# If you use this script to recreate script packages and virtual images, 
# you must first export those archives (zip/tar.gz for script packages, 
# .ova for images) to the machine that will be used to run the generated 
# Jython code. The generated code will ask you for local paths to those 
# archives so it can import them into the appliance.
# 
# This script does not process patterns - to save patterns as CLI code, 
# you can use the patternToPython.py sample script.
# 
#Because we cannot get user's password, set all users' password to this default password.
#You can change it later.

try:
    (options, args) = getopt.getopt(sys.argv[1:], '', ['saveAll'])
except getopt.GetoptError:
   pass

saveAll = False

for option in options:
    if option[0] == '--saveAll':
        saveAll = True   
    
defaultPassword = "restore"

def getAllAttributes(resource):
    attrnames = {}
     
    if hasattr(resource, '_RESTNAMES_') :
       attrnames = resource._RESTNAMES_
    elif hasattr(resource, '_LOCALNAMES_'):
       attrnames = resource._LOCALNAMES_
   
    visible = getattr(resource, "_VISIBLE_", {})
       
    return [key for key in attrnames if utils.all(visible.get(key, []), lambda visCheck: visCheck(resource))]
        
            
    
def asText(resource, ignore = [], indent = '    '):    
    ignoreAll = ['id', 'created_time', 'updated_time', 'state', 'url', 'current_status', 'password']
    ignoreAll.extend(ignore)
    
    text = []
    
    attrnames = getAllAttributes(resource)
    
    for key in attrnames:
        if key not in ignoreAll:
            text.append(utils.utos('%s%s: %s' % (indent, key, getattr(resource, key) or '(none)')))
    
    return '\n'.join(text)


def asJython(collection, variable, resource, ignore = [], variables = [], package = 'admin'): 
    ignoreAll = ['id', 'created_time', 'updated_time', 'state', 'url', 'current_status', 'password', 'roles', 'is_highly_available']
    ignoreAll.extend(ignore)
    
    json = {}
    
    attrnames = getAllAttributes(resource)
    
    for key in attrnames:
        if key not in ignoreAll:
            value = getattr(resource, key)
            if value == None or (value == '' and key == 'secondary_dns') or (key != 'name' and collection == 'scripts'):
               continue
            
            json[key] = value
    #provide a default password        
    if collection == 'users':
        json['password'] = defaultPassword
    
    for key in variables:
        json[key] = '%s_placeholder' % key
    
    code = '\n%s = %s.%s << %s\n' % (variable, package, collection, utils.utos(prettify.prettify(json)))
    
    for key in variables:
        code = code.replace('\"%s_placeholder\"' % key, key)
    
    return code

#
# script starts here!
#

hostName = http.host.replace('.', '_')

#
# create new files for text report and jython code
#

reportName = '%s.txt' % hostName
jythonName = '%s.py' % hostName


report = open(reportName, 'w')
report.write('\nIBM PureApplication System:\n')
report.write('\n    %s\n' % http.host)

jython = open(jythonName, 'w')
jython.write('\n# This script can be used to create the data found on %s.\n\n' % http.host)

#define methods so that we can filter a resource exactly by the key and value
jython.write('def isMatchAll(r, filt={}):\n')
jython.write('    for key in filt:\n')
jython.write('        if getattr(r, key) != filt[key]:\n')
jython.write('           return False\n')
jython.write('    return True\n\n')

jython.write('def localFilter(l, filt={}):\n')
jython.write('    return utils.find(lambda r: isMatchAll(r, filt), l)\n\n')

try:
    print 'Generating report in %s...' % reportName
    print 'Generating script in %s...' % jythonName
    
    
    print 'Reading mail delivery data'
    
    report.write('\nmail delivery:\n\n')
    
    report.write('    reply to address:%s\n' % admin.mail.replytoaddress)
    report.write('    smtp server:%s\n' % admin.mail.smtpserver)
    
    replytoaddress = admin.mail.replytoaddress
    if replytoaddress:
       jython.write('admin.mail.replytoaddress=%s\n' % replytoaddress)
       
    smtpserver= admin.mail.smtpserver
    if smtpserver:
       jython.write('admin.mail.smtpserver=%s\n\n' % smtpserver)

    print 'Reading DNS data...'
    
    report.write('\ndns:\n\n')

    for dns in admin.dns.servers:
        report.write('    %s\n' % dns)
    jython.write('dnsServers = %s\n' % (prettify.prettify(admin.dns.servers)))
    jython.write('admin.dns.servers.extend(dnsServers)\n\n')
    
    print 'Reading NTP data...'
    
    report.write('\nntp:\n\n')
    
    for ntp in admin.dateandtime.ntpservers:
        report.write('    %s\n' % ntp)
    jython.write('ntpServers = %s\n' % (prettify.prettify(admin.dateandtime.ntpservers)))
    jython.write('admin.dateandtime.ntpservers.extend(ntpServers)\n\n')
    
    #
    # find all users and groups
    #
    
    print 'Reading user data...'
    
    report.write('\nusers:\n\n')
    for user in admin.users:
        report.write(asText(user))
        report.write('\n\n')
        
        if user.user_id != 'admin' and user.user_id != 'ibmeng':
            jython.write('\nprint \"Adding user %s...\"\n' % user.user_id)
            jython.write(asJython('users', 'user', user))
            jython.write('user.roles += %s\n' % prettify.prettify(user.roles))
            
    print 'Reading user group data...'
        
    for group in admin.groups:
        report.write(asText(group))
        report.write('\n    users: %s' % '\n           '.join(utils.map(group.users, lambda user: user.user_id)))
        report.write('\n\n')
        
        if group.name != 'Everyone':
            print '    Reading group membership data for %s...' % group.name
            
            jython.write('\nprint \"Adding group %s...\"\n' % group.name)
            jython.write(asJython('groups', 'group', group))
            jython.write('group.roles += %s' % prettify.prettify(group.roles))
            jython.write('\nprint \"    Adding members of group %s...\"\n' % group.name)
            
            for user in group.users:
                jython.write('group.users << localFilter(admin.users[\'%s\'], %s)\n' % (user.user_id, prettify.prettify({"user_id": user.user_id})))

    # find all ipgroups and clouds
    print 'Reading IP group data...'
    
    report.write('ip groups:\n\n')
    
    for ipg in admin.ipgroups:
        ips = []
        hostnames = []
        for ip in ipg.ips:
            if ip.ip:
                ips.append(ip.ip)
            elif ip.hostname:
                hostnames.append(ip.hostname)
                
        #ipList = utils.map(ipg.ips, lambda ip: ip.ip if ip.ip else ip.hostname)
        
        report.write(asText(ipg))
        report.write('\n    ip addresses: %s' % '\n           '.join(ips))
        report.write('\n    hostnames: %s' % '\n           '.join(hostnames))
        report.write('\n\n')
        
        jython.write('\nprint \"Adding IP group %s...\"\n' % utils.utos(ipg.name))
        jython.write(asJython('ipgroups', 'ipg', ipg))
        
        if ips:
           jython.write('ipg.ips << %s\n' % prettify.prettify(ips))
        
        if hostnames:
            jython.write('ipg.ips << %s\n' % prettify.prettify(hostnames))
        
    print 'Reading cloud group data...'
    
    for cg in admin.clouds:
        jython.write('\nprint \"Adding cloud group %s...\"\n' % utils.utos(cg.name))
        jython.write(asJython('clouds', 'cloud', cg))
        jython.write('cloud.waitFor()')
        report.write(asText(cg))
        
        print '    Reading ipgroup data for %s...' % utils.utos(cg.name)
        report.write('\n    ipgroups:\n')
        jython.write('\nprint "add ipgroups to %s"\n'% utils.utos(cg.name))
        
        for ipgInCg in cg.ipgroups:
            report.write('           name=%s,subnet=%s\n' % (ipgInCg.name, ipgInCg.subnet))
            jython.write('\nipgInCg = localFilter(admin.ipgroups["%s"], %s)\n' % (ipgInCg.name, prettify.prettify({"name": ipgInCg.name, "subnet": ipgInCg.subnet})))
            jython.write('cloud.ipgroups.add(ipgInCg)\n\n')
            
            
        print '    Reading compute nodes data for %s...' % utils.utos(cg.name)
        report.write('\n    compute nodes:\n')
        jython.write('\nprint "add compute nodes to %s"\n'% utils.utos(cg.name))
        
        for node in cg.computenodes:
            report.write('          %s\n' % node.name)
            jython.write('\ncomputeNode = localFilter(admin.computenodes["%s"], %s)\n' % (node.name, prettify.prettify({"name": node.name})))
            jython.write('if computeNode:\n')
            jython.write('    cloud.computenodes.add(computeNode)\n\n')
        
        report.write('\n\n') 
    
    VIRTUAL_IMAGES = "virtual_images"
    SCRIPT_PACKAGES = "script_packages"
    
    print 'Reading script packages data...' 
       
    if not os.path.exists(SCRIPT_PACKAGES):
        os.mkdir(SCRIPT_PACKAGES)
        
    for script in deployer.scripts:
        try:
            ignore = ['maintenance', 'resourcetype', 'type', 'label', 'ispublic', 'version', 'currenteditionid']
            report.write(asText(script, ignore))
            report.write('\n\n')
            print '    Reading script package %s...\n' % utils.utos(script.name)
            
            jython.write('\nprint \"Adding script %s...\"\n' % script.name)
            ignore.extend(['filename', 'id', 'created', 'updated', 'ownerid', 'currentstatus', 'currentmessage', 'desiredstatus', 'password'])       
            jython.write(asJython('scripts', 'script', script, ignore, package = 'deployer'))
            
            filename = script.filename
            if filename:
                file = SCRIPT_PACKAGES + '/' + filename
                script.archive.get(file)
                jython.write('script.archive << "%s"' % file)
        except:
          traceback.print_exc()

    print 'Reading virtual images data...' 
      
    #by default, don't save images
    if saveAll:
        if not os.path.exists(VIRTUAL_IMAGES):
            os.mkdir(VIRTUAL_IMAGES)    
        for virtualimage in deployer.virtualimages:
            try:
                ignore = ['parenttemplateid', 'parenttemplateeditionid', 'currenteditionid', 'editionstatus', 'servicelevel', 'hardware']
                report.write(asText(virtualimage, ignore))
                
                jython.write(asJython('virtualimages', 'virtualimage', virtualimage, package = 'deployer'))
                imageFile = virtualimage.export(VIRTUAL_IMAGES)
                jython.write('\nprint \"Adding virtual image %s...\"\n' % virtualimage.name)
                jython.write('vi = deployer.virtualimages << "%s"' % os.path.join(VIRTUAL_IMAGES, imageFile))
                jython.write('vi.waitFor()\n')
                
                if virtualimage.licenseaccepted == 'T':
                   jython.write('vi.acceptLicense()\n')
            except:
                traceback.print_exc()

 
finally:
    if report:
       report.close()
    if jython:
       jython.close()

print 'Saved report to %s.' % reportName
print 'Saved script to %s.' % jythonName
