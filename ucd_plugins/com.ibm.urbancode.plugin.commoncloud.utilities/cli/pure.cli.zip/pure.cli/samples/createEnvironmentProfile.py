print("create environment profile...")
env=deployer.environmentprofiles.create({
"name":"test_env",
"platform":"PureSystems_ESX",
"environment":deployer.environmentprofile.ALL_ENVIRONMENT,
"deployment_priority":deployer.deployment_priorities[0]
})
print(env)

print("\n\n\nadd following cloud group into profile:")
cloud=deployer.clouds[0]
print(cloud)
env.clouds.addCloud(cloud)

print("\n\n\nadd following IP group into profile:")
ip=deployer.ipgroups[0]
print(ip)
env.clouds[cloud].ipgroups.addIPGroup(ip)

print("\n\n\nnow profile has cloud group and IP group:")
print(env.clouds)