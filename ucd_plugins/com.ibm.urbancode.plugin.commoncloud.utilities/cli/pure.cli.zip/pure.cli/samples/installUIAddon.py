# Licensed Materials - Property of IBM
# (C) Copyright IBM Corporation 2012. All Rights Reserved.
# US Government Users Restricted Rights- Use, duplication or disclosure
# restricted by GSA ADP Schedule Contract with IBM Corp.
# Author: lixincdl@cn.ibm.com (Allen Li)

# Import ADP UI Package to IBM Workload Deployer
#
# This script is called as follows:
#
# deployer <deployer_options> -s importUIPackage.py
#     -s|--source <filename>
#
# Where:
#
# -s|--source <filename>
#     Specifies a .zip file for UI Package import
#

import getopt
import sys
import os
import shutil
import tempfile

options =[]
# parse command line arguments
try:
    (options, args) = getopt.getopt(sys.argv[1:], 's:', ['source='])
except getopt.GetoptError:
    print 'usage error, please specify zip file with the parameter -s|--source <filename>'


uiZip = None

for option in options:
    if option[0] == '-s' or option[0] == '--source':
        uiZip = option[1]

if (uiZip is None):
    print 'usage error, please specify zip file with the parameter -s|--source <filename>'
    sys.exit(1)

if (not os.path.exists(uiZip)):
    print 'the file you specified does not exist!'
    sys.exit(1)
    
if (os.path.isdir(uiZip)):
    zipped = False
elif uiZip.endswith('.zip'):
    zipped = True
else:
    print 'you need to specific a zip file'
    sys.exit(1)

try:        
    if zipped:
        deployer.addon_ui.install(uiZip)
        print 'Please reload your browser to see the changes'
        
finally:
    deployer.exit
