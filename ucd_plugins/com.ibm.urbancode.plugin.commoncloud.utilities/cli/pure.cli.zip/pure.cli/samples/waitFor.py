"""
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2012. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
"""
# waits for the specified virtual images and/or virtual systems to get
# to a non-transient state

import sys

i = 1
while i < len(sys.argv):
    if sys.argv[i] == '-vi':
        i = i + 1
        resources = deployer.virtualimages[sys.argv[i]]
    elif sys.argv[i] == '-vs':
        i = i + 1
        resources = deployer.virtualsystems[sys.argv[i]]
    else:
        raise 'unrecognized parameter %s' % sys.argv[i]
    
    i = i + 1

    for resource in resources:
        print 'waiting for %s %s to enter non-transient state' % (resource.__class__.__name__, resource.name)
        resource.waitFor()
