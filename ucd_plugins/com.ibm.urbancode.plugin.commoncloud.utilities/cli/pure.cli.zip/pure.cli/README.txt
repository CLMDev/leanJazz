IBM PureApplication System Command-Line Interface README

This file contains additional information about the PureApplication
System command-line interface that is not included in the online
documentation.

The command-line interface connects to the system with self-signed certification,
you need to use -a or --acceptcert option to avoid an SSL handshake error.

For a complete set of documentation, please refer to the online
documentation available when the command-line interface is run in
interactive mode:

   $ bin/pure
   >>> help

or:

   C:\> bin\pure.bat
   >>> help



Known issues

Issue:
   The command-line interface reports various SSL or HTTPS exceptions
   when trying to connect to a PureApplication System.

Cause:
   The SSL mechanisms that the command-line interface uses to communicate
   securely with the system were not available in older versions of
   the Java Runtime Environment (JRE).

Resolution:
   Be sure you are using a current version of the JRE to run the
   command-line interface.  If you are using a JRE provided by IBM, it
   must be Java 6 SR3 or later to properly support SSL communications
   with the system.  You can determine the level of your JRE by
   executing the following command:

      java -version
