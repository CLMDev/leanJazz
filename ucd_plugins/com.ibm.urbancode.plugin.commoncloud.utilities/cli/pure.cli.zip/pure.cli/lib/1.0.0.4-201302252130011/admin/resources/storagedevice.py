"""
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2011. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
"""

from deployer.resources.commonattrs import CommonAttributes
from deployer import utils
from deployer.resources.relationships import RelatedResource
from ipasrestresource import IPASRESTResourceCollection
from hardwarecomponent import HardwareComponent

@utils.classinit
class StorageDevice(HardwareComponent):
    'IWD11355'
    
    @classmethod
    def _classinit(cls):      
        HardwareComponent._classinit.im_func(cls)
        
        cls._registerURI(r'\A/admin/resources/storage_controllers/(?P<id>[\da-z\-]+)\Z')
        
        cls._defineRESTAttribute('capacity', 'IWD11359', readonly=True)
        cls._defineRESTAttribute('firmwarelevel', 'IWD11003', restname='firmware_level', readonly=True)
        cls._defineRESTAttribute('freecapacity', 'IWD11313', restname='free_capacity', readonly=True)
        cls._defineRESTAttribute('units', 'IWD11306', readonly=True) 
        
        # Nested Object
        cls._defineRESTAttribute('diskdrives', 'IWD11307', readonly=True, elided=True)
        cls._defineRESTAttribute('osvolumes', 'IWD11386', readonly=True, elided=True)
        cls._defineRESTAttribute('ports', 'IWD11308', readonly=True, elided=True)
        cls._defineRESTAttribute('expansions', 'IWD11309', readonly=True, elided=True)
        cls._defineRESTAttribute('mdisks', 'IWD11310', readonly=True, elided=True)  
        cls._defineRESTAttribute('statistics', 'IWD11312', readonly=True, elided=True)
        cls._defineRESTAttribute('pools', 'IWD11311', readonly=True, elided=True)
        cls._defineRESTAttribute('temperaturestats', 'IWD11314', readonly=True, elided=True)
        
        cls._defineRESTAttribute('leds', 'IWD11012', readonly=True, elided=True)
        cls._defineRESTAttribute('locations', 'IWD11010', readonly=True, elided=True)
        
    def _getDiskdrives(self):
        return self._renderRESTResourceCollection('disk_drives');
    
    def _getOsvolumes(self):
        return self._renderRESTResourceCollection('disks');
    
    def _getPorts(self):
        return self._renderRESTResourceCollection('storage_controller_ports');
    
    def _getExpansions(self):
        return self._renderRESTResourceCollection('storage_expansions');
    
    def _getMdisks(self):
        return self._renderRESTResourceCollection('storage_mdisks');

    def _getStatistics(self):
        return self._renderRESTResourceCollection('storage_node_statistics');

    def _getPools(self):
        return self._renderRESTResourceCollection('storage_pools');
    
    def _getTemperaturestats(self):
        return self._renderRESTResourceCollection('temperature_stats');
    
    @classmethod
    def _queryname(self):
        return 'storage_controllers'
    
@utils.classinit
class StorageDevices(IPASRESTResourceCollection):
    'IWD11356'

    @classmethod
    def _classinit(cls):
        cls._contains(StorageDevice)
        cls._methodHelp('__contains__', '__getattr__', '__getitem__', '__iter__',
                        '__len__', 'list', '__lshift__', '__repr__',
                        '__rshift__', '__str__', '__unicode__')
    @classmethod
    def _restname(cls):
        return 'storage_controllers'
   

@utils.classinit    
class _DiskDrive(HardwareComponent):
    'IWD11316'
        
    @classmethod
    def _classinit(cls):      
        HardwareComponent._classinit.im_func(cls)
        
        cls._registerURI(r'\A/admin/resources/disk_drives/(?P<id>[\da-z\-]+)\Z')
        
        cls._defineRESTAttribute('capacity', 'IWD11359', readonly=True)
        cls._defineRESTAttribute('drivebay', 'IWD11315', restname="drive_bay", readonly=True)
        cls._defineRESTAttribute('type', 'IWD11317', readonly=True)
        cls._defineRESTAttribute('units', 'IWD11306', readonly=True)
        
        cls._defineRESTAttribute('leds', 'IWD11012', readonly=True, elided=True)

    @classmethod
    def _queryname(self):
        return 'disk_drives'

@utils.classinit    
class _StorageControllerPort(HardwareComponent):
    'IWD11318'
        
    @classmethod
    def _classinit(cls):      
        HardwareComponent._classinit.im_func(cls)
        
        cls._registerURI(r'\A/admin/resources/storage_controller_ports/(?P<id>[\da-z\-]+)\Z')
        
        cls._defineRESTAttribute('portnum', 'IWD11324', readonly=True)
        cls._defineRESTAttribute('speed', 'IWD11325', readonly=True)
        cls._defineRESTAttribute('wwpn', 'IWD11326', readonly=True)

@utils.classinit    
class _StorageMDisk(HardwareComponent):
    'IWD11319'
        
    @classmethod
    def _classinit(cls):      
        HardwareComponent._classinit.im_func(cls)
        
        cls._registerURI(r'\A/admin/resources/storage_mdisks/(?P<id>[\da-z\-]+)\Z')
        
        cls._defineRESTAttribute('capacity', 'IWD11359', readonly=True)
        cls._defineRESTAttribute('type', 'IWD11327', restname="tier_type", readonly=True)
        
        cls._defineRESTAttribute('statistics', 'IWD11328', readonly=True, elided=True)
    
    def _getStatistics(self):
        return self._renderRESTResourceCollection('storage_mdisk_statistics');
    
@utils.classinit    
class _StorageMDiskStatistics(HardwareComponent):
    'IWD11320'
        
    @classmethod
    def _classinit(cls):      
        HardwareComponent._classinit.im_func(cls)
        
        cls._registerURI(r'\A/admin/resources/storage_mdisk_statistics/(?P<id>[\da-z\-]+)\Z')
        
        cls._defineRESTAttribute('bytesin', 'IWD11330', restname='bytes_in', readonly=True)
        cls._defineRESTAttribute('bytesout', 'IWD11331', restname='bytes_out', readonly=True)
        cls._defineRESTAttribute('created_time', 'IWD10012', readonly=True)
        cls._defineRESTAttribute('latencyin', 'IWD11332', restname='latency_in', readonly=True)
        cls._defineRESTAttribute('latencyout', 'IWD11333', restname='latency_out', readonly=True)
        cls._defineRESTAttribute('lengthoftime', 'IWD11334', restname='length_of_time', readonly=True)
        cls._defineRESTAttribute('readops', 'IWD11335', restname='read_ops', readonly=True)
        cls._defineRESTAttribute('totalbytesin', 'IWD11337', restname='total_bytes_in', readonly=True)
        cls._defineRESTAttribute('totalbytesout', 'IWD11338', restname='total_bytes_out', readonly=True)
        cls._defineRESTAttribute('totallatencyin', 'IWD11339', restname='total_latency_in', readonly=True)
        cls._defineRESTAttribute('totallatencyout', 'IWD11340', restname='total_latency_out', readonly=True)
        cls._defineRESTAttribute('totalreadops', 'IWD11341', restname='total_read_ops', readonly=True)
        cls._defineRESTAttribute('totalwriteops', 'IWD11342', restname='total_write_ops', readonly=True)
        cls._defineRESTAttribute('units', 'IWD11343', restname='units', readonly=True)
        cls._defineRESTAttribute('writeops', 'IWD11336', restname='write_ops', readonly=True)
        
@utils.classinit    
class _StorageNodeStatistics(HardwareComponent):
    'IWD11321'
        
    @classmethod
    def _classinit(cls):      
        HardwareComponent._classinit.im_func(cls)
        
        cls._registerURI(r'\A/admin/resources/storage_node_statistics/(?P<id>[\da-z\-]+)\Z')
        
        cls._defineRESTAttribute('bytesin', 'IWD11330', restname='bytes_in', readonly=True)
        cls._defineRESTAttribute('bytesout', 'IWD11331', restname='bytes_out', readonly=True)
        cls._defineRESTAttribute('created_time', 'IWD11329',  readonly=True)
        cls._defineRESTAttribute('latencyin', 'IWD11332', restname='latency_in', readonly=True)
        cls._defineRESTAttribute('latencyout', 'IWD11333', restname='latency_out', readonly=True)
        cls._defineRESTAttribute('lengthoftime', 'IWD11334', restname='length_of_time', readonly=True)
        cls._defineRESTAttribute('messagein', 'IWD11344', restname='num_of_mes_in', readonly=True)
        cls._defineRESTAttribute('messageout', 'IWD11345', restname='num_of_mes_out', readonly=True)
        cls._defineRESTAttribute('totalbytesin', 'IWD11337', restname='total_bytes_in', readonly=True)
        cls._defineRESTAttribute('totalbytesout', 'IWD11338', restname='total_bytes_out', readonly=True)
        cls._defineRESTAttribute('totallatencyin', 'IWD11339', restname='total_latency_in', readonly=True)
        cls._defineRESTAttribute('totallatencyout', 'IWD11340', restname='total_latency_out', readonly=True)
        cls._defineRESTAttribute('totalmessagein', 'IWD11346', restname='total_num_of_mes_in', readonly=True)
        cls._defineRESTAttribute('totalmessageout', 'IWD11347', restname='total_num_of_mes_out', readonly=True)
        cls._defineRESTAttribute('units', 'IWD11343', restname='units', readonly=True)
        
@utils.classinit    
class _StoragePool(HardwareComponent):
    'IWD11322'
        
    @classmethod
    def _classinit(cls):      
        HardwareComponent._classinit.im_func(cls)
        
        cls._registerURI(r'\A/admin/resources/storage_pools/(?P<id>[\da-z\-]+)\Z')
        
        cls._defineRESTAttribute('capacity', 'IWD11359', restname="total_capacity", readonly=True)
        cls._defineRESTAttribute('usedcapacity', 'IWD11348', restname="used_capacity", readonly=True)
        cls._defineRESTAttribute('freecapacity', 'IWD11313', restname="free_capacity", readonly=True)
        cls._defineRESTAttribute('units', 'IWD11306', restname="units", readonly=True)
        
        cls._defineRESTAttribute('disks', '', readonly=True, elided=True)
        cls._defineRESTAttribute('storagevolumes', '', readonly=True, elided=True)
        cls._defineRESTAttribute('volumes', 'IWD11349', readonly=True, elided=True)
    
    def _getVolumes(self):
        return self._renderRESTResourceCollection('volumes');
    
    def _getStoragevolumes(self):
        return self._renderRESTResourceCollection('storage_volumes');

    def _getDisks(self):
        return self._renderRESTResourceCollection('disks');
    
    @classmethod
    def _queryname(self):
        return 'storage_pools'
    
@utils.classinit    
class _TemperatureStat(HardwareComponent):
    'IWD11350'
        
    @classmethod
    def _classinit(cls):      
        HardwareComponent._classinit.im_func(cls)
        
        cls._registerURI(r'\A/admin/resources/temperature_stats/(?P<id>[\da-z\-]+)\Z')
        
        cls._defineRESTAttribute('ambienttemperature', 'IWD11351', restname="ambient_temperature", readonly=True)
        cls._defineRESTAttribute('exhausttemperature', 'IWD11352', restname="exhaust_temperature", readonly=True)
        cls._defineRESTAttribute('maxambienttemperature', 'IWD11353', restname="max_ambient_temperature", readonly=True)
        cls._defineRESTAttribute('maxexhausttemperature', 'IWD11354', restname="max_exhaust_temperature", readonly=True)

@utils.classinit
class StorageExpansion(HardwareComponent):
    'IWD11323'
    
    @classmethod
    def _classinit(cls):      
        HardwareComponent._classinit.im_func(cls)
        
        cls._registerURI(r'\A/admin/resources/storage_expansions/(?P<id>[\da-z\-]+)\Z')
        
        cls._defineRESTAttribute('capacity', 'IWD11359', readonly=True)
        cls._defineRESTAttribute('firmwarelevel', 'IWD11003', restname='firmware_level', readonly=True)
        cls._defineRESTAttribute('freecapacity', 'IWD11313', restname='free_capacity', readonly=True)
        cls._defineRESTAttribute('units', 'IWD11306', readonly=True) 
        
        # Nested Object
        cls._defineRESTAttribute('diskdrives', 'IWD11307', readonly=True, elided=True)
        cls._defineRESTAttribute('temperaturestats', 'IWD11314', readonly=True, elided=True)
        
        cls._defineRESTAttribute('leds', 'IWD11012', readonly=True, elided=True)
        cls._defineRESTAttribute('locations', 'IWD11010', readonly=True, elided=True)
        
    @classmethod
    def _queryname(self):
        return 'storage_expansions'
            