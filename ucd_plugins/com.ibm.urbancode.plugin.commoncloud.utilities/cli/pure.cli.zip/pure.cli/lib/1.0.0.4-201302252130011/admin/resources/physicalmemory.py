"""
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2011. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
"""

from deployer.resources.commonattrs import CommonAttributes
from deployer import utils, http
from deployer.resources.relationships import RelatedResource, RelatedResourceCollection
from ipasrestresource import IPASRESTResourceCollection, IPASRESTResource
from deployer.resources.restresource import RESTResource
from deployer.messages import message

@utils.classinit
class PhysicalMemory(IPASRESTResource):
    'Instance'
        
    @classmethod
    def _classinit(cls):
        cls._registerURI(r'\A/admin/resources/physical_memory/(?P<id>[\da-z\-]+)\Z')
        
        cls._defineRESTAttribute('id', 'IWD11137', readonly=True)
        cls._defineRESTAttribute('name', 'IWD11138', readonly=True)
        cls._defineRESTAttribute('state', 'IWD11139', readonly=True)
        
        cls._defineRESTAttribute('total', 'IWD11075', readonly=True)
        cls._defineRESTAttribute('used', 'IWD11076', readonly=True)
        cls._defineRESTAttribute('units', 'IWD11140', readonly=True)
        cls._defineRESTAttribute('allocated', 'IWD11077', readonly=True)
        cls._defineRESTAttribute('url', 'IWD10033', restname='id', readonly=True)
        #use another rest call to get this
        cls._defineRESTAttribute('physicalmemorymodules', 'IWD11078', restname='physical_memory_modules', readonly=True, elided=True)   
  
    def _getPhysicalmemorymodules(self):
        if self._restattrs.has_key('physical_memory_modules') and len(self._restattrs['physical_memory_modules']) > 0:
            leds = self._restattrs['physical_memory_modules']
            return [RESTResource.resourceForURI(id) for id in leds]
        else:
            return None   

@utils.classinit
class PhysicalMemoryModule(RelatedResource, CommonAttributes):
    'Instance'
        
    @classmethod
    def _classinit(cls):
        cls._registerURI(r'\A/admin/resources/physical_memory_modules/(?P<id>[\da-z\-]+)\Z')
        
        cls._defineRESTAttribute('id', 'IWD11141', readonly=True)
        cls._defineRESTAttribute('name', 'IWD11142', readonly=True)
        cls._defineRESTAttribute('state', 'IWD11143', readonly=True)
        
        cls._defineRESTAttribute('size', 'IWD11079', readonly=True)
        cls._defineRESTAttribute('units', 'IWD11140', readonly=True)

        #use another rest call to get this
        cls._defineRESTAttribute('leds', 'IWD11144', readonly=True,  elided=True)
    
    def _getLeds(self):
        if self._restattrs.has_key('leds') and len(self._restattrs['leds']) > 0:
            leds = self._restattrs['leds']
            return [RESTResource.resourceForURI(id) for id in leds]
        else:
            return None       
    