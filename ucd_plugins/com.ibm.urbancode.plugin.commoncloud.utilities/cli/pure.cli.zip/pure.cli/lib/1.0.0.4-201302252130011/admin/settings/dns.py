#
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2011. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
#
from deployer import http, messages, utils, validators
from deployer.resources.localresource import LocalResource
from server import _Servers

class Dns(object):
    '''RM09380'''
   
    _PROPERTYHELP_ = ['servers']
    
    _servers = None
    
    class _DNSServers(_Servers):
        def __init__(self):
             super(Dns._DNSServers, self).__init__('DNS_SERVERS')
    
    Servers = utils.MakeSingleton(_DNSServers)
    
    def _getDnsServers(self):
        if self._servers:
            self._servers.refresh()
        else:
            self._servers = Dns.Servers()
        return self._servers

    def servers_(self):
        '''IWD12000'''
        pass

    servers = property(_getDnsServers)
