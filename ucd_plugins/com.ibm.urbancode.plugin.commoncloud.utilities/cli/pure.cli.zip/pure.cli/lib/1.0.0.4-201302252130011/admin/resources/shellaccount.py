"""
#*=================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2011. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
"""

from deployer import http, utils, validators
from deployer.resources.commonattrs import CommonAttributes
from deployer import utils
from deployer.resources.relationships import RelatedResource
from ipasrestresource import IPASRESTResourceCollection, IPASRESTResource
from role import Roles
from deployer import validators

@utils.classinit
class ShellAccount(IPASRESTResource):
    ''

    @classmethod
    def _classinit(cls):
        cls._registerURI(r'\A/admin/resources/users/(?P<userid>[\da-z\-]+)/accounts/(?P<id>[\da-z\-]+)\Z')
        
        cls._defineRESTAttribute('created_time', '', readonly=True)
        cls._defineRESTAttribute('updated_time', '', readonly=True)
                
        cls._methodHelp('delete')
    
             
@utils.classinit
class ShellAccounts(IPASRESTResourceCollection):
    ''

    @classmethod
    def _classinit(cls):
        cls._contains(ShellAccount)
        cls._methodHelp( 'create',  'list')

    @classmethod
    def _restname(cls):
        return 'accounts'
    
    #todo: add help message
    def _create(self, dict={}):
        validators.string(dict.get('password'), 'password')
        return super(ShellAccounts, self)._create(dict)

