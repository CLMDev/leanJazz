"""
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2011. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
"""

from deployer.resources.commonattrs import CommonAttributes
from deployer import utils, http
from deployer.resources.relationships import RelatedResource, RelatedResourceCollection
from ipasrestresource import IPASRESTResourceCollection, IPASRESTResource
from deployer.resources.restresource import RESTResource
from deployer.messages import message

@utils.classinit
class PhysicalCPU(IPASRESTResource):
    ''
        
    @classmethod
    def _classinit(cls):
        cls._registerURI(r'\A/admin/resources/physical_cpus/(?P<id>[\da-z\-]+)\Z')
        
        cls._defineRESTAttribute('id', 'IWD11128', readonly=True)
        cls._defineRESTAttribute('name', 'IWD11129', readonly=True)
        cls._defineRESTAttribute('state', 'IWD11130', readonly=True)
        
        cls._defineRESTAttribute('processors', 'IWD11059', readonly=True)
        cls._defineRESTAttribute('allocated_processors', 'IWD11060', readonly=True)
        cls._defineRESTAttribute('average_core_temperature', 'IWD11061', readonly=True)
        cls._defineRESTAttribute('average_core_temperature_units', 'IWD11062',  readonly=True)
        cls._defineRESTAttribute('cpu_utilization', 'IWD11063',  readonly=True)
        cls._defineRESTAttribute('cpu_utilization_units', 'IWD11064',  readonly=True)
        cls._defineRESTAttribute('max_average_core_temperature', 'IWD11065', readonly=True)
        cls._defineRESTAttribute('max_cpu_utilization', 'IWD11066',  readonly=True)

        #use another rest call to get this
        cls._defineRESTAttribute('physicalcpumodules', 'IWD11067', restname='physical_cpu_modules', readonly=True, elided=True)
        cls._defineRESTAttribute('url', 'IWD10033', restname='id', readonly=True)
        cls._methodHelp('__contains__', '__delattr__', '__eq__',
                        '__hash__', 'isStatusTransient', '__nonzero__',
                        'refresh', '__repr__', '__str__', '__unicode__')
        
    def _getPhysicalcpumodules(self):
        if self._restattrs.has_key('physical_cpu_modules') and len(self._restattrs['physical_cpu_modules'])>0:
            ids = self._restattrs['physical_cpu_modules']
            return [RESTResource.resourceForURI(id) for id in ids]
        else:
            return None
        
@utils.classinit
class PhysicalCPUModule(IPASRESTResource):
    ''
        
    @classmethod
    def _classinit(cls):
        cls._registerURI(r'\A/admin/resources/physical_cpu_modules/(?P<id>[\da-z\-]+)\Z')
        
        cls._defineRESTAttribute('id', 'IWD11131', readonly=True)
        cls._defineRESTAttribute('name', 'IWD11132', readonly=True)
        cls._defineRESTAttribute('state', 'IWD11133', readonly=True)
        
        cls._defineRESTAttribute('capabilities', 'IWD11068', readonly=True)
        cls._defineRESTAttribute('cores', 'IWD11069', readonly=True)
        cls._defineRESTAttribute('current_frequency', 'IWD11070',  readonly=True)

        #use another rest call to get this
        cls._defineRESTAttribute('physical_core_stats', 'IWD11071',  readonly=True, elided=True)
        cls._defineRESTAttribute('url', 'IWD10033', restname='id', readonly=True)
        cls._methodHelp('__contains__', '__delattr__', '__eq__',
                        '__hash__', 'isStatusTransient', '__nonzero__',
                        'refresh', '__repr__', '__str__', '__unicode__')
    
    def _getPhysicalcores(self):
        if self._restattrs.has_key('physical_core_stats') and len(self._restattrs['physical_core_stats'])>0:
            ids = self._restattrs['physical_core_stats']
            return [RESTResource.resourceForURI(id) for id in ids]
        else:
            return None
        

@utils.classinit
class PhysicalCore(IPASRESTResource):
    ''
        
    @classmethod
    def _classinit(cls):
        cls._registerURI(r'\A/admin/resources/physical_core_stats/(?P<id>[\da-z\-]+)\Z')
        
        cls._defineRESTAttribute('id', 'IWD11134', readonly=True)
        cls._defineRESTAttribute('name', 'IWD11135', readonly=True)
        cls._defineRESTAttribute('state', 'IWD11136', readonly=True)
        
        cls._defineRESTAttribute('temperature', 'IWD11072', readonly=True)
        cls._defineRESTAttribute('units', 'IWD11073', readonly=True)
        cls._defineRESTAttribute('warning', 'IWD11074', readonly=True)
        cls._defineRESTAttribute('url', 'IWD10033', restname='id', readonly=True)