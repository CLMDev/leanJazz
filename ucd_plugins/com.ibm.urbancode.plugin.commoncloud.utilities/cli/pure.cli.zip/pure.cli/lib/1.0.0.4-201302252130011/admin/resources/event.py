"""
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2011. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
"""

from deployer.resources.commonattrs import CommonAttributes
from deployer import http, utils, prettify
from deployer.resources.relationships import RelatedResource
from ipasrestresource import IPASRESTResourceCollection, IPASRESTResource
from deployer.resources.restresource import RESTResource, RESTResourceCollection
import os

@utils.classinit
class Event(IPASRESTResource):
    'IWD11305'
    
    @classmethod
    def _classinit(cls):
        cls._registerURI(r'\A/admin/resources/events/(?P<id>[\da-z\-]+)\Z')


        cls._defineRESTAttribute('msg_text', 'IWD11167', readonly=True)
        cls._defineRESTAttribute('type', 'IWD11168', readonly=True)
        cls._defineRESTAttribute('severity', 'IWD11169', readonly=True)
        cls._defineRESTAttribute('category', 'IWD11170', readonly=True)
        cls._defineRESTAttribute('created_time', 'IWD11171', readonly=True)
        cls._defineRESTAttribute('updated_time', '', readonly=True)
        cls._defineRESTAttribute('object_detail', '', readonly=True)
        cls._defineRESTAttribute('state', '', readonly=True)
        cls._defineRESTAttribute('trap_time', '', readonly=True)
        cls._defineRESTAttribute('trap_id', '', readonly=True)
        cls._defineRESTAttribute('count', '', readonly=True)
        cls._defineRESTAttribute('type_detail', '', readonly=True)
        cls._defineRESTAttribute('severity_value', '', readonly=True)
        cls._defineRESTAttribute('parent_type', '', readonly=True)
        cls._defineRESTAttribute('url', 'IWD10033', restname='id', readonly=True)
        
        # Nested Object
        cls._defineRESTAttribute('extra_data', '', readonly=True, elided=True)
        cls._defineRESTAttribute('comments', '', readonly=True, elided=True)
        cls._defineRESTAttribute('parent', '', readonly=True, elided=True)
  
        cls._methodHelp( 'delete', 'refresh')
    
    def _getComments(self):
        eventId = self.url[self.url.rfind("/") + 1:]
        items = http.get('/admin/resources/comments?parent=' + eventId)
        if not items:
            return None
        return [RESTResource.resourceForURI(json['id'], json) for json in items]    
        
    def _getParent(self):
        parentUrl = self._restattrs[self.parent_type]
        items = http.get(parentUrl)
        if not items:
            return None
        return RESTResource.resourceForURI(items['id'])
        
    def _getExtra_data(self):
       extraDataPath = self._restattrs['extra_data_table']
       extraDataid = self._restattrs['extra_data_id']
       if extraDataPath!= None and extraDataid!= None:
           items = http.get('/admin/resources/' + extraDataPath + '/' + extraDataid)
           if not items:
               return None
           return prettify.PrettyDict(items)
    
@utils.classinit
class Events(IPASRESTResourceCollection):
    'IWD11304'

    @classmethod
    def _classinit(cls):
        cls._contains(Event)
        cls._methodHelp( 'delete', 'list', 'export')
    
    #TODO: need a message
    def export(self, path = None, filt = {}):
        doclose = False
        if not path:
            f = 'export/events.csv'
        else:
            if not os.path.isdir(path):
                os.mkdir(path)
            f = os.path.join(path, 'events.csv')
        
        f = file(f, 'w')
        doclose = True
        url = self.uri
        if url.find('?') == -1:
            url += '?'
        else:
            url += '&'
        filter = utils.objectToQuery(filt)
        http.get(url + filter + "&csv=true", responseHandler = utils.curryFunction(utils.getResponseHandler, f))
        if doclose:
            f.close()
        return path
        
    @classmethod    
    def _restname(cls):
        return 'events'
    
   
        
    

@utils.classinit    
class _Comments(IPASRESTResource):
    ''
        
    @classmethod
    def _classinit(cls):      
        
        cls._registerURI(r'\A/admin/resources/comments/(?P<id>[\da-z\-]+)\Z')
        
        cls._defineRESTAttribute('updated_time', '', readonly=True)
        cls._defineRESTAttribute('created_time', '', readonly=True)
        cls._defineRESTAttribute('owner_id', '', readonly=True)
        cls._defineRESTAttribute('events_url', '', restname='events', readonly=True)
        cls._defineRESTAttribute('url', '', restname='id', readonly=True)
        cls._defineRESTAttribute('state', '', readonly=True)
        cls._defineRESTAttribute('type', '', readonly=True)
        cls._defineRESTAttribute('category', '', readonly=True)
        cls._defineRESTAttribute('parent_type', '', readonly=True)
        cls._defineRESTAttribute('comment', '', readonly=True)

    @classmethod
    def _queryname(self):
        return 'id'