"""
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2011. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
"""


from role import Roles
from cloud import Cloud, Clouds
from group import Group, Groups
from user import User, Users
from ip import IP, IPs
from ipgroup import IPGroup, IPGroups
from virtualappliance import VirtualAppliance, VirtualAppliances
from host import Host, Hosts
from deployer import utils

IP._containedBy(IPGroup, doc='RM09304')
IPGroup._contains(IPs, doc='RM09308')

#*===================================================================
# task 23344
#*===================================================================
from computenode import *
from managementnode import *
from event import *
from problem import *
from advmanager import AdvancedManager, AdvancedManagers
from storagedevice import *
from networkdevice import *

from ipasacl import *
from job import Job, Jobs

if not utils.isSparta():
    from virtualmachine import *

from physicalcpu import *
from physicalmemory import *
from image import *
from virtualmachinegroup import *
from volume import *
from osvolume import *
from storagevolume import *
from vmconfiguration import VMConfiguration, VMConfigurations
from volumeconfiguration import VolumeConfiguration, VolumeConfigurations
from vlan import VLAN, VLANs
from fixpack import FixPack, FixPacks
from shellaccount import ShellAccount, ShellAccounts
#from credential import Credential, Credentials

if not utils.isSparta():
    Cloud._contains(VMConfigurations)
    VMConfiguration._containedBy(Cloud)
    Cloud._contains(VolumeConfigurations)
    VolumeConfiguration._containedBy(Cloud)

# auditing
from audit import Audit, Audits

User._manyManyLinksTo(Groups, doc='RM09338')
Group._manyManyLinksTo(Users, doc='RM09339')

Cloud._hasMany(IPGroups, ownedattrname='cloud',ownedrestattrname='vdc',doc='IWD10002')
IPGroup._belongsTo(Cloud, attrname='cloud', restattrname='vdc', doc='IWD10001')

if utils.isSparta():
    Cloud._hasMany(Hosts, ownedattrname='cloud',ownedrestattrname='vdc',doc='IWD32007')
    Host._belongsTo(Cloud, attrname='cloud', restattrname='vdc', doc='IWD32008')

Cloud._hasMany(ComputeNodes, ownedattrname='cloud',ownedrestattrname='vdcs',  doc='IWD10003')
ComputeNode._belongsTo(Cloud, attrname='cloud',restattrname='vdcs', doc='IWD11009')

User._contains(ShellAccounts, attrname='shellaccounts', doc='RM09733')
ShellAccount._containedBy(User, doc='RM09111')
