"""
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2011. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
"""

from deployer import http, utils, validators, prettify
from deployer.resources.commonattrs import CommonAttributes
from deployer import utils
from deployer.resources.relationships import RelatedResource
from deployer.resources.restresource import RESTResource
from ipasrestresource import IPASRESTResourceCollection, IPASRESTResource
from role import Roles

@utils.classinit
class FixPack(IPASRESTResource):
    'IWD12014'
    
    @classmethod
    def _classinit(cls):
        cls._registerURI(r'\A/admin/resources/fix_packs/(?P<id>[\da-z\-]+)\Z')
        cls._defineRESTAttribute('id', 'IWD11000', readonly=True)
        cls._defineRESTAttribute('url', 'IWD10033', restname='id', readonly=True)
        cls._defineRESTAttribute('name', 'IWD11001', readonly=True)
        cls._defineRESTAttribute('description', 'IWD12018', restname='description_text', readonly=True)
        cls._defineRESTAttribute('short_description', 'IWD12019', restname='short_description_text', readonly=True)
        cls._defineRESTAttribute('size', 'IWD12020', readonly=True)
        cls._defineRESTAttribute('unique_size', 'IWD12021', readonly=True)
        cls._defineRESTAttribute('state', 'IWD12022', readonly=True)
        cls._defineRESTAttribute('created_time', 'IWD12023', readonly=True)
        cls._defineRESTAttribute('updated_time', 'IWD12024', readonly=True)
        cls._defineRESTAttribute('fixes', 'IWD12025', restname="aggregated_fixes", readonly=True)
        cls._defineRESTAttribute('change_plan', 'IWD12026', restname='change_plan_id', readonly=True)
        
        cls._methodHelp('delete', 'isStatusTransient', 'refresh', 'waitFor', 'install')

        
    def _getFixes(self):
        if(self._restattrs.has_key("aggregated_fixes")):
            uris = self._restattrs['aggregated_fixes']
            return [RESTResource.resourceForURI(uri) for uri in uris]
        else:
            return None

    def _getChange_plan(self):
        if self._restattrs.has_key("change_plan_id") and self._restattrs['change_plan_id']:
            changePlanId = self._restattrs['change_plan_id'];
            return RESTResource.resourceForURI('/admin/resources/change_plans/%s' % changePlanId)
        else:
            return None
        
    
    def install(self):
        'IWD12028'
        if self._restattrs.has_key("change_plan_id") and self._restattrs['change_plan_id']:
            changePlanId = self._restattrs['change_plan_id']
            return http.putJSON('/admin/resources/change_plans/%s' % changePlanId, {})
        else:
            return 
  
        
    
@utils.classinit
class FixPacks(IPASRESTResourceCollection):
    'IWD12013'

    @classmethod
    def _classinit(cls):
        cls._contains(FixPack)
        if utils.isSparta():
            cls._methodHelp('list','create','listAll')
        else:
            cls._methodHelp('list', 'create')
        
    @classmethod    
    def _restname(cls):
        return 'fix_packs'
    
    
    #todo: add credential support
    def create(self, dict):
        'IWD12027'
        if not dict.has_key('access_type'):
            dict['access_type'] = 'url'
        
        return super(FixPacks, self).create(dict);
    
    if utils.isSparta():
        @staticmethod
        def listAll():
            'IWD32009'
            json = http.get('/admin/resources/all_fixpacks')
            print utils.utos(prettify.prettify(json))
    
    
@utils.classinit
class ChangePlan(RelatedResource, CommonAttributes):
    ''
    @classmethod
    def _classinit(cls):
        cls._registerURI(r'\A/admin/resources/change_plans/(?P<id>[\da-z\-]+)\Z')
        cls._defineRESTAttribute('url', '', restname='id', readonly=True)
        cls._defineRESTAttribute('total_steps', '', readonly=True)
        cls._defineRESTAttribute('completed_steps', '', readonly=True)
        cls._defineRESTAttribute('state', '', readonly=True)
        cls._defineRESTAttribute('created_time', '', readonly=True)
        cls._defineRESTAttribute('updated_time', '', readonly=True)
        cls._defineRESTAttribute('change_requests', '', readonly=True)
    
    def _getChange_requests(self):
        if(self._restattrs.has_key('change_requests')):
            urls = self._restattrs['change_requests']
            return [RESTResource.resourceForURI(url) for url in urls]
        else:
            return None

@utils.classinit
class ChangeRequest(RelatedResource, CommonAttributes):
    ''
    @classmethod
    def _classinit(cls):
        cls._registerURI(r'\A/admin/resources/change_requests/(?P<id>[\da-z\-]+)\Z')
        cls._defineRESTAttribute('url', '', restname='id', readonly=True)
        cls._defineRESTAttribute('order', '', readonly=True)
        cls._defineRESTAttribute('state', '', readonly=True)
        cls._defineRESTAttribute('created_time', '', readonly=True)
        cls._defineRESTAttribute('updated_time', '', readonly=True)
        cls._defineRESTAttribute('fix', '', restname='aggregated_fixes_id', readonly=True)
        cls._defineRESTAttribute('updatable_component', '', restname='updatable_components_id', readonly=True)

    def _getFix(self):
        if self._restattrs.has_key('aggregated_fixes_id'):
            id = self._restattrs['aggregated_fixes_id']
            return RESTResource.resourceForURI('/admin/resources/aggregated_fixes/%s' % id)
        else:
            return None
        
    def _getUpdatable_component(self):
        if self._restattrs.has_key('updatable_components_id'):
            id = self._restattrs['updatable_components_id']
            return RESTResource.resourceForURI('/admin/resources/updatable_components/%s' % id)
        else:
            return None

@utils.classinit
class Fix(RelatedResource, CommonAttributes):
    ''
    @classmethod
    def _classinit(cls):
        cls._registerURI(r'\A/admin/resources/aggregated_fixes/(?P<id>[\da-z\-]+)\Z')
        cls._defineRESTAttribute('url', '', restname='id', readonly=True)
        cls._defineRESTAttribute('name', '', readonly=True)
        cls._defineRESTAttribute('description', '', restname='description_text', readonly=True)
        cls._defineRESTAttribute('short_description', '', restname='short_description_text', readonly=True)
        cls._defineRESTAttribute('install_time_units', '', readonly=True)
        cls._defineRESTAttribute('time_estimate', '', readonly=True)
        cls._defineRESTAttribute('state', '', readonly=True)
        cls._defineRESTAttribute('created_time', '', readonly=True)
        cls._defineRESTAttribute('updated_time', '', readonly=True)
        cls._defineRESTAttribute('order', '', readonly=True)
        cls._defineRESTAttribute('updatable_components_name', '', readonly=True)
        cls._defineRESTAttribute('is_deselectable', '', readonly=True)

@utils.classinit
class UpdatableComponents(RelatedResource, CommonAttributes):
    ''
    @classmethod
    def _classinit(cls):
        cls._registerURI(r'\A/admin/resources/updatable_components/(?P<id>[\da-z\-]+)\Z')
        cls._defineRESTAttribute('url', '', restname='id', readonly=True)
        cls._defineRESTAttribute('chassis_number', '', readonly=True)
        cls._defineRESTAttribute('component_name', '', readonly=True)
        cls._defineRESTAttribute('component_number', '', readonly=True)
        cls._defineRESTAttribute('component_state', '', readonly=True)
        cls._defineRESTAttribute('created_time', '', readonly=True)
        cls._defineRESTAttribute('updated_time', '', readonly=True)
        cls._defineRESTAttribute('name', '', restname='label_text', readonly=True)
        cls._defineRESTAttribute('rack_number', '', readonly=True)
        cls._defineRESTAttribute('rollback_allowed', '', readonly=True)