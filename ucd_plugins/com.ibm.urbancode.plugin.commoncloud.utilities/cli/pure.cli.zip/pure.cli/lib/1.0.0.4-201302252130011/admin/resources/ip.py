"""
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2011. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
"""

from deployer.resources.commonattrs import CommonAttributes
from deployer import http, utils, validators
from deployer.resources.restresource import RESTResource, RESTResourceCollection
from ipasrestresource import IPASRESTResourceCollection,IPASRESTResource


@utils.classinit
class IP(IPASRESTResource):
    'RM09081'

    @classmethod
    def _classinit(cls):
        cls._registerURI(r'\A/deployment/resources/addresses/(?P<id>[\da-f\-]+)\Z')
       
        cls._defineRESTAttribute('currentstatus', 'RM09167', restname='state', readonly=True)
        cls._defineRESTAttribute('id', 'RM09168', readonly=True)
        cls._defineRESTAttribute('url', 'IWD10033', restname='id', readonly=True)
        cls._defineRESTAttribute('ip', 'RM09169', readonly=True)
        cls._defineRESTAttribute('hostname', 'RM09637', readonly=True)
        # type - hidden
        cls._defineRESTAttribute('updated_time', 'IWD10021', readonly=True)
        cls._defineRESTAttribute('created_time', 'IWD10020', readonly=True)

        cls._methodHelp('delete')

    def _containedByFget(self):
        subnetId = self._restattrs.get('subnet')
        if subnetId == None:
            return None
        return RESTResource.resourceForURI(subnetId)



@utils.classinit
class IPs(IPASRESTResourceCollection):
    'IWD10018'
   
    URI = "/deployment/resources/addresses"

    @classmethod
    def _classinit(cls):
        cls._contains(IP)
        cls._methodHelp('list', 'create')


    CREATE_ATTRIBUTES = [
        IP._wizardStep('ip')
    ]

    @classmethod
    def _restname(cls):
        return 'addresses'
    # private methods
 
    def _createFromIPRange(self, fromIP, toIP):
        dict = {"address_range": {"from": fromIP, "to": toIP}}
        json = http.postJSON(self.uri, dict)
        return [RESTResource.resourceForURI(self._uriForResource(address), address) for address in json ]
    
    def _createFromHostnames(self, hostnames):
        json = http.postJSON(self.uri, {"address_range": {"hostnames": hostnames}})
        return [RESTResource.resourceForURI(self._uriForResource(address), address) for address in json ]
    
    def _createFromIPs(self, ips):
        json = http.postJSON(self.uri, {"address_range": {"ips": ips}})
        return [RESTResource.resourceForURI(self._uriForResource(address), address) for address in json ]

    def _defaultSearch(self, s):
        # IP REST API does not support filters
        return utils.findAll(lambda ip: ip.ip == s, self._list())


    def _isIP(self, value):
        try:
            validators.allipaddress(value, value)
            return True
        except ValueError:
            return False

    def _list(self, filt = {}):
       subnetUUID = self.uri.split('/')[-2];
       filt['subnet'] = subnetUUID
       
       temp = self.uri
       self.uri = self.URI
       result =  super(IPs, self)._list(filt)
       self.uri = temp
       
       return result
       
    # public methods

    def create(self, other, toIP=None):
        'IWD10019'
        if toIP == None:
            if isinstance(other, str) or isinstance(other, unicode):
                toIP = other
                return self._createFromIPRange(other, toIP)
            
            elif isinstance(other, list) and utils.all(other, lambda s: utils.isString(s)) and other and self._isIP(other[0]):
                return self._createFromIPs(other)
            
            elif isinstance(other, list) and utils.all(other, lambda s: utils.isString(s)):
                return self._createFromHostnames(other)
        else:
            return self._createFromIPRange(other, toIP)
        
    def _uriForResource(self, attrs):
        '''Given a set of attributes returned from the server, return the
        URI of the corresponding resource from this collection.
        '''
        uuid = attrs['id'].split('/')[-1]
        return '%s/%s' % (self.URI, uuid)  