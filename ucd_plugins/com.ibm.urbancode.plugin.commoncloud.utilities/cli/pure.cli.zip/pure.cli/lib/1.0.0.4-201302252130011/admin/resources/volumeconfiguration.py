"""
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2011. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
"""

from deployer.resources.commonattrs import CommonAttributes
from deployer import http, utils, validators
from deployer.resources.relationships import RelatedResource, RelatedResourceCollection
from deployer.resources.restresource import RESTResource, RESTResourceCollection
from ipasrestresource import IPASRESTResourceCollection, IPASRESTResource



@utils.classinit
class VolumeConfiguration(IPASRESTResource):
    'IWD10017'

    @classmethod
    def _classinit(cls):
        cls._registerURI(r'\A/admin/resources/volume_configurations/(?P<id>[\da-f\-]+)\Z')
        cls._registerURI(r'\A/deployment/resources/volume_configurations/(?P<id>[\da-f\-]+)\Z')
        
        cls._defineRESTAttribute('id', 'IWD10026', readonly=True)
        cls._defineRESTAttribute('name', 'IWD10027')
        cls._defineRESTAttribute('size', 'IWD10028')
        #TODO: add message for description
        cls._defineRESTAttribute('description', '')
        cls._defineRESTAttribute('created_time', 'IWD10029', readonly=True)
        cls._defineRESTAttribute('updated_time', 'IWD10030', readonly=True)
        cls._defineRESTAttribute('url', 'IWD10033', restname='id', readonly=True)
        
    def _containedByFget(self):
        cloudId = self._restattrs.get('vdc')
        if cloudId == None:
            return None
        return RESTResource.resourceForURI(cloudId)
       
@utils.classinit
class VolumeConfigurations(IPASRESTResourceCollection):
    'IWD10025'
   
    URI = "/admin/resources/volume_configurations"

    @classmethod
    def _classinit(cls):
        cls._contains(VolumeConfiguration)
        cls._methodHelp('create', 'list')


    CREATE_ATTRIBUTES = [
        VolumeConfiguration._wizardStep('name'),
        VolumeConfiguration._wizardStep('size'),
    ]
    
    @classmethod
    def _restname(cls):
        return 'volume_configurations'
    
    def _create(self, dict):
        
        dict['vdc'] = {'uri':self.uri[0: self.uri.rindex('/')]}
        
        temp = self.uri
        self.uri = self.URI
        
        object = None
        try:
           object = super(VolumeConfigurations, self)._create(dict, ['vdc'])
        finally:        
            self.uri = temp
            
        return object   
    
    def _list(self, filt = {}):
        
       vdcUUID = self.uri.split('/')[-2]
       filt['vdc'] = vdcUUID
       
       temp = self.uri
       self.uri = self.URI
       result =  super(VolumeConfigurations, self)._list(filt)
       self.uri = temp
       
       return result

 
