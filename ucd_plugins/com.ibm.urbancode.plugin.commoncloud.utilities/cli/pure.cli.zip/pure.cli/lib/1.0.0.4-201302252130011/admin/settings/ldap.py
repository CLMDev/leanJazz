"""
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2011. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
"""

from deployer.resources.commonattrs import CommonAttributes
from deployer import utils, http
from deployer.resources.relationships import RelatedResource
from deployer.resources.restresource import RESTResource, RESTResourceCollection
from deployer.resources.restdict import RESTBackedDict

@utils.classinit
class LDAP(RESTResource):
    'IWD11233'
    
    URI = '/admin/resources/ldap_configs/?name=default'

    @classmethod
    def _classinit(cls):
        cls._registerURI(r'\A/admin/resources/ldap_configs/?name=default')

        cls._defineRESTAttribute('name', 'IWD11172', readonly=True)
        
        cls._defineRESTAttribute('jndi_provider_url', 'RM09418')
        cls._defineRESTAttribute('jndi_security_credentials', 'RM09423', writeonly=True)
        cls._defineRESTAttribute('jndi_security_principal', 'RM09422')
        cls._defineRESTAttribute('ldap_group_base_dn', 'RM09420')
        cls._defineRESTAttribute('ldap_userid_base_dn', 'RM09419')        
        cls._defineRESTAttribute('ldap_userid_search_filter_pattern', 'RM09421')
        
        cls._defineRESTAttribute('ldap_membership_search_filter_pattern', 'RM09995')
        cls._defineRESTAttribute('ldap_membership_search_attr', 'RM09996')
        cls._defineRESTAttribute('ldap_group_search_attr', 'RM09997')
        cls._defineRESTAttribute('jndi_connect_pool', 'RM09998')
        cls._defineRESTAttribute('jndi_read_timeout', 'RM09999')
        
        cls._defineRESTAttribute('created_time', 'IWD11175', readonly=True)
        cls._defineRESTAttribute('updated_time', 'IWD11176', readonly=True)
        cls._defineRESTAttribute('url','IWD10033',restname='id', readonly=True)

        
    def __init__(self, uri=None, attrs=None):
        super(LDAP, self).__init__(self.URI, attrs)
        
    def _setLdap_membership_search_filter_pattern(self, value):    
         http.putJSON('/admin/resources/ldap_configs/', {"ldap_membership_search_filter_pattern": value})
         super(RESTBackedDict, self._restattrs).update({'ldap_membership_search_filter_pattern': value})

    def _setLdap_membership_search_attr(self, value):    
         http.putJSON('/admin/resources/ldap_configs/', {"ldap_membership_search_attr": value})
         super(RESTBackedDict, self._restattrs).update({'ldap_membership_search_attr': value})
         
    def _setLdap_group_search_attr(self, value):    
         http.putJSON('/admin/resources/ldap_configs/', {"ldap_group_search_attr": value})
         super(RESTBackedDict, self._restattrs).update({'ldap_group_search_attr': value})
         
    def _setJndi_connect_pool(self, value):    
         http.putJSON('/admin/resources/ldap_configs/', {"jndi_connect_pool": value})
         super(RESTBackedDict, self._restattrs).update({'jndi_connect_pool': value})
         
    def _setJndi_read_timeout(self, value):    
         http.putJSON('/admin/resources/ldap_configs/', {"jndi_read_timeout": value})
         super(RESTBackedDict, self._restattrs).update({'jndi_read_timeout': value})
                                    
    def _setJndi_provider_url(self, value):    
         http.putJSON('/admin/resources/ldap_configs/', {"jndi_provider_url": value})
         super(RESTBackedDict, self._restattrs).update({'jndi_provider_url': value})
         
    def _setJndi_security_credentials(self, value):    
         http.putJSON('/admin/resources/ldap_configs/', {"jndi_security_credentials": value})
         super(RESTBackedDict, self._restattrs).update({'jndi_security_credentials': value})
         
    def _setJndi_security_principal(self, value):    
         http.putJSON('/admin/resources/ldap_configs/', {"jndi_security_principal": value})
         super(RESTBackedDict, self._restattrs).update({'jndi_security_principal': value})
         
    def _setLdap_group_base_dn(self, value):    
         http.putJSON('/admin/resources/ldap_configs/', {"ldap_group_base_dn": value})
         super(RESTBackedDict, self._restattrs).update({'ldap_group_base_dn': value})
         
    def _setLdap_userid_base_dn(self, value):    
         http.putJSON('/admin/resources/ldap_configs/', {"ldap_userid_base_dn": value})
         super(RESTBackedDict, self._restattrs).update({'ldap_userid_base_dn': value})
         
    def _setLdap_userid_search_filter_pattern(self, value):    
         http.putJSON('/admin/resources/ldap_configs/', {"ldap_userid_search_filter_pattern": value})
         super(RESTBackedDict, self._restattrs).update({'ldap_userid_search_filter_pattern': value})
         
    def acceptCert(self, jndi_provider_url=None):
         'IWD11236'
        
         try:
            if(jndi_provider_url == None):
                    ldapObject = http.get(self.URI)
                    jndi_provider_url = ldapObject.get('jndi_provider_url')
            reponseWithCerts = http.putJSON('/admin/resources/ldap_configs/', {"jndi_provider_url": jndi_provider_url})
            if reponseWithCerts.get('ldaps_certificate') == None :
                raise ValueError('failed to accept the certificat')
            finalObject = http.putJSON('/admin/resources/ldap_configs/', {"ldaps_certificate": reponseWithCerts.get('ldaps_certificate')})
         except ValueError:
                raise ValueError('failed to accept the certificate')
