"""
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2011. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
"""

from deployer.resources.commonattrs import CommonAttributes
from deployer import utils, http
from ipasrestresource import IPASRESTResourceCollection, IPASRESTResource
from deployer.messages import message

isInMerionNetwork = -1

@utils.classinit
class AdvancedManager(IPASRESTResource):
    'IWD00065'
    
    @classmethod
    def _classinit(cls):
        cls._registerURI(r'\A/admin/resources/advanced_managers/(?P<id>[\da-z\-]+)\Z')

        cls._defineRESTAttribute('port', 'IWD00061', readonly=True)
        cls._defineRESTAttribute('name', 'IWD11001', readonly=True)
        cls._defineRESTAttribute('role', 'IWD00060', readonly=True)
        cls._defineRESTAttribute('type', 'IWD00055', readonly=True)
        cls._defineRESTAttribute('id', 'IWD11000', readonly=True)
        cls._defineRESTAttribute('relative_uri', 'IWD00059', restname='uri', readonly=True)
        cls._defineRESTAttribute('managed_resource_type', 'IWD00058', restname="parent_type", readonly=True)
        cls._defineRESTAttribute('location', 'IWD00056',restname="location_text", readonly=True)
        cls._defineRESTAttribute('hardware', 'IWD00057', readonly=True)
        cls._defineRESTAttribute('url', 'IWD10033', restname='id', readonly=True)
        cls._defineRESTAttribute('managed_resource_id', 'IWD10062', readonly=True)
        cls._defineRESTAttribute('status', 'IWD00062', readonly=True)
        cls._defineRESTAttribute('label', 'IWD00063', restname="label_text", readonly=True)
        cls._defineRESTAttribute('protocol', 'IWD00054', restname="access_type", readonly=True)
        cls._defineRESTAttribute('ipaddress', 'IWD10073', readonly=True)
        
        cls._methodHelp('createForwarder')
        
    def _getManaged_resource_id(self):
        parentType = self.managed_resource_type
        if parentType:
            return self._restattrs.get(parentType, None)
        return None

    def _getStatus(self):
        if self.role == None:
            return None
        return self._restattrs.get(self.role +"_connectivity_status", None)
 
    def delete(self):
        raise NotImplementedError('delete')
    
    def createForwarder(self):
        'IWD10072'
        global isInMerionNetwork
        if self.protocol != "ssh":
            raise IOException(utils.utos(message('IWD00066')))
        if isInMerionNetwork == -1:
            resp = http.get('/admin/resources/client_informations')
            isInMerionNetwork = resp.get('merion_network')
        if isInMerionNetwork == True:
            print message('IWD10067')
            return None
        else:
            json = {
                "parent": self.managed_resource_id, 
                "target_port": self.port, 
                "parent_type": self.managed_resource_type,
                'single_connection': 'F'
            }
            resp = http.postJSON('/admin/resources/forwarders', json)
            forwarder = Forwarder(resp['id'], resp)
            forwarder.waitFor()
            return forwarder

@utils.classinit   
class Forwarder(IPASRESTResource):
     'IWD10068' 
     @classmethod
     def _classinit(cls):
        cls._registerURI(r'\A/admin/resources/forwarders/(?P<id>[\da-z\-]+)\Z')
        cls._defineRESTAttribute('created_time', 'IWD10012', readonly=True)
        cls._defineRESTAttribute('updated_time', 'IWD10013', readonly=True)
        cls._defineRESTAttribute('idle_timeout', 'IWD10069', readonly=True)
        cls._defineRESTAttribute('listen_port', 'IWD10070', readonly=True)
        cls._defineRESTAttribute('state', 'IWD10071', readonly=True)
        cls._defineRESTAttribute('id', 'IWD11000', readonly=True)
        cls._defineRESTAttribute('url', 'IWD10033', restname='id', readonly=True)
        cls._methodHelp('waitFor')
        
    
@utils.classinit
class AdvancedManagers(IPASRESTResourceCollection):
    'IWD00064'

    @classmethod
    def _classinit(cls):
        cls._contains(AdvancedManager)
        cls._methodHelp('list')
        
    def _list(self, filt = {}):
        for k in filt:
            restname = AdvancedManager._RESTNAMES_.get(k)
            if  restname != k:
                filt[restname] = filt[k]
                del filt[k]
        return super(AdvancedManagers, self)._list(filt)
    @classmethod    
    def _restname(cls):
        return 'advanced_managers'