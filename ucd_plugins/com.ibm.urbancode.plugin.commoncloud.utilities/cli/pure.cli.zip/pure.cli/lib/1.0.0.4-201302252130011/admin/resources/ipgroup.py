"""
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2011. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
"""

from deployer import utils, validators, http
from deployer.resources.relationships import RelatedResource, RelatedResourceCollection
from ipasrestresource import IPASRESTResourceCollection,IPASRESTResource
from deployer.resources.restresource import RESTResource
import admin

@utils.classinit
class IPGroup(IPASRESTResource):
    'IWD10015'

    @classmethod
    def _classinit(cls):
        cls._registerURI(r'\A/deployment/resources/subnets/(?P<id>[\da-f\-]+)\Z')

        cls._defineRESTAttribute('created_time', 'RM09245', readonly=True)
        cls._defineRESTAttribute('id', 'RM09246', readonly=True)
        cls._defineRESTAttribute('url', 'IWD10033', restname='id', readonly=True)
        cls._defineRESTAttribute('gateway', 'RM09247', validator=validators.allipaddress)
        cls._defineRESTAttribute('ip_version', 'IWD10022', values=('ipv4','ipv6'))
        cls._defineRESTAttribute('dns', 'RM09250', validator=validators.allipaddress)
        cls._defineRESTAttribute('secondary_dns', 'RM09252',  validator=validators.optionalipaddress)
        cls._defineRESTAttribute('name', 'RM09248', validator=validators.string)
        cls._defineRESTAttribute('mask', 'RM09249', visible= [lambda ipgroup: ipgroup.mask != "" and ipgroup.mask != None])
        cls._defineRESTAttribute('subnet', 'RM09244',  validator=validators.allipaddress)
        cls._defineRESTAttribute('updated_time', 'RM09253',readonly=True)
        cls._defineRESTAttribute('vlan_id', 'IWD10080', readonly=True)
        cls._defineAttribute('acl', 'IWD10038', readonly=True, readonlydoc=False, elided=True)
        #TODO: add messages for the attribute
        cls._defineRESTAttribute('state', '', readonly=True)
        cls._methodHelp('delete', 'update')
        
    def  _getCloud(self):
        cloudid = self._restattrs['vdc']
        if cloudid != None:
            return RESTResource.resourceForURI(cloudid.replace('/deployment', '/admin'))
        return None
        
    def  _setCloud(self, cloud):
        if cloud:
            validators.instance(admin.cloud, cloud, 'cloud')
        return http.putJSON(self.uri, {'vdc': cloud.id if cloud else None})
    
            
    def  update(self, d):
        'IWD10034'
        if d.has_key('cloud'):
            validators.instance(admin.cloud, d['cloud'], 'cloud')
            d['vdc'] = d['cloud'].id
            del d['cloud']
        json = http.putJSON(self.uri, d)
        self.refresh()
        return self
        
@utils.classinit
class IPGroups(IPASRESTResourceCollection):
    'IWD10040'

    @classmethod
    def _classinit(cls):
        cls._contains(IPGroup)
        cls._methodHelp( 'create',  'list')


    CREATE_ATTRIBUTES = [
        IPGroup._wizardStep('name', optional=True),
        IPGroup._wizardStep('ip_version', optional=True),
        IPGroup._wizardStep('subnet'),
        IPGroup._wizardStep('mask'),
        IPGroup._wizardStep('gateway'),
        IPGroup._wizardStep('dns'),
        IPGroup._wizardStep('secondary_dns', optional=True),
     #   IPGroup._wizardStep('cloud', optional=True),
        IPGroup._wizardStep('vlan_id')
    ]



    @classmethod
    def _restname(cls):
        return 'subnets'

    @classmethod
    def _restPrefix(cls):
        return "/deployment"
  
    def _list(self, filter={}):
         filter['management'] = "F"
         return super(IPGroups, self)._list(filter)
     
    def _create(self, dict):
        
        if not dict.has_key('ip_version'):
           dict['ip_version'] = 'ipv4'         
        if not dict.has_key('name'):
           dict['name'] = dict['subnet']
           
        if dict['ip_version'] == 'ipv6':
           dict['mask'] =''

        return super(IPGroups, self)._create(dict)
