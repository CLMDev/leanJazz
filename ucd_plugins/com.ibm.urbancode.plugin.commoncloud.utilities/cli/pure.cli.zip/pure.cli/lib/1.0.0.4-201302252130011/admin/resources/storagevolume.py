"""
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2011. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
"""

from deployer.resources.commonattrs import CommonAttributes
from deployer import utils
from deployer.resources.relationships import RelatedResource
from ipasrestresource import IPASRESTResourceCollection, IPASRESTResource
from deployer.utils import utos
from deployer.messages import message

@utils.classinit
class StorageVolume(IPASRESTResource):    
    
    @classmethod
    def _classinit(cls):
        cls._registerURI(r'\A/admin/resources/storage_volumes/(?P<id>[\da-z\-]+)\Z')

        cls._defineRESTAttribute('created_time', 'IWD10012', readonly=True)
        cls._defineRESTAttribute('description', 'IWD11370')
        cls._defineRESTAttribute('id', 'IWD11000', readonly=True)
        cls._defineRESTAttribute('name', 'IWD11373')
        cls._defineRESTAttribute('size', 'IWD11374')
        cls._defineRESTAttribute('harddiskdrive', 'IWD11379', restname='tier_hdd')
        cls._defineRESTAttribute('solidstatedrive', 'IWD11380', restname='tier_ssd')
        cls._defineRESTAttribute('units', 'IWD11381', readonly=True)
        cls._defineRESTAttribute('updated_time', 'IWD10013', readonly=True)
        cls._defineRESTAttribute('volumeconfiguration', 'IWD11377', restname='volume_configuration',)
        cls._defineRESTAttribute('url', 'IWD10033', restname='id', readonly=True)
        cls._defineRESTAttribute('state', 'IWD11375', readonly=True)
        cls._defineRESTAttribute('cloud', 'IWD11376', restname='vdc')
