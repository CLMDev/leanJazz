"""
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2011. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
"""

from deployer.resources.commonattrs import CommonAttributes
from deployer import http, utils, prettify
from deployer.resources.relationships import RelatedResource
from ipasrestresource import IPASRESTResourceCollection, IPASRESTResource
from deployer.resources.restresource import RESTResource, RESTResourceCollection
import os

@utils.classinit
class Problem(IPASRESTResource):
    ''
    
    @classmethod
    def _classinit(cls):
        cls._registerURI(r'\A/admin/resources/problems/(?P<id>[\da-z\-]+)\Z')

        cls._defineRESTAttribute('service_request_number', '', readonly=True)
        cls._defineRESTAttribute('error_code', '', readonly=True)
        cls._defineRESTAttribute('created_time', '', readonly=True)
        cls._defineRESTAttribute('updated_time', '', readonly=True)
        cls._defineRESTAttribute('event_failing_machine_serial', '', readonly=True)
        cls._defineRESTAttribute('event_failing_machine_model', '', readonly=True)
        cls._defineRESTAttribute('event_failing_machine_type', '', readonly=True)
        cls._defineRESTAttribute('eed_location', '', readonly=True)
        cls._defineRESTAttribute('state', '', readonly=True)
        cls._defineRESTAttribute('origin_address', '', readonly=True)
        cls._defineRESTAttribute('count', '', readonly=True)
        cls._defineRESTAttribute('event_id', '', readonly=True)
        cls._defineRESTAttribute('event_customer_defined_details', '', readonly=True)
        cls._defineRESTAttribute('event_msg_text', '', readonly=True)
        cls._defineRESTAttribute('url', 'IWD10033', restname='id', readonly=True)
        cls._defineRESTAttribute('callhome_type', '', readonly=True)
        cls._defineRESTAttribute('component', '', readonly=True)
        cls._defineRESTAttribute('additional_data_1', '', readonly=True)
        cls._defineRESTAttribute('additional_data_2', '', readonly=True)
        cls._defineRESTAttribute('additional_data_3', '', readonly=True)
        cls._defineRESTAttribute('additional_data_4', '', readonly=True)
        cls._defineRESTAttribute('additional_data_5', '', readonly=True)
        cls._defineRESTAttribute('additional_data_6', '', readonly=True)
        cls._defineRESTAttribute('additional_data_7', '', readonly=True)
        cls._defineRESTAttribute('additional_data_8', '', readonly=True)
        cls._defineRESTAttribute('additional_data_9', '', readonly=True)
        cls._defineRESTAttribute('additional_data_10', '', readonly=True)
        cls._defineRESTAttribute('additional_data_11', '', readonly=True)
        cls._defineRESTAttribute('additional_data_12', '', readonly=True)
        
        cls._methodHelp('refresh')
    
@utils.classinit
class Problems(IPASRESTResourceCollection):
    ''
    @classmethod
    def _classinit(cls):
        cls._contains(Problem)
        cls._methodHelp('list', 'export')
    
    #TODO: need a message
    def export(self, path = None, filt = {}):
        doclose = False
        if not path:
            f = 'export/problems.csv'
        else:
            if not os.path.isdir(path):
                os.mkdir(path)
            f = os.path.join(path, 'problems.csv')
        
        f = file(f, 'w')
        doclose = True
        url = self.uri
        if url.find('?') == -1:
            url += '?'
        else:
            url += '&'
        filter = utils.objectToQuery(filt)
        http.get(url + filter + "&csv=true", responseHandler = utils.curryFunction(utils.getResponseHandler, f))
        if doclose:
            f.close()
        return path
        
    @classmethod    
    def _restname(cls):
        return 'problems'
    
