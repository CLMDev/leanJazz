import dns
import dateandtime
import snmp
import maildelivery
import ldap
import report
import deployer.settings.licenseManagement as licenseManagement
import deployer.settings.licenseAwareness  as licenseAwareness
import customerNetwork
import managementLAN

dns = dns.Dns()
dateandtime = dateandtime.DateAndTime()
trapdestination=snmp.TrapDestination
trapdestinations=snmp.TrapDestinations
snmp=snmp.SNMP()
mail=maildelivery.MailDelivery()
ldap=ldap.LDAP()
maintenancereport=report.MaintenanceReport()
ilmt= licenseManagement.LicenseManagement(licenseManagement.LicenseManagement.URI)
licenseawareness = licenseAwareness.LicenseAwareness()
customernetwork = customerNetwork.customerNetwork()
managementlan = managementLAN.managementLAN()


