"""
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2011. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
"""

from deployer import http, utils
from deployer.resources.commonattrs import CommonAttributes
from deployer.resources.relationships import RelatedResource, RelatedResourceCollection
from deployer.messages import message
from deployer.resources.restresource import RESTResourceCollection

@utils.classinit
class MaintenanceReport(RESTResourceCollection):
    'IWD12029'

    @classmethod
    def _classinit(cls):
        cls._methodHelp('download', 'list')
        
    def __init__(self):
        self.uri = '/admin/resources/system_reports'
    
    def _JSON2Python(self, array):
        reports = []
        for json in array:
           o = { 
                 "name" : json.get('name'),
                 "type": json.get('type'),
                 'model': json.get('model'),
                 "firmware_level": json.get('firmware_level'),
                 "fru_serial": json.get('fru_serial'),
                 "software_version": json.get('software_version'),
                 "serial": json.get('serial'),
                 "uefi_level": json.get('uefi_level'),
                 "vendor": json.get('vendor')
                }
           reports.append(o)
           
        return reports
 
    def _list(self, filt = {} ):
        #should add filter in uri
        array = http.get(self.uri)
        reports = self._JSON2Python(array)
        return reports
    
    def download(self, f):
        'IWD12030'
        
        f = file(f, 'wb')
        doclose = True
        http.get(self.uri+'?csv=true', responseHandler=utils.curryFunction(utils.getResponseHandler, f))
        if doclose:
            f.close()