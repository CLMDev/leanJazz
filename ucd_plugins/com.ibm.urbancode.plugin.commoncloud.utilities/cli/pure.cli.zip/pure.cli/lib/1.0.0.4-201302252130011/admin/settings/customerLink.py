#
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2012. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
#

from deployer.messages import message


from customerPort      import customerPort
from customerVLANRange import customerVLANRange


class customerLink(object):
    'IWD12240'
    
    FLOW_CONTROL_MODE_ENABLED  = 'Enabled'
    FLOW_CONTROL_MODE_DISABLED = 'Disabled'
    FLOW_CONTROL_MODE_UNKNOWN  = ''
    VALID_FLOW_CONTROL_MODES = [ FLOW_CONTROL_MODE_ENABLED, FLOW_CONTROL_MODE_DISABLED, FLOW_CONTROL_MODE_UNKNOWN ]

    AGGREGATION_METHOD_LACP         = 'LACP'
    AGGREGATION_METHOD_ETHERCHANNEL = 'Etherchannel'
    AGGREGATION_METHOD_UNKNOWN      = ''
    VALID_AGGREGATION_METHODS       = [ AGGREGATION_METHOD_LACP, AGGREGATION_METHOD_ETHERCHANNEL, AGGREGATION_METHOD_UNKNOWN ]

    VLAN_MODE_TAGGING    = 'Tagging'
    VLAN_MODE_NO_TAGGING = 'No Tagging'
    VLAN_MODE_UNKNOWN    = ''
    VALID_VLAN_MODES = [ VLAN_MODE_TAGGING, VLAN_MODE_NO_TAGGING, VLAN_MODE_UNKNOWN ]

    _ALL_LINKS  = []
    
    _JSON_SEPARATOR = ','
    
    _METHODHELP_   = [ 'addVLANRangeID', 'removeVLANRangeID', 'setVLANRangeIDs', 'delete' ]
                     
    _PROPERTYHELP_ = [ 'name', 'speed', 'flowControlMode', 'aggregationMethod', 'portIDs', 'vlanMode', 'vlanRangeIDs' ]
    
    
    @classmethod
    def _raiseValueErrorBecauseAttrCannotChange(cls, attrName):
        msgKey0CannotBeChanged = 'IWD12274'
        msg = message(msgKey0CannotBeChanged, cls.__name__ + '.' + attrName)
        raise ValueError(msg)
        

    @classmethod
    def _raiseValueErrorBecauseAttrCannotBeSetTo(cls, attrName, value):
        msgKey0IsNotValidFor1 = 'IWD12275'
        msg = message(msgKey0IsNotValidFor1, value, cls.__name__ + '.' + attrName)
        raise ValueError(msg)


    @classmethod
    def _raiseValueErrorBecausePortSpeedsDoNotMatch(cls, portID):
        msgKey0IsWrongSpeed = 'IWD12278'
        msg = message(msgKey0IsWrongSpeed, portID)
        raise ValueError(msg)
        
    
    @classmethod
    def _add(cls, newLink):
        cls._ALL_LINKS.append(newLink)


    @classmethod
    def _get(cls, linkName):
        for link in cls._ALL_LINKS:
            if (link.name == linkName):
                return link
        return None 
    

    @classmethod
    def _getAll(cls, speed):
        links = list([])
        for link in cls._ALL_LINKS:
            if (link.speed == speed):
                links.append(link)
        return links      


    @classmethod
    def _discardAll(cls):
        cls._ALL_LINKS = []
    
    
    @classmethod
    def _findAllLinkIndexesInJSON(cls, speed, jsonData):
        allLinkIndexes = set([])
        linkNamePrefix = 'LINK_' + str(speed) + 'GB_NAME_'
        for key in jsonData:
            if (key.startswith(linkNamePrefix)):
                linkIndex = key[len(linkNamePrefix):]
                allLinkIndexes.add(linkIndex)
        return allLinkIndexes
    
    
    @classmethod
    def _fetchJSONLinkAttribute(cls, index, speed, attr, jsonData):
        key = 'LINK_' + str(speed) + 'GB_' + attr + '_' + str(index)
        return jsonData[key]


    @classmethod
    def _fetchPorts(cls, rawPortString):
        ports = set([])
        rawPorts = rawPortString.split(cls._JSON_SEPARATOR)
        for p in rawPorts:
            p = p.strip()
            if p.startswith('A-') or p.startswith('B-'):
                port = int(p[2:4])
                ports.add(port)
        return ports


    @classmethod
    def _fetchRangeIDs(cls, rawRangeIDsString):
        rangeIDs = set([])
        rawRangeIDs = rawRangeIDsString.split(cls._JSON_SEPARATOR)
        for rangeID in rawRangeIDs:
            rangeIDs.add(rangeID.strip())
        return rangeIDs
            
            
    @classmethod
    def _getLinkFromJSON(cls, index, speed, jsonData):
        name  = cls._fetchJSONLinkAttribute(index, speed, 'NAME', jsonData)
        
        rawPortString = cls._fetchJSONLinkAttribute(index, speed, 'PORTS', jsonData)
        ports = cls._fetchPorts(rawPortString)
        
        flowControlMode   = cls._fetchJSONLinkAttribute(index, speed, 'FLOW_CONTROL_MODE', jsonData)
        aggregationMethod = cls._fetchJSONLinkAttribute(index, speed, 'TRUNK_METHOD', jsonData)
        vlanMode   = cls._fetchJSONLinkAttribute(index, speed, 'VLAN_MODE', jsonData)
        
        rawRangeIDsString = cls._fetchJSONLinkAttribute(index, speed, 'VLAN_RANGES', jsonData)
        vlanRangeIDs = cls._fetchRangeIDs(rawRangeIDsString)
        
        return customerLink(name, ports, flowControlMode, aggregationMethod, vlanMode, vlanRangeIDs)
    
    
    @classmethod
    def _refresh(cls, speed, jsonData):
        allIndexes = cls._findAllLinkIndexesInJSON(speed, jsonData)
        for index in allIndexes:
            newLink = cls._getLinkFromJSON(index, speed, jsonData)
            cls._ALL_LINKS.append(newLink)


    @classmethod
    def _refreshAll(cls, jsonData):
        cls._discardAll()
        for speed in customerPort.VALID_SPEEDS:
            if (customerPort.SPEED_UNKNOWN != speed):
                cls._refresh(speed, jsonData)
    
    
    @classmethod
    def _getJSONValueForLinkPortIDs(cls, portIDs):
        jsonValues = []
        sep = None
        for portID in portIDs:
            if (None == sep):
                sep = ', '
            else:
                jsonValues.append(sep)
            jsonValues.append('A-' + str(portID))
        for portID in portIDs:
            jsonValues.append(sep)
            jsonValues.append('B-' + str(portID))
        return ''.join(jsonValues)


    @classmethod
    def _getJSONValueForLinkVLANRangeIDs(cls, rangeIDs):
        jsonValues = []
        sep = None
        for rangeID in rangeIDs:
            if (None == sep):
                sep = ', '
            else:
                jsonValues.append(sep)
            jsonValues.append(rangeID)
        return ''.join(jsonValues)
            

    @classmethod
    def _saveJSONPropsForLink(cls, index, link, jsonProps):
        jsonProps["LINK_" + link.speed + "GB_NAME_"  + str(index)] = link.name
        jsonProps["LINK_" + link.speed + "GB_PORTS_" + str(index)] = cls._getJSONValueForLinkPortIDs(link.portIDs)
        jsonProps["LINK_" + link.speed + "GB_FLOW_CONTROL_MODE_" + str(index)] = link.flowControlMode
        jsonProps["LINK_" + link.speed + "GB_TRUNK_METHOD_"      + str(index)] = link.aggregationMethod
        jsonProps["LINK_" + link.speed + "GB_VLAN_MODE_"         + str(index)] = link.vlanMode
        jsonProps["LINK_" + link.speed + "GB_VLAN_RANGES_"       + str(index)] = cls._getJSONValueForLinkVLANRangeIDs(link.vlanRangeIDs)
            

    @classmethod
    def _saveAll(cls, jsonProps):
        index = 1
        for link1 in cls._getAll(customerPort.SPEED_1GB):
            cls._saveJSONPropsForLink(index, link1, jsonProps)
            index += 1
        index = 1
        for link10 in cls._getAll(customerPort.SPEED_10GB):
            cls._saveJSONPropsForLink(index, link10, jsonProps)
            index += 1


    @classmethod
    def _getCommonSpeedForPortIDs(cls, portIDs):
        commonSpeed = None
        for portID in portIDs:
            port = customerPort._get(portID)
            if (None == commonSpeed):
                commonSpeed = port.speed
            if (port.speed != commonSpeed):
                return None
        return commonSpeed


    @classmethod
    def _getPortIDWithWrongSpeed(cls, portIDs):
        commonSpeed = None
        for portID in portIDs:
            port = customerPort._get(portID)
            if (None == commonSpeed):
                commonSpeed = port.speed
            if (port.speed != commonSpeed):
                return port.id
        return None
        

    def addVLANRangeID(self, rangeID):
        customerVLANRange._addToLink(rangeID, self.name)


    def removeVLANRangeID(self, rangeID):
        customerVLANRange._removeFromLink(rangeID, self.name)
    

    def delete(self):
        link = customerLink._get(self.name)
        if (None == link):
            customerLink._raiseValueErrorBecauseAttrCannotBeSetTo('name', self.name)
        customerLink._ALL_LINKS.remove(link)
        portIDs = customerPort._getPortIDsForLink(self.name)
        for portID in portIDs:
            customerPort._removeFromLink(portID, self.name)
        vlanRangeIDs = customerVLANRange._getRangeIDsForLink(self.name)
        for rangeID in vlanRangeIDs:
            customerVLANRange._removeFromLink(rangeID, self.name)

        
    def setPortIDsAndSpeed(self, portIDs):
        if (0 == len(portIDs)):
            customerLink._raiseValueErrorBecauseAttrCannotBeSetTo('portIDs','[]')
        commonSpeed = customerLink._getCommonSpeedForPortIDs(portIDs)
        if (None == commonSpeed):
            badPortID = customerLink._getPortIDWithWrongSpeed(portIDs)
            customerLink._raiseValueErrorBecausePortSpeedsDoNotMatch(badPortID)
        for portID in portIDs:
            customerPort._addToLink(portID, self.name)
        self.speed = commonSpeed
       
        
    def setVLANRangeIDs(self, vlanRangeIDs):
        for rangeID in vlanRangeIDs:
            customerVLANRange._addToLink(rangeID, self.name)
        
            
    def __init__(self, name, portIDs, flowControlMode, aggregationMethod, vlanMode, vlanRangeIDs):
        self.name = name
        self.flowControlMode = flowControlMode
        self.aggregationMethod = aggregationMethod
        self.vlanMode = vlanMode
        self.setVLANRangeIDs(vlanRangeIDs)
        self.setPortIDsAndSpeed(portIDs)


    def __setattr__(self, attr, value):
        if (attr == 'name') and hasattr(self, attr):
            customerLink._raiseValueErrorBecauseAttrCannotChange(attr)

        if (attr == 'flowControlMode') and (value not in customerLink.VALID_FLOW_CONTROL_MODES):
            customerLink._raiseValueErrorBecauseAttrCannotBeSetTo(attr, value)

        if (attr == 'speed') and hasattr(self, attr):
            customerLink._raiseValueErrorBecauseAttrCannotChange(attr)
                
        if (attr == 'portIDs'):
            customerLink._raiseValueErrorBecauseAttrCannotChange(attr)
        
        if (attr == 'speed') and hasattr(self, attr):
            customerLink._raiseValueErrorBecauseAttrCannotChange(attr)

        if (attr == 'aggregationMethod') and (value not in customerLink.VALID_AGGREGATION_METHODS):
            customerLink._raiseValueErrorBecauseAttrCannotBeSetTo(attr, value)

        if (attr == 'vlanMode') and (value not in customerLink.VALID_VLAN_MODES):
            customerLink._raiseValueErrorBecauseAttrCannotBeSetTo(attr, value)

        if (attr == 'vlanRangeIDs'):
            customerLink._raiseValueErrorBecauseAttrCannotChange(attr)
    
        self.__dict__[attr] = value


    def __getattr__(self, attr):
        if (attr == 'portIDs'):
            return customerPort._getPortIDsForLink(self.name)

        if (attr == 'vlanRangeIDs'):
            return customerVLANRange._getRangeIDsForLink(self.name)
        
        return self.__dict__[attr]

