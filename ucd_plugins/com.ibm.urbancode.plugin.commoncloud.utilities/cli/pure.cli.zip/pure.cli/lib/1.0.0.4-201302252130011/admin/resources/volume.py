"""
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2011. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
"""

from deployer.resources.commonattrs import CommonAttributes
from deployer import utils, http, prettify
from deployer.resources.relationships import RelatedResource
from ipasrestresource import IPASRESTResourceCollection, IPASRESTResource
from deployer.resources.restresource import RESTResource
from deployer.utils import utos
from deployer.messages import message

@utils.classinit
class Volume(IPASRESTResource):
    'IWD11372'
    
    @classmethod
    def _classinit(cls):
        cls._registerURI(r'\A/admin/resources/volumes/(?P<id>[\da-z\-]+)\Z')

        cls._defineRESTAttribute('created_time', 'IWD10012', readonly=True)
        cls._defineRESTAttribute('description', 'IWD11370')
        cls._defineRESTAttribute('id', 'IWD11000', readonly=True)
        #cls._defineRESTAttribute('isosvolume', 'RM09247', restname='is_detachable')
        #cls._defineRESTAttribute('label', 'RM09635', restname='label_text')
        cls._defineRESTAttribute('name', 'IWD11373')
        cls._defineRESTAttribute('size', 'IWD11374')
        cls._defineRESTAttribute('harddiskdrive', 'IWD11379', restname='tier_hdd')
        cls._defineRESTAttribute('solidstatedrive', 'IWD11380', restname='tier_ssd')
        cls._defineRESTAttribute('units', 'IWD11381', readonly=True)
        cls._defineRESTAttribute('updated_time', 'IWD10013', readonly=True)
        cls._defineRESTAttribute('volumeconfiguration', 'IWD11377', restname='volume_configuration', elided=True)
        cls._defineRESTAttribute('url', 'IWD10033', restname='id', readonly=True)
        cls._defineRESTAttribute('state', 'IWD11375', readonly=True)
        cls._defineRESTAttribute('cloud', 'IWD11376', elided=True)
        if utils.isSparta():
            cls._defineRESTAttribute('hosts', '', readonly=True, elided=True)
        else:
            cls._defineRESTAttribute('virtualmachines', 'IWD11389', readonly=True, elided=True)
        cls._defineAttribute('acl', 'IWD10038', readonly=True, readonlydoc=False)
        
        cls._methodHelp('delete','isStatusTransient','waitFor')
        
    def _getCloud(self):
        return self._renderRESTResource('vdc', '/admin/resources/vdcs')
  
    
    
    def _getVolumeconfiguration(self):
        return self._renderRESTResource('volume_configuration', '/admin/resources/volume_configurations')
    
    class BaseClass(object):

        def __repr__(self):
            'RM09119'
            return utils.utos(unicode(self))

        def __str__(self):
            'RM09118'
            return repr(self)

        def __unicode__(self):
            'RM09118'
            return prettify.prettify(list(self))    
        
    def _getVirtualmachines(self):
        if not hasattr(self, '_virtualmachines'):
            self._virtualmachines = self.__class__.MountedVirtualMachines(self)
        return self._virtualmachines

    def _getHosts(self):
        return self._virtualmachines
    
    def __init__(self, uri, attrs):
        super(Volume, self).__init__(uri, attrs)
        
    
    class MountedVirtualMachines(BaseClass):
        ''
        
        def __len__(self):
            ''
            return len(self.instances)
        
        def __getitem__(self, key):
            ''
            uuid = utils.uuid(self.instances[key]['uri'])
            return RESTResource.resourceForURI('/admin/resources/instances/%s' % uuid)
        
        def __init__(self, volume):
            self.volume = volume
            volume = http.get('%s?resolvechildren=0&resolvechildrenlist=instances' % self.volume.uri)
            self.instances = volume['instances']
        
        def __iter__(self):
            ''
            volume = http.get('%s?resolvechildren=0&resolvechildrenlist=instances' % self.volume.uri)
            self.instances = volume['instances']
        
            return iter([RESTResource.resourceForURI('/admin/resources/instances/%s' % utils.uuid(v['uri'])) for v in self.instances])
        
       
@utils.classinit
class Volumes(IPASRESTResourceCollection):
    'IWD11371'

    @classmethod
    def _classinit(cls):
        cls._contains(Volume)
        cls._methodHelp('list', "create")
    @classmethod
    def _restname(cls):
        return 'volumes'

    CREATE_ATTRIBUTES = [
        Volume._wizardStep('name'),
        Volume._wizardStep('cloud'),
        Volume._wizardStep('description', optional = True),
        Volume._wizardStep('size', optional = True),
        Volume._wizardStep('volumeconfiguration', optional = True)
    ]

    def _create(self, dict):
        if (not dict.has_key('volumeconfiguration')) and (not dict.has_key('size')):
            raise ValueError(utos(message('IWD11382')))
        if (dict.has_key('volumeconfiguration')) and (dict.has_key('size')):
            raise ValueError(utos(message('IWD11382')))
        if dict.has_key('volumeconfiguration'):
            id=dict['volumeconfiguration'].id
            del dict['volumeconfiguration']
            dict['volumeconfiguration']={"uri": id}
        if dict.has_key('cloud'):
            id=dict['cloud'].id
            del dict['cloud']
            dict['vdc']={"uri": id}            
       
        return super(Volumes, self)._create(dict, ['volumeconfiguration', 'cloud','vdc'])