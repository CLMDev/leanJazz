#
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2011. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
#

from deployer import http
from deployer.messages import message

from customerPort      import customerPort
from customerVLANRange import customerVLANRange
from customerLink      import customerLink


class customerNetwork(object):
    ''


    _CUSTOMER_NETWORK_REST_URI = "/admin/resources/global_config?global_config_type=Customer Network"
    
    _METHODHELP_ = [ 'ports', 'vlanRanges', 'createVLANRange', 'links', 'unlinkedPorts', 'createLink', \
                     'managementNetworkVLAN', 'motionNetworkVLAN', 'consoleNetworkVLAN', 'vlagTierID', \
                     'load', 'save' ]
                     
    _PROPERTYHELP_ = [ ]
    
    
    def _reset(self):
        customerPort._resetAll()
        customerVLANRange._discardAll()
        customerLink._discardAll()
    
    
    def __init__(self):
        self._reset()
        

    def _setJSONProps(self, jsonProps):
        customerPort._refreshAll(jsonProps)
        customerVLANRange._refreshAll(jsonProps)
        customerLink._refreshAll(jsonProps)


    def _getJSONProps(self):
        jsonProps = dict([])
        customerPort._saveAll(jsonProps)
        customerVLANRange._saveAll(jsonProps)
        customerLink._saveAll(jsonProps)       
        return jsonProps
    

    def ports(self):
        return customerPort._getAll()


    def vlanRanges(self):
        return customerVLANRange._getAll()


    def createVLANRange(self, rangeID, spanningTreeEnabled, spanningTreeGroup):
        newRange = customerVLANRange(rangeID, spanningTreeEnabled, spanningTreeGroup)
        customerVLANRange._add(newRange)
        

    def links(self, speed):
        return customerLink._getAll(speed)


    def unlinkedPorts(self):
        return customerPort._getAllUnlinkedPorts()

    
    def createLink(self, name, portIDs, flowControlMode, aggregationMethod, vlanMode, vlanRangeIDs):
        newLink = customerLink(name, portIDs, flowControlMode, aggregationMethod, vlanMode, vlanRangeIDs)
        customerLink._add(newLink)
    
    
    def managementNetworkVLAN(self):
        return customerVLANRange._getManagementNetworkVLAN()

    def motionNetworkVLAN(self):
        return customerVLANRange._getMotionNetworkVLAN()

    def consoleNetworkVLAN(self):
        return customerVLANRange._getConsoleNetworkVLAN()
    
    def vlagTierID(self):
        return customerVLANRange._getVLAGTierID()

        
    def load(self):
        reply = http.get(customerNetwork._CUSTOMER_NETWORK_REST_URI)
        if (0 != len(reply)):
            jsonString = reply[0]['json']
            jsonProps = http._parseJSON(jsonString)
            self._setJSONProps(jsonProps)        
    
    def save(self):
        if (0 != len(self.unlinkedPorts())):
            raise ValueError(message('IWD12281'))
        print message('IWD12283')
        jsonProps = self._getJSONProps();
        reply = http.putJSON(customerNetwork._CUSTOMER_NETWORK_REST_URI, jsonProps)
        
    def apply(self):
        self.save()
       
