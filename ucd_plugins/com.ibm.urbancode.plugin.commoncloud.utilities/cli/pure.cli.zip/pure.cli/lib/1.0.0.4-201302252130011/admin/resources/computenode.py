"""
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2011. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
"""

from deployer.resources.commonattrs import CommonAttributes
from deployer import utils, http
from deployer.resources.relationships import RelatedResource, RelatedResourceCollection
from ipasrestresource import IPASRESTResourceCollection
from deployer.resources.restresource import RESTResource
from deployer.messages import message
from hardwarecomponent import HardwareComponent
import ipasutils
from deployer import prettify, utils

@utils.classinit
class ComputeNode(HardwareComponent):
    'IWD11014'
        
    @classmethod
    def _classinit(cls):
        cls._registerURI(r'\A/admin/resources/compute_nodes/(?P<id>[\da-z\-]+)\Z')
        
        cls._defineRESTAttribute('id', 'IWD11000', readonly=True)
        cls._defineRESTAttribute('name', 'IWD11001', readonly=True)
        cls._defineRESTAttribute('state', 'IWD11004', readonly=True)
        
        cls._defineRESTAttribute('architecture', 'IWD11002', readonly=True)
        cls._defineRESTAttribute('firmwarelevel', 'IWD11003', restname='firmware_level', readonly=True)
        cls._defineRESTAttribute('powerstate', 'IWD11005', restname='power_state', readonly=True)
        cls._defineRESTAttribute('machinetype', 'IWD11006', restname='machine_type', readonly=True)
        cls._defineRESTAttribute('numberofpowercycles', 'IWD11007', restname='number_of_power_cycles', readonly=True)
        cls._defineRESTAttribute('pvuvalue', 'IWD11385', restname='pvu_value', readonly=True)
        
        #use another rest call to get this
        cls._defineRESTAttribute('energystats', 'IWD11008', restname='energy_stats', readonly=True, elided=True)
        cls._defineRESTAttribute('locations', 'IWD11010', readonly=True, elided=True)
        cls._defineRESTAttribute('healthstats', 'IWD11011', readonly=True, restname='health_stats', elided=True)
        cls._defineRESTAttribute('leds', 'IWD11012', readonly=True, elided=True)
        if utils.isSparta(): #
            cls._defineRESTAttribute('hosts', 'IWD32013', restname='hosts', readonly=True, elided=True)
        else:
            cls._defineRESTAttribute('virtualmachines', 'IWD11013', restname='virtual_machines', readonly=True, elided=True)
        cls._defineRESTAttribute('physicalcpus', 'IWD11016', restname='physical_cpus', readonly=True, elided=True)
        cls._defineRESTAttribute('physicalmemory', 'IWD11017', restname='physical_memory', readonly=True, elided=True)
        cls._defineRESTAttribute('physicalioadapters', 'IWD11018', readonly=True, elided=True)
        
        cls._defineRESTAttribute('vios', 'IWD12284', readonly=True, elided=True)
        
        cls._methodHelp('refresh','poweron','poweroff','quiesce','maintain','start')
        
    
    def _getVios(self):
        #get its hypervisor without 'resolvechildren=-1'
        computenode = http.get(self.uri)
        
        if computenode.has_key('hypervisors') and len(computenode['hypervisors'])>0:
            hypervisorURI = computenode['hypervisors'][0]
            uuid = utils.uuid(hypervisorURI)
            vios = http.get('/admin/resources/management_endpoints?resolvechildren=1&resolvechildrenlist=management_endpoint_cpus,management_endpoint_memory,mgmt_endpoint_eth_adapters&hypervisors=%s' % uuid)
            return [RESTResource.resourceForURI(json['id'], json) for json in vios]
        else:
            return None
    
    def _getPhysicalioadapters(self):
        return self._renderRESTResource('physical_io_adapters')
    
    def _getPhysicalmemory(self):
        return self._renderRESTResource('physical_memory')
        
    def _getPhysicalcpus(self):
        return self._renderRESTResource('physical_cpus')
    
    def _getVirtualmachines(self):
        if self._restattrs.has_key('hypervisors') and len(self._restattrs['hypervisors'])>0:
            hypervisorURI = self._restattrs['hypervisors'][0]
            hyper = http.get(hypervisorURI + '?resolvechildren=1')
            instaces = hyper.get('instances')
            return [RESTResource.resourceForURI(json['id'], json) for json in instaces]
        else:
            return None

    def _getHosts(self):
        return self._getVirtualmachines()
                    
    def _setCloud(self, cloud):
         resp  = http.putJSON(self.uri, {'vdcs_target': cloud.id if cloud else None})
         if resp.get('jobs'):
             job = RESTResource.resourceForURI('/admin/resources/jobs/%s' % resp['jobs'][0])
             ipasutils.waitForJob(job)

    def poweron(self):
        'IWD11019'
        http.putJSON(self.uri, {'power_target_state': 'powered_on'})
    
    def poweroff(self):
        'IWD11020'
        http.putJSON(self.uri, {'power_target_state': 'powered_off'})
    
    def quiesce(self):
        'IWD11021'
        http.putJSON(self.uri, {'target_state': 'quiesced'})
    
    def maintain(self):
        'IWD11022'
        http.putJSON(self.uri, {'target_state': 'maintenance'})
    
    def initialize(self):
        'Initialize the compute node'
        http.putJSON(self.uri, {'state': 'failed', 'target_state':'initializing'})
        
    def start(self):
        'IWD11023'
        http.putJSON(self.uri, { 'target_state': 'available'})
    
    @classmethod
    def _queryname(self):
        return 'compute_nodes'
    
    def delete(self):
        if utils.isSparta():
            raise NotImplementedError('delete')
        return super(ComputeNode, self).delete


@utils.classinit
class ManagementEndpoint(HardwareComponent):
    @classmethod
    def _classinit(cls):
        cls._registerURI(r'\A/admin/resources/management_endpoints/(?P<id>[\da-z\-]+)\Z')
        
        cls._defineRESTAttribute('id', 'IWD11000', readonly=True)
        cls._defineRESTAttribute('name', 'IWD11001', readonly=True)
        cls._defineRESTAttribute('state', 'IWD11004', readonly=True)
        
        cls._defineRESTAttribute('management_endpoint_cpus', '', readonly=True, elided=True)
        cls._defineRESTAttribute('management_endpoint_memory', '', readonly=True, elided=True)
        cls._defineRESTAttribute('mgmt_endpoint_eth_adapters', '', readonly=True, elided=True)
        
    def _getManagement_endpoint_cpus(self):
        return prettify.PrettyList(self._restattrs['management_endpoint_cpus']);
    
    def _getManagement_endpoint_memory(self):
        return prettify.PrettyList(self._restattrs['management_endpoint_memory']);
    
    def _getMgmt_endpoint_eth_adapters(self):
        return prettify.PrettyList(self._restattrs['mgmt_endpoint_eth_adapters']);
    
@utils.classinit
class ComputeNodes(IPASRESTResourceCollection):
    'IWD11015'

    @classmethod
    def _classinit(cls):
        cls._contains(ComputeNode)
        cls._methodHelp('list')
    @classmethod    
    def _restname(cls):
        return 'compute_nodes'

    def add(self):
        if utils.isSparta():
            raise NotImplementedError('add')
        return super(ComputeNodes, self).add

#######################################
# internal classes for compute node
#######################################
@utils.classinit    
class _PhysicalIOAdapter(HardwareComponent):
    ''
        
    @classmethod
    def _classinit(cls):
        cls._registerURI(r'\A/admin/resources/physical_io_adapters/(?P<id>[\da-z\-]+)\Z')
        
        cls._defineRESTAttribute('id', 'IWD11115', readonly=True)
        cls._defineRESTAttribute('name', 'IWD11116', readonly=True)
        cls._defineRESTAttribute('state', 'IWD11117', readonly=True)
        
        cls._defineRESTAttribute('eth_broadcast_pkts_recvd', 'IWD11025', readonly=True)
        cls._defineRESTAttribute('eth_broadcast_pkts_sent', 'IWD11026', readonly=True)
        cls._defineRESTAttribute('eth_bytes_recvd', 'IWD11027', readonly=True)
        cls._defineRESTAttribute('eth_bytes_sent', 'IWD11028', readonly=True)
        cls._defineRESTAttribute('eth_multicast_pkts_recvd', 'IWD11029', readonly=True)
        cls._defineRESTAttribute('eth_multicast_pkts_sent', 'IWD11030', readonly=True)
        cls._defineRESTAttribute('eth_pkts_recvd', 'IWD11031', readonly=True)
        cls._defineRESTAttribute('eth_pkts_recvd_bad', 'IWD11032', readonly=True)
        cls._defineRESTAttribute('eth_pkts_recvd_dropped', 'IWD11033', readonly=True)
        cls._defineRESTAttribute('eth_pkts_recvd_error', 'IWD11034', readonly=True)
        cls._defineRESTAttribute('eth_pkts_sent', 'IWD11035', readonly=True)
        cls._defineRESTAttribute('eth_pkts_sent_dropped', 'IWD11036', readonly=True)
        cls._defineRESTAttribute('eth_pkts_sent_error', 'IWD11037', readonly=True)
        cls._defineRESTAttribute('eth_recvd_interrupts', 'IWD11038', readonly=True)
        cls._defineRESTAttribute('eth_sent_interrupts', 'IWD11039', readonly=True)
        cls._defineRESTAttribute('fc_dumped_frames', 'IWD11040', readonly=True)
        cls._defineRESTAttribute('fc_error_frames', 'IWD11041', readonly=True)
        cls._defineRESTAttribute('fc_input_bytes', 'IWD11042', readonly=True)
        cls._defineRESTAttribute('fc_input_requests', 'IWD11043', readonly=True)
        cls._defineRESTAttribute('fc_output_bytes', 'IWD11044', readonly=True)
        cls._defineRESTAttribute('fc_output_requests', 'IWD11045', readonly=True)
        cls._defineRESTAttribute('fc_received_frames', 'IWD11046', readonly=True)
        cls._defineRESTAttribute('fc_transmitted_frames', 'IWD11047', readonly=True)
        cls._defineRESTAttribute('physicalioadaptermodules', 'IWD11048', restname='physical_io_adapter_modules', readonly=True)
        
    def _getPhysicalioadaptermodules(self):
        return self._renderRESTResourceCollection('physical_io_adapter_modules');
    
    @classmethod
    def _queryname(self):
        return 'physical_io_adapters'  

@utils.classinit    
class _PhysicalIOAdapterModule(HardwareComponent):
    ''
        
    @classmethod
    def _classinit(cls):
        cls._registerURI(r'\A/admin/resources/physical_io_adapter_modules/(?P<id>[\da-z\-]+)\Z')
        
        cls._defineRESTAttribute('id', 'IWD11118', readonly=True)
        cls._defineRESTAttribute('name', 'IWD11119', readonly=True)
        cls._defineRESTAttribute('state', 'IWD11120', readonly=True)
        
        cls._defineRESTAttribute('adapternumber', 'IWD11049', restname='adapter_number', readonly=True)
        cls._defineRESTAttribute('firmwarelevel', 'IWD11124', restname='firmware_level', readonly=True)
        cls._defineRESTAttribute('physicalioports', 'IWD11050', restname='physical_io_ports', readonly=True)
        
    def _getPhysicalioports(self):
        return self._renderRESTResourceCollection('physical_io_ports');
    
    @classmethod
    def _queryname(self):
        return 'physical_io_adapter_modules'    

@utils.classinit    
class _PhysicalIOPort(RelatedResource, CommonAttributes):
    ''
        
    @classmethod
    def _classinit(cls):
        cls._registerURI(r'\A/admin/resources/physical_io_ports/(?P<id>[\da-z\-]+)\Z')
        
        cls._defineRESTAttribute('id', 'IWD11121', readonly=True)
        cls._defineRESTAttribute('name', 'IWD11122', readonly=True)
        cls._defineRESTAttribute('state', 'IWD11123', readonly=True)
        
        cls._defineRESTAttribute('linkstate', 'IWD11051', restname='link_state', readonly=True)
        cls._defineRESTAttribute('mac', 'IWD11052', restname='mac_address', readonly=True)
        cls._defineRESTAttribute('portnumber', 'IWD11053', restname='port_number', readonly=True)
        cls._defineRESTAttribute('speed', 'IWD11054', readonly=True)
        cls._defineRESTAttribute('vlan', 'IWD11055', readonly=True)
        cls._defineRESTAttribute('wwpn', 'IWD11056', readonly=True)
        