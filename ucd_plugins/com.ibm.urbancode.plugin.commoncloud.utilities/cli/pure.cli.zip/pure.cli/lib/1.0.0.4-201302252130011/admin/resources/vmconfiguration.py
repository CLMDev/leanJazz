"""
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2011. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
"""

from deployer.resources.commonattrs import CommonAttributes
from deployer import http, utils, validators
from deployer.resources.relationships import RelatedResource, RelatedResourceCollection
from deployer.resources.restresource import RESTResource, RESTResourceCollection
from ipasrestresource import IPASRESTResourceCollection, IPASRESTResource



@utils.classinit
class VMConfiguration(IPASRESTResource):
    'IWD10017'

    @classmethod
    def _classinit(cls):
        cls._registerURI(r'\A/admin/resources/vm_configurations/(?P<id>[\da-f\-]+)\Z')
        cls._registerURI(r'\A/deployment/resources/vm_configurations/(?P<id>[\da-f\-]+)\Z')

        cls._defineRESTAttribute('id', 'IWD10011', readonly=True)
        cls._defineRESTAttribute('name', 'IWD10007')
        #TODO: add message for description
        cls._defineRESTAttribute('description', '')
        cls._defineRESTAttribute('pcpu_count', 'IWD10009')
        cls._defineRESTAttribute('cpu_count', 'IWD10008')
        cls._defineRESTAttribute('memory', 'IWD10010')
        # type - hidden
        cls._defineRESTAttribute('created_time', 'IWD10031', readonly=True)
        cls._defineRESTAttribute('updated_time', 'IWD10032', readonly=True)
        cls._defineRESTAttribute('url', 'IWD10033', restname='id', readonly=True)
        
    def _containedByFget(self):
        cloudId = self._restattrs.get('vdc')
        if cloudId == None:
            return None
        return RESTResource.resourceForURI(cloudId)
       


@utils.classinit
class VMConfigurations(IPASRESTResourceCollection):
    'IWD10023'
   
    URI = "/admin/resources/vm_configurations"

    @classmethod
    def _classinit(cls):
        cls._contains(VMConfiguration)
        cls._methodHelp('create', 'list')


    CREATE_ATTRIBUTES = [
        VMConfiguration._wizardStep('name'),
        VMConfiguration._wizardStep('cpu_count'),
        VMConfiguration._wizardStep('memory'),
        VMConfiguration._wizardStep('pcpu_count', optional=True)
    ]
    
    @classmethod
    def _restname(cls):
        return 'vm_configurations'
    
    def _create(self, dict):
        
        
        dict['vdc'] = {"uri":self.uri[0: self.uri.rindex('/')]}
        
        temp = self.uri
        self.uri = self.URI
        
        object = None
        try:
           object = super(VMConfigurations, self)._create(dict, ['vdc'])
        finally:        
            self.uri = temp
            
        return object

    def _list(self, filt = {}):
        
       vdcUUID = self.uri.split('/')[-2]
       filt['vdc'] = vdcUUID
       
       temp = self.uri
       self.uri = self.URI
       result =  super(VMConfigurations, self)._list(filt)
       self.uri = temp
       
       return result

 
