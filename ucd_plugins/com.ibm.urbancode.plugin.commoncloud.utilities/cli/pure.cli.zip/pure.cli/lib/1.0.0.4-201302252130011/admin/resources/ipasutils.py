"""
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2011. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
"""

from deployer.resources.restresource import RESTResource
from deployer.messages import message
from admin.resources.job import Job
from deployer import utils

#pass in a job uri, job object or a http response contains jobs
#this method will block till job is done(failed/succ), and it will throw an exception if job failed
def waitForJob(resp):
    job = None
    if isinstance(resp, Job):
        job = resp
    elif isinstance(resp, str) or isinstance(resp, unicode):
        id = utils.uuid(resp)
        job = RESTResource.resourceForURI(id)
    elif isinstance(resp, dict) and resp.get('jobs'):
        id = utils.uuid(resp['jobs'][0])
        job = RESTResource.resourceForURI('/admin/resources/jobs/%s' % id)
    
    if job != None:
        job.waitFor()
        if job.state != 'successful':
            raise IOError(utils.utos(message('IWD10078')))