"""
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2011. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
"""

from deployer import http, utils, validators
from deployer.resources.commonattrs import CommonAttributes
from deployer import utils
from deployer.resources.relationships import RelatedResource
from ipasrestresource import IPASRESTResourceCollection, IPASRESTResource

        

class Roles(object):
        'RM09112'

        ROLES = [ object(), object(), object(), 'CLOUD_ADMIN',
                  'APPLIANCE_ADMIN', 'CATALOG_CREATOR', 'PATTERN_CREATOR', 'ILMT_USER',
                  'CLOUD_ADMIN_READONLY', 'APPLIANCE_ADMIN_READONLY' ,'PROFILE_CREATOR',
                  'REPORT_READONLY', object(), 'AUDIT_READONLY', 'AUDIT', 'HARDWARE_ADMIN',
                  'SECURITY_ADMIN', 'SECURITY_ADMIN_READONLY',object(),object(),'ROLE_ADMIN',
                  'HARDWARE_ADMIN_READONLY','CLOUDGROUP_ADMIN','CLOUDGROUP_ADMIN_READONLY', 'USER_ADMIN_READONLY' ]
        
        ADD_SIDE_EFFECTS = {
                'APPLIANCE_ADMIN':[ 'CLOUD_ADMIN',
                      'APPLIANCE_ADMIN', 'CATALOG_CREATOR', 'PATTERN_CREATOR', 'ILMT_USER',
                      'CLOUD_ADMIN_READONLY', 'APPLIANCE_ADMIN_READONLY' ,'PROFILE_CREATOR'],
                 'APPLIANCE_ADMIN_READONLY':['APPLIANCE_ADMIN_READONLY','CLOUD_ADMIN_READONLY'],
                 'AUDIT':['AUDIT_READONLY','AUDIT'],
                 'CLOUDGROUP_ADMIN':['CLOUDGROUP_ADMIN','CLOUDGROUP_ADMIN_READONLY'],
                 'SECURITY_ADMIN':['USER_ADMIN_READONLY','SECURITY_ADMIN_READONLY','SECURITY_ADMIN'],
                 'HARDWARE_ADMIN':['HARDWARE_ADMIN_READONLY','HARDWARE_ADMIN']     
                }
        
        REMOVE_SIDE_EFFECTS = {
                               'CLOUD_ADMIN_READONLY':['CLOUD_ADMIN_READONLY','CLOUD_ADMIN'],
                               'APPLIANCE_ADMIN_READONLY':['APPLIANCE_ADMIN_READONLY','APPLIANCE_ADMIN','CLOUD_ADMIN','CLOUD_ADMIN_READONLY'],
                               'APPLIANCE_ADMIN':['APPLIANCE_ADMIN','CLOUD_ADMIN'],
                               'SECURITY_ADMIN_READONLY':['SECURITY_ADMIN_READONLY','SECURITY_ADMIN'],
                               'USER_ADMIN_READONLY':['USER_ADMIN_READONLY','SECURITY_ADMIN','SECURITY_ADMIN_READONLY'],
                               'AUDIT_READONLY':['AUDIT_READONLY','AUDIT'],
                               'HARDWARE_ADMIN_READONLY':['HARDWARE_ADMIN_READONLY','HARDWARE_ADMIN']                                   
                               }
        ADD_REMOVE_SIDE_EFFECTS = {
                                  'USER_ADMIN_READONLY':['SECURITY_ADMIN_READONLY','SECURITY_ADMIN'],
                                  'SECURITY_ADMIN_READONLY':['USER_ADMIN_READONLY','SECURITY_ADMIN']                                  
                                  }
        
        def __init__(self, user):
            self.user = user
            self.role_list = []


        def __iadd__(self, other):
            'RM09113'
            role_list = self._getRoleList()
            if isinstance(other, list):
                for r in other:
                    self._addARole(r,role_list)                     
            else:
                self._addARole(other,role_list)
            try:     
                self._handleReportRole(role_list)                   
                http.putJSON(self.user.uri, {'roles':role_list})
            except ValueError:
                raise ValueError('%s not a recognized role' % other)

            return self
        
        def _handleReportRole(self,role_list):
            rolesRequiresReportRole = ['CLOUDGROUP_ADMIN_READONLY', 'APPLIANCE_ADMIN_READONLY', 'HARDWARE_ADMIN_READONLY','USER_ADMIN_READONLY', 'SECURITY_ADMIN_READONLY', 'SECURITY_ADMIN']
            needReportRole = False
            for oneRoleNeedReportRole in rolesRequiresReportRole:
                if  self.ROLES.index(oneRoleNeedReportRole) in role_list:
                    needReportRole = True
                    if not self.ROLES.index("REPORT_READONLY") in role_list:
                            role_list.append(self.ROLES.index("REPORT_READONLY"))                            
            if not needReportRole:
                 if self.ROLES.index("REPORT_READONLY") in role_list:
                            role_list.remove(self.ROLES.index("REPORT_READONLY"))
                
        def _removeARole(self,aRole, role_list):
            try:  
                if self.REMOVE_SIDE_EFFECTS.has_key(aRole):
                    for oneRoleToRemove in self.REMOVE_SIDE_EFFECTS[aRole]:
                        if self.ROLES.index(oneRoleToRemove) in role_list:
                            role_list.remove(self.ROLES.index(oneRoleToRemove))
                else:
                    role_list.remove(self.ROLES.index(aRole))
            except ValueError:
                pass    
            
        def _addARole(self,aRole, role_list):
            try:  
                if self.ADD_SIDE_EFFECTS.has_key(aRole):
                    for oneRoleToAdd in self.ADD_SIDE_EFFECTS[aRole]:
                        if not self.ROLES.index(oneRoleToAdd) in role_list:
                            role_list.append(self.ROLES.index(oneRoleToAdd))
                elif self.ADD_REMOVE_SIDE_EFFECTS.has_key(aRole):
                    for oneRoleToRemove in self.ADD_REMOVE_SIDE_EFFECTS[aRole]:
                         if self.ROLES.index(oneRoleToRemove) in role_list:
                            role_list.remove(self.ROLES.index(oneRoleToRemove))
                    if not self.ROLES.index(aRole) in role_list:
                        role_list.append(self.ROLES.index(aRole))        
                else:
                    if not self.ROLES.index(aRole) in role_list:
                        role_list.append(self.ROLES.index(aRole))
            except ValueError:
                pass                  
            
        
        def _getRoleList(self):
            userWithAllRoles = http.get('%s?resolvechildrenlist=roles,user_groups&resolvechildren=1&effectiveroles=true' % self.user.uri)
            role_list = []
            if 'roles' in userWithAllRoles:
                json = userWithAllRoles['roles']
            	for element in json:
                    role_list.append(element['role_id'])
            return role_list

        def __isub__(self, other):
            'RM09114'

            role_list = self._getRoleList() 
            if isinstance(other, list):
                for r in other:
                    self._removeARole(r, role_list);
            else:  
                self._removeARole(other, role_list);
            try:   
                self._handleReportRole(role_list)                     
                http.putJSON(self.user.uri, {'roles':role_list})
            except ValueError:
                raise ValueError('%s not a recognized role' % other)

            return self
        

        def __iter__(self):
            'RM09115'
            role_list = self._getRoleList()
            return iter([ self.ROLES[r] for r in range(0, len(self.ROLES)) if r in role_list and isinstance(self.ROLES[r], str)])


        def __lshift__(self, other):
            'RM09116'
            self.__iadd__(other)


        def __repr__(self):
            'RM09119'
            return utils.utos(unicode(self))


        def __rshift__(self, other):
            'RM09117'
            self.__isub__(other)


        def __str__(self):
            'RM09118'
            return repr(self)


        def __unicode__(self):
            'RM09118'
            return unicode(list(self))



 