"""
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2011. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
"""

from deployer import http, utils, validators
from deployer.resources.commonattrs import CommonAttributes
from deployer import utils
from deployer.resources.relationships import RelatedResource
from ipasrestresource import IPASRESTResourceCollection, IPASRESTResource
from role import Roles

@utils.classinit
class Group(IPASRESTResource):
    'RM09073'
    
    @classmethod
    def _classinit(cls):
        cls._registerURI(r'\A/admin/resources/user_groups/(?P<id>[\da-z\-]+)\Z')
        cls._defineRESTAttribute('id', 'IWD11177', readonly=True)
        cls._defineRESTAttribute('name', 'IWD11178', validator=validators.string)
        cls._defineRESTAttribute('description', 'IWD11179', validator=validators.string)
        cls._defineRESTAttribute('created_time', 'IWD11180', readonly=True)
        cls._defineRESTAttribute('updated_time', 'IWD11181', readonly=True)
        cls._defineRESTAttribute('url', 'IWD10033', restname='id', readonly=True)
        cls._defineRESTAttribute('roles', Roles.__doc__, validator=validators.noop, elided=True)
        cls._defineRESTAttribute('member_location', 'IWD11230', validator=validators.noop)
        

        cls._methodHelp('__contains__', '__delattr__', 'delete', '__eq__',
                        '__hash__', 'isStatusTransient', '__nonzero__',
                        'refresh', '__repr__', '__str__', '__unicode__',
                        'waitFor')
            
    def __init__(self, uri, attrs):
        super(Group, self).__init__(uri, attrs)
        self._roles = Roles(self)
        self.role_list = []
        
    def _getRoles(self):
        return self._roles


    def _setRoles(self, value):
        if value != self._roles:
            raise AttributeError("can't set attribute")
    
    

     
    
@utils.classinit
class Groups(IPASRESTResourceCollection):
    'RM09029'

    @classmethod
    def _classinit(cls):
        cls._contains(Group)
        cls._methodHelp('__contains__', 'delete', '__delitem__',
                        '__getattr__', '__getitem__', '__iter__',
                        '__len__', 'list', '__lshift__', '__repr__',
                        '__rshift__', '__str__', '__unicode__')
    @classmethod    
    def _restname(cls):
        return 'user_groups'
    
    CREATE_ATTRIBUTES = [
        Group._wizardStep('name'),
        Group._wizardStep('member_location', optional=True),
        Group._wizardStep('description')
    ]
    
    def _create(self, dict):
        return super(Groups, self)._create(dict)
    
    def everyone(self):
        'RM09030'
        json = self._list({"name":"Everyone"})
        if isinstance(json, list):
            json = json[0]
        return json
