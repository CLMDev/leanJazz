#
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2011. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
#

from ipasrestresource import IPASRESTResource
from deployer.resources.restresource import RESTResource
from deployer.messages import message
from deployer import http, utils
import sys

class HardwareComponent(IPASRESTResource):
    
    @classmethod
    def _classinit(cls):
        cls._defineRESTAttribute('id', 'IWD11000', readonly=True, defaultToNone=True)   
        cls._defineRESTAttribute('labeltext', 'IWD11357', restname='label_text', readonly=True, defaultToNone=True)
        cls._defineRESTAttribute('labeluser', 'IWD11358', restname='label_user', readonly=True, defaultToNone=True)
        cls._defineRESTAttribute('name', 'IWD11001', readonly=True, defaultToNone=True)
        cls._defineRESTAttribute('state', 'IWD11004', readonly=True, defaultToNone=True)
        cls._defineRESTAttribute('url', 'IWD10033', restname='id', readonly=True, defaultToNone=True)
        
    def _getHealthstats(self):
        if self._restattrs.has_key('health_stats') and len(self._restattrs['health_stats'])>0:
            healthURI = self._restattrs['health_stats'][0]
            health = http.get(healthURI)
            return health
        else:
            return None
        
    def _getEnergystats(self):
        if self._restattrs.has_key('energy_stats') and len(self._restattrs['energy_stats'])>0:
            energy = http.get(self._restattrs['energy_stats'][0])
            return energy
        else:
            return None
      
    def _getLocations(self):
        if self._restattrs.has_key('locations') and len(self._restattrs['locations'])>0:
            locationURI = self._restattrs['locations'][0]
            location = http.get(locationURI)
            result = None;
            if location != None:
                result = str(location.get('physical_location', '')) + ' ' + str(location.get('label_text',''))
            return result
        else:
            return None
        
    def _getLeds(self):
        return self._renderRESTResourceCollection('leds')
