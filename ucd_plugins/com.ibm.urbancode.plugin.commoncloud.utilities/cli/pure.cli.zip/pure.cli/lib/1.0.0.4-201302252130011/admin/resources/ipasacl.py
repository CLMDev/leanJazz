"""
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2011. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
"""

from deployer import http, prettify, utils
from deployer.messages import message
from deployer.utils import utos
import java
from deployer.resources.restresource import RESTResource


class ACL(object):
    'RM09061'

    _METHODHELP_ = [
        'check', '__contains__', '__delitem__', '__getitem__',
        '__iter__', '__len__', 'refresh', '__repr__',
        '__setitem__', '__str__', '__unicode__'
    ]

    NO_PERMISSIONS = 0
    READ_PERMISSION = 1
    UPDATE_PERMISSION = 2
    CREATE_PERMISSION = 3
    DELETE_PERMISSION = 4
    ALL_PERMISSIONS = DELETE_PERMISSION

    NLS_KEYS = {
        NO_PERMISSIONS: 'RM12000',
        READ_PERMISSION: 'RM12001',
        UPDATE_PERMISSION: 'RM12002',
        CREATE_PERMISSION: 'RM12003',
        DELETE_PERMISSION: 'RM12004',
        'F': 'F',
        'R': 'R',
        'RW': 'RW'
    }


    def __init__(self, parent):
        self.parent = parent
        self.acls = None


    # private methods

    def _acls(self):
        if not self.acls:
            self._refreshAcls()


    def _refreshAcls(self):
        self.acls = {}
        for acl in http.get('%s/acls/?resolveparents=1' % self.parent.uri):
            if acl['is_group'] == 'T':    
                group = acl["user_groups"]          
                self.acls[group["name"] + u"?group"] = acl['permissions']
            else:
                user = acl["users"]  
                self.acls[user["user_id"] + u"?user"] = acl['permissions']


    def _uriFor(self, entity):
        
        if(isinstance(entity, basestring)):
            split = entity.split("?")
            if(split[1] == "group"):
                type = "user_group"
            else:
                type = split[1]
            return '%s/acls/?%s=%s' % (self.parent.uri,type,split[0])
        else:
            for acl in http.get('%s/acls' % self.parent.uri):
                if acl['is_group'] == 'T':    
                    lastIdxofSlash = acl['user_groups'].rfind('/')
                    userOrGroupID = acl['user_groups'][lastIdxofSlash+1:]
                else:
                    lastIdxofSlash = acl['users'].rfind('/') 
                    userOrGroupID = acl['users'][lastIdxofSlash+1:]
                if userOrGroupID == entity.id:
                    lastIdxofSlash = acl['id'].rfind('/')
                    aclID  = acl['id'][lastIdxofSlash+1:]
                    return '%s/acls/%s' % (self.parent.uri,  aclID)
                    
        return ''


    # public methods

    def check(self, entity):
        'RM09062'
        checkingURL = self._uriFor(entity)
        if checkingURL != '':
            return http.get(self._uriFor(entity))
        else :
            return ''


    def __contains__(self, key):
        'RM09063'
        self._acls()
        key = self._formatKey(key)
        return self.acls.has_key(key)


    def __delitem__(self, key):
        'RM09064'
        http.delete(self._uriFor(key))
        self.acls = None


    def __getitem__(self, key):
        'RM09065'
        self._acls()
        key = self._formatKey(key)
        return int(self.acls.get(key, self.NO_PERMISSIONS))


    def __iter__(self):
        'RM09066'
        self._acls()
        return iter(self.acls)


    def __len__(self):
        'RM09067'
        self._acls()
        return len(self.acls)


    def refresh(self):
        'RM09068'
        self._refreshAcls()


    def __repr__(self):
        'RM09069'
        return utos(unicode(self))

    def _formatKey(self, key):
        if(not isinstance(key, basestring)):
            if(hasattr(key, 'member_location')):
                key =  key.name+ u"?group"
            else:
                key =  key.user_id + u"?user"
        return key

    def __setitem__(self, key, value):
        'RM09070'
        self._acls()
        
        key = self._formatKey(key)
        
        if not self.acls.has_key(key):
            http.postJSON(self._uriFor(key), {"permissions":value})
        else:
            http.putJSON(self._uriFor(key),{"permissions":value})
        self.acls = None


    def __str__(self):
        'RM09071'
        return repr(self)


    def __unicode__(self):
        'RM09071'

        self._acls()
        result = {}
        for entity in iter(self):
            split = entity.split("?")
            result[u"("+ split[1] +u" " + split[0] + u")"] = message(self.NLS_KEYS[self.acls[entity]])
        if prettify.enabled:
            return prettify.prettify(result, quoteStrings=False)
        else:
            return unicode(result)
