"""
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2011. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
"""

from deployer.resources.commonattrs import CommonAttributes
from deployer import utils, http
from deployer.resources.restresource import RESTResource
from deployer.messages import message
from admin.resources.ipasrestresource import IPASRESTResourceCollection, IPASRESTResource

@utils.classinit
class TraceSetting(IPASRESTResource):
    'IWD12107'
    
    @classmethod
    def _classinit(cls):
        cls._registerURI(r'\A/admin/resources/traces/(?P<id>[\da-z\-]+)\Z')

        cls._defineRESTAttribute('id', 'IWD11000', readonly=True)
        cls._defineRESTAttribute('component', 'IWD12101', readonly=True)
        cls._defineRESTAttribute('level', 'IWD12102', values=['OFF', 'SEVERE', 'WARNING', 'INFO', 'FINE', 'FINER', 'FINEST', 'ALL'])
        cls._defineRESTAttribute('state', 'IWD12103', readonly=True)
        cls._defineRESTAttribute('created_time', 'IWD12104', readonly=True)
        cls._defineRESTAttribute('updated_time', 'IWD12105', readonly=True)
        cls._defineRESTAttribute('version', 'IWD12106', readonly=True)
        cls._methodHelp('delete')

@utils.classinit
class TraceSettings(IPASRESTResourceCollection):
    'IWD12108'

        
    CREATE_ATTRIBUTES = [
        TraceSetting._wizardStep('component'),
        TraceSetting._wizardStep('level')
    ]
      
    @classmethod
    def _classinit(cls):
        cls._contains(TraceSetting)
        cls._methodHelp('create', 'list')

    @classmethod
    def _restname(cls):
        return 'traces'

    def _getDefaultSearchField(self):
        return "component"
        
