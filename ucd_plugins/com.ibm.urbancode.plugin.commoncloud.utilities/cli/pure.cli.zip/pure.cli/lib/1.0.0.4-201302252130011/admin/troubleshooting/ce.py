from deployer import http, utils, validators

class CEAccount(object):
    '''IWD10076'''

    _PROPERTYHELP_ = ['enabled', 'secretkey']

    CE_URI = '/admin/resources/ibmce'
    
    uri = None
    
    def enabled_(self):
        '''IWD10077'''
        pass
    
    def _getEnabled(self):
        resp = http.get(self.CE_URI)
        if resp and len(resp) > 0:
           self.uri = resp[0].get('id')
           return True if resp[0].get('is_disabled') == 'F' else False
        return False
            
       
    def _setEnabled(self, enabled):
       if self.uri == None:
           resp = http.get(self.CE_URI)
           if resp:
               self.uri = resp[0].get('id')
       validators.boolean(enabled, "enabled")
       return http.putJSON(self.uri, { "is_disabled": 'F' if enabled else 'T' })
   
    def _getSecretKey(self):
       if self.enabled:
           resp = http.get('/admin/resources/ibmce_auth_requests')
           if resp and len(resp) > 0:
               return resp[0].get('auth_request')
       return None
           
       
    enabled = property(_getEnabled, _setEnabled)
    secretkey = property(_getSecretKey)