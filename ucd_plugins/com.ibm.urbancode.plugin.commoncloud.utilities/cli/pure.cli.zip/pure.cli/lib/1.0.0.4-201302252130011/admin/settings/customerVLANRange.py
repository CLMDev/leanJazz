#
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2012. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
#

from deployer.messages import message


class customerVLANRange(object):
    'IWD12233'

    _ALL_RANGES = []
 
    _RANGE_SEPARATOR = '-'

    _MIN_VLAN = 0
    _MAX_VLAN = 4096
    
    VALID_ENABLE_SPANNING_TREE_VALUES = [ True, 'true', False, 'false' ]

    _MIN_SPANNING_TREE_GROUP = 1
    _MAX_SPANNING_TREE_GROUP = 127
    
    _MANAGEMENT_NETWORK_VLAN = None
    _MOTION_NETWORK_VLAN     = None
    _CONSOLE_NETWORK_VLAN    = None
    _VLAG_TIER_ID            = None


    _METHODHELP_   = [ 'delete' ]
                     
    _PROPERTYHELP_ = [ 'id', 'spanningTreeEnabled', 'spanningTreeGroup' ]


    @classmethod
    def _raiseValueErrorBecauseAttrCannotChange(cls, attrName):
        msgKey0CannotBeChanged = 'IWD12274'
        msg = message(msgKey0CannotBeChanged, cls.__name__ + '.' + attrName)
        raise ValueError(msg)
        

    @classmethod
    def _raiseValueErrorBecauseAttrCannotBeSetTo(cls, attrName, value):
        msgKey0IsNotValidFor1 = 'IWD12275'
        msg = message(msgKey0IsNotValidFor1, value, cls.__name__ + '.' + attrName)
        raise ValueError(msg)


    @classmethod
    def _raiseValueErrorBecauseVLANIsAlreadyInARange(cls, vlanID):
        msgKey0IsAlreadyInARange = 'IWD12276'
        msg = message(msgKey0IsAlreadyInARange, vlanID)
        raise ValueError(msg)

    
    @classmethod
    def _raiseValueErrorBecauseVLANRangeIsAlreadyInALink(cls, rangeID):
        msgKey0IsAlreadyInALink = 'IWD12279'
        msg = message(msgKey0IsAlreadyInALink, rangeID)
        raise ValueError(msg)
                
        
    @classmethod
    def _getManagementNetworkVLAN(cls):
        return cls._MANAGEMENT_NETWORK_VLAN


    @classmethod
    def _getMotionNetworkVLAN(cls):
        return cls._MOTION_NETWORK_VLAN


    @classmethod
    def _getConsoleNetworkVLAN(cls):
        return cls._CONSOLE_NETWORK_VLAN


    @classmethod
    def _getVLAGTierID(cls):
        return cls._VLAG_TIER_ID
    

    @classmethod
    def _add(cls, newRange):
        cls._ALL_RANGES.append(newRange)


    @classmethod
    def _get(cls, rangeID):
        (startID,endID) = cls._getStartAndEndOfVLANRangeFromStr(rangeID)
        for vlanRange in cls._ALL_RANGES:
            if (startID == vlanRange._startID) and (endID == vlanRange._endID):
                return vlanRange
        return None
           

    @classmethod
    def _getAll(cls):
        return cls._ALL_RANGES


    @classmethod
    def _addToLink(cls, rangeID, linkName):
        vlanRange = cls._get(rangeID)
        if (None == vlanRange):
            customerVLANRange._raiseValueErrorBecauseAttrCannotBeSetTo('id', str(rangeID))
        
        if (None != vlanRange._memberOfLink):
            customerVLANRange._raiseValueErrorBecauseVLANRangeIsAlreadyInALink(str(rangeID))
            
        vlanRange._memberOfLink = linkName


    @classmethod
    def _removeFromLink(cls, rangeID, linkName):
        vlanRange = cls._get(rangeID)
        if (linkName != vlanRange._memberOfLink):
            customerVLANRange._raiseValueErrorBecauseAttrCannotBeSetTo('id', str(rangeID))
        vlanRange._memberOfLink = None    


    @classmethod
    def _getRangeIDsForLink(cls, linkName):
        rangeIDs = set([])
        for vlanRange in cls._ALL_RANGES:
            if (linkName == vlanRange._memberOfLink):
                if (vlanRange._startID == vlanRange._endID):
                    rangeIDs.add(str(vlanRange._startID))
                else:
                    rangeIDs.add(str(vlanRange._startID) + '-' + str(vlanRange._endID))
        return rangeIDs
    
    
    @classmethod
    def _discardAll(cls):
        cls._ALL_RANGES = []
    

    @classmethod
    def _refreshAll(cls, jsonData):
        cls._ALL_RANGES = []
        allVLANRangeIDs = cls._findAllVLANRangeIDsInJSON(jsonData)
        for newID in allVLANRangeIDs:
            newRange = cls._getVLANRangeFromJSON(newID, jsonData)
            cls._ALL_RANGES.append(newRange)
        cls._MANAGEMENT_NETWORK_VLAN = cls._getVLANFromStr(jsonData['VLAN_MANAGEMENT_NETWORK'])
        cls._MOTION_NETWORK_VLAN     = cls._getVLANFromStr(jsonData['VLAN_MOTION_NETWORK'])
        cls._CONSOLE_NETWORK_VLAN    = cls._getVLANFromStr(jsonData['VLAN_CONSOLE_NETWORK'])
        cls._VLAG_TIER_ID            = cls._getVLANFromStr(jsonData['VLAG_TIER_ID'])


    @classmethod
    def _getVLANRangeIDAttrFromJSON(cls, index, jsonData):
        return jsonData['VLAN_RANGE_' + str(index)]
 
 
    @classmethod
    def _getVLANSpanningTreeEnabledAttrFromJSON(cls, index, jsonData):
        return jsonData['VLAN_ENABLE_SPANNING_TREE_' + str(index)]
 
 
    @classmethod
    def _getVLANSpanningTreeGroupAttrFromJSON(cls, index, jsonData):
        return jsonData['VLAN_SPANNING_TREE_GROUP_' + str(index)]
 
 
    @classmethod
    def _getVLANRangeFromJSON(cls, index, jsonData):
        rangeID = cls._getVLANRangeIDAttrFromJSON(index, jsonData)
        spanningTreeEnabled = cls._getVLANSpanningTreeEnabledAttrFromJSON(index, jsonData)
        spanningTreeGroup   = cls._getVLANSpanningTreeGroupAttrFromJSON(index, jsonData)
        return customerVLANRange(rangeID, spanningTreeEnabled, spanningTreeGroup)


    @classmethod
    def _saveJSONPropsForVLANRange(cls, index, vlanRange, jsonProps):
        jsonProps["VLAN_RANGE_" + str(index)]                =  vlanRange.id
        jsonProps["VLAN_ENABLE_SPANNING_TREE_" + str(index)] = vlanRange.spanningTreeEnabled
        jsonProps["VLAN_SPANNING_TREE_GROUP_"  + str(index)] = vlanRange.spanningTreeGroup


    @classmethod
    def _saveAll(cls, jsonProps):
        index = 1
        for vlanRange in cls._ALL_RANGES:
            cls._saveJSONPropsForVLANRange(index, vlanRange, jsonProps)
            index += 1 
        jsonProps["VLAN_MANAGEMENT_NETWORK"] = str(cls._MANAGEMENT_NETWORK_VLAN) 
        jsonProps["VLAN_MOTION_NETWORK"]     = str(cls._MOTION_NETWORK_VLAN)
        jsonProps["VLAN_CONSOLE_NETWORK"]    = str(cls._CONSOLE_NETWORK_VLAN)
        jsonProps["VLAG_TIER_ID"]            = str(cls._VLAG_TIER_ID)
    

    @classmethod
    def _getVLANFromStr(cls, value):
        try:
            vlan = int(value)
            if (vlan >= cls._MIN_VLAN) and (vlan <= cls._MAX_VLAN):
                return vlan
            else:
                return None
        except ValueError:
            return None


    @classmethod
    def _getStartAndEndOfVLANRangeFromStr(cls, vlanRange):
        vlanStart = None
        vlanEnd   = None
        vlans = vlanRange.split(cls._RANGE_SEPARATOR)
        if (len(vlans) == 1):
            vlanStart = cls._getVLANFromStr(vlans[0])
            vlanEnd   = vlanStart
        if (len(vlans) == 2):
            vlanStart = cls._getVLANFromStr(vlans[0])
            vlanEnd   = cls._getVLANFromStr(vlans[1])
        return ( vlanStart, vlanEnd )


    @classmethod
    def _findAllVLANRangeIDsInJSON(cls, jsonData):
        allRangeIDs = set([])
        vlanRangePrefix = 'VLAN_RANGE_'
        for key in jsonData:
            if (key.startswith(vlanRangePrefix)):
                rangeID = key[len(vlanRangePrefix):]
                allRangeIDs.add(rangeID)
        return allRangeIDs


    def __init__(self, rangeID, spanningTreeEnabled, spanningTreeGroup):
        self._memberOfLink = None
        self.id = rangeID
        self.spanningTreeEnabled = spanningTreeEnabled
        self.spanningTreeGroup   = spanningTreeGroup
        
        (self._startID, self._endID) = customerVLANRange._getStartAndEndOfVLANRangeFromStr(rangeID)


    def _isValidRange(self, value):
        if not isinstance(value, str) and not isinstance(value, unicode):
            return False
        (vlanStart, vlanEnd) = customerVLANRange._getStartAndEndOfVLANRangeFromStr(value)
        return (None != vlanStart) and (None != vlanEnd)


    def _isValidSpanningTreeGroup(self, value):
        if not isinstance(value, (str, unicode)):
            return False
        if (0 == len(value)):
            return True
        try:
            vlan = int(value)
            return (vlan >= self._MIN_SPANNING_TREE_GROUP) and (vlan <= self._MAX_SPANNING_TREE_GROUP)
        except ValueError:
            return False
        

    @classmethod
    def _rangesOverlap(cls, range1, range2):
        (start1,end1) = cls._getStartAndEndOfVLANRangeFromStr(range1)
        (start2,end2) = cls._getStartAndEndOfVLANRangeFromStr(range2)
        return (end1 >= start2) and (end2 >= start1)


    def _findAnyOverlappingRange(self, someRange, otherVLANRanges):
        for otherRange in otherVLANRanges:
            if (self._rangesOverlap(someRange, otherRange.id)):
                return otherRange
        return None
        

    def __validateIDAttr(self, value):
        if hasattr(self, 'id'):
            customerVLANRange._raiseValueErrorBecauseAttrCannotChange('id')
        if not self._isValidRange(value):
            customerVLANRange._raiseValueErrorBecauseAttrCannotBeSetTo('id', value)
        overlaps = self._findAnyOverlappingRange(value, customerVLANRange._ALL_RANGES)
        if (None != overlaps):
            customerVLANRange._raiseValueErrorBecauseVLANIsAlreadyInARange(value)


    def __validateSpanningTreeEnabledAttr(self, value):
        if not value in customerVLANRange.VALID_ENABLE_SPANNING_TREE_VALUES:
            customerVLANRange._raiseValueErrorBecauseAttrCannotBeSetTo('spanningTreeEnabled', value)


    def __validateSpanningTreeGroupAttr(self, value):
        if not self._isValidSpanningTreeGroup(value):
            customerVLANRange._raiseValueErrorBecauseAttrCannotBeSetTo('spanningTreeGroup', value)
        

    def __setattr__(self, attr, value):
        if (attr == 'id'):
            self.__validateIDAttr(value)
        if (attr == 'spanningTreeEnabled'):
            self.__validateSpanningTreeEnabledAttr(value)
        if (attr == 'spanningTreeGroup'): 
            self.__validateSpanningTreeGroupAttr(value)
        self.__dict__[attr] = value

    
    def delete(self):
        if not self in customerVLANRange._ALL_RANGES:
            customerVLANRange._raiseValueErrorBecauseAttrCannotBeSetTo('id', self.id)
        customerVLANRange._ALL_RANGES.remove(self)


