#
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2012. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
#

from deployer.messages import message


class customerPort(object):
    'IWD12227'
    
    _ALL_PORTS = None

    __MIN_PORT = 41
    __MAX_PORT = 56
    __VALID_PORT_IDS = range(__MIN_PORT, __MAX_PORT + 1)

    TYPE_COPPER  = 'Copper'
    TYPE_FIBER   = 'Fiber'
    TYPE_DAC     = 'DAC'
    TYPE_UNKNOWN = ''
    VALID_TYPES = [ TYPE_COPPER, TYPE_FIBER, TYPE_DAC, TYPE_UNKNOWN ]

    SPEED_1GB     = '1'
    SPEED_10GB    = '10'
    SPEED_UNKNOWN = ''
    VALID_SPEEDS = [ SPEED_1GB, SPEED_10GB, SPEED_UNKNOWN ]


    _METHODHELP_   = [ ]
                     
    _PROPERTYHELP_ = [ 'id', 'type', 'speed' ]


    @classmethod
    def _raiseValueErrorBecauseAttrCannotChange(cls, attrName):
        msgKey0CannotBeChanged = 'IWD12274'
        msg = message(msgKey0CannotBeChanged, cls.__name__ + '.' + attrName)
        raise ValueError(msg)
        

    @classmethod
    def _raiseValueErrorBecauseAttrCannotBeSetTo(cls, attrName, value):
        msgKey0IsNotValidFor1 = 'IWD12275'
        msg = message(msgKey0IsNotValidFor1, value, cls.__name__ + '.' + attrName)
        raise ValueError(msg)


    @classmethod
    def _raiseValueErrorBecausePortIsAlreadyInALink(cls, portID):
        msgKey0IsAlreadyInALink = 'IWD12277'
        msg = message(msgKey0IsAlreadyInALink, portID)
        raise ValueError(msg)
        

    @classmethod
    def _getAll(cls):
        if (None == cls._ALL_PORTS):
            cls.resetAll()
        return cls._ALL_PORTS
    
    
    @classmethod
    def _get(cls, portID):
        if not portID in cls.__VALID_PORT_IDS:
            customerPort._raiseValueErrorBecauseAttrCannotBeSetTo('id', str(portID))
        if (None == cls._ALL_PORTS):
            cls.resetAll()
        for port in cls._ALL_PORTS:
            if (portID == port.id):
                return port


    @classmethod
    def _addToLink(cls, portID, linkName):
        if (None == cls._ALL_PORTS):
            cls.resetAll()
        port = cls._get(portID)
        if (None != port._memberOfLink):
            customerPort._raiseValueErrorBecausePortIsAlreadyInALink(str(port.id))
        if (cls.SPEED_UNKNOWN == port.speed):
            customerPort._raiseValueErrorBecauseAttrCannotBeSetTo('speed', 'None')
        port._memberOfLink = linkName


    @classmethod
    def _removeFromLink(cls, portID, linkName):
        if (None == cls._ALL_PORTS):
            cls.resetAll()
        port = cls._get(portID)
        if (linkName != port._memberOfLink):       
            customerPort._raiseValueErrorBecauseAttrCannotBeSetTo('id', str(portID))
        port._memberOfLink = None


    @classmethod
    def _getPortIDsForLink(cls, linkName):
        portIDs = set([])
        for port in cls._ALL_PORTS:
            if (linkName == port._memberOfLink):
                portIDs.add(port.id)
        return portIDs
    
       
    @classmethod
    def _getAllUnlinkedPorts(cls):
        unlinkedPorts = set()
        if (None != cls._ALL_PORTS):
            for port in cls._ALL_PORTS:
                if (None == port._memberOfLink) and (cls.SPEED_UNKNOWN != port.speed):
                    unlinkedPorts.add(port)
        return unlinkedPorts
    

    @classmethod
    def _resetAll(cls):
        cls._ALL_PORTS = []
        for portID in cls.__VALID_PORT_IDS:
            defaultPort = customerPort(portID, cls.TYPE_UNKNOWN, cls.SPEED_UNKNOWN)
            cls._ALL_PORTS.append(defaultPort)
            

    @classmethod
    def _getPortAttrFromJSON(cls, portID, attr, jsonData):
        keyAttrA  = 'SWITCH_A_PORT_' + str(portID) + '_' + attr
        keyAttrB  = 'SWITCH_B_PORT_' + str(portID) + '_' + attr

        valueA = jsonData[keyAttrA]
        valueB = jsonData[keyAttrB]

        if (valueA != valueB):
            print 'Warning: inconsistent settings for port ' + str(portID)
            print 'Applying: ' + keyAttrA + ' = ' + valueA
            print 'Ignoring: ' + keyAttrB + ' = ' + valueB

        return valueA


    @classmethod
    def _getPortFromJSON(cls, portID, jsonData):
        if (portID not in cls.__VALID_PORT_IDS):
            return None

        portType = cls._getPortAttrFromJSON(portID, 'TYPE', jsonData)
        portGb   = cls._getPortAttrFromJSON(portID, 'GB',   jsonData)

        return customerPort(portID, portType, portGb)


    @classmethod
    def _saveJSONPropsForPort(cls, port, jsonProps):
        keySwitchAType = "SWITCH_A_PORT_" + str(port.id) + "_TYPE"
        keySwitchBType = "SWITCH_B_PORT_" + str(port.id) + "_TYPE"
        
        jsonProps[keySwitchAType] = port.type
        jsonProps[keySwitchBType] = port.type
        
        keySwitchASpeed = "SWITCH_A_PORT_" + str(port.id) + "_GB"
        keySwitchBSpeed = "SWITCH_B_PORT_" + str(port.id) + "_GB"
        
        jsonProps[keySwitchASpeed] = port.speed
        jsonProps[keySwitchBSpeed] = port.speed
 

    @classmethod
    def _refreshAll(cls, jsonData):
        cls._ALL_PORTS = []
        for portID in cls.__VALID_PORT_IDS:
            cls._ALL_PORTS.append(cls._getPortFromJSON(portID, jsonData))


    @classmethod
    def _saveAll(cls, jsonProps):
        for portID in cls.__VALID_PORT_IDS:
            port = cls._get(portID)
            cls._saveJSONPropsForPort(port, jsonProps)


    def __init__(self, portID, portType, portGb):
        self._memberOfLink = None
        self.id    = portID
        self.type  = portType
        self.speed = portGb
   

    def __setattr__(self, attr, value):
        if (attr == 'id') and hasattr(self, attr):
            customerPort._raiseValueErrorBecauseAttrCannotChange(attr)

        if (attr == 'type') and (value not in customerPort.VALID_TYPES):
            customerPort._raiseValueErrorBecauseAttrCannotBeSetTo(attr, value)
 
        if (attr == 'speed'):
            if (value not in customerPort.VALID_SPEEDS):
                customerPort._raiseValueErrorBecauseAttrCannotBeSetTo(attr, value)
            if (None != self._memberOfLink):
                customerPort._raiseValueErrorBecausePortIsAlreadyInALink(str(self.id))
 
        self.__dict__[attr] = value

