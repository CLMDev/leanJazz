"""
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2011. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
"""

from deployer import http, utils, validators
from deployer.resources.commonattrs import CommonAttributes
from deployer.resources.relationships import RelatedResource, RelatedResourceCollection
from deployer.messages import message
from ipasrestresource import IPASRESTResourceCollection, IPASRESTResource
from ipgroup import IPGroups
from deployer.resources.restresource import RESTResource

@utils.classinit
class Cloud(IPASRESTResource):
    'IWD10014'

    @classmethod
    def _classinit(cls):
        
        cls._registerURI(r'\A/admin/resources/vdcs/(?P<id>[\da-f\-]+)\Z')
        cls._registerURI(r'\A/deployment/resources/vdcs/(?P<id>[\da-f\-]+)\Z')
        
        cls._defineRESTAttribute('id', 'RM09140', readonly=True)
        cls._defineRESTAttribute('name', 'RM09141', validator=validators.string)
        cls._defineRESTAttribute('description', 'RM09139', validator=validators.string)
        cls._defineRESTAttribute('type', 'IWD10004', values=['Dedicated', 'Average'])
        cls._defineRESTAttribute('colocation_policy', 'IWD10005', restname='colocation_policy', readonly=True, values=['Availability'])
        cls._defineRESTAttribute('state', 'RM09471')
        
        if utils.isSparta():
           cls._defineRESTAttribute('hosts', 'IWD32007', restname='vdc')
        
        cls._defineRESTAttribute('created_time', 'RM09128', readonly=True)
        cls._defineRESTAttribute('updated_time', 'RM09142',readonly=True)
        cls._defineRESTAttribute('url', 'IWD10033', restname='id', readonly=True)
        cls._defineAttribute('acl', 'IWD10038', readonly=True, readonlydoc=False, elided=True)
        #cls._defineRESTAttribute('is_highly_available', 'IWD00053', readonly=True)
        cls._defineRESTAttribute('mgmt_vlan_id', 'IWD10081',readonly=True, elided=True)
        cls._methodHelp('delete', 'waitFor')
        
    def _getMgmt_vlan_id(self):
        vlans = http.get("/deployment/resources/subnets/?management=T&vdc=%s" % self.id)
        if not vlans:
            return None
        return vlans[0].get('vlan_id')
    
    def delete(self):
        if utils.isSparta():
            raise NotImplementedError('delete')
        return super(Cloud, self).delete()

@utils.classinit
class Clouds(IPASRESTResourceCollection):
    'IWD10039'

    @classmethod
    def _classinit(cls):
        cls._contains(Cloud)
 
    @classmethod
    def _restname(cls):
        return 'vdcs'
    
    def _list(self, filter={}):
         if not filter.get('type'):
            filter['type'] = "~VirtualManagement"
         return super(Clouds, self)._list(filter)

    def _create(self, dict):
        temp = self.uri
        if dict.get('mgmt_vlan_id') is None:
            raise ValueError(utils.utos(message('RM09366', 'mgmt_vlan_id')))
        
        #validators.integerrange(1, 4093, dict.get('mgmt_vlan_id'), 'mgmt_vlan_id')
        
        self.uri += "?management_vlan_id=%s"% dict['mgmt_vlan_id']
        del dict['mgmt_vlan_id']
        
        try:
            result = super(Clouds, self)._create(dict, ['mgmt_vlan_id'])
            return result
        finally:
            self.uri = temp
            
    def _uriForResource(self, attrs):
        uuid = attrs['id'].split('/')[-1]
        return '/admin/resources/%s/%s' % (self._restname(), uuid)

    CREATE_ATTRIBUTES = [
        Cloud._wizardStep('name'),
        Cloud._wizardStep('description', optional=True),
        Cloud._wizardStep('type'),
        Cloud._wizardStep('colocation_policy', optional=True),
        Cloud._wizardStep('mgmt_vlan_id')
    ]
