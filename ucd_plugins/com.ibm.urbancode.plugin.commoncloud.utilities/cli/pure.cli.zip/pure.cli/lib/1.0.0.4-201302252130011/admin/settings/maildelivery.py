#
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2011. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
#
from deployer import http, utils

class MailDelivery(object):
    # TODO - message is useless
    '''RM09401'''

    _PROPERTYHELP_ = [ 'replytoaddress', 'smtpserver' ]

    MAIL_URI = '/admin/resources/configure_emails'
     
    
    def smtpserver_(self):
        '''RM09402'''
        pass
    
    def _getSmtp(self):
        mail =  http.get(self.MAIL_URI)
        if mail:
            return mail[0].get("mail_server")
        return None
    
    def _setSmtp(self, serverName):
        json = {"mail_server": utils.stou(serverName)}
        http.putJSON(self.MAIL_URI, json)
        
    def replytoaddress_(self):
        '''RM09403'''
        pass
    
    def _getReplyToAddress(self):
        mail =  http.get(self.MAIL_URI)
        if mail:
            return mail[0].get("reply_to_address")
        return None
    
    def _setReplyToAddress(self, address):
        json = {"reply_to_address": utils.stou(address)}
        http.putJSON(self.MAIL_URI, json)
    
    smtpserver = property(_getSmtp, _setSmtp)
    replytoaddress = property(_getReplyToAddress, _setReplyToAddress)
 
