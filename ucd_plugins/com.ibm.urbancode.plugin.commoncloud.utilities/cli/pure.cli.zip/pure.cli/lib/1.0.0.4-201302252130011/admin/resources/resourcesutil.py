"""
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2011. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
"""

from deployer.resources.commonattrs import CommonAttributes
from deployer import http, utils, validators
from deployer.resources.relationships import RelatedResource, RelatedResourceCollection
from deployer.resources.restresource import RESTResource

from deployer import http, logging, utils
from deployer.messages import message
from deployer.utils import utos
import re
import resource
from   restdict import RESTBackedDict
import urllib


@utils.classinit
class CommonResource(RelatedResource, CommonAttributes):
    'RM09111'

    @classmethod
    def _classinit(cls):
        cls._registerURI(r'\A/resources/users/(?P<id>\d+)\Z')

        cls._methodHelp('__contains__', '__delattr__', 'delete', '__eq__',
                        '__hash__', 'isStatusTransient', '__nonzero__',
                        'refresh', '__repr__', '__str__', '__unicode__',
                        'waitFor')

#provide common rest resources.
@utils.classinit
class CommonResources(RelatedResourceCollection):
    'RM09045'

    @classmethod
    def _classinit(cls):
        cls._methodHelp('__contains__', 'create', 'delete', '__delitem__',
                        '__getattr__', '__getitem__', '__iter__',
                        '__len__', 'list', '__lshift__', '__repr__',
                        '__rshift__', '__str__', '__unicode__',
                        'update', 'self')
    
    def _list(self, filt = {}):
        utf8filt = filt.copy()
        # logging.debug('UriBasedResourceCollection._list: %s' % str(utf8filt))

        for k in utf8filt:
            if isinstance(utf8filt[k], str) or isinstance(utf8filt[k], unicode):
                utf8filt[k] = utf8filt[k].encode('utf-8')

        # logging.debug(str(utf8filt))
        if filt:
            filt = '?' + urllib.urlencode(utf8filt)
        else:
            filt = ''

        return http.get('%s%s' % (self.uri, filt), _responseHandler )
    
    def _delete(self, id):
        'RM09053'
        http.delete('%s/%s' % (self.uri, id))
        
    def _get(self, id):
        return http.get('%s/%s' % (self.uri, id) )
    
    def update(self, data ):
        # <rescoll>.create({ ... })
        if isinstance(other, dict):
            return self._update(utils.stou(other))

        # <rescoll>.create([ ... ])
        elif isinstance(other, list):
            return [ self._update(o) for o in other ]

        # <rescoll>.create('<filename>')
        elif (isinstance(other, str) or isinstance(other, unicode)) and os.path.isfile(other):
            json = utils.readJSON(other)

            if (json):
                return self._update(json)

            return None

        # <rescoll>.create(deployer.wizard)
        elif inspect.isclass(other) and issubclass(other, wizard.Wizard):
            return self._update(other())

        # <rescoll>.create(<wizard>)
        elif isinstance(other, wizard.Wizard):
            try:
                return self._update(other(*self.__class__.CREATE_ATTRIBUTES))
            except EOFError, e:
                print e
                return None

        raise TypeError('unsupported operand type for create: %s' % type(other))

    def _update(self, d ):
        json = http.postJSON(self.uri, d)
        return RESTResource.resourceForURI(self._uriForResource(json))

# will implement later.
@utils.classinit
class ResourcesUtil(RelatedResourceCollection):
	'RM09045'
	
	@classmethod
	def _classinit(cls):
		cls._RES_URI_MAP_ ={}
		
	def __getattr__(self, name):
		'RM09018'

		if name.startswith('_') and name.endswith('_'):
			raise AttributeError(name)

		if name.endswith('s'):
			resourceURI = self.getResourceURI( name )
			return CommonResources( resourceURI )
		
	def getResourceURI( self, name ):
		return '/SystemResources/%s' % ( name )
        
# global function
from deployer.http import _decodeResponseBody,_parseJSON
def _responseHandler(resp):
        read = _decodeResponseBody(resp.read(), resp.getheader('Content-Type'))
        logging.debug('HTTP response: %d %s\n---------[body]---------\n%s\n\n' % (resp.status, resp.reason, utos(read.strip())))
    
        #if resp.getheader('Content-Type', '').find('json') >= 0:
        #    read = _parseJSON(read)
    
        if resp.status > 299:
            if isinstance(read, dict):
                raise IOError(utos(read.get('message', resp.reason)))
            else:
                raise IOError(utos(resp.reason))
    
        return read		