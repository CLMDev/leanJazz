"""
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2011. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
"""

from deployer.resources.commonattrs import CommonAttributes
from deployer import utils, http
from deployer.resources.relationships import RelatedResource, RelatedResourceCollection
from ipasrestresource import IPASRESTResourceCollection
from deployer.resources.restresource import RESTResource
from deployer.messages import message
from hardwarecomponent import HardwareComponent
from computenode import ComputeNode

@utils.classinit
class ManagementNode(HardwareComponent):
    'IWD12200'
        
    @classmethod
    def _classinit(cls):
        cls._registerURI(r'\A/admin/resources/management_nodes/(?P<id>[\da-z\-]+)\Z')
        
        cls._defineRESTAttribute('id', 'IWD11000', readonly=True)
        cls._defineRESTAttribute('name', 'IWD11001', readonly=True)
        cls._defineRESTAttribute('state', 'IWD11004', readonly=True)
        
        cls._defineRESTAttribute('architecture', 'IWD11002', readonly=True)
        cls._defineRESTAttribute('firmwarelevel', 'IWD11003', restname='firmware_level', readonly=True)
        cls._defineRESTAttribute('powerstate', 'IWD11005', restname='power_state', readonly=True)
        cls._defineRESTAttribute('machinetype', 'IWD11006', restname='machine_type', readonly=True)
        cls._defineRESTAttribute('numberofpowercycles', 'IWD11007', restname='number_of_power_cycles', readonly=True)
        
        #use another rest call to get this
        cls._defineRESTAttribute('energystats', 'IWD11008', restname='energy_stats', readonly=True, elided=True)
        cls._defineRESTAttribute('locations', 'IWD11010', readonly=True, elided=True)
        cls._defineRESTAttribute('healthstats', 'IWD11011', readonly=True, restname='health_stats', elided=True)
        cls._defineRESTAttribute('leds', 'IWD11012', readonly=True, elided=True)
        cls._defineRESTAttribute('physicalcpus', 'IWD12202', restname='physical_cpus', readonly=True, elided=True)
        cls._defineRESTAttribute('physicalmemory', 'IWD12203', restname='physical_memory', readonly=True, elided=True)
        cls._defineRESTAttribute('physicalioadapters', 'IWD12204', restname='physical_io_adapters', readonly=True, elided=True)
        
        cls._methodHelp('refresh','poweron','poweroff','quiesce','maintain','start')
        
    
    def _getPhysicalioadapters(self):
        return self._renderRESTResource('physical_io_adapters')
    
    def _getPhysicalmemory(self):
        return self._renderRESTResource('physical_memory')
        
    def _getPhysicalcpus(self):
        return self._renderRESTResource('physical_cpus')
    
    def poweron(self):
        'IWD12205'
        http.putJSON(self.uri, {'power_target_state': 'powered_on'})
    
    def poweroff(self):
        'IWD12206'
        http.putJSON(self.uri, {'power_target_state': 'powered_off'})
    
    def quiesce(self):
        'IWD12207'
        http.putJSON(self.uri, {'target_state': 'quiesced'})
    
    def maintain(self):
        'IWD12208'
        http.putJSON(self.uri, { 'target_state': 'maintenance'})
        
    def start(self):
        'IWD12209'
        http.putJSON(self.uri, { 'target_state': 'available'})
    
    @classmethod
    def _queryname(self):
        return 'compute_nodes'
    
@utils.classinit
class ManagementNodes(IPASRESTResourceCollection):
    'IWD12201'

    @classmethod
    def _classinit(cls):
        cls._contains(ComputeNode)
        cls._methodHelp('list')
    @classmethod    
    def _restname(cls):
        return 'management_nodes'

