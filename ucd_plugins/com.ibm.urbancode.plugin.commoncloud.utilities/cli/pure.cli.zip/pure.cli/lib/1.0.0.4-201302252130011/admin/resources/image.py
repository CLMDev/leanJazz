"""
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2011. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
"""

from deployer.resources.commonattrs import CommonAttributes
from deployer import utils, http
from deployer.resources.relationships import RelatedResource, RelatedResourceCollection
from ipasrestresource import IPASRESTResourceCollection, IPASRESTResource
from deployer.resources.restresource import RESTResource
from deployer.messages import message

@utils.classinit
class Image(IPASRESTResource):
    'Instance'
        
    @classmethod
    def _classinit(cls):
        cls._registerURI(r'\A/admin/resources/images/(?P<id>[\da-z\-]+)\Z')
        
        cls._defineRESTAttribute('id', '', readonly=True)
        cls._defineRESTAttribute('name', '', readonly=True)
        cls._defineRESTAttribute('url', 'IWD10033', restname='id', readonly=True)
        #use another rest call to get this
           
        
        cls._methodHelp('__contains__', '__delattr__', 'delete', '__eq__',
                        '__hash__', 'isStatusTransient', '__nonzero__',
                        'refresh', '__repr__', '__str__', '__unicode__',
                        'waitFor')