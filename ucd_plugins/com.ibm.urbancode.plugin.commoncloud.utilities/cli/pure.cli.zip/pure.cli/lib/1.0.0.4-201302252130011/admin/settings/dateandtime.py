#
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2011. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
#
from deployer import http, utils
from deployer.utils import stou
from server import _Servers

class DateAndTime(object):
    'RM10006'

    _PROPERTYHELP_ = [ 'ntpservers']
    
    _servers = None
           
    def ntpservers_(self):
        '''RM09377'''
        pass

    class _NTPServers(_Servers):
        def __init__(self):
            super(DateAndTime._NTPServers, self).__init__('NTP_SERVERS')

        def extend(self, serversToAdd, ignore_save=True):
            newServers = []
            for server in serversToAdd:
                if (0 == newServers.count(server)) and (0 == self.count(server)):
                    newServers.append(server)
            _Servers.extend(self, newServers)
 
    Servers = utils.MakeSingleton(_NTPServers)
        
    def _getNtpServers(self):
        if self._servers:
            self._servers.refresh()
        else:
            self._servers = DateAndTime.Servers()
        return self._servers
                
    ntpservers = property(_getNtpServers)
