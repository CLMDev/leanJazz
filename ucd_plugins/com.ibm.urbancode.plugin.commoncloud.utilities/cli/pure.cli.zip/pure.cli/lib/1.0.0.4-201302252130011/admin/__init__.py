'IWD10036'
"""
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2011. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
"""


import admin.resources
import admin.settings
import admin.troubleshooting
from deployer.utils import utos
import deployer.http
from deployer.messages import message

# If it's Sparta get Sparta help message for admin
if deployer.utils.isSparta():
    admin.__doc__='IWD32002'

if not deployer.utils.isSparta():
    virtualappliance = admin.resources.VirtualAppliance
    virtualappliances = admin.resources.VirtualAppliances()

# cloud resources
ipgroup = admin.resources.IPGroup
ipgroups = admin.resources.IPGroups()
ip = admin.resources.IP
ips = admin.resources.IPs
 
cloud = admin.resources.Cloud
clouds = admin.resources.Clouds()



# appliance stuff
user = admin.resources.User
users = admin.resources.Users()
group = admin.resources.Group
groups = admin.resources.Groups()

roles = admin.resources.Roles
 
#*===================================================================
# task 23344
#*===================================================================
event = admin.resources.Event
events = admin.resources.Events()
problem = admin.resources.Problem
problems = admin.resources.Problems()
advancedmanager=admin.resources.AdvancedManager
advancedmanagers=admin.resources.AdvancedManagers()
storagedevice = admin.resources.StorageDevice
storagedevices = admin.resources.StorageDevices()
volume = admin.resources.Volume
volumes = admin.resources.Volumes()
computenode = admin.resources.ComputeNode
computenodes = admin.resources.ComputeNodes()
managementnode = admin.resources.ManagementNode
managementnodes = admin.resources.ManagementNodes()

job = admin.resources.Job
jobs = admin.resources.Jobs()

if deployer.utils.isSparta():
    host = admin.resources.Host
    hosts = admin.resources.Hosts()
        
if not deployer.utils.isSparta():
   virtualmachine = admin.resources.VirtualMachine
   virtualmachines = admin.resources.VirtualMachines()
   virtualmachinegroup = admin.resources.VirtualMachineGroup
   virtualmachinegroups = admin.resources.VirtualMachineGroups()
   vmconfiguration=admin.resources.VMConfiguration
   vmconfigurations=admin.resources.VMConfigurations

volumeconfiguration=admin.resources.VolumeConfiguration
volumeconfigurations=admin.resources.VolumeConfigurations

ldap = admin.settings.ldap
dns = admin.settings.dns
dateandtime = admin.settings.dateandtime
snmp = admin.settings.snmp
mail = admin.settings.mail
trapdestination=admin.settings.trapdestination
trapdestinations=admin.settings.trapdestinations
maintenancereport=admin.settings.maintenancereport
ilmt = admin.settings.ilmt
licenseawareness = admin.settings.licenseawareness
# auditing
audit = admin.resources.Audit
audits = admin.resources.Audits()

# troubleshooting
led = admin.troubleshooting.LED
leds = admin.troubleshooting.LEDs()
vendor = admin.troubleshooting.Vendor
vendors = admin.troubleshooting.Vendors()
systemlog = admin.troubleshooting.SystemLog
systemlogs = admin.troubleshooting.SystemLogs()
tracesetting = admin.troubleshooting.TraceSetting
tracesettings = admin.troubleshooting.TraceSettings()
ceaccount = admin.troubleshooting.ceaccount

networkdevice = admin.resources.NetworkDevice
networkdevices = admin.resources.NetworkDevices()
vlan = admin.resources.VLAN
vlans = admin.resources.VLANs()

customernetwork = admin.settings.customernetwork
managementlan   = admin.settings.managementlan

fixpack = admin.resources.FixPack
fixpacks = admin.resources.FixPacks()

#credential = admin.resources.Credential
#credentials = admin.resources.Credentials()

# role constants
PATTERN_CREATOR_ROLE = 'PATTERN_CREATOR'
PROFILE_CREATOR_ROLE = 'PROFILE_CREATOR'
CATALOG_CREATOR_ROLE = 'CATALOG_CREATOR'
ILMT_USER_ROLE = 'ILMT_USER'
ROLE_ADMIN_ROLE = 'ROLE_ADMIN'
WORKLOAD_ADMIN_READONLY_ROLE = 'APPLIANCE_ADMIN_READONLY'
WORKLOAD_ADMIN_ROLE = 'APPLIANCE_ADMIN'
CLOUD_ADMIN_READONLY_ROLE = 'CLOUDGROUP_ADMIN_READONLY'
CLOUD_ADMIN_ROLE = 'CLOUDGROUP_ADMIN'
HARDWARE_READONLY_ROLE = 'HARDWARE_ADMIN_READONLY'
HARDWARE_ADMIN_ROLE = 'HARDWARE_ADMIN'
AUDIT_READONLY_ROLE = 'AUDIT_READONLY'
AUDIT_ROLE = 'AUDIT'
SECURITY_ADMIN_ROLE = 'SECURITY_ADMIN'
SECURITY_READONLY_ROLE = 'SECURITY_ADMIN_READONLY'
USER_ADMIN_READONLY_ROLE = 'USER_ADMIN_READONLY'

acl=admin.resources.ACL
NO_PERMISSIONS = admin.resources.ACL.NO_PERMISSIONS
READ_PERMISSION = admin.resources.ACL.READ_PERMISSION
UPDATE_PERMISSION = admin.resources.ACL.UPDATE_PERMISSION
CREATE_PERMISSION = admin.resources.ACL.CREATE_PERMISSION
DELETE_PERMISSION = admin.resources.ACL.DELETE_PERMISSION
ALL_PERMISSIONS = admin.resources.ACL.ALL_PERMISSIONS

# convenience method to get current user
_self = None

def self():
    'RM09006'

    global _self

    if not _self:
        _self = users.self()

    return _self

# convenience method to get Everyone group
_everyone = None

def everyone():
    'RM09007'

    global _everyone

    if not _everyone:
        _everyone = groups.everyone()

    return _everyone

# server version
class _FSMVersioner(object):
    'RM09011'

    def __repr__(self):
        return utos(unicode(self))


    def __unicode__(self):
        try:
            host = deployer.http.host
        except AttributeError:
            host = message('RM09133')

        try:
            version = deployer.versionClass.getFSMVersion()['version']
        except Exception, e:
            print e
            version = message('RM09134')

        return message('RM09135', host, version)

version = _FSMVersioner()