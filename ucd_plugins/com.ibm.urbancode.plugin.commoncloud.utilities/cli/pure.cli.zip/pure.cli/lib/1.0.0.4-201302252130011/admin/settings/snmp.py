from deployer import http,utils
from deployer.resources.restresource import RESTResource, RESTResourceCollection
from deployer.resources.localresource import LocalResource
from deployer.resources.resource import ResourceCollection
from deployer.resources.restdict import RESTBackedDict

@utils.classinit
class SNMP(RESTResource):
    'IWD12011'
    
    URI = '/admin/resources/global_config?global_config_type=SNMP'
    
    COMMUNITY = "SNMP_SUBSCRIBER_COMMUNITY"
    PORT = "SNMP_SUBSCRIBER_PORT"
    IPADDRESS = "SNMP_SUBSCRIBER_IP_ADDRESS"
    SEVERITY  = "SNMP_SUBSCRIBER_SEVERITY"
    VERSION  = "SNMP_SUBSCRIBER_VERSION"
    MIB_URI = "/ipas/mibs/ipasMibs.zip"
    OMNI_BUS_URI = "/ipas/mibs/ipasRulesNckl_2_0.zip"
    
    @classmethod
    def _classinit(cls):
        cls._defaultRESTAttrs(True)

        cls._defineRESTAttribute('system_name', 'IWD12003', restname='SNMP_SYSTEM_NAME')
        cls._defineRESTAttribute('system_contact', 'IWD12004', restname='SNMP_SYSTEM_CONTACT')
        cls._defineRESTAttribute('system_location', 'IWD12005', restname='SNMP_SYSTEM_LOCATION')
        cls._defineRESTAttribute('trapdestinations', 'IWD12012', elided=True)
        cls._methodHelp('getMIB', 'getOMNIBusRules')

    def __init__(self, uri=None, attrs=None):
        def munger(json):
            if json:
                config = json[0]
                self.uri = config.get('id')
                data = config.get('json', {})
                if isinstance(data, unicode) or isinstance(data, str):
                    data = http._parseJSON(data)
                return data
            else:
                return {}

        super(SNMP, self).__init__(self.URI, attrs, munge=munger)
        
    def _getTrapdestinations(self):
        self.refresh()
        return TrapDestinations(self._restattrs, self)
    
    def _update(self, key, value):
        self.refresh()
        currentConfig = self._restattrs.copy()
        currentConfig[key] = value
        json = {'json': currentConfig}
        http.putJSON(self.uri, json)
        
        super(RESTBackedDict, self._restattrs).update({key: value})
    
    def _updateTrapInformation(self, currentTraps):
       if self.uri == self.URI:
            self.refresh()
       d = {}

       if self.system_name:
           d['SNMP_SYSTEM_NAME'] = self.system_name
        
       if self.system_contact:
           d['SNMP_SYSTEM_CONTACT'] = self.system_contact
       
       if self.system_location:
           d['SNMP_SYSTEM_LOCATION'] = self.system_location
       
       for key, value in currentTraps.items():
           d[key] = value
        
       json = {'json': d}
       http.putJSON(self.uri, json)
           
                     
    def _setSystem_name(self, value):
        if value == None:
            return
        self._update('SNMP_SYSTEM_NAME', value)
        
    
    def _setSystem_contact(self, value):
        if value == None:
            return
        self._update('SNMP_SYSTEM_CONTACT', value)
        
        
    def _setSystem_location(self, value):
        if value == None:
            return
        self._update('SNMP_SYSTEM_LOCATION', value)
        
    def getMIB(self, f):
        'IWD10074'
        f = file(f, 'wb')
        try:
            http.get(self.MIB_URI, responseHandler=utils.curryFunction(utils.getResponseHandler, f))
        finally:
            f.close()
            
    def getOMNIBusRules(self, f):
        'IWD10075'
        f = file(f, 'wb')
        try:
            http.get(self.OMNI_BUS_URI, responseHandler=utils.curryFunction(utils.getResponseHandler, f))
        finally:
            f.close()
   
@utils.classinit
class TrapDestination(LocalResource):
    'IWD12001'
    @classmethod
    def _classinit(cls):
        cls._defineAttribute('community', 'IWD12008', readonly=True)
        cls._defineAttribute('port', 'IWD12007', readonly=True)
        cls._defineAttribute('ipaddress', 'IWD12006', readonly=True)
        cls._defineAttribute('version', 'IWD12009', values=('1', '2c'), readonly=True)
        cls._defineAttribute('severity', 'IWD12010', values=('Fatal', 'Critical', 'Major','Minor', 'Warning', 'Informational', 'Debug', 'Audit', 'Unknown'), readonly=True)
        cls._methodHelp('delete')

    def __init__(self, attrs, parent):
        super(TrapDestination, self).__init__(attrs)
        self.parent = parent
        
    def delete(self):
        'RM09053'
        newarray = []
        newarray.extend(self.parent.subscribers)
        newarray.remove(self)
        json = self.parent._Python2JSON(newarray)
        self.parent.snmp._updateTrapInformation(json)
        self.parent.subscribers.remove(self)

@utils.classinit
class TrapDestinations(RESTResourceCollection):
    'IWD12002'

    @classmethod
    def _classinit(cls):
        cls._methodHelp('create', 'list')

    CREATE_ATTRIBUTES = [
        TrapDestination._wizardStep('community'),
        TrapDestination._wizardStep('port', optional=True),
        TrapDestination._wizardStep('ipaddress'),
        TrapDestination._wizardStep('version', optional=True),
        TrapDestination._wizardStep('severity', optional=True)
    ]
    


    def __init__(self, attrs, snmp):
        array = self._JSON2Python(attrs)
        self.subscribers = [TrapDestination(json, self) for json in array]
        self.snmp = snmp
    
    def _JSON2Python(self, json):
        i = 1
        array = []
        while True:
           if not json.get('%s_%d' %(SNMP.IPADDRESS, i)):
              break
           o = { 
                 "community" : json.get('%s_%d' %(SNMP.COMMUNITY, i)),
                 "port": json.get('%s_%d' %(SNMP.PORT, i)),
                 "ipaddress": json.get('%s_%d' %(SNMP.IPADDRESS, i)),
                 "version": json.get('%s_%d' %(SNMP.VERSION, i)),
                 "severity": json.get('%s_%d' %(SNMP.SEVERITY, i))
                }
           array.append(o)
           i += 1
        return array
    
    def _Python2JSON(self, objs):
        i = 1
        obj = {}
        for o in objs:
            obj['%s_%d' %(SNMP.COMMUNITY, i)] = o.community
            obj['%s_%d' %(SNMP.IPADDRESS, i)] = o.ipaddress
            obj['%s_%d' %(SNMP.VERSION, i)] = o.version
            obj['%s_%d' %(SNMP.SEVERITY, i)] = o.severity
            obj['%s_%d' %(SNMP.PORT, i)] = o.port
            i += 1
        return obj

    def _list(self, filt = {}):
        result =  self.subscribers
        
        if filt.has_key('count'):
            del filt['count']
        
        if filt:
            def match(r, filt={}):
                for key in filt:
                    if getattr(r, key, None) == filt[key]:
                       return True
                return False
            result = utils.findAll(lambda r: match(r, filt), result)
            
        return result

    def _create(self, dict):
        self._checkCreateAttributes(dict)
        
        if not dict.has_key('port'):
            dict['port'] = 162
        if not dict.has_key('version'):
            dict['version'] = '1'
        if not dict.has_key('severity'):
            dict['severity'] = 'Minor'

        newarray = []
        newarray.extend(self.subscribers)
        newObj = TrapDestination(dict, self)
        newarray.append(newObj)
        json = self._Python2JSON(newarray)
        self.snmp._updateTrapInformation(json)
        self.subscribers.append(newObj)
        return newObj
 
         