"""
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2011. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
"""

from deployer.resources.commonattrs import CommonAttributes
from deployer import utils, http, validators
from deployer.resources.restresource import RESTResource
from deployer.messages import message
from admin.resources.ipasrestresource import IPASRESTResourceCollection, IPASRESTResource

import os

@utils.classinit
class SystemLog(IPASRESTResource):
    'IWD11222'
    
    @classmethod
    def _classinit(cls):
        cls._registerURI(r'\A/admin/resources/systemlogs/(?P<id>[\da-z\-]+)\Z')

        cls._methodHelp('delete', 'download')

        cls._defineRESTAttribute('id', 'IWD11000', readonly=True)
        cls._defineRESTAttribute('state', 'IWD11216', readonly=True)
        cls._defineRESTAttribute('created_time', 'IWD11217', readonly=True)
        cls._defineRESTAttribute('updated_time', 'IWD11218', readonly=True)
        cls._defineRESTAttribute('version', 'IWD11219', readonly=True)
        cls._defineRESTAttribute('collection_set', 'IWD11220', readonly=True)
        cls._defineRESTAttribute('packaged_log_url', 'IWD11221', readonly=True)

    def delete(self):
        'IWD11225'
        return http.delete('%s?synchronous' % (self.uri))

    def download(self, dir=None):
        'IWD11227'

        if self.state != 'available':
            return utils.utos(message('IWD11228'))

        doclose = False

        if dir != None and not os.path.isdir(dir):
            print message('IWD11265', dir)
            dir = ''

        if dir == None:
            dir = ''

        filename = dir + self.id
        
        if os.path.exists(filename + '.tgz'):
            x = 0
            while True:
                if not os.path.exists(filename + '.' + str(x) + '.tgz'):
                    break
                x += 1
            filename += '.' + str(x) + '.tgz'
        else:
            filename += '.tgz'

        print message('IWD11266', filename)
        f = file(filename, 'wb')

        doclose = True
        http.get(self.packaged_log_url, responseHandler=utils.curryFunction(utils.getResponseHandler, f))
        
        if doclose:
            f.close()

@utils.classinit
class SystemLogs(IPASRESTResourceCollection):
    'IWD11223'
    
    @classmethod
    def _classinit(cls):
        cls._contains(SystemLog)
        cls._methodHelp('create', 'get')

    def create(self, collection_set = 'management'):
        'IWD11224'

        valid_sets = ['management', 'deploy', 'system', 'complete', 'dumps']

        collection_set = collection_set.lower()
        
        if collection_set[:2] == "ip":
            validators.allipaddress(collection_set[3:], 'collection_set')
        elif (not collection_set in valid_sets) and (collection_set[:4] != "vios"):
            raise ValueError(utils.utos(message('IWD11238')))

        json = http.postJSON(self.uri, {'collection_set': collection_set})
        return RESTResource.resourceForURI(self._uriForResource(json), json)

    def get(self, id):
        'IWD11226'
        return self._list({'id': id})[0]
