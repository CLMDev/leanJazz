"""
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2011. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
"""

from deployer.resources.commonattrs import CommonAttributes
from deployer import utils, http, prettify, validators
from deployer.resources.relationships import RelatedResource, RelatedResourceCollection
from ipasrestresource import IPASRESTResourceCollection, IPASRESTResource
from deployer.resources.restresource import RESTResource
from deployer.messages import message
from ip import IPs, IP

from virtualappliance import VirtualAppliance
from cloud import Cloud
import ipasutils

@utils.classinit
class VirtualMachine(IPASRESTResource):
    'IWD11080'
        
    @classmethod
    def _classinit(cls):
        cls._registerURI(r'\A/admin/resources/instances/(?P<id>[\da-z\-]+)\Z')
        cls._registerURI(r'\A/deployment/resources/instances/(?P<id>[\da-z\-]+)\Z')
        
        cls._defineRESTAttribute('id', 'IWD11145', readonly=True)
        cls._defineRESTAttribute('name', 'IWD11146', readonly=True)
        cls._defineRESTAttribute('state', 'IWD11147')
        
        cls._defineRESTAttribute('description', 'IWD11081')
        cls._defineRESTAttribute('created_time', 'IWD11082',  readonly=True)
        cls._defineRESTAttribute('updated_time', 'IWD11083', readonly=True)
        cls._defineRESTAttribute('cpucount', 'IWD11084', restname='cpu_count', readonly=True)
        cls._defineRESTAttribute('memory', 'IWD11085', readonly=True)
        cls._defineRESTAttribute('physicalcpucount', 'IWD11086', restname='pcpu_count', readonly=True)
        
        #use another rest call to get this
        cls._defineRESTAttribute('cloud', 'IWD11148', restname='vdc', readonly=True)
        cls._defineRESTAttribute('computenode', 'IWD11149', restname='hypervisors', readonly=True, elided=True)   
        cls._defineRESTAttribute('cpustats', 'IWD11087', restname='virtual_cpus', readonly=True, elided=True)
        cls._defineRESTAttribute('memorystats', 'IWD11088', restname='virtual_memory', readonly=True, elided=True)
        cls._defineRESTAttribute('image', 'IWD11089', readonly=True, elided=True)
        cls._defineAttribute('acl', 'IWD10038', readonly=True, readonlydoc=False, elided=True)
        
        cls._defineRESTAttribute('vmconfiguration', 'IWD11192', readonly=True, elided=True)
        cls._defineRESTAttribute('ips', 'IWD11193', elided=True)
        cls._defineRESTAttribute('osvolumes', 'IWD11387', readonly=True, elided=True)
        cls._defineRESTAttribute('mountedvolumes', 'IWD11194', elided=True)
        cls._defineRESTAttribute('url', 'IWD10033', restname='id', readonly=True)
        cls._methodHelp('delete','isStatusTransient','refresh', 'waitFor','start','stop','restart', 'configure')
    
    class BaseClass(object):

        def __lshift__(self, other):
            'RM09116'
            self.__iadd__(other)


        def __repr__(self):
            'RM09119'
            return utils.utos(unicode(self))


        def __rshift__(self, other):
            'RM09117'
            self.__isub__(other)


        def __str__(self):
            'RM09118'
            return repr(self)


        def __unicode__(self):
            'RM09118'
            return prettify.prettify(list(self))
         
    class MountedVolumes(BaseClass):
        'IWD11191'
        
        def __len__(self):
            'RM09801'
            return len(self.volumes)
        
        def __getitem__(self, key):
            'RM09800'
            v = self.volumes[key]
            return {"volume": RESTResource.resourceForURI('/admin/resources/volumes/%s' % utils.uuid(v['uri'])), "mount_point": v['mount_point']}
        
        def __init__(self, instance):
            self.instance = instance
            instance = http.get(self.instance.uri)
            self.volumes = instance.get('volumes', [])
            
        def __iadd__(self, other):
            'IWD11189'
            instance = http.get(self.instance.uri)
            self.volumes = instance.get('volumes', [])
            volumes = utils.map( self.volumes, lambda x: {"uri": '/admin/resources/volumes/%s' % utils.uuid(x['uri'])})
            
            arg = other            
            if isinstance(other, dict):
               arg = [other]
            #arg = utils.map( arg, lambda x: {"uri": x['volume'].url, 'mount_point': x['mount_point']})
            #defect 50309, remove all input volumes' mount point
            arg = utils.map( arg, lambda x: {"uri": x['volume'].url})
            
            for volume in arg:
                volUUID = utils.uuid(volume['uri'])
                exist = utils.find(lambda x: utils.uuid(x['uri']) == volUUID, volumes)
                if exist:
                    pass
                   #exist["mount_point"] = volume["mount_point"]
                else:
                   volumes.append(volume)
            
            resp = http.putJSON(self.instance.uri, {"volumes": volumes})
            ipasutils.waitForJob(resp)
            return self
        
        def __isub__(self, other):
            'IWD11190'
            instance = http.get(self.instance.uri)
            self.volumes = instance.get('volumes', [])
            volumes = utils.map( self.volumes, lambda x: {"uri": '/admin/resources/volumes/%s' % utils.uuid(x['uri'])})
            
            arg = other            
            if isinstance(other, dict):
               arg = [other]
            arg = utils.map(arg, lambda x: {"uri": x['volume'].url})
            
            for idx, volume in enumerate(arg):
                volUUID = utils.uuid (volume['uri'])
                if utils.any(volumes, lambda x: utils.uuid (x['uri']) == volUUID):
                   del volumes[idx]
            resp = http.putJSON(self.instance.uri, {"volumes": volumes})
            ipasutils.waitForJob(resp)
            return self

        def __iter__(self):
            'RM09115'
            instance = http.get(self.instance.uri)
            self.volumes = instance.get('volumes', [])

            return iter([{"volume": RESTResource.resourceForURI('/admin/resources/volumes/%s' % utils.uuid(v['uri'])), "mount_point": v['mount_point']} for v in self.volumes])
            
    class Addresses(BaseClass):
        'IWD11193'
        
        def __len__(self):
            'RM09801'
            return len(self.addresses)
        
        def __getitem__(self, key):
            'RM09800'
            uuid = str(utils.uuid(self.addresses[key]))
            return RESTResource.resourceForURI('/deployment/resources/addresses/%s' % uuid)
        
        def __init__(self, instance):
            self.instance = instance
            instance = http.get(self.instance.uri)
            if instance.get('addresses') == None:
                self.addresses = []
            else:
                self.addresses = instance['addresses']
            
        def __iadd__(self, other):
            'IWD11186'
            instance = http.get(self.instance.uri)
            self.addresses = instance['addresses']
            addresses = self.addresses
            setaddresses = []
            
            for attached in addresses:
                setaddresses.append({"uri": attached})
            
            arg = other            
            if isinstance(other, IP):
               arg = [other]
            arg = utils.map( arg, lambda x: {"uri": x.url})
            for address in arg:
                addrUUID = utils.uuid(address['uri'])
                exist = utils.find(lambda x: utils.uuid(x) == addrUUID, addresses)
                if exist == None:
                   setaddresses.append({"uri":address['uri']})
            
            resp = http.putJSON(self.instance.uri, {"addresses": setaddresses})
            ipasutils.waitForJob(resp)
            return self
        
        def __isub__(self, other):
            'IWD11187'
            instance = http.get(self.instance.uri)
            self.addresses = instance['addresses']
            addresses = self.addresses
            putaddresses = []
            
            arg = other            
            if isinstance(other, IP):
               arg = [other]
            arg = utils.map(arg, lambda x: {"uri": x.url})
            
            for address in addresses:
                addrUUID = utils.uuid (address)
                if not utils.any(arg, lambda x: utils.uuid(x['uri']) == addrUUID):
                    putaddresses.append(address)
                    
            resp = http.putJSON(self.instance.uri, {"addresses": putaddresses})
            ipasutils.waitForJob(resp)
            return self

        def __iter__(self):
            'RM09115'
            instance = http.get(self.instance.uri)
            self.addresses = instance['addresses']
            return iter([RESTResource.resourceForURI('/deployment/resources/addresses/%s' % utils.uuid(v)) for v in self.addresses])
            
    def __init__(self, uri, attrs):
        super(VirtualMachine, self).__init__(uri, attrs)
        
    def _getMountedvolumes(self):
        if not hasattr(self, '_volumes'):
           self._volumes = self.__class__.MountedVolumes(self)
        return self._volumes
    
    def _setMountedvolumes(self, value):
       if value != self._volumes:
            raise AttributeError("can't set attribute")
        
    def _getIps(self):
        if not hasattr(self, '_addresses'):
            self._addresses = self.__class__.Addresses(self)
        return  self._addresses
    
    def _setIps(self, value):
       if value != self._addresses:
            raise AttributeError("can't set attribute")

    # other read only attributes
    def _getVmconfiguration(self):
        if self._restattrs.get('vm_configuration') and self._restattrs['vm_configuration'] != None:
            uuid = str(self._restattrs['vm_configuration']).split('/')[-1]
            uri = '%s/%s' % ('/admin/resources/vm_configurations', uuid)
            return RESTResource.resourceForURI(uri)
        else:
            return None
    
    def _getImage(self):
        if self._restattrs.has_key('image') and self._restattrs['image'] != None:
            uri = self._restattrs['image']
            return RESTResource.resourceForURI(uri)
        else:
            return None
    
    def _getOsvolumes(self):
        return self._renderRESTResourceCollection('disks');
    
    def _getMemorystats(self):
        if self._restattrs.has_key('virtual_memory') and len(self._restattrs['virtual_memory'])>0:
            uri = self._restattrs['virtual_memory'][0]
            return RESTResource.resourceForURI(uri)
        else:
            return None
    
    def _getCpustats(self):
        if self._restattrs.has_key('virtual_cpus') and len(self._restattrs['virtual_cpus'])>0:
            uri = self._restattrs['virtual_cpus'][0]
            return RESTResource.resourceForURI(uri)
        else:
            return None
    
    def _getComputenode(self):
        if self._restattrs.has_key('hypervisors') and self._restattrs['hypervisors'] != None:
            hyper = http.get(self._restattrs['hypervisors'])
            if hyper != None and hyper.get('compute_nodes') != None:
                return RESTResource.resourceForURI(hyper.get('compute_nodes'))
            else:
                return None
        else:
            return None
            
     
    def _getCloud(self):
        if self._restattrs.has_key('vdc') and self._restattrs['vdc'] != None:
            uuid = str(self._restattrs['vdc'] ).split('/')[-1]
            cloudid = '%s/%s' % ('/admin/resources/vdcs', uuid) 
            return RESTResource.resourceForURI(cloudid)
        else:
            return None
        
    
    # operations
    def configure(self, dict):
        'IWD12226'
        http.putJSON(self.uri, dict)
    
    def start(self):
        'IWD11090'
        self.state = 'start'
        self.refresh()
    
    def stop(self):
        'IWD11091'
        self.state = 'stop'
        self.refresh()
        
    def restart(self):
        'IWD11092'
        self.state = 'restart'
        self.refresh()
    
    #def capture(self, imagename):
    #    'IWD11093'
    #    if imagename == None:
    #        imagename = self.name
    #    url = str(self.uri) + '?_capturedImageName=' + imagename
    #    http.putJSON(url, {"state":"capture"})
    
    @classmethod
    def _queryname(self):
        return 'instances' 
    
@utils.classinit
class VirtualMachines(IPASRESTResourceCollection):
    'IWD11094'

    @classmethod
    def _classinit(cls):
        cls._contains(VirtualMachine)
        cls._methodHelp('delete', 'list', 'create')
    @classmethod    
    def _restname(cls):
        return 'instances'
    
    CREATE_ATTRIBUTES = [
        VirtualMachine._wizardStep('name'),
        VirtualMachine._wizardStep('image'),
        VirtualMachine._wizardStep('cloud'),
        VirtualMachine._wizardStep('vmconfiguration', optional=True)
    ]
    
    #todo: add credential support
    def create(self, dict):
        'IWD11195'
        
        data = {}
        
        validators.string(dict.get('name'), 'name')
        validators.instance(VirtualAppliance, dict.get('virtualappliance'), 'image')
        validators.instance(Cloud, dict.get('cloud'), 'vdc')
        
        data['name'] = dict['name']
        data['image'] = {'uri': dict['virtualappliance'].id}
        data['vdc'] = {'uri': dict['cloud'].id}
        
        if 'address' in dict:
            data['addresses'] = [{'uri':dict['address'].id}]
        
        if 'vmconfiguration' in dict:
            data['vm_configuration'] = {'uri': dict['vmconfiguration'].id}
            
        #customise settings:
        if 'cpu_count' in dict:
            data['cpu_count'] = dict['cpu_count']
        if 'pcpu_count' in dict:
            data['pcpu_count'] = dict['pcpu_count']
        if 'memory' in dict:
            data['memory'] = dict['memory']
            
        if 'options' in dict:
            data['options'] = dict['options']
        else:
            data['options'] = []
        
        data['credentials'] = []
        if 'credentials' in dict:
            creds = dict['credentials']
            for cred in creds:
                data['credentials'].append({"uri":cred.id})
        
        resp =  http.postJSON('/deployment/resources/instances', data)
        return RESTResource.resourceForURI(resp['id'], resp)


#######################################
# internal classes for virtual machine
#######################################

@utils.classinit    
class _VirtualCPU(RelatedResource, CommonAttributes):
    ''
        
    @classmethod
    def _classinit(cls):
        cls._registerURI(r'\A/admin/resources/virtual_cpus/(?P<id>[\da-z\-]+)\Z')
        
        cls._defineRESTAttribute('id', 'IWD11150', readonly=True)
        cls._defineRESTAttribute('name', 'IWD11151', readonly=True)
        cls._defineRESTAttribute('state', 'IWD11152', readonly=True)
        
        cls._defineRESTAttribute('cappedmode', 'IWD11095', restname='capped_mode', readonly=True)
        cls._defineRESTAttribute('cpuioutilization', 'IWD11096', restname='cpu_io_utilization', readonly=True)
        cls._defineRESTAttribute('cpusysutilization', 'IWD11097', restname='cpu_sys_utilization', readonly=True)
        cls._defineRESTAttribute('cpuuserutilization', 'IWD11098', restname='cpu_user_utilization', readonly=True)
        cls._defineRESTAttribute('cpuutilization', 'IWD11153', restname='cpu_utilization', readonly=True)
        cls._defineRESTAttribute('cpuutilizationunits', 'IWD11064', restname='cpu_utilization_units', readonly=True)
        cls._defineRESTAttribute('cpuwaitutilization', 'IWD11099', restname='cpu_wait_utilization', readonly=True)
        cls._defineRESTAttribute('created_time', 'IWD11155', readonly=True)
        cls._defineRESTAttribute('donating', 'IWD11100', readonly=True)
        cls._defineRESTAttribute('entitledcpu', 'IWD11101', restname='entitled_cpu', readonly=True)
        cls._defineRESTAttribute('estimateddemand', 'IWD11384', restname='estimated_demand', readonly=True)
        cls._defineRESTAttribute('maxcpuutilization', 'IWD11154', restname='max_cpu_utilization', readonly=True)
        cls._defineRESTAttribute('maxphysicalcpu', 'IWD11102', restname='max_physical_cpu', readonly=True)
        cls._defineRESTAttribute('maxvirtualcpu', 'IWD11103', restname='max_virtual_cpu', readonly=True)
        cls._defineRESTAttribute('minphysicalcpu', 'IWD11104', restname='min_physical_cpu', readonly=True)
        cls._defineRESTAttribute('minvirtualcpu', 'IWD11105', restname='min_virtual_cpu', readonly=True)
        cls._defineRESTAttribute('physicalcpuunitsused', 'IWD11106', restname='physical_cpu_units_used', readonly=True)
        cls._defineRESTAttribute('sharedmode', 'IWD11107', restname='shared_mode', readonly=True)
        cls._defineRESTAttribute('updated_time', 'IWD11156', readonly=True)
        cls._defineRESTAttribute('virtualcpu', 'IWD11157', restname='virtual_cpu', readonly=True)

@utils.classinit    
class _VirtualMemory(RelatedResource, CommonAttributes):
    '_VirtualMemory'
        
    @classmethod
    def _classinit(cls):
        cls._registerURI(r'\A/admin/resources/virtual_memory/(?P<id>[\da-z\-]+)\Z')
        
        cls._defineRESTAttribute('id', 'IWD11158', readonly=True)
        cls._defineRESTAttribute('name', 'IWD11159', readonly=True)
        cls._defineRESTAttribute('state', 'IWD11160', readonly=True)
        
        cls._defineRESTAttribute('max_total', 'IWD11108', restname='max_total', readonly=True)
        cls._defineRESTAttribute('min_total', 'IWD11109', restname='min_total', readonly=True)
        cls._defineRESTAttribute('swap_total', 'IWD11110', restname='swap_total', readonly=True)
        cls._defineRESTAttribute('swap_used', 'IWD11111', restname='swap_used', readonly=True)
        cls._defineRESTAttribute('total', 'IWD11075', readonly=True)
        cls._defineRESTAttribute('units', 'IWD11073', readonly=True)
        cls._defineRESTAttribute('used', 'IWD11076', readonly=True)

@utils.classinit    
class _MountedVolume(RelatedResource, CommonAttributes):
    '_VirtualMemory'
        
    @classmethod
    def _classinit(cls):
        cls._registerURI(r'\A/admin/resources/mounted_volumes/(?P<id>[\da-z\-]+)\Z')
        
        cls._defineRESTAttribute('id', 'IWD11158', readonly=True)
        #cls._defineRESTAttribute('mountpoint', 'IWD11159', restname='mount_point', readonly=True)
        cls._defineRESTAttribute('state', 'IWD11160', readonly=True)
        cls._defineRESTAttribute('volume', 'IWD11108', readonly=True)
        
    def _getVolume(self):
        if self._restattrs.has_key('volume') and self._restattrs['volume'] != None:
            return RESTResource.resourceForURI(self._restattrs['volume'])
        else:
            return None    
      