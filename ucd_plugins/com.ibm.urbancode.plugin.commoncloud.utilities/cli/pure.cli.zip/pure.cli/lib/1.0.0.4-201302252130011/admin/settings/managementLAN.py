#
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2012. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
#

from deployer import http
from deployer.messages import message

from customerPort import customerPort
from customerLink import customerLink
from customerVLANRange import customerVLANRange


class managementLAN(object):
    'IWD12251'

    _MANAGEMENT_LAN_REST_URI = "/admin/resources/global_config?global_config_type=Networking"

    FIXED_PORT_ID = 64
    
    _VALID_BOOLEANS = [ True, 'true', False, 'false' ]

    _METHODHELP_   = [ 'load', 'save' ]
                     
    _PROPERTYHELP_ = [ 'portID', 'portTypeA', 'portTypeB', 'portSpeedA', 'portSpeedB', \
                       'aggregatePort', 'flowControlMode', 'aggregationMethod', \
                       'vlanMode', 'vlanID', 'configIPV4', 'ipv4Address', 'ipv4Hostname', 'ipv4Domain', \
                       'ipv4PrimaryAddress', 'ipv4SecondaryAddress', 'ipv4Netmask', 'ipv4Gateway', \
                       'configIPV6', 'ipv6AutoConfig', 'ipv6Address', 'ipv6PrimaryAddress', \
                       'ipv6SecondaryAddress', 'ipv6Gateway', 'ipv6PrefixLen' \
                     ]


    @classmethod
    def _raiseValueErrorBecauseAttrCannotChange(cls, attrName):
        msgKey0CannotBeChanged = 'IWD12274'
        msg = message(msgKey0CannotBeChanged, cls.__name__ + '.' + attrName)
        raise ValueError(msg)


    @classmethod
    def _raiseValueErrorBecauseAttrCannotBeSetTo(cls, attrName, value):
        msgKey0IsNotValidFor1 = 'IWD12275'
        msg = message(msgKey0IsNotValidFor1, value, cls.__name__ + '.' + attrName)
        raise ValueError(msg)


    def _setJSONProps(self, jsonProps):
        self.portTypeA  = jsonProps['MANAGE_LAN_SWITCH_A_PORT_64_TYPE']
        self.portTypeB  = jsonProps['MANAGE_LAN_SWITCH_B_PORT_64_TYPE']
        self.portSpeedA = jsonProps['MANAGE_LAN_SWITCH_A_PORT_64_GB']
        self.portSpeedB = jsonProps['MANAGE_LAN_SWITCH_B_PORT_64_GB']

        self._aggregatePort    = jsonProps['MANAGE_LAN_AGGREGATE_PORT_64']
        self.flowControlMode   = jsonProps['MANAGE_LAN_AGGREGATE_FLOW_CONTROL_MODE']
        self.aggregationMethod = jsonProps['MANAGE_LAN_AGGREGATE_TRUNK_METHOD']
        self.vlanMode          = jsonProps['MANAGE_LAN_AGGREGATE_VLAN_MODE']
        self.vlanID            = customerVLANRange._getVLANFromStr(jsonProps['MANAGE_LAN_VLAN'])
        
        self.configIPV4   = jsonProps['MANAGE_LAN_CONFIG_IPV4']      
        self.ipv4Address  = jsonProps['MANAGE_LAN_IPV4_ADDRESS']
        self.ipv4Hostname = jsonProps['MANAGE_LAN_IPV4_SHORT_NAME']
        self.ipv4Domain   = jsonProps['MANAGE_LAN_IPV4_DOMAIN_NAME']
        self.ipv4PrimaryAddress   = jsonProps['MANAGE_LAN_IPV4_PRIMARY_ADDRESS']
        self.ipv4SecondaryAddress = jsonProps['MANAGE_LAN_IPV4_SECONDARY_ADDRESS']
        self.ipv4Netmask  = jsonProps['MANAGE_LAN_IPV4_SUBNET_MASK']
        self.ipv4Gateway  = jsonProps['MANAGE_LAN_IPV4_DEFAULT_GATEWAY']

        self.configIPV6     = jsonProps['MANAGE_LAN_CONFIG_IPV6']
        self.ipv6AutoConfig = jsonProps['MANAGE_LAN_IPV6_AUTO_CONFIG']
        self.ipv6Address    = jsonProps['MANAGE_LAN_IPV6_ADDRESS']
        self.ipv6PrimaryAddress   = jsonProps['MANAGE_LAN_IPV6_PRIMARY_ADDRESS'] 
        self.ipv6SecondaryAddress = jsonProps['MANAGE_LAN_IPV6_SECONDARY_ADDRESS']
        self.ipv6Gateway          = jsonProps['MANAGE_LAN_IPV6_DEFAULT_GATEWAY']
        self.ipv6PrefixLen  = jsonProps['MANAGE_LAN_IPV6_PREFIX_LENGTH']
         
        self._ntpServers = jsonProps['NTP_SERVERS']
        self._dnsServers = jsonProps['DNS_SERVERS']
        
         
    def _getJSONProps(self):
        jsonProps = dict([])
        
        jsonProps['MANAGE_LAN_SWITCH_A_PORT_64_TYPE'] = self.portTypeA
        jsonProps['MANAGE_LAN_SWITCH_B_PORT_64_TYPE'] = self.portTypeB
        jsonProps['MANAGE_LAN_SWITCH_A_PORT_64_GB']   = self.portSpeedA
        jsonProps['MANAGE_LAN_SWITCH_B_PORT_64_GB']   = self.portSpeedB

        jsonProps['MANAGE_LAN_AGGREGATE_PORT_64']           = self._aggregatePort
        jsonProps['MANAGE_LAN_AGGREGATE_FLOW_CONTROL_MODE'] = self.flowControlMode
        jsonProps['MANAGE_LAN_AGGREGATE_TRUNK_METHOD']      = self.aggregationMethod
        jsonProps['MANAGE_LAN_AGGREGATE_VLAN_MODE']         = self.vlanMode     
        jsonProps['MANAGE_LAN_VLAN']                        = str(self.vlanID)

        jsonProps['MANAGE_LAN_CONFIG_IPV4']      = self.configIPV4        
        jsonProps['MANAGE_LAN_IPV4_ADDRESS']     = self.ipv4Address
        jsonProps['MANAGE_LAN_IPV4_SHORT_NAME']  = self.ipv4Hostname
        jsonProps['MANAGE_LAN_IPV4_DOMAIN_NAME'] = self.ipv4Domain
        jsonProps['MANAGE_LAN_IPV4_PRIMARY_ADDRESS']   = self.ipv4PrimaryAddress
        jsonProps['MANAGE_LAN_IPV4_SECONDARY_ADDRESS'] = self.ipv4SecondaryAddress
        jsonProps['MANAGE_LAN_IPV4_SUBNET_MASK']       = self.ipv4Netmask
        jsonProps['MANAGE_LAN_IPV4_DEFAULT_GATEWAY']   = self.ipv4Gateway

        jsonProps['MANAGE_LAN_CONFIG_IPV6']      = self.configIPV6
        jsonProps['MANAGE_LAN_IPV6_AUTO_CONFIG'] = self.ipv6AutoConfig
        jsonProps['MANAGE_LAN_IPV6_ADDRESS']     = self.ipv6Address
        jsonProps['MANAGE_LAN_IPV6_PRIMARY_ADDRESS']   = self.ipv6PrimaryAddress
        jsonProps['MANAGE_LAN_IPV6_SECONDARY_ADDRESS'] = self.ipv6SecondaryAddress
        jsonProps['MANAGE_LAN_IPV6_DEFAULT_GATEWAY']   = self.ipv6Gateway
        jsonProps['MANAGE_LAN_IPV6_PREFIX_LENGTH']     = self.ipv6PrefixLen
      
        jsonProps['NTP_SERVERS'] = self._ntpServers
        jsonProps['DNS_SERVERS'] = self._dnsServers
        
        return jsonProps


    def _isValidIPV4AddrStr(self, value):
        if not isinstance(value, str) and not isinstance(value, unicode):
            return False
        if ('' == value):
            return True
        octets = value.split('.')
        if (len(octets) != 4):
            return False
        for octet in octets:
            try:
                b = int(octet)
                if (b < 0) or (b > 255):
                    return False
            except ValueError:
                return False
        return True 


    def _isValidIPV6AddrStr(self, value):
        if not isinstance(value, str) and not isinstance(value, unicode):
            return False
        if ('' == value):
            return True
        groups = value.split(':')
        if (len(groups) == 0) or (len(groups) > 8):
            return False
        for group in groups:
            if ('' != group):
                try:
                    h = int(group, 16)
                    if (h < 0) or (h > 65535):
                        return False
                except ValueError:
                    return False


    def _isValidIPV6PrefixLen(self, value):
        return True 
        if not isinstance(value, str) and not isinstance(value, unicode):
            return False
        try:
            x = int(value)
        except ValueError:
            return False
        return True       

           
    def _reset(self):
    
        self.__dict__['portID'] = managementLAN.FIXED_PORT_ID
            
        self.portTypeA  = customerPort.TYPE_UNKNOWN
        self.portTypeB  = customerPort.TYPE_UNKNOWN
        self.portSpeedA = customerPort.SPEED_UNKNOWN
        self.portSpeedB = customerPort.SPEED_UNKNOWN
        
        self._aggregatePort = 'false'
        self.flowControlMode   = customerLink.FLOW_CONTROL_MODE_DISABLED
        self.aggregationMethod = customerLink.AGGREGATION_METHOD_UNKNOWN
        self.vlanMode          = customerLink.VLAN_MODE_UNKNOWN

        self.__dict__['vlanID'] = None
        
        self.configIPV4 = 'false'       
        self.ipv4Address  = ''
        self.ipv4Hostname = ''
        self.ipv4Domain   = ''
        self.ipv4PrimaryAddress   = ''
        self.ipv4SecondaryAddress = ''
        self.ipv4Netmask  = ''
        self.ipv4Gateway  = ''

        self.configIPV6     = 'false'
        self.ipv6AutoConfig = 'false'
        self.ipv6Address  = ''
        self.ipv6PrimaryAddress   = ''
        self.ipv6SecondaryAddress = ''
        self.ipv6Gateway = ''
        self.ipv6PrefixLen = '0'
      
        self._dnsServers = ''
        self._ntpServers = ''


    def __init__(self):
        self._reset()       
       
        
    def __setattr__(self, attr, value):
        if (attr == 'portID') and hasattr(self, attr):
            managementLAN._raiseValueErrorBecauseAttrCannotChange(attr)

        if (attr == 'portTypeA') and (value not in customerPort.VALID_TYPES):
            managementLAN._raiseValueErrorBecauseAttrCannotBeSetTo(attr, value)
        if (attr == 'portTypeB') and (value not in customerPort.VALID_TYPES):
            managementLAN._raiseValueErrorBecauseAttrCannotBeSetTo(attr, value)

        if (attr == 'portSpeedA') and (value not in customerPort.VALID_SPEEDS):
            managementLAN._raiseValueErrorBecauseAttrCannotBeSetTo(attr, value)
        if (attr == 'portSpeedB') and (value not in customerPort.VALID_SPEEDS):
            managementLAN._raiseValueErrorBecauseAttrCannotBeSetTo(attr, value)

        if (attr == '_aggregatePort') and (value not in managementLAN._VALID_BOOLEANS):
            managementLAN._raiseValueErrorBecauseAttrCannotBeSetTo(attr, value)
        if (attr == 'flowControlMode') and (value not in customerLink.VALID_FLOW_CONTROL_MODES):
            managementLAN._raiseValueErrorBecauseAttrCannotBeSetTo(attr, value)
        if (attr == 'aggregationMethod') and (value not in customerLink.VALID_AGGREGATION_METHODS):
            managementLAN._raiseValueErrorBecauseAttrCannotBeSetTo(attr, value)
        if (attr == 'vlanMode') and (value not in customerLink.VALID_VLAN_MODES):
            managementLAN._raiseValueErrorBecauseAttrCannotBeSetTo(attr, value)
            
        if (attr == 'vlanID') and hasattr(self, attr):
            idValue = customerVLANRange._getVLANFromStr(str(value))
            if (None == idValue):
                 managementLAN._raiseValueErrorBecauseAttrCannotBeSetTo(attr, value)

        if (attr == 'configIPV4') and (value not in managementLAN._VALID_BOOLEANS):
            managementLAN._raiseValueErrorBecauseAttrCannotBeSetTo(attr, value)
            
        if (attr == 'ipv4Address') and not self._isValidIPV4AddrStr(value):
            managementLAN._raiseValueErrorBecauseAttrCannotBeSetTo(attr, value)
        if (attr == 'ipv4PrimaryAddress') and not self._isValidIPV4AddrStr(value):
            managementLAN._raiseValueErrorBecauseAttrCannotBeSetTo(attr, value)
        if (attr == 'ipv4SecondaryAddress') and not self._isValidIPV4AddrStr(value):
            managementLAN._raiseValueErrorBecauseAttrCannotBeSetTo(attr, value)
        if (attr == 'ipv4Netmask') and not self._isValidIPV4AddrStr(value):
            managementLAN._raiseValueErrorBecauseAttrCannotBeSetTo(attr, value)            
        if (attr == 'ipv4Gateway') and not self._isValidIPV4AddrStr(value):
            managementLAN._raiseValueErrorBecauseAttrCannotBeSetTo(attr, value)            

        if (attr == 'configIPV6') and (value not in managementLAN._VALID_BOOLEANS):
            managementLAN._raiseValueErrorBecauseAttrCannotBeSetTo(attr, value)
        if (attr == 'ipv6AutoConfig') and (value not in managementLAN._VALID_BOOLEANS):
            managementLAN._raiseValueErrorBecauseAttrCannotBeSetTo(attr, value)
        if (attr == 'ipv6Address') and not self._isValidIPV6AddrStr(value):
            managementLAN._raiseValueErrorBecauseAttrCannotBeSetTo(attr, value)
        if (attr == 'ipv6PrimaryAddress') and not self._isValidIPV6AddrStr(value):
            managementLAN._raiseValueErrorBecauseAttrCannotBeSetTo(attr, value)
        if (attr == 'ipv6SecondaryAddress') and not self._isValidIPV6AddrStr(value):
            managementLAN._raiseValueErrorBecauseAttrCannotBeSetTo(attr, value)
        if (attr == 'ipv6Gateway') and not self._isValidIPV6AddrStr(value):
            managementLAN._raiseValueErrorBecauseAttrCannotBeSetTo(attr, value)
        if (attr == 'ipv6PrefixLen') and not self._isValidIPV6PrefixLen(value):
            managementLAN._raiseValueErrorBecauseAttrCannotBeSetTo(attr, value)
                       
     
        self.__dict__[attr] = value        
 
      
    def load(self):
        reply = http.get(managementLAN._MANAGEMENT_LAN_REST_URI)
        if (0 != len(reply)):
            jsonString = reply[0]['json']
            jsonProps = http._parseJSON(jsonString)
            self._setJSONProps(jsonProps)


    def save(self):
        print message('IWD12283')
        jsonProps = self._getJSONProps();
        reply = http.putJSON(managementLAN._MANAGEMENT_LAN_REST_URI, jsonProps)
        
    def apply(self):
        self.save()
        
        
      