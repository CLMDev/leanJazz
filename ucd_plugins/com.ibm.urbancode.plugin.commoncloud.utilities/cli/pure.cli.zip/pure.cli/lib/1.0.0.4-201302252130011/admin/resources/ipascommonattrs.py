from datetime import datetime,time

from deployer.messages import localize as localize
from deployer.resources.restresource import RESTResource
import java.util
import java.text
import ipasacl

ipasDateFormat = java.text.SimpleDateFormat("EEE dd MMM yyyy HH:mm:ss.SSS z", java.util.Locale.ENGLISH)
dateFormatter  = java.text.DateFormat.getDateTimeInstance()

class IPASCommonAttributes(RESTResource):
    
    def _getAcl(self):
        try:
            return self._acl
        except AttributeError:
            self._acl = ipasacl.ACL(self)
            return self._acl
    
    def _getId(self):
        return self._restattrs['id'].split('/')[-1]
    
    def _getCreated_time(self):
        timeStr = self._restattrs['created_time']
        return self._parseDatetimeString(timeStr)

    def _getUpdated_time(self):
        timeStr = self._restattrs['updated_time']
        return self._parseDatetimeString(timeStr)
        

    def _parseDatetimeString(self, timeStr):
        if timeStr == None:
            return None
        try:    
            date = ipasDateFormat.parse(timeStr)
        except java.text.ParseException:
            try:
                date = java.util.Date(timeStr)
            except:
                pass
        
        try: 
            return dateFormatter.format(date)
        except:
            return timeStr
     
        