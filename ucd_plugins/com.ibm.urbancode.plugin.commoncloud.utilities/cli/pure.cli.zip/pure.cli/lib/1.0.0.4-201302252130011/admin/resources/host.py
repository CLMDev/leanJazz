"""
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2011. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
"""

from deployer.resources.commonattrs import CommonAttributes
from deployer import utils, http, prettify
from deployer.resources.relationships import RelatedResource
from ipasrestresource import IPASRESTResourceCollection, IPASRESTResource
from deployer.messages import message 
from deployer.resources.restresource import RESTResource

from virtualappliance import VirtualAppliance
from cloud import Cloud
import ipasutils


@utils.classinit
class Host(IPASRESTResource):
    'IWD32003'

    @classmethod
    def _classinit(cls):
        cls._registerURI(r'\A/admin/resources/instances/(?P<id>[\da-z\-]+)\Z')
        cls._defineRESTAttribute('id', 'IWD11145', readonly=True)
        cls._defineRESTAttribute('name', 'IWD11146', readonly=True)
        cls._defineRESTAttribute('state', 'IWD11147')

        cls._defineRESTAttribute('description', 'IWD32016')
        cls._defineRESTAttribute('created_time', 'IWD32017',  readonly=True)
        cls._defineRESTAttribute('updated_time', 'IWD32018', readonly=True)
        cls._defineRESTAttribute('cpucount', 'IWD32019', restname='cpu_count', readonly=True)
        cls._defineRESTAttribute('memory', 'IWD32020', readonly=True)
        cls._defineRESTAttribute('physicalcpucount', 'IWD32021', restname='pcpu_count', readonly=True)
        
        #use another rest call to get this
        cls._defineRESTAttribute('cloud', 'IWD32008', restname='vdc', readonly=True)
        cls._defineRESTAttribute('computenode', 'IWD32015', restname='hypervisors', readonly=True, elided=True)   
        cls._defineRESTAttribute('cpustats', 'IWD32014', restname='virtual_cpus', readonly=True, elided=True)
        cls._defineRESTAttribute('memorystats', 'IWD32013', restname='virtual_memory', readonly=True, elided=True)
        cls._defineRESTAttribute('image', 'IWD32012', readonly=True, elided=True)
        cls._defineAttribute('acl', 'IWD10038', readonly=True, readonlydoc=False, elided=True)
        #cls._defineAttribute('ip', 'RM09331', readonly=True, elided=True)
        cls._defineRESTAttribute('ips', 'IWD32011', elided=True)
        cls._defineRESTAttribute('osvolumes', 'IWD32010', readonly=True, elided=True)
        cls._defineRESTAttribute('mountedvolumes', 'IWD32009', elided=True)
        cls._defineRESTAttribute('url', 'IWD10033', restname='id', readonly=True)

        cls._methodHelp('start','stop','restart', 'list')
        
    class BaseClass(object):
        def __lshift__(self, other):
            'RM09116'
            self.__iadd__(other)


        def __repr__(self):
            'RM09119'
            return utils.utos(unicode(self))


        def __rshift__(self, other):
            'RM09117'
            self.__isub__(other)


        def __str__(self):
            'RM09118'
            return repr(self)


        def __unicode__(self):
            'RM09118'
            return prettify.prettify(list(self))
         



    class MountedVolumes(BaseClass):
        'IWD11191'
        
        def __len__(self):
            'RM09801'
            return len(self.volumes)
        
        def __getitem__(self, key):
            'RM09800'
            v = self.volumes[key]
            return {"volume": RESTResource.resourceForURI('/admin/resources/volumes/%s' % utils.uuid(v['uri'])), "mount_point": v['mount_point']}
        
        def __init__(self, instance):
            self.instance = instance
            
        def __iadd__(self, other):
            'IWD11189'
            instance = http.get(self.instance.uri)
            self.volumes = instance.get('volumes', [])
            volumes = utils.map( self.volumes, lambda x: {"uri": '/admin/resources/volumes/%s' % utils.uuid(x['uri'])})
            
            arg = other            
            if isinstance(other, dict):
               arg = [other]
            #arg = utils.map( arg, lambda x: {"uri": x['volume'].url, 'mount_point': x['mount_point']})
            #defect 50309, remove all input volumes' mount point
            arg = utils.map( arg, lambda x: {"uri": x['volume'].url})
            
            for volume in arg:
                volUUID = utils.uuid(volume['uri'])
                exist = utils.find(lambda x: utils.uuid(x['uri']) == volUUID, volumes)
                if exist:
                    pass
                   #exist["mount_point"] = volume["mount_point"]
                else:
                   volumes.append(volume)
            
            resp = http.putJSON(self.instance.uri, {"volumes": volumes})
            ipasutils.waitForJob(resp)
            return self
        
        def __isub__(self, other):
            'IWD11190'
            instance = http.get(self.instance.uri)
            self.volumes = instance.get('volumes', [])
            volumes = utils.map( self.volumes, lambda x: {"uri": '/admin/resources/volumes/%s' % utils.uuid(x['uri'])})
            
            arg = other            
            if isinstance(other, dict):
               arg = [other]
            arg = utils.map(arg, lambda x: {"uri": x['volume'].url})
            
            for idx, volume in enumerate(arg):
                volUUID = utils.uuid (volume['uri'])
                if utils.any(volumes, lambda x: utils.uuid (x['uri']) == volUUID):
                   del volumes[idx]
            resp = http.putJSON(self.instance.uri, {"volumes": volumes})
            ipasutils.waitForJob(resp)
            return self

        def __iter__(self):
            'RM09115'
            instance = http.get(self.instance.uri)
            self.volumes = instance.get('volumes', [])

            return iter([{"volume": RESTResource.resourceForURI('/admin/resources/volumes/%s' % utils.uuid(v['uri'])), "mount_point": v['mount_point']} for v in self.volumes])
            

    class Addresses(BaseClass):
        'IWD11193'
        def __len__(self):
            'RM09801'
            return len(self.addresses)
        
        def __getitem__(self, key):
            'RM09800'
            uuid = str(utils.uuid(self.addresses[key]))
            return RESTResource.resourceForURI('/deployment/resources/addresses/%s' % uuid)
                

        def __init__(self, instance):
            self.instance = instance

        def __iadd__(self, other):
            'IWD11186'
            self.instance = RESTResource.resourceForURI('/admin/resources/instances/%s' % utils.uuid(self.instance.uri))
            self.addresses = self.instance._restattrs.get('addresses', [])
            addresses = self.addresses
            setaddresses = []
            
            for attached in addresses:
                setaddresses.append({"uri": attached})
            
            arg = other            
            if isinstance(other, IP):
               arg = [other]
            arg = utils.map( arg, lambda x: {"uri": x.url})
            for address in arg:
                addrUUID = utils.uuid(address['uri'])
                exist = utils.find(lambda x: utils.uuid(x) == addrUUID, addresses)
                if exist == None:
                   setaddresses.append({"uri":address['uri']})
            
            resp = http.putJSON(self.instance.uri, {"addresses": setaddresses})
            ipasutils.waitForJob(resp)
            return self
       
        def __isub__(self, other):
            'IWD11187'
            self.instance = RESTResource.resourceForURI('/admin/resources/instances/%s' % utils.uuid(self.instance.uri))
            self.addresses = self.instance._restattrs.get('addresses', [])
            addresses = self.addresses
            
            arg = other            
            if isinstance(other, IP):
               arg = [other]
            arg = utils.map(arg, lambda x: {"uri": x.url})
            for idx, address in enumerate(arg):
                addrUUID = utils.uuid (address['uri'])
                if utils.any(addresses, lambda x: utils.uuid(x) == addrUUID):
                   del addresses[idx]
            resp = http.putJSON(self.instance.uri, {"addresses": addresses})
            ipasutils.waitForJob(resp)
            return self
            
        def __iter__(self):
            'RM09115'
            self.instance = RESTResource.resourceForURI('/admin/resources/instances/%s' % utils.uuid(self.instance.uri))
            self.addresses = self.instance._restattrs.get('addresses', [])
            return iter([RESTResource.resourceForURI('/deployment/resources/addresses/%s' % utils.uuid(v)) for v in self.addresses])

    def __init__(self, uri, attrs):
        super(Host, self).__init__(uri, attrs)
        self._volumes = self.__class__.MountedVolumes(self)
        self._addresses = self.__class__.Addresses(self)

    def _getMountedvolumes(self):
        return self._volumes
    
    def _setMountedvolumes(self, value):
       if value != self._volumes:
            raise AttributeError("can't set attribute")
        
    def _getIps(self):
        return  self._addresses
    
    def _setIps(self, value):
       if value != self._addresses:
            raise AttributeError("can't set attribute")

    # other read only attributes
    def _getVmconfiguration(self):
        if self._restattrs.get('vm_configuration') and self._restattrs['vm_configuration'] != None:
            uuid = str(self._restattrs['vm_configuration']).split('/')[-1]
            uri = '%s/%s' % ('/admin/resources/vm_configurations', uuid)
            return RESTResource.resourceForURI(uri)
        else:
            return None
    
    def _getImage(self):
        if self._restattrs.has_key('image') and self._restattrs['image'] != None:
            uri = self._restattrs['image']
            return RESTResource.resourceForURI(uri)
        else:
            return None
    
    def _getOsvolumes(self):
        return self._renderRESTResourceCollection('disks');
    
    def _getMemorystats(self):
        if self._restattrs.has_key('virtual_memory') and len(self._restattrs['virtual_memory'])>0:
            uri = self._restattrs['virtual_memory'][0]
            return RESTResource.resourceForURI(uri)
        else:
            return None
    
    def _getCpustats(self):
        if self._restattrs.has_key('virtual_cpus') and len(self._restattrs['virtual_cpus'])>0:
            uri = self._restattrs['virtual_cpus'][0]
            return RESTResource.resourceForURI(uri)
        else:
            return None
    
    def _getComputenode(self):
        if self._restattrs.has_key('hypervisors') and self._restattrs['hypervisors'] != None:
            hyper = http.get(self._restattrs['hypervisors'])
            if hyper != None and hyper.get('compute_nodes') != None:
                return RESTResource.resourceForURI(hyper.get('compute_nodes'))
            else:
                return None
        else:
            return None
            
     
    def _getCloud(self):
        if self._restattrs.has_key('vdc') and self._restattrs['vdc'] != None:
            uuid = str(self._restattrs['vdc'] ).split('/')[-1]
            cloudid = '%s/%s' % ('/admin/resources/vdcs', uuid) 
            return RESTResource.resourceForURI(cloudid)
        else:
            return None
        
    # operations
    def configure(self, dict):
        'IWD12226'
        http.putJSON(self.uri, dict)

    def start(self):
        'IWD32004'
        self.state = 'start'
        self.refresh()

    def stop(self):
        'IWD32005'
        self.state = 'stop'
        self.refresh()

    def restart(self):
        'IWD32006'
        self.state = 'restart'
        self.refresh()

@utils.classinit
class Hosts(IPASRESTResourceCollection):
    'IWD32003'

    @classmethod
    def _classinit(cls):
        cls._contains(Host)
        cls._methodHelp('start','stop','restart')

    @classmethod    
    def _restname(cls):
       return 'instances'

    CREATE_ATTRIBUTES = [
        Host._wizardStep('name'),
        Host._wizardStep('image'),
        Host._wizardStep('cloud')
    ]


@utils.classinit    
class _MountedVolume(RelatedResource, CommonAttributes):
    '_VirtualMemory'
        
    @classmethod
    def _classinit(cls):
        cls._registerURI(r'\A/admin/resources/mounted_volumes/(?P<id>[\da-z\-]+)\Z')
        
        cls._defineRESTAttribute('id', 'IWD11158', readonly=True)
        #cls._defineRESTAttribute('mountpoint', 'IWD11159', restname='mount_point', readonly=True)
        cls._defineRESTAttribute('state', 'IWD11160', readonly=True)
        cls._defineRESTAttribute('volume', 'IWD11108', readonly=True)