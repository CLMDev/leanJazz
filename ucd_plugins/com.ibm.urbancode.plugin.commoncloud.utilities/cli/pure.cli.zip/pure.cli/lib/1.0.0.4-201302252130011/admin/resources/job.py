"""
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2011. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
"""

from deployer.resources.commonattrs import CommonAttributes
from deployer import utils
from deployer.resources.relationships import RelatedResource
from ipasrestresource import IPASRESTResourceCollection, IPASRESTResource

@utils.classinit
class Job(IPASRESTResource):
    'IWD11234'

    @classmethod
    def _classinit(cls):
        cls._registerURI(r'\A/admin/resources/jobs/(?P<id>[\da-z\-]+)\Z')
        cls._registerURI(r'\A/deployment/resources/jobs/(?P<id>[\da-z\-]+)\Z')

        cls._defineRESTAttribute('name', 'IWD11172', readonly=True)
        cls._defineRESTAttribute('state', 'IWD11173', readonly=True)
        cls._defineRESTAttribute('type', 'IWD11174', readonly=True)
        cls._defineRESTAttribute('created_time', 'IWD11175', readonly=True)
        cls._defineRESTAttribute('updated_time', 'IWD11176', readonly=True)
        cls._defineRESTAttribute('url', 'IWD10033', restname='id', readonly=True)
        cls._defineRESTAttribute('message', 'IWD10079', readonly=True, defaultToNone=True)

        cls._methodHelp('delete', 'waitFor')
        
    #called by waitFor
    #started is not final status for job
    def isStatusTransient(self):
        finalStates = [
             'successful',
             'failed',
             'stoppped'
         ]
        return not self.state in finalStates  

@utils.classinit
class Jobs(IPASRESTResourceCollection):
    'IWD11231'

    @classmethod
    def _classinit(cls):
        cls._contains(Job)
        cls._methodHelp('list')
    @classmethod    
    def _restname(cls):
        return 'jobs'
