"""
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2011. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
"""

from deployer import utils, validators, http
from deployer.resources.commonattrs import CommonAttributes
from deployer.resources.relationships import RelatedResource, RelatedResourceCollection
from ipasrestresource import IPASRESTResourceCollection,IPASRESTResource
from deployer.resources.restresource import RESTResource

@utils.classinit
class NetworkDevice(IPASRESTResource):
    'IWD11363'
        
    @classmethod
    def _classinit(cls):
        cls._registerURI(r'\A/admin/resources/switches/(?P<id>[\da-z\-]+)\Z')
        
        cls._defineRESTAttribute('id', 'IWD11000', readonly=True)
        cls._defineRESTAttribute('label_text', 'IWD11187', readonly=True)
        cls._defineRESTAttribute('state', 'IWD11190', readonly=True)
        
        cls._defineRESTAttribute('switch_type', 'IWD11196', readonly=True)
        cls._defineRESTAttribute('locations', 'IWD11010', readonly=True, elided=True)
        cls._defineRESTAttribute('firmwarelevel', 'IWD11003', restname='firmware_level', readonly=True)
        cls._defineRESTAttribute('softwareversion', 'IWD11366', restname='software_version', readonly=True)
        cls._defineRESTAttribute('switchmodel', 'IWD11365', restname='switch_model', readonly=True)
        cls._defineRESTAttribute('temperaturestats', 'IWD11314', readonly=True, elided=True)
        cls._defineRESTAttribute('switchports', 'IWD11367', readonly=True, elided=True)

        
        cls._methodHelp('__contains__', '__delattr__', 'delete', '__eq__',
                        '__hash__', 'isStatusTransient', '__nonzero__',
                        'refresh', '__repr__', '__str__', '__unicode__')
        
    def _getSwitchports(self):
        return self._renderRESTResourceCollection('switch_ports');
    
    def _getTemperaturestats(self):
        return self._renderRESTResourceCollection('temperature_stats');
    
    def _getLocations(self):
        if self._restattrs.has_key('locations') and len(self._restattrs['locations'])>0:
            locationURI = self._restattrs['locations'][0]
            location = http.get(locationURI)
            result = None;
            if location != None:
                result = str(location.get('physical_location', '')) + ' ' + str(location.get('label_text',''))
            return result
        else:
            return None
    
    @classmethod
    def _queryname(self):
        return 'switches'

@utils.classinit
class NetworkDevices(IPASRESTResourceCollection):
    'IWD11364'

    @classmethod
    def _classinit(cls):
        cls._contains(NetworkDevice)
        cls._methodHelp('__contains__', '__delitem__',
                        '__getattr__', '__getitem__', '__iter__',
                        '__len__', 'list', '__lshift__', '__repr__',
                        '__rshift__', '__str__', '__unicode__')
    @classmethod    
    def _restname(cls):
        return 'switches'

@utils.classinit    
class _SwitchPort(RelatedResource, CommonAttributes):
    'IWD11367'
        
    @classmethod
    def _classinit(cls):
        cls._registerURI(r'\A/admin/resources/switch_ports/(?P<id>[\da-z\-]+)\Z')
        
        cls._defineRESTAttribute('id', 'IWD11121', readonly=True)
        cls._defineRESTAttribute('name', 'IWD11122', readonly=True)
        cls._defineRESTAttribute('state', 'IWD11123', readonly=True)
        cls._defineRESTAttribute('linkstate', 'IWD11051', restname='link_state', readonly=True)
        cls._defineRESTAttribute('mac', 'IWD11052', restname='mac_address', readonly=True)
        cls._defineRESTAttribute('portnumber', 'IWD11053', restname='port_number', readonly=True)
        cls._defineRESTAttribute('speed', 'IWD11054', readonly=True)
        cls._defineRESTAttribute('wwpn', 'IWD11056', readonly=True)
