"""
#*=================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2011. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
"""

from deployer import http, utils, validators
from deployer.resources.commonattrs import CommonAttributes
from deployer import utils
from deployer.resources.relationships import RelatedResource
from ipasrestresource import IPASRESTResourceCollection, IPASRESTResource
from role import Roles

@utils.classinit
class User(IPASRESTResource):
    'RM09111'


    @classmethod
    def _classinit(cls):
        cls._registerURI(r'\A/admin/resources/users/(?P<id>[\da-z\-]+)\Z')        
        cls._defineRESTAttribute('id', 'IWD11182', readonly=True)
        cls._defineRESTAttribute('name', 'IWD11183', restname='name', validator=validators.string)
        cls._defineRESTAttribute('email', 'IWD11184', validator=validators.string)
        cls._defineRESTAttribute('url', 'IWD10033', restname='id', readonly=True)
        cls._defineRESTAttribute('roles', Roles.__doc__, validator=validators.noop, elided=True)
        cls._defineRESTAttribute('created_time', 'IWD11185', readonly=True)
        cls._defineRESTAttribute('auth_mode', 'IWD11229', readonly=True)        
        cls._defineRESTAttribute('user_id', 'IWD11300', validator=validators.string)
        cls._defineRESTAttribute('password', 'RM09259', writeonly=True, validator=validators.string)
        cls._defineRESTAttribute('current_status', 'IWD11303', validator=validators.string)
        
       
        # name -> fullname

        cls._methodHelp('__contains__', '__delattr__', 'delete', '__eq__',
                        '__hash__', 'isStatusTransient', '__nonzero__',
                        'refresh', '__repr__', '__str__', '__unicode__',
                        'waitFor')
        
    def __init__(self, uri, attrs):
        super(User, self).__init__(uri, attrs)
        self._roles = Roles(self)
        self.role_list = []
        
    def _getRoles(self):
        return self._roles


    def _setRoles(self, value):
        if value != self._roles:
            raise AttributeError("can't set attribute")       

  


@utils.classinit
class Users(IPASRESTResourceCollection):
    'RM09045'

    @classmethod
    def _classinit(cls):
        cls._contains(User)
        cls._methodHelp('__contains__', 'create', 'delete', '__delitem__',
                        '__getattr__', '__getitem__', '__iter__',
                        '__len__', 'list', '__lshift__', '__repr__',
                        '__rshift__', '__str__', '__unicode__',
                        'admin', 'self')

    CREATE_ATTRIBUTES = [
        User._wizardStep('name'),
        User._wizardStep('email'),
        User._wizardStep('auth_mode', optional=True),
        User._wizardStep('user_id'),
        User._wizardStep('password', optional=True, password=True)
    ]


    def _create(self, dict):
        return super(Users, self)._create(dict)
                                                                
    #def _list(self, filt = {}):
        #filt['resolvechildren'] = 2
        #return super(Users, self)._list(filt)
        
    def _list(self, filter={}):
     filter['is_internal'] = "F"
     return super(Users, self)._list(filter)
 
    def _getDefaultSearchField(self):
        return 'user_id'


    def self(self):
        'RM09046'
        currentUserName = http.userid
        json = http.get('%s/?user_id=%s' %(self.uri, currentUserName))
        if isinstance(json, list):
            json = json[0]
                      
        return IPASRESTResource.resourceForURI(json['id'], json)


 