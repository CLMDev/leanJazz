"""
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2011. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
"""

from deployer.resources.commonattrs import CommonAttributes
from deployer import utils, http
from deployer.resources.restresource import RESTResource
from deployer.messages import message
from admin.resources.ipasrestresource import IPASRESTResourceCollection, IPASRESTResource

@utils.classinit
class LED(IPASRESTResource):
    'IWD11258'
    
    @classmethod
    def _classinit(cls):
        cls._registerURI(r'\A/admin/resources/leds/(?P<id>[\da-z\-]+)\Z')
        
        cls._defineRESTAttribute('id', 'IWD11125', readonly=True)
        cls._defineRESTAttribute('name', 'IWD11126', readonly=True)
        cls._defineRESTAttribute('state', 'IWD11127', readonly=True)

        cls._defineRESTAttribute('severity', 'IWD11057', readonly=True)
        cls._defineRESTAttribute('power_state', 'IWD11058', readonly=True)
        cls._defineRESTAttribute('url', 'IWD10033', restname='id', readonly=True)

@utils.classinit
class LEDs(IPASRESTResourceCollection):
    'IWD11259'
    
    @classmethod
    def _classinit(cls):
        cls._contains(LED)
        cls._methodHelp('list', 'get')


    def get(self, name):
        'IWD11260'
        return self._list({'name': name})
