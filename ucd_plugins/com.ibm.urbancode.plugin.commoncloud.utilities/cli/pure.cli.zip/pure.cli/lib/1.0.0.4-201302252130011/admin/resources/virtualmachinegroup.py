"""
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2011. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
"""

from deployer.resources.commonattrs import CommonAttributes
from deployer import utils, http
from deployer.resources.relationships import RelatedResource, RelatedResourceCollection
from ipasrestresource import IPASRESTResourceCollection, IPASRESTResource
from deployer.resources.restresource import RESTResource


@utils.classinit
class VirtualMachineGroup(IPASRESTResource):
    'IWD11112'

    @classmethod
    def _classinit(cls):
        cls._registerURI(r'\A/deployment/resources/groups/(?P<id>[\da-z\-]+)\Z')

        cls._defineRESTAttribute('id', 'IWD11161', readonly=True)
        cls._defineRESTAttribute('name', 'IWD11162', readonly=True)
        cls._defineRESTAttribute('state', 'IWD11163', readonly=True)
        
        cls._defineRESTAttribute('description', 'IWD11164', readonly=True)
        cls._defineRESTAttribute('created_time', 'IWD11165', readonly=True)
        cls._defineRESTAttribute('updated_time', 'IWD11166',  readonly=True)
        cls._defineRESTAttribute('url', 'IWD10033', restname='id', readonly=True)
        cls._defineRESTAttribute('members', 'IWD11114', readonly=True, elided=True)

        cls._defineAttribute('acl', 'IWD10038', readonly=True, readonlydoc=False)
        
        cls._methodHelp()

    def _getMembers(self):
        resp = http.get('%s?resolvechildren=1&resolvechildrenlist=members' % self.uri)
        members = []
        for r in resp.get('members', []):
            if r.get('resource_type') == 'instances':
                members.append(r)
            elif r.get('resource_type') == 'groups':
                members.extend(r.get('members', []))
        
        return [RESTResource.resourceForURI(json['id'], json) for json in members]

@utils.classinit
class VirtualMachineGroups(IPASRESTResourceCollection):
    'IWD11113'

    @classmethod
    def _classinit(cls):
        cls._contains(VirtualMachineGroup)
        cls._methodHelp('list')
    @classmethod    
    def _restname(cls):
        return 'groups'
    
    @classmethod
    def _restPrefix(cls):
        return "/deployment"