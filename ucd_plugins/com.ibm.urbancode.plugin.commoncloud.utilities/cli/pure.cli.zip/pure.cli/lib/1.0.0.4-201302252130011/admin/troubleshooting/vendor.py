"""
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2011. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
"""

from deployer.resources.commonattrs import CommonAttributes
from deployer import utils, http
from deployer.resources.restresource import RESTResource
from deployer.messages import message
from admin.resources.ipasrestresource import IPASRESTResourceCollection, IPASRESTResource

@utils.classinit
class Vendor(IPASRESTResource):
    'IWD11209'
    
    @classmethod
    def _classinit(cls):
        cls._registerURI(r'\A/admin/resources/vendor_informations/(?P<id>[\da-z\-]+)\Z')
        
        cls._defineRESTAttribute('id', 'IWD11200', readonly=True)
        cls._defineRESTAttribute('name', 'IWD11201', readonly=True)
        cls._defineRESTAttribute('serial', 'IWD11202', readonly=True)
        cls._defineRESTAttribute('state', 'IWD11203', readonly=True)
        cls._defineRESTAttribute('type', 'IWD11204', readonly=True)
        cls._defineRESTAttribute('created_time', 'IWD11205', readonly=True)
        cls._defineRESTAttribute('updated_time', 'IWD11206', readonly=True)
        cls._defineRESTAttribute('vendor', 'IWD11207', readonly=True)
        cls._defineRESTAttribute('version', 'IWD11208', readonly=True)

    @classmethod
    def _restname(cls):
        return 'vendor_information'

@utils.classinit
class Vendors(IPASRESTResourceCollection):
    'IWD11210'
    
    @classmethod
    def _classinit(cls):
        cls._contains(Vendor)
        cls._methodHelp('__contains__', 'getByVendor', 'getBySerial', '__delitem__',
                        '__getattr__', '__getitem__', '__iter__',
                        '__len__', 'list', '__lshift__', '__repr__',
                        '__rshift__', '__str__', '__unicode__')

    @classmethod
    def _restname(cls):
        return 'vendor_informations'

    def getByVendor(self, vendor):
        'IWD11211'
        return self._list({'vendor': vendor})

    def getBySerial(self, serial):
        'IWD11212'
        return self._list({'serial': serial})
