"""
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2011. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
"""

from deployer import http, utils, validators
from deployer.resources.commonattrs import CommonAttributes
from deployer.resources.relationships import RelatedResource, RelatedResourceCollection
from deployer.messages import message
from ipasrestresource import IPASRESTResourceCollection, IPASRESTResource
from ipgroup import IPGroups
from deployer.resources.restresource import RESTResource

@utils.classinit
class VLAN(IPASRESTResource):
    'IWD10043'

    @classmethod
    def _classinit(cls):
        cls._registerURI(r'\A/admin/resources/networks/(?P<id>[\da-f\-]+)\Z')
        cls._defineRESTAttribute('name', 'IWD11001', readonly=True)
        cls._defineRESTAttribute('vlanid', 'IWD10046', readonly=True)
        cls._defineRESTAttribute('isCustomerVlan', '', readonly=True, defaultToNone=True)
      #  cls._defineRESTAttribute('created_time', 'IWD10044', readonly=True)
      #  cls._defineRESTAttribute('updated_time', 'IWD10045',readonly=True)
    



@utils.classinit
class VLANs(IPASRESTResourceCollection):
    'IWD10042'

    @classmethod
    def _classinit(cls):
        cls._contains(VLAN)
        cls._methodHelp('list')
 
    @classmethod
    def _restname(cls):
        return 'networks'
    
    def _list(self, filter={}):
        
         filter['type'] = "vlan"
         filter = '?' + utils.objectToQuery(filter)
         
         customerVlans = [r["vlanid"] for r in http.get('/admin/resources/customer_vlans') if r["vlanid"] != None]
         
         result = []
         for x in http.get('%s%s' % (self.uri, filter)):
             if x['vlanid'] in customerVlans:
                 x['isCustomerVlan'] = True
             else:
                 x['isCustomerVlan'] = False
             result.append(x)
        
         return [ RESTResource.resourceForURI(self._uriForResource(json), json) for json in result ]
        
    def _uriForResource(self, attrs):
        return attrs['id']
