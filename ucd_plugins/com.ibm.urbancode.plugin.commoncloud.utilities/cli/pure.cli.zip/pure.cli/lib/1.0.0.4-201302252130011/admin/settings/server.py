from deployer import http,utils

class _Servers(list):
    
    URI = '/admin/resources/global_config?global_config_type=Networking'
    
    def __init__(self, serverKey):
        self.serverKey = serverKey
        self._initList()

          
    def _initList(self):
        while self:
            self.pop(ignore_save=True)
        if not self:
           networkConfigs = http.get(self.URI)
           #config = [{'json':{'NTP_SERVERS':''}}]
           if  not networkConfigs:
               return
           config = networkConfigs[0]
           self.uri = config.get('id')
                 
           json = config['json']
           if isinstance(json, str) or isinstance(json, unicode):
               json = http._parseJSON(config['json'])
               servers = json.get(self.serverKey,'').split(',')
               self.extend(utils.utos(servers), ignore_save=True)
          
    
    def refresh(self):
        self._initList()

    def addSave(func):
        def newfunc(self, *args, **kw):
            temp = self[:]
            func(temp, *args)
            if not kw.get('ignore_save'):
                  self.save(temp)
            #data is refreshed only when the request is processed successfully
            func(self, *args)
        return newfunc
        
    def save(self, temp):
        json = {"json": { }}
        json["json"][self.serverKey] = ",".join(temp)
        http.putJSON(self.uri, json)
            
    append = addSave(list.append)
    extend = addSave(list.extend)
    insert = addSave(list.insert)
    pop = addSave(list.pop)
    remove = addSave(list.remove)
    reverse = addSave(list.reverse)
    sort = addSave(list.sort)
    __setslice__ = addSave(list.__setslice__)
    __delslice__ = addSave(list.__delslice__)
    __setitem__ = addSave(list.__setitem__)
    __delitem__ = addSave(list.__delitem__)