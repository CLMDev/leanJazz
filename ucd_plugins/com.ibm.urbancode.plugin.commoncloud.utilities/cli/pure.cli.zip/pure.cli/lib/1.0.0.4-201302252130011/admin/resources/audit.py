"""
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2011. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
"""

from deployer.resources.commonattrs import CommonAttributes
from deployer import utils, http, validators
from deployer.resources.restresource import RESTResource
from deployer.messages import message
from admin.resources.ipasrestresource import IPASRESTResourceCollection, IPASRESTResource

import os

@utils.classinit
class Audit(IPASRESTResource):
    'IWD11248'
    
    @classmethod
    def _classinit(cls):
        cls._registerURI(r'\A/audit/resources/recordpackages/(?P<id>[\da-z\-]+)\Z')
        
        cls._methodHelp('download')
        
        cls._defineRESTAttribute('id', 'IWD11240', readonly=True)
        cls._defineRESTAttribute('state', 'IWD11241', readonly=True)
        cls._defineRESTAttribute('created_time', 'IWD11242', readonly=True)
        cls._defineRESTAttribute('filesize', '', readonly=True)
        cls._defineRESTAttribute('timezone', 'IWD11246', readonly=True)
        cls._defineRESTAttribute('packaged_log_url', 'IWD11247', readonly=True)

    @classmethod
    def _restname(cls):
        return 'recordpackage'
    
    # override
    def _getCreated_time(self):
        return self._restattrs['created_time']

    def download(self, dir=None):
        'IWD11250'

        if self.state != 'available':
            return utils.utos(message('IWD11251'))

        doclose = False

        if dir != None and not os.path.isdir(dir):
            print message('IWD11265', dir)
            dir = ''

        if dir == None:
            dir = ''

        filename = dir + self.packaged_log_url[self.packaged_log_url.rfind('/') + 1:]
        
        print message('IWD11266', filename)
        f = file(filename, 'wb')

        doclose = True
        http.get("/audit/resources/recordpackages/" + self.id + "?download", responseHandler=utils.curryFunction(utils.getResponseHandler, f))
        
        if doclose:
            f.close()

@utils.classinit
class Audits(IPASRESTResourceCollection):
    'IWD11249'
    
    @classmethod
    def _classinit(cls):
        cls._contains(Audit)
        cls._methodHelp('create', 'get', 'getConfig', 'setConfig', 'getKey', 'getUtilization')

    @classmethod
    def _restPrefix(cls):
        return "/audit"

    @classmethod
    def _restname(cls):
        return 'recordpackages'

    def create(self, param = {}, suppressCheck=[]):
        'IWD11252'
        
        if 'start_time' in param and 'end_time' in param and param['start_time'] > param['end_time']:
            return utils.utos(message('IWD11262'))
            
        self._checkCreateAttributes(param, suppressCheck)
        json = http.postJSON(self.uri, param)
        return RESTResource.resourceForURI(self._uriForResource(json), json)

    def get(self, id):
        'IWD11253'
        return self._list({'id': id})[0]
        
    def getConfig(self):
        'IWD11254'
        
        configs = http.get('/audit/resources/audit_config')
        
        if configs:
            return utils.utos(configs[0])
        
    def deleteConfig(self, id = ''):
        if len(id) == 0:
            id = self.getConfig()['id']
            id = id[id.rindex('/') + 1:]
        utils.utos(http.delete('/audit/resources/audit_config/' + id))
        return utils.utos(message('IWD11263'))

    def setConfig(self, setting, pingtest = False):
        'IWD11255'
        # CLI relies on REST interface regarding parameter validation check
        suffix = '?ping' if pingtest else ''

        return utils.utos(http.postJSON('/audit/resources/audit_config' + suffix, setting))

    def testConfigConnection(self, setting, pingtest = False):
        'IWD11267'
        # CLI relies on REST interface regarding parameter validation check
        suffix = '&ping' if pingtest else ''

        return utils.utos(http.postJSON('/audit/resources/audit_config?connectiontest' + suffix, setting))

    def getKey(self):
        'IWD11256'
        return utils.utos(http.get('/audit/resources/audit_config?audit_public_key'))

    def getUtilization(self):
        'IWD11257'
        return http.get('/audit/resources/records?utilization') / 100.0
