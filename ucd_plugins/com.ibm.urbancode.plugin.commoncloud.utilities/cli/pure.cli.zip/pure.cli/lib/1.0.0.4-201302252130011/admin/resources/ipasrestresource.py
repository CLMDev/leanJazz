#
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2011. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
#

from deployer.resources.relationships import RelatedResourceCollection, RelatedResource
from ipascommonattrs import IPASCommonAttributes
from deployer.resources.resource import ResourceCollection
from deployer.resources.restresource import RESTResource, RESTResourceCollection

from deployer import http, utils
import sys

class IPASRESTResourceCollection(RelatedResourceCollection):
    
    @classmethod
    def _restPrefix(cls):
        return "/admin"
    
    def _uriForResource(self, attrs):
        '''Given a set of attributes returned from the server, return the
        URI of the corresponding resource from this collection.
        '''
        uuid = attrs['id'].split('/')[-1]
        return '%s/%s' % (self.uri, uuid)  

    #in IPAS, we should use resolvechildren=-1 to list resources by default to enhance performance
    def _list(self, filt={}):
        if filt.get('resolvechildren') is None:
            filt['resolvechildren'] = -1
        return super(IPASRESTResourceCollection,self)._list(filt)
    
class IPASRESTResource(RelatedResource, IPASCommonAttributes):
    def _statusField(self):
        return 'state'

    def _renderRESTResource(self, key, path = None):
        if self._restattrs.has_key(key) and self._restattrs[key] != None:
            uri =  self._restattrs[key][0]
            if utils.isString(self._restattrs[key]):
                uri = self._restattrs[key]
            if path != None:
                uuid = utils.uuid(uri)
                uri = '%s/%s' % (path, uuid)
            return RESTResource.resourceForURI(uri)
        else:
            return None
   
    def _renderRESTResourceCollection(self, key):
        if self._restattrs.has_key(key) and self._restattrs[key] != None:
            items = http.get('/admin/resources/' + key + "/?" + self._queryname() + "=" + self.id)
            return [RESTResource.resourceForURI(json['id'], json) for json in items]
        else:
            return None
        
    def _belongsToFget(self, attrname, restattrname, ownerClass):
        ownerid = self._restattrs.get(restattrname, None)
        if ownerid:
            return RESTResource.resourceForURI(ownerid)
        return None
        
    def _belongsToFset(self, attrname, restattrname, ownerClass, ownerInstance):
        if ownerInstance:
            self._validate(attrname, ownerInstance)

        if self._restattrs.has_key(restattrname):
            if ownerInstance == None:
                self._restattrs[restattrname] = None
            else:
                self._restattrs[restattrname] = ownerInstance.id
                
    def __eq__(self, other):
        'RM09054'
        if isinstance(other, IPASRESTResource):
            index1 = self.uri.find('/', 1)
            index2 = other.uri.find('/', 1)
            if index1 > 0 and index2 > 0:
                return self.uri[index1:] == other.uri[index2:]
             
        return super(IPASRESTResource, self).__eq__(other)

    def isStatusTransient(self):
        finalStates = [
             'available',
             'downloaded',
             'failed',
             'ready',
             'started',
             'stopped',
             'stored',
             'successful',
             'unavailable'
         ]
        return  not self.state in finalStates

    class HasManyResourceCollection(RelatedResource.HasManyResourceCollection):
        'RM09183'

        def __init__(self, owner, ownedCollClass, **options):
            super(IPASRESTResource.HasManyResourceCollection, self).__init__(owner, ownedCollClass, **options)
            self.ownedRestAttrName = options.get('ownedrestattrname', self.ownedAttrName)
            
        def _list(self, filt = {}):
           # logging.debug("IPASRESTResource.HasManyResourceCollection._list: filt: %s" % filt)

            count = filt.get('count', sys.maxint)
            if filt.has_key('count'):
                del filt['count']

            result = []
            if count > 0:
                d = filt.copy()
                d[self.ownedRestAttrName] = self.owner.id
                for res in self.ownedCollClass().list(d):
                    result.append(res)
                    if len(result) >= count:
                        break

            return result
        

    #override relationships.py
    class ManyManyResourceCollection(ResourceCollection):
        'RM09183'

        def __init__(self, this, otherCollClass, **options):
            """Collection of resources associated with a particular resource
            via a many-many relationship.

            Arguments

            this - Instance of RelatedResource that represents a
               resource on one side of the relationship.

            otherCollClass - subclass of RESTResourceCollection that
               represents the resource collection on the other side of
               the relationship.


            Keyword arguments

            listfilter - callable that can be used to filter which resources
               in otherCollClass are included in the output of _list().
               Callable should accept a RESTResource and return True/False
               to indicate if it should be included in the _list() result.
            """

            # TODO - can remove if/when REST API returns URIs
            if not issubclass(otherCollClass, RESTResourceCollection):
                raise TypeError('ResourceCollection must be RESTResourceCollection')

            self.type1 = utils.pluralize(this.__class__._restname())
            self.id1 = this.id

            self.coll2 = otherCollClass
            self.type2 = otherCollClass._restname()

            self.uri = '%s/%s' % (this.url, self.type2)

            self.options = options


        def _add(self, other):
            http.postJSON(self.uri, { self.type2: other.url})
       
        def _list(self, filt = {}):
            count = filt.get('count', sys.maxint)
            if filt.has_key('count'):
                del filt['count']

            result = []
            if count > 0:
                # TODO - unnecessary if/when REST API returns URIs
                listFilter = self.options.get('listfilter', lambda r: True)

                for json in http.get(self.uri):
                    res = RESTResource.resourceForURI(json['id'], json)
                    if listFilter(res) and RelatedResource._localfilter(filt, res):
                        result.append(res)
                    if len(result) >= count:
                        break

            return result

        def _remove(self, otherId):
            http.delete("%s/%s" %(self.uri , otherId))
        
        def _verifyResourceType(self, res):
            self.coll2._verifyResourceType(res)
 