"""
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2011. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
"""

from deployer.resources.commonattrs import CommonAttributes
from deployer import utils, validators, http, prettify
from deployer.resources.relationships import RelatedResource
from ipasrestresource import IPASRESTResourceCollection, IPASRESTResource
from deployer.messages import message
from deployer.resources.restresource import RESTResource
import os
import admin

@utils.classinit
class VirtualAppliance(IPASRESTResource):
    'RM09916'


    @classmethod
    def _classinit(cls):
        cls._registerURI(r'\A/deployment/resources/images/(?P<id>[\da-z\-]+)\Z')

        cls._defineAttribute('acl', 'IWD10038', readonly=True, readonlydoc=False)
        cls._defineRESTAttribute('created_time', 'RM09917', readonly=True)
        cls._defineRESTAttribute('description', 'RM09920', validator=validators.string)
        cls._defineRESTAttribute('id', 'RM09921', readonly=True)
        cls._defineRESTAttribute('name', 'RM09922', validator=validators.string)
        cls._defineRESTAttribute('state', 'IWD11378', readonly=True)        
        cls._defineRESTAttribute('importurl', 'RM09925', restname='binary')
        cls._defineRESTAttribute('updated_time', 'RM09924', readonly=True)
        cls._defineRESTAttribute('url', 'IWD10033', restname='id', readonly=True)
        cls._defineRESTAttribute('cloud', '' , elided=True)         
        cls._defineRESTAttribute('vmconfigurations', '', elided=True)
        cls._defineRESTAttribute('options', 'options', elided=True, readonly=True)
        
        cls._methodHelp('delete', 'export','isStatusTransient','waitFor')
        
    
    def _getOptions(self):
        image = http.get(self.uri)
        opdict = {}
        if image.has_key('options'):
            opdict = image['options']
        self._options = prettify.PrettyDict(opdict)
        return self._options
    
    def _getCloud(self):
        return self._renderRESTResource('vdc')
    
    def  _setCloud(self, cloud):
        if cloud:
            validators.instance(admin.cloud, cloud, 'cloud')
        return http.putJSON(self.uri, {'vdc': cloud.id if cloud else None})

    def export(self, d):
        'IWD10037'
        if isinstance(d, unicode) or isinstance(d, str) and os.path.isdir(d):
             f = os.path.join(d, '%s.ova' % self.name)
             doclose = False
             f = file(f, 'wb')
             doclose = True
             try:
                http.get('%s/%s.ova' %(self.uri, self.id), responseHandler=utils.curryMethod(self._getResponseHandler, f))
             finally:
                 if doclose:
                     f.close()
        elif isinstance(d, dict):
            if not d.has_key('protocol'):
                d['protocol'] = 'scp'
            
            validators.enum(['scp', 'https'], d.get('protocol'), 'protocol')
            validators.string(d.get('username'), 'username')
            validators.string(d.get('password'), 'password')
            
            options = {}
            options['file.protocol'] = d['protocol']
            options['file.username'] = d['username']
            options['file.password'] = d['password']
            
            if d['protocol'] == 'scp':
               validators.string(d.get('host'), 'host')
               validators.string(d.get('path'), 'path')
               options['file.host'] = d['host']
               filePath = d['path']
               options['file.path'] = filePath if filePath.lower().endswith('.ova') else '%s/%s.ova' % (filePath, self.name.replace(' ', '_'))
    
            else:
               validators.string(d.get('url'), 'url')
               options['file.url'] = d['url']
               
            json = http.putJSON("%s/export" % self.uri, {"export_options": options})
            job = RESTResource.resourceForURI(json['jobs'][0])
            job.waitFor()
            if job.state != 'successful':
                raise IOError(utils.utos(job.message or job.state))
             
    def _getResponseHandler(self, f, resp):
        if resp.status > 299:
            raise IOError(utils.utos(resp.reason))

        s = resp.read(100000)

        while s:
            f.write(s)
            s = resp.read(100000)
    
    
    class BaseClass(object):

        def __lshift__(self, other):
            ''
            self.__iadd__(other)

        def __repr__(self):
            ''
            return utils.utos(unicode(self))

        def __rshift__(self, other):
            ''
            self.__isub__(other)

        def __str__(self):
            ''
            return repr(self)

        def __unicode__(self):
            ''
            x = prettify.prettify(list(self)) 
            return x
              
        
    def _getVmconfigurations(self):
        return self._vmconfigurations
    
    def _setVmconfigurations(self, value):
        if value != self._vmconfigurations:
            raise AttributeError("can't set attribute")
    
    def __init__(self, uri, attrs):
        super(VirtualAppliance, self).__init__(uri, attrs)
        self._vmconfigurations = self.__class__._VMConfigurations(self)
    
    class _VMConfigurations(BaseClass):
        ''
        
        def __len__(self):
            ''
            return len(self.vmconfigurations)
        
        def __getitem__(self, key):
            ''
            v = self.vmconfigurations[key]
            return RESTResource.resourceForURI(v)
        
        def __init__(self, virtualappliance):
            self.virtualappliance = virtualappliance
            
        def __iadd__(self, other):
            ''
            appliance = http.get(self.virtualappliance.uri)
            vmconfigurations = appliance.get('vm_configurations', [])
            
            arg = other            
            if isinstance(other, admin.vmconfiguration):
               arg = [other]
            
            for item in arg:
                uuid = utils.uuid(item.uri)
                exist = utils.find(lambda x: utils.uuid(x) == uuid, vmconfigurations)
                if exist:
                    pass
                else:
                   vmconfigurations.append(item.uri)
            
            http.putJSON(self.virtualappliance.uri, {"vm_configurations": vmconfigurations})
            return self
        
        def __isub__(self, other):
            ''
            appliance = http.get(self.virtualappliance.uri)
            vmconfigurations = appliance.get('vm_configurations', [])
            
            arg = other            
            if isinstance(other, admin.vmconfiguration):
               arg = [other]
            
            for idx, item in enumerate(arg):
                uuid = utils.uuid(item.uri)
                if utils.any(vmconfigurations, lambda x: utils.uuid (x) == uuid):
                   del vmconfigurations[idx]
            http.putJSON(self.virtualappliance.uri, {"vm_configurations": vmconfigurations})
            return self

        def __iter__(self):
            ''
            virtualappliance = http.get(self.virtualappliance.uri + "?resolvechildren=1&resolvechildrenlist=vm_configurations")
            vmconfigurations = virtualappliance.get('vm_configurations', [])
            return iter([RESTResource.resourceForURI(json['id'], json) for json in vmconfigurations])


@utils.classinit
class VirtualAppliances(IPASRESTResourceCollection):
    'RM09914'


    @classmethod
    def _classinit(cls):
        cls._contains(VirtualAppliance)
        cls._methodHelp('create')


    CREATE_ATTRIBUTES = [
        VirtualAppliance._wizardStep('name'),
        VirtualAppliance._wizardStep('description', optional = True),
        VirtualAppliance._wizardStep('importurl'),
        { 'name': 'userid', 'help': message('RM09912'), 'validator': validators.string, 'optional': True },
        { 'name': 'password', 'help': message('RM09913'), 'validator': validators.string, 'optional': True }
    ]

    @classmethod
    def _restname(cls):
        return 'images'

    @classmethod
    def _restPrefix(cls):
        return "/deployment"
    
    def _list(self, filter={}):
        filter['vmtype'] = "virtualappliance"
        return super(VirtualAppliances, self)._list(filter)
     
    def _create(self, dict):
        # validate importurl ahead of time since we're about to rename it
        if not dict.has_key('importurl'):
            raise ValueError(utils.utos(message('RM09366', 'importurl')))
        dict['binary'] = dict['importurl']
        del dict['importurl']
        
        parms = {}
        if  dict.has_key('userid'):
            parms['binary.url.username'] = dict['userid']
            del dict['userid']
        
        if dict.has_key('password'):
            parms['binary.url.password'] = dict['password']
            del dict['password']
        
        dict['options'] = parms
        dict['vmtype'] = 'virtualappliance'
        return super(VirtualAppliances, self)._create(dict, ['options', 'importurl', 'binary', 'vmtype'])
