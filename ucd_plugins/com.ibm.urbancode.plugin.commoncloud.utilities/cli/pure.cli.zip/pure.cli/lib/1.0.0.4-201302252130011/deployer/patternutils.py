"""
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2012. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
"""
import http
import utils

def _matchPropertiesToPattern(pattern, d, propertyCallback, parameterCallback):
    # pre-parse supplied property keys & sort into priority order
    sorted = filter(lambda t: len(t[0]) == 3, [(k.split('.'), d[k]) for k in d])

    def cmpSection(section1, section2):
        if section1 == '*':
            if section2 == '*':
                return 0
            else:
                return 1
        elif section2 == '*':
            return -1
        else:
            return cmp(section1, section2)
        
    def cmpSections(sections1, sections2):
        return cmpSection(sections1[0][2], sections2[0][2]) or cmpSection(sections1[0][1], sections2[0][1]) or cmpSection(sections1[0][0], sections2[0][0])

    sorted.sort(cmpSections)


    # fill in pattern values from properties
    def getValueFor(part, x, y):
        match = utils.find(lambda z: (z[0][0]==part or z[0][0]=='*') and (z[0][1]==x or z[0][1]=='*') and (z[0][2]==y or z[0][2]=='*'), sorted)
        if match:
            return match
        else:
            return None

    for part in pattern.get('parts', []):
        # TODO - fix when userConfigurable becomes a boolean
        for property in filter(lambda p: p.get('userConfigurable', 'false') == 'true' and p.get('propSrc', 'xxx') == None, part.get('properties', [])):
            val = getValueFor('part-%d' % part['id'], property['pclass'], property['key'])
            if val:
                propertyCallback(part, property, val[1], val[0])
            elif property.get('value'):
                propertyCallback(part, property, property['value'], property)
            else:
                propertyCallback(part, property, None, None)

        for script in part.get('scripts', []):
            for parameter in filter(lambda p: p.get('userConfigurable', False), script.get('parameters', [])):
                val = getValueFor('part-%d' % part['id'], 'script-%s' % script['id'], parameter['key'])
                if val:
                    parameterCallback(part, script, parameter, val[1], val[0])
                elif parameter.get('defaultvalue'):
                    parameterCallback(part, script, parameter, parameter['defaultvalue'], parameter)
                else:
                    parameterCallback(part, script, parameter, None, None)


def _parameterKey(part, script, parameter):
    return 'part-%d.script-%d.%s' % (part['id'], script['id'], parameter['key'])


def _propertyKey(part, property):
    return 'part-%d.%s.%s' % (part['id'], property['pclass'], property['key'])



def applyPropertiesToPattern(pattern, d, **options):
    '''Applies a set of properties to the ppart properties and script parameters of a pattern.  Note that pattern is a deserialized JSON object, NOT a Pattern object.'''

    noValueFor = []
    flagOpt = options.get('flagMissingOptionalProperties', False)

    def propcb(part, property, value, src):
        if src is None:
            # report as missing if required for deployment or if we are
            # flagging optional properties
            if property['requiredForDeployment'] or flagOpt:
                noValueFor.append((part, property))
        else:
            property['value'] = value

    def paramcb(part, script, parameter, value, src):
        if src is None:
            noValueFor.append((part, script, parameter))
        else:
            parameter['value'] = value

    _matchPropertiesToPattern(pattern, d, propcb, paramcb)
    return noValueFor


def getPattern(uri):
    '''Returns a deserialized JSON object for the specified pattern URI.'''

    pattern = http.get(uri + '?parts=true&properties=true')
    for part in pattern.get('parts', []):
        part['scripts'] = http.get('%s/pparts/%d/pscripts' % (uri, part['id']))

    return pattern


def listConfig(pattern, d):
    props = {}

    def propcb(part, property, value, src):
        props[_propertyKey(part, property)] = value

    def paramcb(part, script, parameter, value, src):
        props[_parameterKey(part, script, parameter)] = value
        
    _matchPropertiesToPattern(pattern, d, propcb, paramcb)
    return props
