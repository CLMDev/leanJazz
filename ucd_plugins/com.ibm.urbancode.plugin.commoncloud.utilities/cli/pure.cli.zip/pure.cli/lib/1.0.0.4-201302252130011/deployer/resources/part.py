"""
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2012. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
"""

from commonattrs import CommonAttributes
from deployer import http, utils, validators
from relationships import RelatedResource, RelatedResourceCollection


@utils.classinit
class Part(RelatedResource, CommonAttributes):
    'RM09083'


    @classmethod
    def _classinit(cls):
        cls._registerURI(r'\A/resources/part2s/(?P<id>\d+)\Z')

        # info verified with Michael Kalantar, 2009Apr03 2pm
        # contentmodel - hidden
        cls._defineRESTAttribute('created', 'RM09509', readonly=True)
        cls._defineRESTAttribute('currentmessage', 'RM09178', readonly=True)
        cls._defineAttribute('currentmessage_text', 'RM09154', readonly=True)
        cls._defineRESTAttribute('currentstatus', 'RM09179', readonly=True)
        cls._defineAttribute('currentstatus_text', 'RM09156', readonly=True)
        cls._defineRESTAttribute('description', 'RM09180', readonly=True)
        cls._defineRESTAttribute('id', 'RM09181', readonly=True)
        cls._defineRESTAttribute('label', 'RM09182', readonly=True)
        cls._defineRESTAttribute('name', 'RM09182', readonly=True)
        # partmodelstring - hidden
        cls._defineRESTAttribute('updated', 'RM09184', readonly=True)
        cls._defineAttribute('productids', 'RM09524', readonly=True, elided=True)
        cls._defineRESTAttribute('validationmessage', 'RM09185', reaodnly=True)
        cls._defineAttribute('validationmessage_text', 'RM09186', readonly=True)
        cls._defineRESTAttribute('validationstatus', 'RM09187', readonly=True)
        cls._defineAttribute('validationstatus_text', 'RM09188', readonly=True)
        cls._defineRESTAttribute('supportsIPv6', 'RM09854', readonly=True)

        cls._methodHelp('__contains__', '__delattr__', 'delete', '__eq__',
                        '__hash__', 'isStatusTransient', '__nonzero__',
                        'refresh', '__repr__', '__str__', '__unicode__',
                        'waitFor',
                        'isConceptual', 'addProductid', 'deleteProductid')


    def _getProductids(self):
        return http.get('/resources/templates/%d/part/%d/productids' % (self.virtualimage.id, self.id))


    def isConceptual(self):
        'RM09084'
        # TODO - need official way to do this
        return self.virtualimage == None


    def addProductid(self, productid, licensetype='PVU', licensecpu=0, licensememory=0):
        'RM09737'

        json = {'productid': productid, 'licensetype': licensetype, 'licensecpu': licensecpu, 'licensememory': licensememory}
        return http.putJSON('/resources/templates/%d/part/%d/productids' % (self.virtualimage.id, self.id), json)


    def deleteProductid(self, productid, licensetype='PVU'):
        'RM09738'

        return http.delete('/resources/templates/%d/part/%d/productids?productid=%s&licensetype=%s' % (self.virtualimage.id, self.id, productid, licensetype))




@utils.classinit
class Parts(RelatedResourceCollection):
    'RM09035'


    @classmethod
    def _classinit(cls):
        cls._contains(Part)
        cls._methodHelp('__contains__', 'delete', '__delitem__',
                        '__getattr__', '__getitem__', '__iter__',
                        '__len__', 'list', '__lshift__', '__repr__',
                        '__rshift__', '__str__', '__unicode__')


    def _defaultSearch(self, s):
        '''Performs the default search for resources in this collection.'''
        all = self._list()
        value = s.upper()
        result = utils.findAll(lambda p: p.label.upper().find(value) >= 0, all)
        result.sort(lambda p1, p2: utils.exactMatchCmp(p1.label.upper(), p2.label.upper(), value))
        return result


    def _list(self, filt = {}):
        filt = filt.copy()

        filt[self.options['type']] = 'true'
        if self.options.has_key('virtualimage'):
            filt['templateid'] = self.options['virtualimage'].id
        return super(Parts, self)._list(filt)


    @classmethod
    def _restname(cls):
        return 'part2s'
