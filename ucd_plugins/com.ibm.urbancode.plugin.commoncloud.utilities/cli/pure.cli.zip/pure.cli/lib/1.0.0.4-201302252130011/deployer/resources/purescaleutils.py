"""
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2012. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
"""

from deployer import utils, validators, messages,http, mappingutils
from restresource import RESTResource, RESTResourceCollection
from envprofile import EnvironmentProfile
from cloud import Cloud
from ipgroup import IPGroup
import os
import sys


def getFileBaseName(fileObj):
    return utils.stou(os.path.basename(fileObj.name))

def getFileExt(fileObj):
    basename, extension = os.path.splitext(os.path.basename(fileObj.name))
    if extension != None:
        return utils.stou(extension.split('.')[1])
        
    #if len(utils.stou(os.path.basename(fileObj.name)).split('.')) == 2:
    #   fileExt = utils.stou(os.path.basename(fileObj.name)).split('.')[1]
    #  return fileExt"""
    else:
        raise ValueError(utils.utos(messages.message('RM09779')))

def getFileName(fileObj):
    basename, extension = os.path.splitext(os.path.basename(fileObj.name))
    if basename != None:
        return utils.stou(basename)
    #if len(utils.stou(os.path.basename(fileObj.name)).split('.')) == 2:
    # fileName = utils.stou(os.path.basename(fileObj.name)).split('.')[0]
    #return fileName
    else:
        raise ValueError(utils.utos(messages.message('RM09779')))

def userInputChecker(userInput, inputType):
    try:
        if isinstance(userInput, str) or isinstance(userInput, unicode):
            if inputType == 'str':
                return utils.stou(userInput)
            else:
                return userInput
    except:
        raise ValueError(utils.utos(messages.message('RM09781')))

def fileTypeErrorIndicator():
    raise ValueError(utils.utos(messages.message('RM09780')))

def inputTypeErrorIndicator():
    raise ValueError(utils.utos(messages.message('RM09782')))

def objTypeErrorIndicator():
    raise ValueError(utils.utos(messages.message('RM09784')))

def curryMethod(meth, *curryargs, **curryopts):
    return lambda *callargs: meth(*(curryargs + callargs), **curryopts)

def JSON2VirtualAppObj(json):
    depl_id = json["deployment_id"]
    single_depl_uri = '/resources/virtualApplications/?id=%s' % (depl_id)
    depl_json = http.get(single_depl_uri)[0]
    depl_uri = '/resources/virtualApplications/%s' % (depl_id)
    return RESTResource.resourceForURI(depl_uri, depl_json)

def getSSHKeys(f):
    f = userInputChecker(f, 'file')
    doClose = False
    f = file(f, 'rb')
    doClose = True
    fileContent = f.readline()
    if doClose:
       f.close()
    ssh_keys = [fileContent]
    return ssh_keys

#deployOptions = {'environment_profile': <env_profile_obj>
#                 'cloud_group': <cloud_group_obj>
#                 'ip_group': <ip_group_obj>
#                 'ip_version': 'IPv4' or 'IPv6' }
def extractDeployOptions(deployOptions):
    json = {}
    
    if not isinstance(deployOptions, dict):
        return json
    
    if deployOptions.has_key("environment_profile"):
        env_profile = deployOptions['environment_profile']
        if isinstance(env_profile, EnvironmentProfile):
            json['environment_profile_id'] = str(env_profile.id)
            
    if deployOptions.has_key("cloud_group"):
       cloud_group = deployOptions['cloud_group']
       cloud_group = mappingutils.getMappingResource(cloud_group)
       json['cloud_group'] = str(cloud_group.id)
    
    if deployOptions.has_key("ip_group"):
       ip_group = deployOptions['ip_group']
       ip_group = mappingutils.getMappingResource(ip_group)
       json['ip_group'] = str(ip_group.id)
           
    if deployOptions.has_key("ip_version"):
        json['ip_version'] = deployOptions['ip_version']
    else:
        json['ip_version'] = 'IPv4'
        
    if utils.isIPAS():
        if deployOptions.has_key("priority"):
            priority = deployOptions['priority']
            if priority == 'high' or priority == 'medium' or priority == 'low':
                json['priority'] = priority
            else:
                json['priority'] = 'low'
    return json
               
               
            
        
    