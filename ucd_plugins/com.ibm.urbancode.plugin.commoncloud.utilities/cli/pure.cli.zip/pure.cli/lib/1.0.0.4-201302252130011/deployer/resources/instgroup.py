"""
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2012. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
"""
from deployer import utils, validators, messages,http
from restresource import RESTResource, RESTResourceCollection
from relationships import RelatedResource, RelatedResourceCollection
from envprofile import EnvironmentProfile
from cloud import Cloud
from ipgroup import IPGroup
from commonattrs import CommonAttributes
import os
import sys
import deployer.http as http
import deployer.prettify as prettify
import purescaleutils
import urllib

@utils.classinit
class instgroup(RelatedResource, CommonAttributes):
    ''
    @classmethod
    def _classinit(cls):
        cls._registerURI(r'\A/resources/pureScaleInstances/(?P<id>[a-zA-Z0-9\.\-\_\/]+)/databaseGroups\Z')    
        cls._defaultRESTAttrs(True)
        cls._defineRESTAttribute('groupId', '', readonly=True, visible=[ lambda application: application._restattrs.has_key('groupId') ])
        cls._defineRESTAttribute('groupName', '', readonly=True, visible=[ lambda application: application._restattrs.has_key('groupName') ])
        cls._defineRESTAttribute('groupPermission', '', readonly=True, visible=[ lambda application: application._restattrs.has_key('groupPermission') ])
        cls._methodHelp('__contains__', '__delitem__',
                        '__getattr__', '__getitem__', '__iter__',
                        '__len__', 'list', '__lshift__', '__repr__',
                        '__rshift__', '__str__', '__unicode__')

    def __init__(self, uri, attrs):
        super(instgroup, self).__init__(uri, attrs)
    
@utils.classinit
class instgroups(RelatedResourceCollection):
    ''
    @classmethod
    def _classinit(cls):
        cls._contains(instgroup)
        cls._methodHelp('__contains__', '__delitem__',
                        '__getattr__', '__getitem__', '__iter__',
                        '__len__', 'list', '__lshift__', '__repr__',
                        '__rshift__', '__str__', '__unicode__', 'get')

    @classmethod
    #def _restname(cls):
    #   return 'instgroup'

    def _uriForResource(self, attrs):
        return '%s/%s' % (self.uri, attrs['id'])     

    def _list(self, filt = {}):
        'RM32063'
        utf8filt = filt.copy()
        for k in utf8filt:
            if isinstance(utf8filt[k], str) or isinstance(utf8filt[k], unicode):
                utf8filt[k] = utf8filt[k].encode('utf-8')

        if filt:
            filt = '?' + urllib.urlencode(utf8filt)
        else:
            filt = ''

        json=http.get('%s/%s' % (self.uri.replace("instgroups", "databaseGroups"), filt))
        return utils.utos(json)
        
    def get(self, group):
        'RM32062'
        id = self.uri.split("/")[3]
        json = http.get('%s/%s' % (self.uri.replace("instgroups", "databaseGroups"), group))
        return utils.utos(json)
        
    def create(self, d):
        'RM32065'
        id = self.uri.split("/")[3]
        uri = '/resources/pureScaleInstances/%s' % id
        if isinstance(d, dict):
           json = http.putJSON(uri, d)
           return utils.utos(json)
        else:
           purescaleutils.inputTypeErrorIndicator()


    def update(self, d):
        ''
        id = self.uri.split("/")[3]
        uri = '/resources/pureScaleInstances/%s' % id
        if isinstance(d, dict):
            json = http.putJSON(uri, d)
            return utils.utos(json)
        else:
            purescaleutils.inputTypeErrorIndicator()
