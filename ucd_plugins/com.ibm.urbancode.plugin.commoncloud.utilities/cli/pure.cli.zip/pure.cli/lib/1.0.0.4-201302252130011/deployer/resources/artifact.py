#
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2012. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
#
"""
Licensed Materials - Property of IBM
IBM WebSphere CloudBurst Appliance (9235-72X)
Copyright IBM Corporation 2011. All Rights Reserved.
US Government Users Restricted Rights - Use, duplication or disclosure
restricted by GSA ADP Schedule Contract with IBM Corp.
"""

import deployer
from deployer import utils, validators, http
from restresource import RESTResource, RESTResourceCollection
from relationships import RelatedResource, RelatedResourceCollection
from commonattrs import CommonAttributes
from deployer.messages import Helpable
import urllib
import purescaleutils

@utils.classinit
class Artifact(RelatedResource, CommonAttributes):
    'RM09696'

    @classmethod
    def _classinit(cls):
        cls._registerURI(r'\A/resources/(applicationPatterns|sharedServices)/[\dabcdef\-]+/artifacts/(?P<name>[a-zA-Z0-9\.\_\-]+)\Z')
        cls._defaultRESTAttrs(True)
        cls._getParams({ 'details': True })

        cls._defineAttribute('name', 'RM09709', readonly=True, visible=[ lambda artifact: artifact.name != None ])
        cls._defineRESTAttribute('content_md5', 'RM09710', readonly=True, visible=[ lambda artifact: artifact.content_md5 != None ])
        cls._defineRESTAttribute('content_type', 'RM09711', readonly=True, visible=[ lambda artifact: artifact.content_type != None ])
        cls._defineRESTAttribute('create_time', 'RM09712', readonly=True, visible=[ lambda artifact: artifact.create_time != None ])
        cls._defineRESTAttribute('creator', 'RM09713', readonly=True, visible=[ lambda artifact: artifact.creator != None ])
        cls._defineRESTAttribute('last_modifier', 'RM09714', readonly=True, visible=[ lambda artifact: artifact.last_modifier != None ])
        cls._defineRESTAttribute('last_modified', 'RM09715', readonly=True, visible=[ lambda artifact: artifact.last_modified != None ])
        cls._defineRESTAttribute('access_rights', 'RM09716', readonly=True, visible=[ lambda artifact: artifact.access_rights != None ])

        cls._methodHelp('download')

    def _getName(self):
        name = self.uri.split("/")[5]
        return name

    def download(self, f):
        'RM09753'
        f = purescaleutils.userInputChecker(f, 'file')
        f = file(f, 'wb')
        try:
           http.get('%s?download' % (self.uri), responseHandler=utils.curryFunction(utils.getResponseHandler, f))
        finally:
            f.close()

@utils.classinit
class Artifacts(RelatedResourceCollection):
    'RM09878'

    @classmethod
    def _classinit(cls):
        cls._contains(Artifact)
        cls._methodHelp('create', 'delete', 
                        'upload', 'download')

    def delete(self, artifact_name):
        'RM09016'
        artifact_name = purescaleutils.userInputChecker(artifact_name, 'str')
        http.delete('%s/%s' % (self.uri, artifact_name))

    def upload(self, f):
        'RM09752'
        f = purescaleutils.userInputChecker(f, 'file')
        f = file(f, 'rb')
        try:
           fileName = purescaleutils.getFileBaseName(f)
           json = http.restChunked('%s/%s' % (self.uri, fileName), f, 'PUT', 'application/binary')
           return utils.utos(json)
        finally:
           f.close()

    def download(self, artifact_name, f):
        'RM09753'
        artifact_name = purescaleutils.userInputChecker(artifact_name, 'str')
        f = purescaleutils.userInputChecker(f, 'file')
        f = file(f, 'wb')
        try:
           http.get('%s/%s?download' % (self.uri, artifact_name), responseHandler=utils.curryFunction(utils.getResponseHandler, f))
        finally:
            f.close()


    def _uriForResource(self, attrs):
        return '%s/%s' % (self.uri, attrs['name'])
