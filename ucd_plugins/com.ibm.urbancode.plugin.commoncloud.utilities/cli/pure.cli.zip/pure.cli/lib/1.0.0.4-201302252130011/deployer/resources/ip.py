"""
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2011. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
"""

from commonattrs import CommonAttributes
from deployer import http, utils, validators
from relationships import RelatedResource, RelatedResourceCollection
import os


@utils.classinit
class IP(RelatedResource, CommonAttributes):
    'IWD00052'


    @classmethod
    def _classinit(cls):
        cls._registerURI(r'\A/resources/subnets/\d+/ips/(?P<id>\d+)\Z')

        cls._defineRESTAttribute('created', 'RM09165', readonly=True)
        cls._defineRESTAttribute('currentmessage', 'RM09166', readonly=True)
        cls._defineRESTAttribute('currentmessage_text', 'RM09154', readonly=True)
        cls._defineRESTAttribute('currentstatus', 'RM09167', readonly=True)
        cls._defineRESTAttribute('currentstatus_text', 'RM09156', readonly=True)
        cls._defineRESTAttribute('id', 'RM09168', readonly=True)
        cls._defineRESTAttribute('ipaddress', 'RM09169', readonly=True)
        cls._defineRESTAttribute('userhostname', 'RM09637', readonly=True)
        # type - hidden
        cls._defineRESTAttribute('updated', 'RM09170', readonly=True)
 

    def delete(self):
        raise NotImplementedError('delete')
@utils.classinit
class IPs(RelatedResourceCollection):
    'IWD10049'


    @classmethod
    def _classinit(cls):
        cls._contains(IP)
        cls._methodHelp('list')


    def create(self, dict):
        raise NotImplementedError('create')
    
    def delete(self, id):
        raise NotImplementedError('delete')


