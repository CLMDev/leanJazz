"""
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2012. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
"""

import deployer
from deployer import utils, validators, http, prettify
from restresource import RESTResource, RESTResourceCollection
from relationships import RelatedResource, RelatedResourceCollection
from commonattrs import CommonAttributes
from deployer.messages import Helpable
import urllib
import purescaleutils
import os

@utils.classinit
class instuser(RelatedResource, CommonAttributes):
    ''
    @classmethod
    def _classinit(cls):
        cls._registerURI(r'\A/resources/pureScaleInstances/(?P<id>[a-zA-Z0-9\.\-\_\/]+)/databaseUsers\Z')    
        cls._defaultRESTAttrs(True)
        cls._defineRESTAttribute('groups', '', readonly=True, visible=[ lambda application: application._restattrs.has_key('groups') ])
        cls._defineRESTAttribute('userId', '', readonly=True, visible=[ lambda application: application._restattrs.has_key('userId') ])
        cls._defineRESTAttribute('userName', '', readonly=True, visible=[ lambda application: application._restattrs.has_key('userName') ])
        cls._defineRESTAttribute('sshAccess', '', readonly=True, visible=[ lambda application: application._restattrs.has_key('sshAccess') ])
        cls._defineRESTAttribute('isDefaultUser', '', readonly=True, visible=[ lambda application: application._restattrs.has_key('isDefaultUser') ])
        cls._methodHelp('__contains__', '__delitem__',
                        '__getattr__', '__getitem__', '__iter__',
                        '__len__', 'list', '__lshift__', '__repr__',
                        '__rshift__', '__str__', '__unicode__')

    def __init__(self, uri, attrs):
        super(instuser, self).__init__(uri, attrs)
    
@utils.classinit
class instusers(RelatedResourceCollection):
    ''
    @classmethod
    def _classinit(cls):
        cls._contains(instuser)
        cls._methodHelp('__contains__', '__delitem__',
                        '__getattr__', '__getitem__', '__iter__',
                        '__len__', 'list', '__lshift__', '__repr__',
                        '__rshift__', '__str__', '__unicode__', 'get')
    @classmethod
    #def _restname(cls):
    #    return 'instuser'

    def _uriForResource(self, attrs):
        return '%s/%s' % (self.uri, attrs['id'])     

    def _list(self, filt = {}):
        'RM32062'
        utf8filt = filt.copy()

        for k in utf8filt:
            if isinstance(utf8filt[k], str) or isinstance(utf8filt[k], unicode):
                utf8filt[k] = utf8filt[k].encode('utf-8')

        if filt:
            filt = '?' + urllib.urlencode(utf8filt)
        else:
            filt = ''

        json=http.get('%s/%s' % (self.uri.replace("instusers", "databaseUsers"), filt))
        return utils.utos(json)  

    def get(self, usrname):
        ''
        id = self.uri.split("/")[3]
        uri = '/resources/pureScaleInstances/%s/databaseUsers/%s' % (id, usrname)
        json = http.get('/resources/pureScaleInstances/%s/databaseUsers/%s' % (id, usrname))
        return utils.utos(json)

    def create(self, d):
        'RM32059'
        id = self.uri.split("/")[3]
        uri = '/resources/pureScaleInstances/%s' % id
        if isinstance(d, dict):
           json = http.putJSON(uri, d)
           return utils.utos(json)
        else:
           purescaleutils.inputTypeErrorIndicator()


    def update(self, d):
        'RM32060'
        id = self.uri.split("/")[3]
        uri = '/resources/pureScaleInstances/%s' % id
        if isinstance(d, dict):
            json = http.putJSON(uri, d)
            return utils.utos(json)
        else:
            purescaleutils.inputTypeErrorIndicator()
