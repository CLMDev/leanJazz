"""
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2011. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
"""

from commonattrs import CommonAttributes
from deployer import http, utils, validators
from relationships import RelatedResource, RelatedResourceCollection
import os


@utils.classinit
class DeploymentPriority(RelatedResource, CommonAttributes):
    'IWD12212'
    
    @classmethod
    def _classinit(cls):
        cls._registerURI(r'\A/resources/deploymentPriorities/\d+\Z')
        
        cls._defineRESTAttribute('id', 'IWD11000', readonly=True)
        cls._defineRESTAttribute('name', 'IWD11001', readonly=True)
        cls._defineRESTAttribute('high', 'IWD12214', readonly=True)
        cls._defineRESTAttribute('medium', 'IWD12215', readonly=True)
        cls._defineRESTAttribute('low', 'IWD12216', readonly=True)

    
@utils.classinit
class DeploymentPriorities(RelatedResourceCollection):
    'IWD12211'

    @classmethod
    def _classinit(cls):
        cls._contains(DeploymentPriority)
        cls._methodHelp('list')

    @classmethod
    def _restname(cls):
        return 'deploymentPriorities'
    
    def _list(self, filt = {}):
        result =  super(DeploymentPriorities, self)._list(filt)
        return utils.filterRestResult(result, filt)
