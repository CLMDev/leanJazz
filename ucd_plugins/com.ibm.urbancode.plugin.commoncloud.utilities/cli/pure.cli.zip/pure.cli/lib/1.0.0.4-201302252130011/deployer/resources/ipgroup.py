"""
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2011. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
"""

from commonattrs import CommonAttributes
from deployer import utils, validators
from relationships import RelatedResource, RelatedResourceCollection


@utils.classinit
class IPGroup(RelatedResource, CommonAttributes):
    'IWD00051'


    @classmethod
    def _classinit(cls):
        cls._registerURI(r'\A/resources/subnets/(?P<id>\d+)\Z')

        cls._defineRESTAttribute('created', 'RM09245', readonly=True)
        cls._defineRESTAttribute('id', 'RM09246', readonly=True)
        cls._defineRESTAttribute('gateway', 'RM09247', validator=validators.allipaddress, readonly=True)
        cls._defineRESTAttribute('name', 'RM09248', validator=validators.string, readonly=True)
        cls._defineRESTAttribute('netmask', 'RM09249', visible= [lambda ipgroup: ipgroup.netmask != ""], readonly=True)
        cls._defineRESTAttribute('primarydns', 'RM09250', validator=validators.allipaddress, readonly=True)
        # protocol - hidden
        cls._defineRESTAttribute('secondarydns', 'RM09252', validator=validators.optionalipaddress, readonly=True)
        cls._defineRESTAttribute('subnetaddress', 'RM09244', restname='address', validator=validators.allipaddress, readonly=True)
        cls._defineRESTAttribute('updated', 'RM09253', readonly=True)
        cls._defineRESTAttribute('version', 'RM09635', values=('IPv4','IPv6'), readonly=True)


    def delete(self):
        raise NotImplementedError('delete')

@utils.classinit
class IPGroups(RelatedResourceCollection):
    'IWD10048'


    @classmethod
    def _classinit(cls):
        cls._contains(IPGroup)
        cls._methodHelp('list')


    @classmethod
    def _restname(cls):
        return 'subnets'

    def _list(self, filt={}):
        if not filt.has_key('refresh'):
            filt['refresh'] = 'true'
        result = super(IPGroups, self)._list(filt)
        return utils.findAll(lambda r: r._restattrs.get('ismanagement') == 0, result)
    
    def create(self, dict):
        raise NotImplementedError('create')
    def delete(self, id):
        raise NotImplementedError('delete')