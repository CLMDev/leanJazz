#
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2012. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
#
from deployer import http, utils

# A dict that is backed by a REST API on the appliance.
#
# A URI from which to retrieve the data is supplied when this class is
# instantiated.  The code assumes that HTTP GETs to this URI will
# return a JSON map and that updates in the form of JSON maps can be
# sent via HTTP PUT to the same URI.
#
# Note that this class fetches data lazily to avoid unnecessary
# network round trips.
#
# After sending an update to the appliance, this class invalidates its
# contents and will refetch the data from the appliance the next time
# it is needed.  This is to handle situations where the appliance
# morphs the updated value or where updating one attribute triggers
# updates to other attributes.

class RESTBackedDict(dict):
    def __init__(self, uri, initial=None, munge=None):
        self._uri = uri
        self._munge = munge or (lambda json: json)

        if initial:
            super(RESTBackedDict, self).update(initial)
            self._initialized = True
        else:
            self._initialized = False


    # private methods

    # ensures that attributes have been populated before certain methods
    # are called
    @classmethod
    def _ensureDataFor(cls, *methodNames):
        def addwrapper(methodName):
            def wrapper(self, *args, **kw):
                self._ensure()
                return getattr(super(RESTBackedDict, self), methodName)(*args, **kw)

            setattr(cls, methodName, wrapper)

        for methodName in methodNames:
            addwrapper(methodName)


    # ensures that attributes have been populated
    def _ensure(self):
        if not self._initialized:
            super(RESTBackedDict, self).update(self._munge(http.get(self._uri)))
            self._initialized = True



    # public methods

    # clears all attributes, sets values to null on server
    def clear(self):
        http.putJSON(self._uri, dict.fromkeys(self, None))
        self._initialized = False


    # deletes a key from the dict, sets value to null on server
    def __delitem__(self, k):
        http.putJSON(self._uri, { k: None })
        self._initialized = False


    # marks the table as dirty so it will be reloaded the next time it
    # is required, typically called when the server data is updated via
    # a side channel (that is, NOT through this code)
    def markdirty(self):
        self._initialized = False


    # pops and returns one key/value, sets returned key to null on server
    def popitem(self):
        self._ensure()
        result = super(RESTBackedDict, self).popitem()
        http.putJSON(self._uri, { result[0]: None })
        return result


    # (re)fetches a copy of the attributes/values from the appliance
    def refresh(self):
        # make sure we can get new data before clearing old data
        newData = self._munge(http.get(self._uri))
        super(RESTBackedDict, self).clear()
        super(RESTBackedDict, self).update(newData)


    # returns D[k] if k is a key in D; otherwise sets D[k] = x and returns x
    def setdefault(self, k, x=None):
        # override in case dict implementation takes shortcuts
        if k not in self:
            self[k] = x

        return self[k]


    # sets a value for the specified key
    def __setitem__(self, k, v):
        http.putJSON(self._uri, { k: v })
        self._initialized = False


    # copies keys/values from another dict
    def update(self, d):
        http.putJSON(self._uri, d)
        self._initialized = False


RESTBackedDict._ensureDataFor(
    '__contains__', 'copy', 'get', '__getitem__', 'has_key',
    'items', '__iter__', 'iteritems', 'iterkeys', 'itervalues',
    'keys', '__len__', '__nonzero__', '__repr__', '__str__',
    '__unicode__', 'values'
)
