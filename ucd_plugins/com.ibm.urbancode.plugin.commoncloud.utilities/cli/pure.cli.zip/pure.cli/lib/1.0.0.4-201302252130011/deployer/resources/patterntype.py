#
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2012. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
#
"""
Licensed Materials - Property of IBM
IBM WebSphere CloudBurst Appliance (9235-72X)
Copyright IBM Corporation 2011. All Rights Reserved.
US Government Users Restricted Rights - Use, duplication or disclosure
restricted by GSA ADP Schedule Contract with IBM Corp.
"""

import deployer
from deployer import utils, validators, http, prettify, progressindicators
from restresource import RESTResource, RESTResourceCollection
from relationships import RelatedResource, RelatedResourceCollection
from commonattrs import CommonAttributes
from deployer.messages import Helpable
from deployer.messages import message
from deployer.messages import localize as localize
import urllib
import purescaleutils
import os

@utils.classinit
class PatternType(RelatedResource, CommonAttributes):
    'RM09834'
    STATUS_MESSAGES = {'unaccepted': 'IWD00014', 'accepted': 'IWD00012', 'avail': 'IWD00013', 'deprecated': 'IWD00012'}
    @classmethod
    def _classinit(cls):
        cls._registerURI(r'\A/resources/patternTypes/(?P<shortnameandversion>[\d\w\/\.]+)\Z')
        cls._defaultRESTAttrs(True)
        #cls._getParams({ 'details': True })

        cls._defineRESTAttribute('shortname', 'RM09887', readonly=True, visible=[ lambda patterntype: patterntype.shortname != None ])
        cls._defineRESTAttribute('name', 'RM09838', readonly=True, visible=[ lambda patterntype: patterntype.name != None ])
        cls._defineRESTAttribute('version', 'RM09836', readonly=True, visible=[ lambda patterntype: patterntype.version != None ])
        cls._defineRESTAttribute('description', 'RM09837', readonly=True, visible=[ lambda patterntype: patterntype.description != None ])
        cls._defineRESTAttribute('status', 'RM09928', visible=[ lambda patterntype: patterntype.status != None ])
        cls._defineRESTAttribute('required', 'RM09929', restname='prereqs', readonly=True, visible=[ lambda patterntype: patterntype.required != None ])
        cls._defineRESTAttribute('status_text', 'IWD00015',readonly=True)

        cls._methodHelp('__contains__', '__delattr__', 'delete', '__eq__',
                        '__hash__', 'isStatusTransient', '__nonzero__',
                         '__repr__', '__str__', '__unicode__',
                        'acceptLicense','enable','disable')

     
    def acceptLicense(self):
        'RM09843'
        self.status = "accepted"
        return {"status":"accepted"}

    def enable(self):
        'RM09930'
        self.status = "avail"
        return {"status":"avail"}

    def disable(self):
        'RM09931'
        self.status = "deprecated"
        return {"status":"deprecated"}
    
    @localize
    def _getStatus_text(self):
        return self.STATUS_MESSAGES[self.status]

@utils.classinit
class PatternTypes(RelatedResourceCollection):
    'RM09835'
    
    @classmethod
    def _classinit(cls):
        cls._contains(PatternType)
        cls._methodHelp('__contains__', '__delitem__',
                        '__getattr__', '__getitem__', '__iter__',
                        '__len__', 'list', '__lshift__', '__repr__',
                        '__rshift__', '__str__', '__unicode__','get','create')
        
    def __init__(self):
        super(PatternTypes, self).__init__()
        self.progressIndicators = False
        
    @classmethod
    def _restname(cls):
        return 'patternTypes'

    def _list(self, filter={}):
        'RM09839'  
        if "version" not in filter:
            filter['version'] = 'vr'
        return super(PatternTypes, self)._list(filter)
           
    def get(self, patterntype, version):
        'IWD00041'
        patterntype = purescaleutils.userInputChecker(patterntype, 'str')
        version = purescaleutils.userInputChecker(version, 'str')
        return RESTResource.resourceForURI('%s/%s/%s' % (self.uri, patterntype, version))
    
    def create(self, other):
        'IWD00042'
        
        params = None
        
        #patterntypes.create(<url>)
        if (isinstance(other, str) or isinstance(other, unicode)) and not os.path.isfile(other):
            params = { 'url': utils.stou(other) }
            
         # <patterntypes>.create("<filename.tgz>")    
        elif (isinstance(other, str) or isinstance(other, unicode)) and os.path.isfile(other) and other.lower().endswith('.tgz'):
            if self.progressIndicators:
                f = progressindicators.ReadProgressFile(other, 'rb')
            else:
                f = file(other, 'rb')

            try:
                return self.create(f)
            finally:
                f.close()
                
        # <patterntypes>.create(<file>)
        elif isinstance(other, file):
            if self.progressIndicators and not isinstance(other, progressindicators.ReadProgressFile):
                other = progressindicators.ReadProgressFile(other.name, other.mode)

            json = http.restChunked(self.uri, other, 'POST', 'application/binary')
            return self._handleResponse(json)
        
        # <patterntypes>.create({...})
        elif isinstance(other, dict):
            params = utils.stou(other)

        if params:
            json = http.postJSON(self.uri, params)
            return self._handleResponse(json)                                
        else:
            purescaleutils.fileTypeErrorIndicator()

    def _handleResponse(self, json):
        if 'patterntypes' in json:
            entity = [ RESTResource.resourceForURI(self._uriForResource(ptype)) for ptype in json['patterntypes'] ]
        else:
            entity = []
        return entity
             
    def delete(self, patterntype, version):
        'RM09016'
        patterntype = purescaleutils.userInputChecker(patterntype, 'str')
        json = http.delete('%s/%s/%s' % (self.uri, patterntype, version))
        return utils.utos(json)
    
    def _uriForResource(self, attrs):
        return '%s/%s/%s' % (self.uri, attrs['shortname'], attrs['version'])

    def check(self, patterntypes = {}, plugins = {}):
        json = {'toCheckPatternTypes': patterntypes, 'toCheckPlugins': plugins}
        return http.postJSON('%s/check' % self.uri, json)
    
    def clean(self, patterntypes = {}, plugins = {}):
        json = {'toCheckPatternTypes': patterntypes, 'toCheckPlugins': plugins}
        return http.postJSON('%s/clean' % self.uri, json)
        