"""
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2012. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
"""
import java

from com.ibm.workloaddeployer.cli import JLineConsole
from messages import message
from utils import stou, utos


def promptForPassword(prompt=None):
    'Prompts the user for a password'

    prompt = prompt or message('RM09356("RM09541")')

    if JLineConsole.inUse():
        password = JLineConsole.getConsoleReader().readLine(utos(prompt), '\0')
    elif java.lang.System.console():
        password = str(java.lang.String(java.lang.System.console().readPassword(prompt, [])))
    else:
        password = None

    return stou(password)


def promptForUserid(prompt=None):
    'Prompts the user for a user name'

    prompt = prompt or message('RM09356("RM09540")')

    if JLineConsole.inUse():
        userid = JLineConsole.getConsoleReader().readLine(utos(prompt))
    elif java.lang.System.console():
        userid = java.lang.System.console().readLine(prompt, [])
    else:
        userid = None

    return stou(userid)
