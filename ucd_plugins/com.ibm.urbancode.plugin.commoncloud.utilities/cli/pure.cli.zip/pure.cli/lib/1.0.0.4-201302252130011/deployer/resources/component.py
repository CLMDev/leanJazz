#
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2012. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
#
"""
Licensed Materials - Property of IBM
IBM WebSphere CloudBurst Appliance (9235-72X)
Copyright IBM Corporation 2011. All Rights Reserved.
US Government Users Restricted Rights - Use, duplication or disclosure
restricted by GSA ADP Schedule Contract with IBM Corp.
"""

import deployer
from cloud import Cloud
from deployer import utils, validators, http
from restresource import RESTResource, RESTResourceCollection
from relationships import RelatedResource, RelatedResourceCollection
from commonattrs import CommonAttributes
from deployer.messages import Helpable
import urllib
import purescaleutils

@utils.classinit
class Component(RelatedResource, CommonAttributes):
    'RM09861'

    @classmethod
    def _classinit(cls):
        cls._registerURI(r'\A/resources/components/(?P<id>[\dabcdef\-]+)\Z')
        cls._defaultRESTAttrs(True)
        cls._getParams({'details': True })

        cls._defineAttribute('acl', 'RM09874', readonly=True, readonlydoc=False, elided=True)
        cls._defineRESTAttribute('content_type', 'RM10033', readonly=True, visible=[ lambda component: component.content_type != None ])
        cls._defineRESTAttribute('content_md5', 'RM09862', readonly=True, visible=[ lambda component: component.content_md5 != None ])
        cls._defineRESTAttribute('last_modifier', 'RM09863', readonly=True, visible=[ lambda component: component.last_modifier != None ])
        cls._defineRESTAttribute('create_time', 'RM09864', readonly=True, visible=[ lambda component: component.create_time != None ])
        cls._defineRESTAttribute('last_modified', 'RM09865', readonly=True, visible=[ lambda component: component.last_modified != None ])
        cls._defineRESTAttribute('access_rights', 'RM09866', readonly=True, visible=[ lambda component: component.access_rights != None ])
        cls._defineRESTAttribute('typeName', 'RM09867', readonly=True, visible=[ lambda component: component.typeName != None ])
        cls._defineRESTAttribute('type', 'RM09868', readonly=True, visible=[ lambda component: component.type != None ])
        cls._defineRESTAttribute('name', 'RM09869', readonly=True, visible=[ lambda component: component.name != None ])
        cls._defineRESTAttribute('component_id', 'RM09870', readonly=True, visible=[ lambda component: component.component_id != None ])
        cls._defineRESTAttribute('creator', 'RM09871', readonly=True, visible=[ lambda component: component.creator != None ])
        
        cls._defineRESTAttribute('patterntype', 'RM09887', readonly=True, visible=[ lambda component: component.patterntype != None ])
        cls._defineRESTAttribute('version', 'RM09836', readonly=True, visible=[ lambda component: component.version != None ])
        
        cls._methodHelp('refresh', 'delete', 'update', 'download', 'uploadArtifact')

    def update(self, d):
        'RM09873'
        if isinstance(d, dict):
            json = http.putJSON(self.uri, d)
        else:
            purescaleutils.inputTypeErrorIndicator()
    
    def uploadArtifact(self, f):
        'RM09966'
        f = purescaleutils.userInputChecker(f, 'file')
        f = file(f, 'rb')
        try:
           baseName = purescaleutils.getFileBaseName(f)
           json = http.restChunked('%s/componentArtifacts/%s' % (self.uri, baseName), f, 'PUT', 'application/binary')
        finally:
           f.close()
        return utils.utos(json)

    def download(self, f):
        'RM09872'
        f = purescaleutils.userInputChecker(f, 'file')
        lowerFileName = f.lower()
        if lowerFileName.endswith('.json'):
           uri = '%s?model' % (self.uri)
           f = file(f, 'wb')
           try:
                http.get(uri, responseHandler=utils.curryFunction(utils.getResponseHandler, f))
           finally:
                f.close()
        else:
            purescaleutils.fileTypeErrorIndicator()
            

@utils.classinit
class Components(RelatedResourceCollection):
    'RM09860'

    @classmethod
    def _classinit(cls):
        cls._contains(Component)
        cls._methodHelp('create','list', 'get')

    def delete(self, component_id):
        'RM09016'
        component_id = purescaleutils.userInputChecker(component_id, 'str')
        http.delete('%s/%s' % (self.uri, component_id))

    def create(self, d):
        'RM09015'
        if isinstance(d, dict):
            json = http.postJSON(self.uri, d)
            return RESTResource.resourceForURI(self._uriForResource(json), json)
        else:
            purescaleutils.inputTypeErrorIndicator()

    def get(self, component_id):
        'RM09750'
        component_id = purescaleutils.userInputChecker(component_id, 'str')
        return RESTResource.resourceForURI('%s/%s' % (self.uri, component_id))


    def _uriForResource(self, attrs):
        return '%s/%s' % (self.uri, attrs['component_id'])
