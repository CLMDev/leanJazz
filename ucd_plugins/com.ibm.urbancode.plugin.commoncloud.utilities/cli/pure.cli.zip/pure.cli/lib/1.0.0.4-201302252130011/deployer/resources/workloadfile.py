#
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2012. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
#
"""
Licensed Materials - Property of IBM
IBM WebSphere CloudBurst Appliance (9235-72X)
Copyright IBM Corporation 2011. All Rights Reserved.
US Government Users Restricted Rights - Use, duplication or disclosure
restricted by GSA ADP Schedule Contract with IBM Corp.
"""

import deployer.http as http
import deployer.prettify as prettify
import deployer.utils as utils
import deployer.validators as validators
from   commonattrs import CommonAttributes
from   relationships import RelatedResource, RelatedResourceCollection
from   restresource import RESTResource
import purescaleutils
import urllib


@utils.classinit
class WorkloadFile(RelatedResource, CommonAttributes):
    'RM10040'
    @classmethod
    def _classinit(cls):
        cls._registerURI(r'\A/resources/databaseWorkloads/[a-zA-Z0-9\-]+/workloadFiles/(?P<name>[a-zA-Z0-9\.\_\-]+)\Z')
        cls._methodHelp()
        
        
    def __init__(self, uri, attrs):
        super(WorkloadFile, self).__init__(uri, attrs)
        
        
@utils.classinit
class WorkloadFiles(RelatedResourceCollection):
    'RM10040'
    @classmethod
    def _classinit(cls):
        cls._contains(WorkloadFile)
        cls._methodHelp('list', 'upload', 'download')
    @classmethod
    def _restname(cls):
        return 'workloadFiles'
                  
    def upload(self, f):
        'RM10041'
        doclose = False
        f = purescaleutils.userInputChecker(f, 'file')
        f = file(f, 'rb')
        doclose = True
        fileName = purescaleutils.getFileBaseName(f)
        workloadId = self.uri.split("/")[3]
        workloadUri = "/resources/workloadFiles/" + workloadId + "?filename=" + fileName
        #json = http.restChunked('%s/%s' % (workloadUri, fileName), f, 'PUT', 'application/binary')
        json = http.restChunked('%s' % (workloadUri), f, 'PUT', 'application/binary')
        if doclose:
            f.close()
        return utils.utos(json)

    #def _getResponseHandler(self, f, resp):
    def _getResponseHandler(self, resp, f):
        if resp.status > 299:
            raise IOError(utos(resp.reason))

        s = resp.read(100000)

        while s:
            f.write(s)
            s = resp.read(100000)
    
    def _list(self):
        return []
             
    def download(self, artifact_name, f):
        'RM10042'
        artifact_name = purescaleutils.userInputChecker(artifact_name, 'str')
        doclose = False
        f = purescaleutils.userInputChecker(f, 'file')
        f = file(f, 'wb')
        doclose = True
        
        workloadId = self.uri.split("/")[3]
        if utils.isSparta():
            if "OLTP"==workloadId:
                workloadUri = "/resources/downloadSysZip/"    + artifact_name
            else:
                workloadUri = "/resources/dbdownloadzip/" + workloadId + "/artifact/" + artifact_name
        else:
            if "departmental_OLTP"==workloadId or "dynamic_datamart"==workloadId:
                workloadUri = "/resources/downloadSysZip/"    + artifact_name
            else:
                workloadUri = "/resources/dbdownloadzip/" + workloadId + "/artifact/" + artifact_name    
        
        http.get('%s' % (workloadUri), responseHandler=utils.curryMethod(self._getResponseHandler, f))
        #http.get('%s/%s' % (workloadUri, workloadId + "/artifact/" + artifact_name), responseHandler=utils.curryMethod(self._getResponseHandler, f))
        if doclose:
            f.close()
            
