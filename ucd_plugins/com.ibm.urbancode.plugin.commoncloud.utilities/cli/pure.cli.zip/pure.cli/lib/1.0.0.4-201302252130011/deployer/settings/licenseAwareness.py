#
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2012. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
#
import java
import os

from deployer import http, messages, prettify, utils, validators
from deployer.resources.localresource import LocalResource
from deployer.utils import utos
from deployer.resources.restresource import RESTResource


class LicenseAwareness(object):
    '''RM09514'''

    #
    # deployer.licenseawareness.thresholdalert
    # deployer.licenseawareness.thresholdalert=True || False
    #

    THRESHOLDALERT_URI = '/resources/licenseAwareness/licenseThresholdAlert'
    _PROPERTYHELP_ = ['thresholdalert', 'ibmsoftwarecatalog', 'pvutable', 'product', 'products', 'highwatermarklicense']

    def __init__(self):
        if utils.isIPAS():
            self._PROPERTYHELP_.remove('pvutable')
            self._PROPERTYHELP_.append('vmwarelicense')
            
    def thresholdalert_(self):
        '''RM09515'''
        pass

    def _setThresholdAlert(self, enabled):
        http.putJSON(self.THRESHOLDALERT_URI, enabled)

    def _getThresholdAlert(self):
        return http.get(self.THRESHOLDALERT_URI)

    thresholdalert = property(_getThresholdAlert, _setThresholdAlert)


    #
    # deployer.licenseawareness.ibmsoftwarecatalog.import_('/tmp/IBMSoftwareCatalog.xml')
    #
    class IbmSoftwareCatalog(object):
        'RM09516'

        def import_(self, f):
            'RM09534'

            doclose = False

            if isinstance(f, str) or isinstance(f, unicode):
                f = file(f, 'rb')
                doclose = True

            http.postChunked('/resources/licenseAwareness/ibmSoftwareCatalog/%s' % os.path.basename(f.name), f)

            if doclose:
                f.close()

    IbmSoftwareCatalog.import = IbmSoftwareCatalog.import_
    ibmsoftwarecatalog = IbmSoftwareCatalog()

    #
    # deployer.licenseawareness.pvutable.import_('/tmp/PVU-table.xml')
    #
    class PvuTable(object):
        'RM09517'

        def import_(self, f):
            'RM09535'

            doclose = False

            if isinstance(f, str) or isinstance(f, unicode):
                f = file(f, 'rb')
                doclose = True

            http.postChunked('/resources/licenseAwareness/pvuTable/%s' % os.path.basename(f.name), f)

            if doclose:
                f.close()

    PvuTable.import = PvuTable.import_
    if not utils.isIPAS():
       pvutable = PvuTable()


    #
    # deployer.licenseawareness.products[0]
    #
    # TODO - this really should be RESTResource, but server doesn't
    # support HTTP GET on /resources/licenseAwareness/product/{id}...
    @utils.classinit
    class Product(LocalResource):
        '''RM09518'''

        URI = '/resources/licenseAwareness/product/%s'

        @classmethod
        def _classinit(cls):
            cls._defineAttribute('enforcement', 'RM09526', values=('I','W','E'))
            cls._defineAttribute('totalallocation', 'RM09527', validator=validators.nonnegativeinteger)
            cls._defineAttribute('warningthreshold', 'RM09528', validator=utils.curryFunction(validators.floatrange, 0, 100))
            if not utils.isIPAS():
               cls._defineAttribute('created', 'RM09519', readonly=True)
               cls._defineAttribute('updated', 'RM09522', readonly=True)
            cls._defineAttribute('id', 'RM09520', readonly=True)
            cls._defineAttribute('type', 'RM09739', readonly=True)
            cls._defineAttribute('name', 'RM09521', readonly=True)
            cls._defineAttribute('productid', 'RM09524', readonly=True)
            cls._defineAttribute('currentallocation', 'RM09529', readonly=True)
            cls._defineAttribute('reservedallocation', 'RM09547', readonly=True)


        def __init__(self, attrs):
            super(LicenseAwareness.Product, self).__init__(attrs)
            self._uri = self.__class__.URI % attrs['id']


        def _localSetAttr(self, name, value):
            # horrible way to do this, but server side HTTP semantics don't
            # give us much choice
            self._validate(name, value)
            http.putJSON(self._uri, { 'id': self._localattrs['id'], name: value })
            self._localattrs[self.__class__._LOCALNAMES_[name]] = value


    #
    # deployer.licenseawareness.products
    #
    class Products(messages.Helpable):
        # TODO - need docstring

        LICENSE_AWARENESS_URI = '/resources/licenseAwareness/products'

        # TODO - use _classinit and _methodHelp() instead
        _METHODHELP_ = [
            '__contains__', '__getattr__', '__getitem__', '__iter__',
            '__len__', '__repr__', '__str__', '__unicode__'
        ]


        def __init__(self):
            self._prods = [ LicenseAwareness.Product(i) for i in http.get(self.LICENSE_AWARENESS_URI) ]

        def __contains__(self, item):
            'RM09013'
            self._prods = [ LicenseAwareness.Product(i) for i in http.get(self.LICENSE_AWARENESS_URI) ]
            return utils.any(self._prods, lambda it: it == item)


        def __getattr__(self, name):
            'RM09018'
            if name.startswith('__') and name.endswith('__'):
                raise AttributeError(name)
            self._prods = [ LicenseAwareness.Product(i) for i in http.get(self.LICENSE_AWARENESS_URI) ]
            return utils.find(lambda prod: prod.name == name, self._prods)


        def __getitem__(self, key):
            'RM09019'
            self._prods = [ LicenseAwareness.Product(i) for i in http.get(self.LICENSE_AWARENESS_URI) ]

            # int key -> get by index
            if isinstance(key, int) or isinstance(key, long):
                return self._prods[key]

            # str key -> defer to __getattr__
            elif isinstance(key, str) or isinstance(key, unicode):
                return self.__getattr__(key)

            raise TypeError('unsupported operand type for __getitem__: %s' % type(key))


        def __iter__(self):
            'RM09020'
            self._prods = [ LicenseAwareness.Product(i) for i in http.get(self.LICENSE_AWARENESS_URI) ]
            return iter(self._prods)


        def __len__(self):
            'RM09021'
            self._prods = [ LicenseAwareness.Product(i) for i in http.get(self.LICENSE_AWARENESS_URI) ]
            return len(self._prods)


        def __repr__(self):
            'RM09027'
            self._prods = [ LicenseAwareness.Product(i) for i in http.get(self.LICENSE_AWARENESS_URI) ]
            return utils.utos(unicode(self))


        def __str__(self):
            'RM09026'
            self._prods = [ LicenseAwareness.Product(i) for i in http.get(self.LICENSE_AWARENESS_URI) ]
            return repr(self)


        def __unicode__(self):
            'RM09026'
            self._prods = [ LicenseAwareness.Product(i) for i in http.get(self.LICENSE_AWARENESS_URI) ]

            if prettify.enabled:
                return prettify.prettify(self._prods)
            else:
                return unicode(self._prods)


    def products_(self):
        '''RM09530'''
        pass


    product = Product


    # products attribute

    _products = None

    def _getProducts(self):
        if not self._products:
            self._products = LicenseAwareness.Products()
        return self._products

    products = property(_getProducts, doc=messages.message('RM09530'))


    #
    # deployer.licenseawareness.highwatermarklicense.get(filename,productid,startdate,enddate,licensetype)
    # deployer.licenseawareness.highwatermarklicense.get('/tmp/highwater.csv','5724-X89',20100202,20100303,'PVU')
    #
    class HighwaterMarkLicense(object):
        'RM09532'

        def _getResponseHandler(self, f, resp):
            if resp.status > 299:
                raise IOError(utos(resp.reason))

            s = resp.read(100000)

            while s:
                f.write(s)
                s = resp.read(100000)


        def get(self, f, productid=None, start=None, end=None, licensetype=None):
            'RM09533'

            doclose = False

            if isinstance(f, str) or isinstance(f, unicode):
                if not f.lower().endswith('.csv'):
                    f = f + '.csv'
                f = file(f, 'wb')
                doclose = True

            parms = []
            if (licensetype==None):
                licensetype = 'PVU'
            if productid:
                parms.append('productid=%s,%s' % (productid, licensetype))
            if start:
                parms.append('startdate=%d' % start)
            if end:
                parms.append('enddate=%d' % end)

            if parms:
                uri = '/resources/licenseAwareness/highwaterMarkLicense?%s' % '&'.join(parms)
            else:
                uri = '/resources/licenseAwareness/highwaterMarkLicense'

            http.get(uri, responseHandler=utils.curryMethod(self._getResponseHandler, f))

            if doclose:
                f.close()

    highwatermarklicense = HighwaterMarkLicense()
    
    class VmwareLicense(object):
        
        _PROPERTYHELP_ = [ 'vcenterkey', 'esxikey' ]
        
        VMWARE_LICENSE_URI = '/admin/resources/hypervisor_keys'
        
        def _getKey(self, type="vcenter"):
            
            resp = http.get(self.VMWARE_LICENSE_URI)
            license = utils.find(lambda r: r.get('type') == type, resp)
            return license.get("license_key") if license else None
        
        def _setKey(self, key, type="vcenter"):
            
            resp = http.get('/admin/resources/hypervisor_keys')
            license = utils.find(lambda r: r.get('type') == type, resp)
            
            json = None
            
            if license:
                json = http.putJSON(license.get('id'), {'license_key': key})    
            else:
                json = http.postJSON(self.VMWARE_LICENSE_URI, {'type': type, 'license_key': key})
            
            return RESTResource.resourceForURI('/admin/resources/jobs/%s' % json.get('jobs')[0])
        
        def _getESXKey(self):
            return self._getKey(type = 'esxi')
        
        def _setESXKey(self, key):
            return self._setKey(key, type = 'esxi')
            
        vcenterkey = property(_getKey, _setKey)
        esxikey = property(_getESXKey, _setESXKey)
                
    vmwarelicense = VmwareLicense()