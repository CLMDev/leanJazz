"""
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2012. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
"""
import http
import string
import time
import utils

# refresh appliance version every 10mins
MAX_CACHE_TIME = 600

cachedVersion = None
cachedTimestamp = 0
cacheFSMVersion = None

def getFSMVersion():
    global cacheFSMVersion, cachedTimestamp

    if time.time() - cachedTimestamp > MAX_CACHE_TIME:
        cacheFSMVersion = None

    if not cacheFSMVersion:
        cacheFSMVersion = http.get('/admin/resources/version')
        #IPAS returns a string for version
        if isinstance(cacheFSMVersion, unicode) or isinstance(cacheFSMVersion, str):
            cacheFSMVersion = http._parseJSON(cacheFSMVersion)
        cachedTimestamp = time.time()

    return cacheFSMVersion

def getVersion():
    global cachedVersion, cachedTimestamp

    if time.time() - cachedTimestamp > MAX_CACHE_TIME:
        cachedVersion = None

    if not cachedVersion:
        cachedVersion = http.get('/resources/version')
        #IPAS returns a string for version
        if isinstance(cachedVersion, unicode) or isinstance(cachedVersion, str):
            cachedVersion = http._parseJSON(cachedVersion)
        cachedTimestamp = time.time()

    return cachedVersion


def getVersionAsIdentifier(prefix='_'):
    toid = '_' * ord('0') + string.digits + '_' * (ord('A') - ord('9') - 1) + string.ascii_uppercase + '_' * (ord('a') - ord('Z') - 1) + string.ascii_lowercase + '_' * (256 - ord('z') - 1)
    return prefix + utils.utos(getVersion()['version']).translate(toid)
