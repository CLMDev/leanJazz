#
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2012. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
#
from deployer import http, utils
from deployer.resources.restresource import RESTResource

@utils.classinit
class LicenseManagement(RESTResource):
    '''RM09397'''
    
    URI = '/resources/ilmt'

    @classmethod
    def _classinit(cls):
        cls._defaultRESTAttrs(True)

        cls._defineRESTAttribute('enabled', 'RM09398')
        cls._defineRESTAttribute('hostname', 'RM09399')
        cls._defineRESTAttribute('scangroup', 'RM09400')
    

    def __init__(self, uri, attrs=None):
        def munger(json):
            if json:
                return json[0]
            else:
                return {}

        super(LicenseManagement, self).__init__(uri, attrs, munge=munger)
