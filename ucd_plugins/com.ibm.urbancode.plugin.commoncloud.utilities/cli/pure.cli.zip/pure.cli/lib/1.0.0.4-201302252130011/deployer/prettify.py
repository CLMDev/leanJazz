"""
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2012. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
"""
import utils

from messages import message
from utils import utos

enabled = True

# pretty printer

class NestedObject(object):
    def __str__(self):
        return unicode(self)


    def __unicode__(self):
        return message('RM09131')


NESTED_OBJECT = NestedObject()


class UnquotedString(object):
    def __init__(self, s):
        self.s = s + u''


    def __unicode__(self):
        return self.s

        
class WriteOnly(object):
    def __str__(self):
        return unicode(self)


    def __unicode__(self):
        return message('RM09132')


WRITE_ONLY = WriteOnly()


def prettify(o, indentAmount = 2, quoteStrings=True, alwaysBreak=False):
    indent = u' ' * indentAmount
    
    if isinstance(o, list):
        pretty = [ prettify(x, indentAmount, quoteStrings) for x in o ]

        if utils.any(pretty, lambda s: s.find('\n') >= 0) or alwaysBreak:
            return u'[\n' + indent + \
                u',\n'.join(pretty).replace('\n', '\n' + indent) + \
                u'\n]'
        else:
            return u'[ ' + u', '.join(pretty) + u' ]'

    elif isinstance(o, dict):
        keys = o.keys()
        keys.sort()

        pretty = [ prettify(k, indentAmount, quoteStrings) + u': ' + prettify(o[k], indentAmount, quoteStrings) for k in keys ]
        
        return u'{\n' + indent + \
            (u',\n').join(pretty).replace('\n', '\n' + indent) + \
            u'\n}'

    elif isinstance(o, UnquotedString):
        return unicode(o)
    
    elif isinstance(o, str) or isinstance(o, unicode):
        if quoteStrings:
            return u'"' + o + u'"'
        else:
            return o + u''
        
    else:
        try:
            return unicode(o)
        except: 
            return unicode(str(o), 'utf_8')  # for 66147


class PrettyDict(dict):
    def __init__(self, d):
        self.update(d)

    
    def __repr__(self):
        return utos(unicode(self))
    

    def __unicode__(self):
        if enabled:
            return prettify(self)
        else:
            return unicode(self)
        
class PrettyList(list): 
    def __repr__(self):
        return utos(unicode(self))
    
    def __unicode__(self):
        if enabled:
            return prettify(self)
        else:
            return unicode(self)
