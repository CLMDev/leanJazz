"""
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2012. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
"""

from deployer import http, utils, validators
from restresource import RESTResource
from relationships import RelatedResource, RelatedResourceCollection
from commonattrs import CommonAttributes

from virtualimage import VirtualImage

@utils.classinit
class DeploySettings(RelatedResourceCollection, CommonAttributes):
    'IWD00004'
    
    _METHODHELP_=['list', 'update']
    
    @classmethod
    def _classinit(cls):
        cls._registerURI('/resources/workloadSettings')

    @classmethod
    def _restname(cls):
        return 'workloadSettings'
		
    def _list(self, filt = ''):
	    return http.get('%s/%s' % (self.uri, filt))
    
    @utils.docstring('IWD00005', 'IWD10082')
    def update(self, hypervisor, virtualimages):
        
        imgs = virtualimages
        if isinstance(virtualimages, VirtualImage):
            imgs = virtualimages.id
        elif utils.all(virtualimages, lambda s:isinstance(s, VirtualImage)):
            imgs = []
            for i in virtualimages:
                imgs.append(i.id)
        
        json = {"hypervisor_type" : hypervisor, "virtual_image": imgs}
        return http.putJSON(self.uri, json)
        

