#
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2012. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
#
"""
Licensed Materials - Property of IBM
IBM WebSphere CloudBurst Appliance (9235-72X)
Copyright IBM Corporation 2011. All Rights Reserved.
US Government Users Restricted Rights - Use, duplication or disclosure
restricted by GSA ADP Schedule Contract with IBM Corp.
"""

import deployer
from deployer import utils, validators, http, prettify
from restresource import RESTResource, RESTResourceCollection
from relationships import RelatedResource, RelatedResourceCollection
from commonattrs import CommonAttributes
from deployer.messages import Helpable
import urllib
import purescaleutils
import os

@utils.classinit
class Operation(RelatedResource, CommonAttributes):
    'RM09762'

    @classmethod
    def _classinit(cls):
        cls._registerURI(r'\A/resources/virtualApplications/[\dabcdef\-]+/operations/(?P<operation_id>[\dabcdefo\-]+)\Z')
        cls._defaultRESTAttrs(True)
        cls._getParams({ 'details': True })

        cls._defineRESTAttribute('operation_id', 'RM09764', readonly=True)
        cls._defineRESTAttribute('name', 'RM09765', readonly=True)
        cls._defineRESTAttribute('parameters', 'RM09766', readonly=True)
        cls._defineRESTAttribute('status', 'RM09767', restname='running_status', readonly=True)
        cls._defineRESTAttribute('result', 'RM09768', readonly=True)
        cls._defineRESTAttribute('role', '', readonly=True)
        cls._defineRESTAttribute('submit_time', '', readonly=True)
        cls._defineRESTAttribute('complete_time', '', readonly=True)
        cls._defineRESTAttribute('return_value', '', readonly=True)
        cls._defineRESTAttribute('type', '', readonly=True)
        cls._methodHelp('delete', 'refresh')

@utils.classinit
class Operations(RelatedResourceCollection):
    'RM09763'

    @classmethod
    def _classinit(cls):
        cls._contains(Operation)
        cls._methodHelp('__contains__', 'create', 'delete', '__delitem__',
                        '__getattr__', '__getitem__', '__iter__',
                        '__len__', 'list', '__lshift__', '__repr__',
                        '__rshift__', '__str__', '__unicode__',
                        'get','uploadArtifact')


    CREATE_ATTRIBUTES = [
        Operation._wizardStep('operation_id')
    ]

    def delete(self, operation_id):
        'RM09769'
        operation_id = purescaleutils.userInputChecker(operation_id, 'str')
        json = http.delete('%s/%s' % (self.uri, operation_id))
        return utils.utos(json)

    def create(self, d, role = None):
        'RM09770'
        if isinstance(d, dict):
            if isinstance(role, dict):
                d['role'] = role['name']
            
            elif role != None:
                purescaleutils.inputTypeErrorIndicator()
                
            if not 'parameters' in d:
                d['parameters'] = {}
                
            json = http.postJSON(self.uri, d)
            return RESTResource.resourceForURI('%s/%s' %(self.uri,json['operation_id']))
        else:
            purescaleutils.inputTypeErrorIndicator()
    
    def uploadArtifact(self, f):
        'RM09756'
        f = purescaleutils.userInputChecker(f, 'file')
        f = file(f, 'rb')
        try:
           fileNameAndExt = utils.stou(os.path.basename(f.name))
           index = self.uri.rfind('/')
           uri = self.uri[0 : index]
           json = http.restChunked('%s/operationArtifacts/%s' % (uri, fileNameAndExt), f, 'PUT', 'application/binary')
           return utils.utos(json)
        finally:
            f.close()
        
    
    def get(self, operation_id):
        'RM09771'
        operation_id = purescaleutils.userInputChecker(operation_id, 'str')
        return RESTResource.resourceForURI('%s/%s' % (self.uri, operation_id))

    def _getDefaultSearchField(self):
        return 'operation_id'

    def _uriForResource(self, attrs):
        return '%s/%s' % (self.uri, attrs['operation_id'])
