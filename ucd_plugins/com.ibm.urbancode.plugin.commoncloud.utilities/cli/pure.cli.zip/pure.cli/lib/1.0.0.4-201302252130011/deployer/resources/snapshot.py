"""
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2012. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
"""

from deployer import http, utils, validators
from commonattrs import CommonAttributes
from relationships import RelatedResource, RelatedResourceCollection


@utils.classinit
class Snapshot(RelatedResource, CommonAttributes):
    'RM09107'


    @classmethod
    def _classinit(cls):
        cls._registerURI(r'\A/resources/instances/\d+/snapshots/(?P<id>\d+)\Z')

        # TODO = need snapshot attrs
        cls._defineRESTAttribute('description', 'RM09512', validator=validators.string)

        cls._methodHelp('__contains__', '__delattr__', 'delete', '__eq__',
                        '__hash__', 'isStatusTransient', '__nonzero__',
                        'refresh', '__repr__', '__str__', '__unicode__',
                        'waitFor',
                        'restore')


    def restore(self):
        'RM09108'
        http.putJSON(self.uri, {'desiredstatus': 'RM01020'}) # Status.SNAPSHOT





@utils.classinit
class Snapshots(RelatedResourceCollection):
    'RM09177'


    @classmethod
    def _classinit(cls):
        cls._contains(Snapshot)
        cls._methodHelp('__contains__', 'create', 'delete', '__delitem__',
                        '__getattr__', '__getitem__', '__iter__',
                        '__len__', 'list', '__lshift__', '__repr__',
                        '__rshift__', '__str__', '__unicode__')
