"""
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2012. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
"""

from deployer import http, logging, messages, utils, validators
from deployer.messages import message
import re
from resource import ResourceCollection
from restresource import RESTResource, RESTResourceCollection
import sys


class RelatedResource(RESTResource):
    """Internal class that adds relationship logic to a RESTResource.
    """

    @staticmethod
    def _localfilter(filt, res):
        """Indicates if a resource matches a filter.

        This method is used to filter lists of resources in the CLI in
        cases where the server does not support the required
        filtering.
        """

        for key in filt:
            filtvalue = filt[key]
            resvalue = getattr(res, key, None)

            if filtvalue == None:
                if not resvalue == None:
                    return False

            elif isinstance(filtvalue, str) or isinstance(filtvalue, unicode):
                if not isinstance(resvalue, str) and not isinstance(resvalue, unicode):
                    return False

                elif resvalue.find(filtvalue) < 0:
                    return False

            elif isinstance(filtvalue, int) or isinstance(filtvalue, long):
                if not isinstance(resvalue, int) and not isinstance(resvalue, long):
                    return False

                elif resvalue != filtvalue:
                    return False

            else:
                raise ValueError('filter contains unrecognized type %s' % unicode(type(value)))

        return True



    # belongs-to relationship

    @classmethod
    def _belongsTo(cls, ownerClass, **options):
        """Defines a belongs-to relationship.

        Sets up a belongs-to relationship between Resources of this
        class and the specified owning Resource class.  That is, an
        instance of this class belongs to an instance of the owner
        class.


        Arguments

        ownerClass - class of the owning resource, must be a subclass
           of Resource


        Keyword arguments

        attrname - Name of the attribute that will be defined to represent the
           relationship.  Default is the lowercased name of the owning class.

        doc - Documentation to be associated with the new attribute.
           Defaults to owning class' docstring.

        readonly - Boolean indicating if the user is allowed to delete
           or change the owning resource.  Default is false (owning
           resource can be changed).

        restattrname - Name of attribute in _restattrs that stores
           owning resource's identity.  Defaults to attrname.  Note
           that 'uri' (for URI reference) or 'id' (for id reference)
           will be automatically appended to this value as necessary.
        """

        attrname = options.get('attrname', utils.englishlc(ownerClass.__name__))
        restattrname = options.get('restattrname', attrname)

        daOptions = {}

        if hasattr(cls, '_get' + utils.capitalize(attrname)):
            daOptions['fget'] = getattr(cls, '_get' + utils.capitalize(attrname))
        else:
            daOptions['fget'] = utils.curryMethod(cls._belongsToFget,
                                                attrname, restattrname, ownerClass)

        if options.get('readonly', False):
            pass
        elif hasattr(cls, '_set' + utils.capitalize(attrname)):
            daOptions['fset'] = getattr(cls, '_set' + utils.capitalize(attrname))
        else:
            daOptions['validator'] = utils.curryFunction(validators.instance,
                                                         ownerClass)
            daOptions['fset'] = utils.curryMethod(cls._belongsToFset,
                                                  attrname, restattrname, ownerClass)

        if options.get('readonly', False):
            pass
        elif hasattr(cls, '_del' + utils.capitalize(attrname)):
            daOptions['fdel'] = getattr(cls, '_del' + utils.capitalize(attrname))
        else:
            daOptions['fdel'] = utils.curryMethod(cls._belongsToFdel,
                                                  attrname, restattrname, ownerClass)

        if options.get('readonly', False):
            daOptions['readonly'] = True

        daOptions['elided'] = True

        cls._defineAttribute(attrname, options.get('doc', ownerClass.__doc__),
                             **daOptions)



    def _belongsToFget(self, attrname, restattrname, ownerClass):
        if self._restattrs.has_key(restattrname + 'uri'):
            logging.debug("RelatedResource._belongsToFget: building resource for uri %s" % self._restattrs[restattrname + 'uri'])
            return RESTResource.resourceForURI(self._restattrs.get(restattrname + 'uri'))

        elif self._restattrs.get(restattrname + 'id', 0) > 0:
            logging.debug("RelatedResource._belongsToFget: building %s for id %s" % (ownerClass, self._restattrs[restattrname + 'id']))
            return RESTResource._resourceForId(ownerClass, self._restattrs[restattrname + 'id'])
        else:
            return None


    def _belongsToFset(self, attrname, restattrname, ownerClass, ownerInstance):
        if ownerInstance:
            self._validate(attrname, ownerInstance)

        if self._restattrs.has_key(restattrname + 'uri'):
            if ownerInstance == None:
                self._restattrs[restattrname + 'uri'] = None
            else:
                self._restattrs[restattrname + 'uri'] = ownerInstance.uri

        else:
            if ownerInstance == None:
                self._restattrs[restattrname + 'id'] = 0
            else:
                self._restattrs[restattrname + 'id'] = ownerInstance._restattrs['id']


    def _belongsToFdel(self, attrname, restattrname, ownerClass):
        setattr(self, attrname, None)




    # contained-by relationship

    # TODO - not tested yet
    @classmethod
    def _containedBy(cls, containerClass, **options):
        """Defines a contained-by relationship.

        Sets up a contained-by relationship between this Resource
        class and the containing Resource class.


        Arguments

        containerClass - class of the containing resource, must be a
           subclass of Resource


        Keyword arguments

        attrname - Name of the attribute that will be defined to
           represent the relationship.  Default is the lowercased name
           of the containing class.

        doc - Documentation to be associated with the new attribute.
           Defaults to containing class' docstring.
        """

        attrname = options.get('attrname', utils.englishlc(containerClass.__name__))

        cls._defineAttribute(attrname,
                             options.get('doc', containerClass.__doc__),
                             fget=cls._containedByFget,
                             readonly=True, elided=True)


    def _containedByFget(self):
        #workload REST resources' id contains \w, \d and -, especially artifact's id is file name
        #last regular expression is .+, unless we can specify it for files
        urire = re.compile(r'\A(.+/[\d\w\-]+)/%s/.+\Z' % utils.pluralize(self.__class__._restname()))
        return RESTResource.resourceForURI(urire.match(self.uri).group(1))




    # contains relationship

    # TODO - not fixed yet
    @classmethod
    def _contains(cls, containedCollClass, **options):
        """Defines a containment relationship.

        Sets up a containment relationship between this Resource class
        and the contained RESTResourceCollection.


        Arguments

        containedCollClass - class of the contained collection, must
           be a subclass of RESTResourceCollection


        Keyword arguments

        attrname - Name of the attribute that will be defined to
           represent the relationship.  Default is the lowercased name
           of the contained class.

        doc - Documentation to be associated with the new attribute.
           Defaults to contained class' docstring.
        """

        # _containsInit needs RESTResourceCollection
        assert issubclass(containedCollClass, RESTResourceCollection)

        attrname = options.get('attrname', utils.englishlc(containedCollClass.__name__))

        cls._defineAttribute(attrname,
                             options.get('doc', containedCollClass.__doc__),
                             fget=utils.curryMethod(RelatedResource._containsFget, containedCollClass),
                             readonly=True, elided=True)


    def _containsFget(self, containedCollClass):
        return containedCollClass('%s/%s' % (self.uri, containedCollClass._restname()))




    # has-many relationship

    @classmethod
    def _hasMany(cls, ownedCollClass, **options):
        """Defines a one-many relationship

        Sets up a has-many relationship between Resources of this
        class and the specified owned Resource class.  That is, an
        instance of this class has many instances of the owned class.

        Note that in order for the relationship to work correctly the
        owned (non-collection) class must define a belongs-to
        relationship to this class.  The ResourceCollection that
        represents the owned resources assumes this belongs-to
        relationship has been defined.


        Arguments

        ownedCollClass - class of the owned resource, must be a subclass
           of ResourceCollection


        Keyword arguments

        attrname - Name of the attribute that will be defined to
           represent the relationship.  Default is the lowercased name
           of the owned class.

        doc - Documentation to be associated with the new attribute.
           Defaults to owned class' docstring.  Note the provided
           documentation should only describe the nature of the
           relationship.  This method automatically appends
           documentation that describes the generic semantics of the
           has-many relationship.

        ownedattrname - Name of the attribute in the owned resource
           that references the owner.  Note that the value of this
           attribute in the owned resource is compared to the owner
           using ==.  Default is the lowercased name of the owner's
           class.
        """

        attrname = options.get('attrname', utils.englishlc(ownedCollClass.__name__))
        doc = message(options.get('doc', ownedCollClass.__doc__))
        doc += '\n\n' + messages.docstring(cls.HasManyResourceCollection)

        for method in ('add', '__contains__', '__delitem__', '__getitem__', '__iter__', '__len__', 'list', '__lshift__', 'remove', '__repr__', '__rshift__', '__str__', '__unicode__'):
            doc += '\n\n' + method + '\n' + messages.indent(messages.docstring(getattr(cls.HasManyResourceCollection, method)))

        cls._defineAttribute(attrname, doc,
                             fget=utils.curryMethod(cls.
                                                       _hasManyFget,
                                                    ownedCollClass, options),
                             readonly=True, elided=True)


    class HasManyResourceCollection(ResourceCollection):
        'RM09183'

        def __init__(self, owner, ownedCollClass, **options):
            self.ownedAttrName = options.get('ownedattrname', utils.englishlc(owner.__class__.__name__))
            self.owner = owner
            self.ownedCollClass = ownedCollClass


        def _add(self, other):
            self.ownedCollClass._verifyResourceType(other)

            # assumes that other has a belongs-to relationship with
            # self.owner.__class__
            setattr(other, self.ownedAttrName, self.owner)


        def _list(self, filt = {}):
            logging.debug("RelatedResource.HasManyResourceCollection._list: filt: %s" % filt)

            count = filt.get('count', sys.maxint)
            if filt.has_key('count'):
                del filt['count']

            result = []
            if count > 0:
                # TODO - unnecessary if/when REST API returns URIs
                for res in self.ownedCollClass():
                    if getattr(res, self.ownedAttrName) == self.owner and RelatedResource._localfilter(filt, res):
                        result.append(res)
                    if len(result) >= count:
                        break

            return result

        #in _remove, the argument is resource's id instead of resource
        def remove(self, other):
            'RM09024'
            self._verifyResourceType(other)
            # assumes that other has a belongs-to relationship with
            # self.owner.__class__
            delattr(other, self.ownedAttrName)


        def _verifyResourceType(self, res):
            self.ownedCollClass._verifyResourceType(res)


    def _hasManyFget(self, ownedCollClass, options):
        return self.__class__.HasManyResourceCollection(self, ownedCollClass, **options)




    # many-many relationship

    @classmethod
    def _manyManyLinksTo(cls, otherCollClass, **options):
        """Defines one side of a many-many relationship.

        This method sets up one half of a many-many relationship.
        That is, it defines the behavior that lets instances of this
        RelatedResource class access the multiple instances of the
        other RESTResourceCollection.

        Note that in order for the relationship to work correctly the
        other class must define a many-many relationship to this
        class.  Nothing breaks per se if the mirrored relationship
        does not exist; it just looks stupid.


        Arguments

        otherCollClass - class of the other resources, must be a
           subclass of RESTResourceCollection


        Keyword arguments

        attrname - Name of the attribute that will be defined to
           represent the relationship.  Default is the lowercased name
           of the other collection class.

        doc - Documentation to be associated with the new attribute.
           Defaults to other class' docstring.  Note the provided
           documentation should only describe the nature of the
           relationship.  This method automatically appends
           documentation that describes the generic semantics of the
           many-many relationship.

        listfilter - See description in ManyManyResourceCollection.__init__
        """

        attrname = options.get('attrname', utils.englishlc(otherCollClass.__name__))
        doc = message(options.get('doc', otherCollClass.__doc__))
        doc += '\n\n' + messages.docstring(cls.ManyManyResourceCollection)

        for method in ('add', '__contains__', '__delitem__', '__getitem__', '__iter__', '__len__', 'list', '__lshift__', 'remove', '__repr__', '__rshift__', '__str__', '__unicode__'):
            doc += '\n\n' + method + '\n' + messages.indent(messages.docstring(getattr(cls.ManyManyResourceCollection, method)))

        mmfgetopts = {}
        if options.has_key('listfilter'):
            mmfgetopts['listfilter'] = options['listfilter']

        cls._defineAttribute(attrname, doc,
                             fget=utils.curryMethod(RelatedResource.
                                                       _manyManyFget,
                                                    otherCollClass,
                                                    **mmfgetopts),
                             readonly=True, elided=True)


    class ManyManyResourceCollection(ResourceCollection):
        'RM09183'

        def __init__(self, this, otherCollClass, **options):
            """Collection of resources associated with a particular resource
            via a many-many relationship.

            Arguments

            this - Instance of RelatedResource that represents a
               resource on one side of the relationship.

            otherCollClass - subclass of RESTResourceCollection that
               represents the resource collection on the other side of
               the relationship.


            Keyword arguments

            listfilter - callable that can be used to filter which resources
               in otherCollClass are included in the output of _list().
               Callable should accept a RESTResource and return True/False
               to indicate if it should be included in the _list() result.
            """

            # TODO - can remove if/when REST API returns URIs
            if not issubclass(otherCollClass, RESTResourceCollection):
                raise TypeError('ResourceCollection must be RESTResourceCollection')

            self.type1 = utils.pluralize(this.__class__._restname())
            self.id1 = this.id

            self.coll2 = otherCollClass
            self.type2 = otherCollClass._restname()

            self.uri = [ self.type1, self.type2 ]
            self.uri.sort()
            self.uri = '/resources/%s' % ''.join(self.uri)

            self.options = options


        def _add(self, other):
            http.postJSON(self.uri, { '%sid' % self.type1: self.id1,
                                      '%sid' % self.type2: other.id } )


        def _list(self, filt = {}):
            count = filt.get('count', sys.maxint)
            if filt.has_key('count'):
                del filt['count']

            result = []
            if count > 0:
                # TODO - unnecessary if/when REST API returns URIs
                collInst = self.coll2()
                listFilter = self.options.get('listfilter', lambda r: True)

                for json in http.get('%s?%sid=%s' % (self.uri, self.type1, self.id1)):
                    res = collInst._get(json[self.type2 + 'id'])
                    if listFilter(res) and RelatedResource._localfilter(filt, res):
                        result.append(res)
                    if len(result) >= count:
                        break

            return result


        def _remove(self, otherId):
            if self.type1 < self.type2:
                joinId = '%s-%s' % (self.id1, otherId)
            else:
                joinId = '%s-%s' % (otherId, self.id1)

            http.delete('%s/%s' % (self.uri, joinId))


        def _verifyResourceType(self, res):
            self.coll2._verifyResourceType(res)



    def _manyManyFget(self, otherCollClass, **options):
        return self.__class__.ManyManyResourceCollection(self, otherCollClass, **options)





class RelatedResourceCollection(RESTResourceCollection):
    pass
