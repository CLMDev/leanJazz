"""
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2012. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
"""

import re
import urllib
import sys


resolvers = []
MSGRE = re.compile(r'(RM|IWD)\d{5}')
MSGARGSRE = re.compile(r'((?:RM|IWD)\d{5})\((.*?)\)')


class Helpable(object):
    """Helper class for objects that provide method and/or property help.
    """

    @classmethod
    def _methodHelp(cls, *methods):
        """Registers method names to be included in the class docstring.
        """

        try:
            cls._METHODHELP_.extend(methods)
        except AttributeError:
            cls._METHODHELP_ = []
            cls._METHODHELP_.extend(methods)


    @classmethod
    def _propertyHelp(cls, *properties):
        """Registers property names to be included in the class docstring.
        """

        try:
            cls._PROPERTYHELP_.extend(properties)
        except AttributeError:
            cls._PROPERTYHELP_ = []
            cls._PROPERTYHELP_.extend(properties)


    
def _addnewlines(s, maxlen=75):
    s = s.strip()

    if len(s) <= maxlen:
        return s

    space = s.rfind(' ', 0, maxlen)
    if space < 0:
        space = maxlen
    
    return s[:space] + '\n' + _addnewlines(s[space:], maxlen)


def docstring(o):
    if o is None:
        infoUrl = sys.registry.get('infocenter.url')
        doc = message('RM09003', infoUrl) if infoUrl else message('RM09003')
        
    elif not hasattr(o, '__doc__') or o.__doc__ is None:
        doc = message('RM09005', repr(o))

    elif not MSGRE.match(o.__doc__):
        doc = o.__doc__

    else:
        doc = message(o.__doc__)

    if hasattr(o, '_METHODHELP_'):
        o._METHODHELP_.sort(_uscorecmp)
        doc += message('RM09012', indent(_addnewlines(', '.join([ m for m in o._METHODHELP_ ]))))

    if hasattr(o, '_PROPERTYHELP_'):
        o._PROPERTYHELP_.sort(_uscorecmp)
        doc += message('RM09127', indent(_addnewlines(', '.join([ p for p in o._PROPERTYHELP_ ]))))

    if o.__doc__ == 'RM09015' and hasattr(o, 'im_class') and hasattr(o.im_class, 'CREATE_ATTRIBUTES'):
        reqd = ''
        opt = ''

        for attr in o.im_class.CREATE_ATTRIBUTES:
            if attr.get('optional', False):
                opt += '\n' + attr['name'] + '\n' + indent(attr.get('help', '')) + '\n'
            else:
                reqd += '\n' + attr['name'] + '\n' + indent(attr.get('help', '')) + '\n'

        if opt:
            doc += message('RM09797', reqd, opt)
        else:
            doc += message('RM09796', reqd)

    return doc


def indent(s, indent=3):
    return (' ' * indent) + s.replace('\n', '\n' + ' ' * indent)


def localize(m):
    """Method decorator that localizes the method's return value.

    Use as:

       @localize
       def foo(self, arg):
           return 'RM12345'
    """

    def _localize(*args):
        result = m(*args)
        return message(result)

    return _localize

        
def message(msg, *inserts):
    inserts = [ x for x in inserts ]

    if msg == None:
        return msg
    
    if msg.find('(') >= 0:
        m = MSGARGSRE.match(msg)
        if m:
            msg = m.group(1)

            for insert in m.group(2).split(','):
                insert = message(urllib.unquote_plus(insert[1:-1]))
                inserts.append(insert)

    if MSGRE.match(msg):
        for r in resolvers:
            resolved = r.resolve(msg)
            if resolved:
                msg = resolved
                break

    for i in range(0, len(inserts)):
        insert = inserts[i] if type(inserts[i]) in [ 'str', 'unicode' ] else unicode(inserts[i])
        msg = msg.replace('${%d}' % i, insert)
   
    if sys.registry.get('product.name'):
       msg = msg.replace('$PRODUCT_NAME', sys.registry.get('product.name'))
    
    return msg


def _uscorecmp(x, y):
    return cmp(x.strip('_'), y.strip('_'))
