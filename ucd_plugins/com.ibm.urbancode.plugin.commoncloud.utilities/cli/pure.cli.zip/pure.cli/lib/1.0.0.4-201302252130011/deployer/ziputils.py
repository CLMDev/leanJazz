#
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2012. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
#

from java.io import File, FileInputStream, BufferedInputStream, FileOutputStream, BufferedOutputStream
from java.util.zip import GZIPInputStream, GZIPOutputStream
from org.apache.commons.compress.archivers.tar import TarArchiveInputStream, TarArchiveOutputStream, TarArchiveEntry
import jarray
import os

BUFFER_SIZE = 4096

def _tar(tarOutput, directory, folder = ""):    
    for item in os.listdir(os.path.join(directory, folder)):
        path = os.path.join(directory, folder, item)
        file = File(path);
        tarEntry = TarArchiveEntry(file);
        tarEntry.setName(os.path.join(folder, item))
        tarOutput.putArchiveEntry(tarEntry);
        if os.path.isfile(path):
            fis = FileInputStream(file);
            bis = BufferedInputStream(fis)
            buf = jarray.zeros(BUFFER_SIZE, 'b')

            try:
                len = bis.read(buf)
                while len > 0 :
                    tarOutput.write(buf, 0, len)
                    len = bis.read(buf)
                tarOutput.closeArchiveEntry();
            finally:                
                if bis:
                   bis.close()
                if fis:
                   fis.close()
               
        elif os.path.isdir(path):
            _tar(tarOutput, directory, os.path.join(folder, item))
     

def compress(src, dest):
    output = None
    bufOutput = None
    gzipOutput = None
    tarOutput = None
    
    try:
        output = FileOutputStream(File(dest));
        bufOutput = BufferedOutputStream(output);
        gzipOutput = GZIPOutputStream(bufOutput);
        tarOutput = TarArchiveOutputStream(gzipOutput);
        tarOutput.setLongFileMode(TarArchiveOutputStream.LONGFILE_GNU);
        tarOutput.setBigNumberMode(TarArchiveOutputStream.BIGNUMBER_STAR);
        _tar(tarOutput, src)
        
    finally:
        if tarOutput:
            tarOutput.close()
        if gzipOutput:
            gzipOutput.close()
        if bufOutput:
            bufOutput.close()
        if output:
            output.close()


def copyEntryContentsToFile(tarInput, dataRemaining, destFile):
    
    try:
        fileOutput = FileOutputStream(destFile)

        buffer = jarray.zeros(BUFFER_SIZE, 'b')
        bytesRead = 0
        while ((bytesRead != -1) and (dataRemaining > 0)):
            bytesRead = tarInput.read(buffer);
            fileOutput.write(buffer, 0, bytesRead);
            dataRemaining -= bytesRead

    finally:
        if fileOutput:
            fileOutput.close();


def extract(src, destDir):
    input = None
    bufInput = None
    gzipInput = None
    tarInput = None
    try:
        input = FileInputStream(File(src));
        bufInput = BufferedInputStream(input);
        gzipInput = GZIPInputStream(bufInput);
        tarInput = TarArchiveInputStream(gzipInput);
    
        tarEntry = tarInput.getNextTarEntry()
    
        while (tarEntry):
            destFile = File(destDir, tarEntry.getName());
            if tarEntry.isDirectory():
                if not destFile.exists():
                    destFile.mkdirs()
            else:
                dataSize = tarEntry.getSize();
                copyEntryContentsToFile(tarInput, dataSize, destFile)

            tarEntry = tarInput.getNextTarEntry()
    
    finally:
        if tarInput:
            tarInput.close()
        if gzipInput:
            gzipInput.close()
        if bufInput:
            bufInput.close()
        if input:
            input.close()