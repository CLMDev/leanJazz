"""
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2012. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
"""

from cloud import Cloud
import deployer
from deployer import facetutils, http, patterntopython, prettify, utils, validators, patternloader, patternutils
from deployer.messages import message
from deployer.utils import utos
from commonattrs import CommonAttributes
from envprofile import EnvironmentProfile
from relationships import RelatedResource, RelatedResourceCollection
from restresource import RESTResource
import urllib
import os
from deployer import mappingutils


@utils.classinit
class Pattern(RelatedResource, CommonAttributes):
    'RM09085'


    @classmethod
    def _classinit(cls):
        cls._registerURI(r'\A/resources/patterns/(?P<id>\d+)\Z')

        # info verified with Michael Kalantar/Bill Arnold, 2009Apr03 2:30pm
        cls._defineAttribute('acl', 'RM09189', readonly=True, readonlydoc=False, elided=True)
        cls._defineAttribute('advancedoptions', 'RM09042', elided=True)
        # cloudcapacity - hidden
        # counter - hidden
        cls._defineRESTAttribute('created', 'RM09192', readonly=True)
        cls._defineRESTAttribute('currentmessage', 'RM09193', readonly=True)
        cls._defineAttribute('currentmessage_text', 'RM09154', readonly=True)
        cls._defineRESTAttribute('currentstatus', 'RM09194', values=('RM01028',))
        cls._defineAttribute('currentstatus_text', 'RM09156', readonly=True)
        cls._defineRESTAttribute('description', 'RM09195', validator=validators.string)
        cls._defineRESTAttribute('id', 'RM09196', readonly=True)
        cls._defineRESTAttribute('name', 'RM09197', readonly=True)
        cls._defineRESTAttribute('updated', 'RM09198', readonly=True)
        cls._defineAttribute('validationmessage', 'RM09199', readonly=True)
        cls._defineAttribute('validationmessage_text', 'RM09186', readonly=True)
        cls._defineAttribute('validations', 'RM09537', readonly=True)
        cls._defineAttribute('validationstatus', 'RM09200', readonly=True)
        cls._defineAttribute('validationstatus_text', 'RM09188', readonly=True)
        # deprecated, no longer returned from server
        cls._defineAttribute('virtualimage', 'RM09201', fdel=None, elided=True)

        cls._methodHelp('__contains__', '__delattr__', 'delete', '__eq__',
                        '__hash__', 'isStatusTransient', '__nonzero__',
                        'refresh', '__repr__', '__str__', '__unicode__',
                        'waitFor',
                        'clone', 'isDraft', 'isReadOnly', 'listConfig',
                        'makeReadOnly', 'runInCloud', 'toPython', 'save')


    class AdvancedOptions(object):
        def __init__(self, pattern):
            self.pattern = pattern
            self.config = facetutils.getConfig(self.pattern)
            if not self.config:
                raise ValueError('')


        def _save(self):
            facetutils.setConfig(self.pattern, self.config)


        def add(self, key, save=True):
            if isinstance(key, list):
                for o in key:
                    self.add(o, False)

            else:
                self.config.select(key)

            if save:
                self._save()


        def clear(self, save=True):
            self.config.unselectAll()
            if save:
                self._save()


        def __contains__(self, item):
            return item in self.config.getSelected()


        def getAvailableOptions(self):
            return self.config.getDefined()


        def __iadd__(self, other):
            self.add(other)
            return self


        def __isub__(self, other):
            self.remove(other)
            return self


        def __iter__(self):
            return iter(self.config.getSelected())


        def __len__(self):
            return len(self.config.getSelected())


        def remove(self, other, save=True):
            if isinstance(other, list):
                for o in other:
                    self.remove(o, False)

            else:
                self.config.unselect(other)

            if save:
                self._save()


        def __repr__(self):
            return utos(unicode(self))


        def __str__(self):
            return repr(self)


        def __unicode__(self):
            if prettify.prettify:
                return self.config.prettify()
            else:
                return unicode(self.config)


    def _getAdvancedoptions(self):
        if not hasattr(self, '_advancedoptions') or not self._advancedoptions:
            try:
                self._advancedoptions = self.__class__.AdvancedOptions(self)
            except:
                self._advancedoptions = None

        return self._advancedoptions


    def _setAdvancedoptions(self, value):
        self._getAdvancedoptions()

        if value is self._advancedoptions:
            pass

        elif isinstance(value, list) or isinstance(value, str) or instance(value, unicode):
            self._advancedoptions.clear(False)
            self._advancedoptions.add(value)

        else:
            raise ValueError(utos(message('RM09106', unicode(value))))


    def _getCloudcapacity(self):
        return http.postJSON('/resources/instancesQuery', { 'patternid': self._restattrs['id'] })


    def _getValidationmessage(self):
        for validation in self._getValidations():
            return validation['message']

        return None


    def _getValidationmessage_text(self):
        for validation in self._getValidations():
            return validation['message_text']

        return None


    def _getValidations(self):
        validations = self._restattrs['validation']

        for validation in validations:
            validation['status_text'] = message(validation['status'])
            validation['message_text'] = message(validation['message'])

        return validations


    def _getValidationstatus(self):
        for validation in self._getValidations():
            return validation['status']

        return None


    def _getValidationstatus_text(self):
        for validation in self._getValidations():
            return validation['status_text']

        return None


    def _getVirtualimage(self):
        vi = None

        vis = [ ppart.virtualimage for ppart in self.parts ]
        if len(vis) > 0 and utils.all(vis, lambda vi: vi == vis[0]):
            vi = RESTResource.resourceForURI('/resources/templates/%s' % vis[0].id)

        return vi


    def _setVirtualimage(self, vi):
        validators.instance(VirtualImage, vi, 'virtualimage')
        Patterns._setCachedVI(self, vi)


    def clone(self, **options):
        'RM09086'

        options = utils.stou(options)

        for k in options:
            if k not in ['name', 'description', 'virtualimage']:
                raise ValueError(utos(message('RM09367', k)))

        oldPattern = http.get(self.uri + '?' + urllib.urlencode({ 'patternmodelstring': 'true' }))

        newPattern = {
            'name': options.get('name', 'Copy of ' + oldPattern['name']),
            'patternmodelstring': oldPattern['patternmodelstring']
        }

        if options.has_key('description'):
            newPattern['description'] = options['description']
        elif oldPattern.has_key('description'):
            newPattern['description'] = oldPattern['description']

        patternsURI = self.uri[0:self.uri.rfind('/')]
        newJSON = http.postJSON(patternsURI, newPattern)

        newPattern = RESTResource.resourceForURI('%s/%s' % (patternsURI, newJSON['id']))

        newVI = options.get('virtualimage')
        if newVI:
            for newPpart in newPattern.parts:
                newPpart.virtualimage = newVI

        return newPattern

	
    def save(self, dest, **options):
        'RM09980'
        doclose = False
        patternloader.patternToJSON(self, dest, **options)

    def toPython(self, f, **options):
        'RM09494'
        doclose = False

        if isinstance(f, str) or isinstance(f, unicode):
            f = file(f, 'wb')
            doclose = True

        try:
            patterntopython.patternToPython(self, f, options.get('includePasswords', False))

        finally:
            if doclose:
                f.close()


    def isDraft(self):
        'RM09087'
        return self.currentstatus == 'RM01027'


    def isReadOnly(self):
        'RM09088'
        return self.currentstatus == 'RM01028'


    def listConfig(self, data={}):
        'RM09226'
        pattern = patternutils.getPattern(self.uri)
        return prettify.PrettyDict(patternutils.listConfig(pattern, data))


    def makeReadOnly(self):
        'RM09089'
        self.currentstatus = 'RM01028'


    def runInCloud(self, cloudorep, dict={}):
        'RM09090'
        cloudorep = mappingutils.getMappingResource(cloudorep)
        
        d = dict.copy()
        d['pattern'] = self

        if isinstance(cloudorep, Cloud):
            d['cloud'] = cloudorep
        elif isinstance(cloudorep, EnvironmentProfile):
            d['environmentprofile'] = cloudorep

        return deployer.virtualsystems.create(d)




@utils.classinit
class Patterns(RelatedResourceCollection):
    'RM09036'


    @classmethod
    def _classinit(cls):
        cls._contains(Pattern)
        cls._methodHelp('__contains__', 'create', 'delete', '__delitem__',
                        '__getattr__', '__getitem__', '__iter__',
                        '__len__', 'list', '__lshift__', '__repr__',
                        '__rshift__', '__str__', '__unicode__')


    CREATE_ATTRIBUTES = [
        Pattern._wizardStep('name'),
        Pattern._wizardStep('description', optional=True),
    ]


    _cachedVIs = {}


    def __init__(self, uri=None, **options):
        options['useListAttrs'] = False
        super(Patterns, self).__init__(uri, **options)


    def _create(self, dict):
        patternvi = None
        if dict.has_key('virtualimage'):
            patternvi = dict['virtualimage']
            del dict['virtualimage']

        pattern = super(Patterns, self)._create(dict)

        if patternvi:
            self.__class__._cachedVIs[pattern.id] = patternvi

        return pattern


    @classmethod
    def _getCachedVI(cls, pattern):
        if isinstance(pattern, Pattern):
            id = pattern.id
        else:
            id = pattern

        return cls._cachedVIs.get(id)


    @classmethod
    def _setCachedVI(cls, pattern, vi):
        if isinstance(pattern, Pattern):
            id = pattern.id
        else:
            id = pattern

        cls._cachedVIs[id] = vi

    def load(self, dest, **options):
        'RM09981'

        patternloader.JSONtoPattern(self, dest)
