"""
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2011. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
"""

from commonattrs import CommonAttributes
from deployer import http, utils, validators
from relationships import RelatedResource, RelatedResourceCollection
from restresource import RESTResource


@utils.classinit
class Group(RelatedResource, CommonAttributes):
    'RM09073'


    @classmethod
    def _classinit(cls):
        cls._registerURI(r'\A/resources/groups/(?P<id>\d+)\Z')

        cls._defineRESTAttribute('created', 'RM09144', readonly=True)
        cls._defineRESTAttribute('description', 'RM09145', validator=validators.string, readonly=True)
        cls._defineRESTAttribute('id', 'RM09146', readonly=True)
        cls._defineRESTAttribute('name', 'RM09147', validator=validators.string, readonly=True)
        cls._defineAttribute('roles', cls.Roles.__doc__, validator=validators.noop, readonly=True)
        cls._defineRESTAttribute('updated', 'RM09148', readonly=True)

        cls._methodHelp('refresh')



    class Roles(object):
        'RM09424'

        ROLES = [ object(), object(), 'CLOUD_USER', 'CLOUD_ADMIN',
                  'APPLIANCE_ADMIN', 'CATALOG_CREATOR', 'PATTERN_CREATOR', 'ILMT_USER',
                  'CLOUD_ADMIN_READONLY', 'APPLIANCE_ADMIN_READONLY','PROFILE_CREATOR',
                  'REPORT_READONLY', object(), 'AUDIT_READONLY', 'AUDIT', 'HARDWARE']

        def __init__(self, group):
            self.group = group

        def __iter__(self):
            'RM09427'
            json = http.get('%s/roles' % self.group.uri)
            return iter([ self.ROLES[r] for r in range(0, len(self.ROLES)) if r in json and isinstance(self.ROLES[r], str)])


        def __repr__(self):
            'RM09431'
            return utils.utos(unicode(self))

        def __str__(self):
            'RM09430'
            return repr(self)


        def __unicode__(self):
            'RM09430'
            return unicode(list(self))


    def __init__(self, uri, attrs = None):
        super(Group, self).__init__(uri, attrs)
        self._roles = self.__class__.Roles(self)


    def _getRoles(self):
        return self._roles
        
    def delete(self, id):
        raise NotImplementedError('delete')


@utils.classinit
class Groups(RelatedResourceCollection):
    'RM09029'

    @classmethod
    def _classinit(cls):
        cls._contains(Group)
        cls._methodHelp('list')

    def create(self, dict):
        raise NotImplementedError('create')
    
    def delete(self, id):
        raise NotImplementedError('delete')
