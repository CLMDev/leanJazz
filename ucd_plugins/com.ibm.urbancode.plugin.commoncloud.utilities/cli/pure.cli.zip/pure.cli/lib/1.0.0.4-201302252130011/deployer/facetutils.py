"""
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2012. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
"""

import http
import prettify as prettifyx
import utils

from messages import message
from utils import utos

import re
OPTIONRE = re.compile(r'\A(.+?)\d*\Z')

class Config(object):
    def getDefined(self):
        result = []
        
        for facet in  self.facets:
            result.extend(facet.getDefined())
        return result

    
    def getSelected(self):
        result = []

        for facet in  self.facets:
            result.extend(facet.getSelected())
        return result

    
    def __init__(self, raw):
        self.raw = raw
        self.facets = [Facet(r, self) for r in raw]
        for facet in self.facets:
            facet.parentSelected() 


    def select(self, name):
        exist = False
        
        for facet in self.facets:
            if facet.select(name):
                exist = True
                break

        if not exist:
            raise ValueError(utos(message('RM09106', unicode(name))))


    def prettify(self):
        s = ''
        for facet in self.facets:
            s += facet.prettify(0)
        return s


    def __repr__(self):
        return utos(unicode(self))


    def __str__(self):
        return repr(self)

    
    def __unicode__(self):
        return unicode(self.raw)


    def unselect(self, name):
        exist = False
        
        for facet in self.facets:
            if facet.unselect(name):
                exist = True
                break
                
            
        if not exist:
            raise ValueError(utos(message('RM09106', unicode(name))))


    def unselectAll(self):
         for facet in self.facets:
             facet.unselectAll()
    
        

class Facet(object):
    def getDefined(self):
        result = []

        if self.eo:
            result.append(self.eo.name())

        for o in self.options:
            result.append(o.name())

        for f in self.facets:
            result.extend(f.getDefined())

        return result

    
    def getSelected(self):
        result = []
        
        if self.eo and self.eo.isSelected():
            result.append(self.eo.name())

        for o in self.options:
            if o.isSelected():
                result.append(o.name())

        for f in self.facets:
            result.extend(f.getSelected())

        return result

        
    def __init__(self, raw, parent):
        self.raw = raw
        self.parent = parent

        if raw.has_key('enablementoptionkey'):
            self.eo = Option(utils.find(lambda o: o['name'] == raw['enablementoptionkey'], raw['options']), self)
          #  if self.eo.isDefault() and self.eo.getSelected() == None:
          #     self.eo.select()
        else:
            self.eo = None

        self.options = [ Option(x, self) for x in raw.get('options', []) if x['name'] != raw['enablementoptionkey'] ]
        self.facets = [ Facet(x, self) for x in raw.get('facets', []) ]


    def name(self):
        if self.eo:
            return self.eo.name()
        else:
            return self.raw['name']


    def isOptionSelected(self):
        return utils.any(self.options, lambda o: o.isSelected())


    def isRadioButton(self):
        return self.raw['mincardinality'] == 1 and self.raw['maxcardinality'] == 1

    
    def parentSelected(self):
        if not self.eo or self.eo.isSelected():
            for o in self.options:
                o.parentSelected()

            for f in self.facets:
                f.parentSelected()


    def prettify(self, indent):
        if self.eo:
            s = self.eo.prettify(True, indent)
        else:
            s = u'%s%s ("%s")\n' % (u' ' * indent, self.raw['name'], self.raw['label'])

        for o in self.options:
            if o is self.eo:
                continue
        
            s += o.prettify(False, indent + 2)
        
        for f in self.facets:
            s += f.prettify(indent + 2)

        return s
    #ignore the index at end and compare others
    def isKeysEqual(self, k1, k2):
        m1 = OPTIONRE.match(k1)
        m2 = OPTIONRE.match(k2)
        if m1 and m2 and m1.group(1) == m2.group(1):
            return True
        return False
            
    def select(self, name):
        if self.eo and (self.eo.name() == name or self.isKeysEqual(self.eo.name(), name)):
            self.eo.select()

            for o in self.options:
                o.parentSelected()

            for f in self.facets:
                f.parentSelected()

            return True

        match = utils.find(lambda o: o.name() == name or self.isKeysEqual(o.name(), name), self.options)
        if match:
            match.select()
            if self.eo:
                self.eo.select()

            if self.isRadioButton():
                for o in self.options:
                    if o is not match:
                        o.unselect()
                    
            return True

        for f in self.facets:
            if f.select(name):
                if self.eo:
                    self.eo.select()
                return True

        return False


    def unselect(self, name):
        if self.eo and (self.eo.name() == name or self.isKeysEqual(self.eo.name(), name)):
            self.eo.unselect()
            return True

        match = utils.find(lambda o: o.name() == name or self.isKeysEqual(o.name(), name), self.options)
        if match:
            match.unselect()

            if self.isRadioButton() and not self.isOptionSelected():
                default = utils.find(lambda o: o.isDefault(), self.options)
                if default:
                    default.select()

            return True

        for f in self.facets:
            if f.unselect(name):
                return True

        return False


    def unselectAll(self):
        if self.eo:
            self.eo.unselect()

        for o in self.options:
            o.unselect()

        for f in self.facets:
            f.unselectAll()



class Option(object):
    def __init__(self, raw, facet):
        self.raw = raw
        self.facet = facet


    def isDefault(self):
        return self.raw.get('isdefault', 'false') == 'true'

    
    def isSelected(self):
        return self.raw.get('isselected', 'false') == 'true'
    
    def getSelected(self):
        return self.raw.get('isselected')
    
    def label(self):
        return self.raw['label']


    def name(self):
        return self.raw['name']

    
    def parentSelected(self):
        # harden default
        if not self.facet.isOptionSelected() and self.isDefault():
            self.select()


    def parentUnselected(self):
        pass

    
    def prettify(self, iseo, indent):
        #show selected if the option's isdefault is true
        if self.isSelected() or (iseo and self.isDefault() and self.getSelected() == None):
            if self.facet.isRadioButton() and not iseo:
                star = u'(*)'
            else:
                star = u'|x|'
        else:
            if self.facet.isRadioButton() and not iseo:
                star = u'( )'
            else:
                star = u'| |'
            
        return u'%s%s %s ("%s")\n' % (u' ' * indent, star, self.name(), self.label())
    
        
    def select(self):
        self.raw['isselected'] = 'true'


    def unselect(self):
        self.raw['isselected'] = 'false'
        


def getConfig(pattern):
    '''Returns a deserialized JSON object with configuration options for the specified pattern id.'''

    json = http.get('/resources/configurations?patternid=%d' % pattern.id)
    if len(json) > 0:
        return Config(json)
    else:
        return None


def setConfig(pattern, config):
    http.putJSON(pattern.uri, {'appliedConfigurations':  config.raw })
