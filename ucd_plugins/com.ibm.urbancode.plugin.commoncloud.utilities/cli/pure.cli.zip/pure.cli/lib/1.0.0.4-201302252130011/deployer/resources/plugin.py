#
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2012. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
#
"""
Licensed Materials - Property of IBM
IBM WebSphere CloudBurst Appliance (9235-72X)
Copyright IBM Corporation 2011. All Rights Reserved.
US Government Users Restricted Rights - Use, duplication or disclosure
restricted by GSA ADP Schedule Contract with IBM Corp.
"""

from deployer import utils, validators, http
from restresource import RESTResource, RESTResourceCollection
from relationships import RelatedResource, RelatedResourceCollection
from commonattrs import CommonAttributes
from deployer.messages import Helpable
import deployer.prettify as prettify
import urllib
import purescaleutils
import os

@utils.classinit
class Plugin(RelatedResource, CommonAttributes):
    'RM09699'

    @classmethod
    def _classinit(cls):
        cls._registerURI(r'\A/resources/plugins/(?P<name>[a-zA-Z0-9\.\_\-]+)/[0-9\.]+\Z')
        cls._defaultRESTAttrs(True)
        cls._getParams({ 'details': True })

        cls._defineRESTAttribute('name', 'RM09726', visible=[ lambda plugin: plugin.name != None ])
        cls._defineRESTAttribute('create_time', 'RM09727', readonly=True, visible=[ lambda plugin: plugin.create_time != None ])
        cls._defineRESTAttribute('content_md5', 'RM09728', readonly=True, visible=[ lambda plugin: plugin.content_md5 != None ])
        cls._defineRESTAttribute('creator', 'RM09729', readonly=True, visible=[ lambda plugin: plugin.creator != None ])
        cls._defineRESTAttribute('last_modifier', 'RM09730', readonly=True, visible=[ lambda plugin: plugin.last_modifier != None ])
        cls._defineRESTAttribute('content_type', 'RM09731', readonly=True, visible=[ lambda plugin: plugin.content_type != None ])
        cls._defineRESTAttribute('last_modified', 'RM09732', readonly=True, visible=[ lambda plugin: plugin.last_modified != None ])
        cls._defineRESTAttribute('access_rights', 'RM09741', readonly=True, visible=[ lambda plugin: plugin.access_rights != None ])
        cls._defineRESTAttribute('enabled', 'IWD10066', readonly=True)
        cls._defineRESTAttribute('patterntype', 'RM09887', readonly=True)
        cls._defineRESTAttribute('version', 'RM09836', readonly=True)
        cls._defineRESTAttribute('patterntype_package', '', readonly=True)
        
        cls._methodHelp('delete', 'refresh',  'getMeta', 'getConfig', 'updateConfig', 'uploadArtifact')
    
    def _getPatterntype(self):
        primary = self._retrievePrimaryInfo()    
        return primary.keys()[0] if primary else None
        
    def _getVersion(self):
        primary = self._retrievePrimaryInfo()
        return primary.values()[0] if primary else None
    
    def _retrievePrimaryInfo(self):
        patterntypes = self._restattrs.get('patterntypes')
        return  patterntypes.get('primary') if patterntypes else None
            
    def getMeta(self):
        'RM09858'
        json = http.get('%s/metadata' % self.uri)
        return utils.utos(json)

    def getConfig(self):
        'RM09856'
        json = http.get('%s/config' % self.uri)
        return utils.utos(json)["config"]
    
    def getFixes(self):
        'RM10053'
        json = http.get('%s/fixes' % self.uri)
        return utils.utos(json)

    def updateConfig(self, d):
        'RM09857'        
        if isinstance(d, dict):
            json = http.putJSON('%s/config' % (self.uri), d)
            return utils.utos(json)        
        else:
            purescaleutils.inputTypeErrorIndicator()  
    
    def uploadArtifact(self, f):
        'RM09967'      
        f = purescaleutils.userInputChecker(f, 'file')
        f = file(f, 'rb')
        try:
           baseName = purescaleutils.getFileBaseName(f)
           json = http.restChunked('%s/artifacts/%s' % (self.uri, baseName), f, 'PUT', 'application/binary')
        finally:
            f.close()
        return utils.utos(json)


@utils.classinit
class Plugins(RelatedResourceCollection):
    'RM09695'

    @classmethod
    def _classinit(cls):
        cls._contains(Plugin)
        cls._methodHelp('__contains__', 'create', 'delete', '__delitem__',
                        '__getattr__', '__getitem__', '__iter__',
                        '__len__', 'list', '__lshift__', '__repr__',
                        '__rshift__', '__str__', '__unicode__',
                        'get', 'getMeta', 'getConfig', 'updateConfig')

    def _list(self, filt = {}):
        utf8filt = filt.copy()

        for k in utf8filt:
            if isinstance(utf8filt[k], str) or isinstance(utf8filt[k], unicode):
                utf8filt[k] = utf8filt[k].encode('utf-8')

        if filt:
            filt = '?' + urllib.urlencode(utf8filt)
        else:
            filt = ''

        if self.options['useListAttrs']:
            return [ RESTResource.resourceForURI(self._uriForResource(json), json) for json in http.get('%s/%s' % (self.uri, filt)) ]
        else:
            return [ RESTResource.resourceForURI(self._uriForResource(json)) for json in http.get('%s/%s' % (self.uri, filt)) ]
    
    def get(self, plugin_name):
        'RM09750'
        plugin_name = purescaleutils.userInputChecker(plugin_name, 'str')
        return RESTResource.resourceForURI('%s/%s' % (self.uri, plugin_name))
    
    def getMeta(self, plugin_name):
        'RM09858'
        plugin_name = purescaleutils.userInputChecker(plugin_name, 'str')
        json = http.get('%s/%s/metadata' % (self.uri, plugin_name))
        return utils.utos(json)

    def getConfig(self, plugin_name):
        'RM09856'
        plugin_name = purescaleutils.userInputChecker(plugin_name, 'str')
        json = http.get('%s/%s/config' % (self.uri, plugin_name))
        return utils.utos(json)
    
    def updateConfig(self, plugin_name, d):
        'RM09857'
        if isinstance(d, dict):
            plugin_name = purescaleutils.userInputChecker(plugin_name, 'str')
            json = http.putJSON('%s/%s/config' % (self.uri, plugin_name), d)
            return utils.utos(json)
        else:
            purescaleutils.inputTypeErrorIndicator()

    def create(self, f):
        'RM09990'
        if isinstance(f, unicode) or isinstance(f, str) and os.path.isfile(f) and f.lower().endswith('.tgz'):
            f = file(f, 'rb')
            try:
               json = http.restChunked(self.uri, f, 'POST', 'application/binary')
               return RESTResource.resourceForURI(self._uriForResource(json), json)
            finally:
                f.close()
        else:
            purescaleutils.fileTypeErrorIndicator()

    def delete(self, plugin_name):
        'RM09016'
        plugin_name = purescaleutils.userInputChecker(plugin_name, 'str')
        json = http.delete('%s/%s' % (self.uri, plugin_name))
        return utils.utos(json)

    def _uriForResource(self, attrs):
        return '%s/%s' % (self.uri, attrs['name'])
