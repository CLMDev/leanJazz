"""
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2012. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
"""
import consoleio
import getopt
import http
import java
import messages
import os
import prettify
import sys
import utils
from com.ibm.workloaddeployer.cli import CustomTrustManager
from com.ibm.workloaddeployer.cli import PasswordUtil

from messages import message
from servermessageresolver import ServerMessageResolver
from utils import stou, utos
from deployer.shortcuts import exit, help


def _help(error=None):
    print >>sys.stderr, utos(message('RM09000'))
    if error:
        print >>sys.stderr, '\n', error
    sys.exit()


def dashWarning(meant, rather):
    print >>sys.stderr, utos(message('RM09001', meant, rather))


def readFromFile(passFileName):
    passFile = PasswordUtil.locateFile(passFileName)
    password = ""
    try:
        password = PasswordUtil.readFromFile(passFile)
    except:
        print >>sys.stderr, utos(message('IWD10067', passFile.getAbsolutePath() ))
    return password


_file = None

try:
    (_opts, _args) = getopt.getopt(sys.argv[1:], 'u:h:p:fP:c:?a?i?', [ 'userid=', 'host=', 'password=', 'passfile=', 'port=', 'help', 'acceptcert', 'ignoreversion'])
except getopt.GetoptError, goe:
    _help(goe)

commands = []

http.host = os.environ.get('DEPLOYER_HOSTNAME') or os.environ.get('CLOUDBURST_HOSTNAME') if not utils.isIPAS() else os.environ.get('PURE_HOSTNAME') 
http.port = os.environ.get('DEPLOYER_PORT') or os.environ.get('CLOUDBURST_PORT', '443') if not utils.isIPAS() else os.environ.get('PURE_PORT', 443)
http.userid = stou(os.environ.get('DEPLOYER_USERID') or os.environ.get('CLOUDBURST_USERID')) if not utils.isIPAS() else stou(os.environ.get('PURE_USERID'))
http.password = stou(os.environ.get('DEPLOYER_PASSWORD') or os.environ.get('CLOUDBURST_PASSWORD')) if not utils.isIPAS() else stou(os.environ.get('PURE_PASSWORD')) 

if not _opts and len(_args) == 1 and _args[0] == 'help':
    _help()

acceptcert = False
    
for _opt in _opts:
    if _opt[0] == '--help' or (_opt[0] == '-h' and _opt[1] == 'elp') or _opt[0] == '-?':
        _help()
        
    elif _opt[0] == '-u' or _opt[0] == '--userid':
        if _opt[1] == 'serid':
            dashWarning('-u or --userid', '-userid')
        http.userid = stou(_opt[1])

    elif _opt[0] == '--passfile':
        http.password = readFromFile(_opt[1])
        
    elif _opt[0] == '-p' or _opt[0] == '--password':
        if _opt[1] == 'assword':
            dashWarning('-p or --password', '-password')
        elif _opt[1] == 'ort':
            dashWarning('-P or --port', '-port')
        http.password = stou(_opt[1])

    elif _opt[0] == '-h' or _opt[0] == '--host':
        if _opt[1] == 'ost':
            dashWarning('-h or --host', '-host')
        http.host = _opt[1]

    elif _opt[0] == '-P' or _opt[0] == '--port':
        http.port = _opt[1]

    elif _opt[0] == '-c':
        # Looks like the command line has gone through JVM decoding, so
        # we get unicode characters stuffed into a plain string.  stou()
        # is smart enough to handle this correctly, but Jython interpreter
        # seems to want locally-encoded bytes in its command strings.
        commands.append(utos(stou(_opt[1])))

    elif _opt[0] == '-f':
        _file = True

    elif _opt[0] == '-a' or _opt[0] == '--acceptcert':
        acceptcert = True


if http.host and not http.userid:
    http.userid = consoleio.promptForUserid()

if http.host and not http.password:
    http.password = consoleio.promptForPassword()

try:
    assert http.host
    assert http.userid
    assert http.password
except AssertionError:
    print >>sys.stderr, utos(message('RM09002'))

try:
  messages.resolvers.append(ServerMessageResolver())
except:
    pass

if acceptcert:
    CustomTrustManager.install()

#force prompting if userid and password are wrong
#print message for wrong userid/password
for  i in range(0,3):
    try:
        http.get('/resources/status')
        break
    except IOError, e:
        if 401 == e.errno:
            print e


if _file:
    import deployer
    if utils.isIPAS():
       import admin   
    if os.environ.get('DEPLOYER_CALLED_AS', 'deployer').startswith('cloudburst'):
        import cloudburst

    sys.argv = _args
    __name__ = '__main__'
    execfile(_args[0])

elif commands:
    import deployer
    if utils.isIPAS():
        import admin
    if os.environ.get('DEPLOYER_CALLED_AS', 'deployer').startswith('cloudburst'):
        import cloudburst

    for c in commands:
        try:
            code = compile(c, '<command>', 'eval')
            useEval = True
        except SyntaxError:
            code = compile(c, '<command>', 'exec')
            useEval = False

        if useEval:
            if prettify.enabled:
                print utos(prettify.prettify(eval(code)))
            else:
                print repr(eval(code))
        else:
            exec(code)

else:
    print utos(message('RM09136'))
