"""
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2011. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
"""

from deployer import http, utils, validators
from commonattrs import CommonAttributes
from relationships import RelatedResource, RelatedResourceCollection
from deployer.messages import message
import sys


@utils.classinit
class Cloud(RelatedResource, CommonAttributes):
    'IWD00050'

    @classmethod
    def _classinit(cls):
        cls._registerURI(r'\A/resources/clouds/(?P<id>\d+)\Z')

        cls._defineAttribute('acl', 'RM09456', readonly=True, readonlydoc=False)
        cls._defineRESTAttribute('address', 'RM09469', validator=validators.string, visible=[ lambda cloud: cloud.type == 'manager' ], readonly=True)
        cls._defineAttribute('certificate', 'RM09480', readonly=True, elided=True)
        cls._defineRESTAttribute('certified', 'RM09470', values=('T','F','I'), visible=[ lambda cloud: cloud.type == 'manager' ], readonly=True)
        cls._defineRESTAttribute('created', 'RM09128', readonly=True)
        cls._defineRESTAttribute('currentstatus', 'RM09471', readonly=True)
        cls._defineRESTAttribute('currentstatus_text', 'RM09471', readonly=True)
        cls._defineRESTAttribute('defaultcloud', 'RM09130', readonly=True)
        cls._defineRESTAttribute('deploymentlimit', 'RM09531', validator=validators.nonnegativeinteger, visible=[ lambda cloud: cloud.vendor == 'PowerVM' ], readonly=True)
        cls._defineRESTAttribute('description', 'RM09139', validator=validators.string, readonly=True)
        cls._defineRESTAttribute('id', 'RM09140', readonly=True)
        cls._defineAttribute('linkedclones', 'RM09510', values=(True, False), visible=[ lambda cloud: cloud.vendor == 'ESX' ], readonly=True)
        cls._defineRESTAttribute('name', 'RM09141', validator=validators.string, readonly=True)
        cls._defineAttribute('ospassword', 'RM09472', validator=validators.string, visible=[ lambda cloud: False ], readonly=True)
        cls._defineAttribute('osuserid', 'RM09473', validator=validators.string, visible=[ lambda cloud: False ], readonly=True)
        cls._defineRESTAttribute('overcommitby', 'RM09531', restname='diskovercommit', validator=validators.nonnegativeinteger, visible=[ lambda cloud: cloud.vendor == 'ESX' ], readonly=True)
        cls._defineRESTAttribute('password', 'RM09474', validator=validators.string, visible=[ lambda cloud: cloud.type == 'manager' ], readonly=True)
        cls._defineAttribute('sharedminidisks', 'RM09511', values=(True, False), visible=[ lambda cloud: cloud.vendor == 'zVM' ], readonly=True)
        cls._defineRESTAttribute('type', 'RM09475', readonly=True, readonlydoc=False, values=('manager', None), readonly=True)
        cls._defineRESTAttribute('updated', 'RM09142', readonly=True, readonly=True)
        cls._defineRESTAttribute('userid', 'RM09476', validator=validators.string, visible=[ lambda cloud: cloud.type == 'manager' ], readonly=True)
        cls._defineRESTAttribute('userversion', 'RM09565', validator=validators.version, visible=[ lambda cloud: False ], readonly=True)
        cls._defineRESTAttribute('vendor', 'RM09143', values=('ESX','PowerVM','zVM'), readonly=True)
        cls._defineAttribute('attachvolumes', 'RM09970', readonly=True, values=(True, False), readonly=True)
        cls._defineAttribute('useinternalreserveip', 'RM09971', readonly=True, values=(True, False), readonly=True)
        cls._defineAttribute('useinternalplacement', 'RM09972', readonly=True, values=(True, False), readonly=True)
        cls._defineAttribute('version', 'RM09546', readonly=True, elided=True, readonly=True)
 


    def delete(self):
        raise NotImplementedError('delete')

    def _getCertificate(self):
        json = http.get('%s?certificate=true' % self.uri)
        return '\n'.join(json['certificates'])


    def _getDefaultcloud(self):
        return self._restattrs['defaultcloud'] == 'T'


    def _getLinkedclones(self):
        return self._restattrs['thinservers'] == 'T'


    def _setLinkedclones(self, enabled):
        self._restattrs['thinservers'] = enabled and 'T' or 'F'

    def _getAttachvolumes(self):
        return self._restattrs['attachvolumes'] == 'T'

    def _getUseinternalreserveip(self):
        return self._restattrs['useinternalreserveip'] == 'T'

    def _getUseinternalplacement(self):
        return self._restattrs['useinternalplacement'] == 'T'

    def _getDeploymentlimit(self):
        return self._restattrs['deploymentlimit']


    def _setDeploymentlimit(self, limit):
        self._restattrs['deploymentlimit'] = limit


    def _getOspassword(self):
        # attribute deprecated in 2.0.0.2.  Return replacing attribute
        print >>sys.stderr, utils.utos(message('RM09617', 'ospassword', 'cloud', '2.0.0.2'))
        return self._restattrs['password']


    def _setOspassword(self, passwd):
        # attribute deprecated in 2.0.0.2, ignore it
        print >>sys.stderr, utils.utos(message('RM09617', 'ospassword', 'cloud', '2.0.0.2'))
        print >>sys.stderr, utils.utos(message('RM09618', 'ospassword', 'cloud'))


    def _getOsuserid(self):
        # attribute deprecated in 2.0.0.2.  Return replacing attribute
        print >>sys.stderr, utils.utos(message('RM09617', 'osuserid', 'cloud', '2.0.0.2'))
        return self._restattrs['userid']


    def _setOsuserid(self, user):
        # attribute deprecated in 2.0.0.2, ignore it
        print >>sys.stderr, utils.utos(message('RM09617', 'osuserid', 'cloud', '2.0.0.2'))
        print >>sys.stderr, utils.utos(message('RM09618', 'osuserid', 'cloud'))


    def _getUserversion(self):
        # attribute deprecated in 3.0.0.0.  Return replacing attribute
        print >>sys.stderr, utils.utos(message('RM09617', 'userversion', 'cloud', '3.0.0.0'))


    def _setUserversion(self, user):
        # attribute deprecated in 3.0.0.0, ignore it
        print >>sys.stderr, utils.utos(message('RM09617', 'userversion', 'cloud', '3.0.0.0'))
        print >>sys.stderr, utils.utos(message('RM09618', 'userversion', 'cloud'))


    def _getSharedminidisks(self):
        return self._restattrs['thinservers'] == 'T'


    def _setSharedminidisks(self, enabled):
        self._restattrs['thinservers'] = enabled and 'T' or 'F'


    def _getVersion(self):
        ver = http.get('/resources/clouds/%s/cloudversion' % self.id)
        if (len(ver) > 0):
            return ver
        else:
            return


@utils.classinit
class Clouds(RelatedResourceCollection):
    'IWD10047'

    @classmethod
    def _classinit(cls):
        cls._contains(Cloud)
        cls._methodHelp('list')

    def create(self, dict):
        raise NotImplementedError('create')
    def delete(self, id):
        raise NotImplementedError('delete')
