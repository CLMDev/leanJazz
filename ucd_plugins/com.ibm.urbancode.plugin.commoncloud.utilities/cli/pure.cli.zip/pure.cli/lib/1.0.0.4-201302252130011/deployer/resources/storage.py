"""
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2012. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
"""

from commonattrs import CommonAttributes
from deployer import http, utils, validators
from relationships import RelatedResource, RelatedResourceCollection


@utils.classinit
class Storage(RelatedResource, CommonAttributes):
    'RM09109'


    @classmethod
    def _classinit(cls):
        cls._registerURI(r'\A/resources/storage/(?P<id>\d+)\Z')

        cls._defineRESTAttribute('created', 'RM09239', readonly=True)
        cls._defineRESTAttribute('hypervisorstorageid', 'RM09240', readonly=True)
        cls._defineRESTAttribute('id', 'RM09241', readonly=True)
        cls._defineRESTAttribute('name', 'RM09242', validator=validators.string)
        cls._defineRESTAttribute('updated', 'RM09243', readonly=True)
       # cls._defineAttribute('inuse', 'RM09656', values=('T','F'))

        cls._methodHelp('__contains__', '__delattr__', 'delete', '__eq__',
                        '__hash__', 'isStatusTransient', '__nonzero__',
                        'refresh', '__repr__', '__str__', '__unicode__',
                        'waitFor',
                        'cleanup')


    def cleanup(self):
        'RM09453'
        return http.postNoContent('%s?cleanup=true' % self.uri)




@utils.classinit
class Storages(RelatedResourceCollection):
    'RM09043'


    @classmethod
    def _classinit(cls):
        cls._contains(Storage)
        cls._methodHelp('__contains__', 'create', 'delete', '__delitem__',
                        '__getattr__', '__getitem__', '__iter__',
                        '__len__', 'list', '__lshift__', '__repr__',
                        '__rshift__', '__str__', '__unicode__')


    # private methods

    @classmethod
    def _cliname(cls):
        return 'storage'


    def _create(self, dict):
        raise TypeError('storage cannot be manually defined')


    @classmethod
    def _restname(cls):
        return 'storage'
