#
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2012. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
#
"""
Licensed Materials - Property of IBM
IBM WebSphere CloudBurst Appliance (9235-72X)
Copyright IBM Corporation 2011. All Rights Reserved.
US Government Users Restricted Rights - Use, duplication or disclosure
restricted by GSA ADP Schedule Contract with IBM Corp.
"""

import deployer.http as http
import deployer.prettify as prettify
import deployer.utils as utils
import deployer.validators as validators
from   commonattrs import CommonAttributes
from   relationships import RelatedResource, RelatedResourceCollection
from   restresource import RESTResource, RESTResourceCollection
import urllib
import purescaleutils

@utils.classinit
class PSDatabaseWorkload(RelatedResource, CommonAttributes):
    'RM31031'
    @classmethod
    def _classinit(cls):
        cls._registerURI(r'\A/resources/pSDatabaseWorkloads/(?P<id>[a-zA-Z0-9\.\-\_\/]+)\Z')
        cls._defineRESTAttribute('id', 'RM31034', readonly=True)
        cls._defineRESTAttribute('name', 'RM31035', readonly=True, visible=[ lambda application: application._restattrs.has_key('name') ])
        cls._defineRESTAttribute('description', 'RM31036', readonly=True, visible=[ lambda application: application._restattrs.has_key('description') ])
        cls._defineRESTAttribute('compatibility_mode', 'RM31037', readonly=True, visible=[ lambda application: application._restattrs.has_key('compatibility_mode') ])
        cls._defineRESTAttribute('is_system', 'RM31038', readonly=True, visible=[ lambda application: application._restattrs.has_key('is_system') ])
        cls._defineRESTAttribute('version', 'RM31039', readonly=True, visible=[ lambda application: application._restattrs.has_key('version') ])
        cls._defineRESTAttribute('workload_file', 'RM31040', readonly=True, visible=[ lambda application: application._restattrs.has_key('workload_file') ])
        cls._methodHelp('__contains__', '__delattr__', '__eq__',
                        '__hash__', 'isStatusTransient', '__nonzero__',
                        'refresh', '__repr__', '__str__', '__unicode__')        
        
    def __init__(self, uri, attrs):
        super(PSDatabaseWorkload, self).__init__(uri, attrs)
        
@utils.classinit
class PSDatabaseWorkloads(RelatedResourceCollection):
    'RM31032'
    @classmethod
    def _classinit(cls):
        cls._contains(PSDatabaseWorkload)
        cls._methodHelp('list')
        
    @classmethod
    def _restname(cls):
        return 'pSDatabaseWorkloads'