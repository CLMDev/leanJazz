"""
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2012. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
"""

import deployer
from deployer import http, prettify, utils, validators
from deployer.messages import Helpable
from deployer.utils import utos
from commonattrs import CommonAttributes
import os
from relationships import RelatedResource, RelatedResourceCollection
from scriptutil import ScriptLike


@utils.classinit
class AddOn(RelatedResource, CommonAttributes, ScriptLike):
    'RM09659'


    DISK_ADDON = 'ADDON_DISK'
    NIC_ADDON = 'ADDON_NIC'
    USER_ADDON = 'ADDON_USER'


    @classmethod
    def _classinit(cls):
        cls._registerURI(r'\A/resources/addons/(?P<id>\d+)\Z')

        cls._defineAttribute('acl', 'RM09673', readonly=True, readonlydoc=False)
        cls._defineAttribute('archive', cls.Archive.__doc__, readonly=True)
        cls._defineRESTAttribute('command', 'RM09674', validator=validators.string)
        cls._defineRESTAttribute('commandargs', 'RM09675', validator=validators.string)
        cls._defineRESTAttribute('created', 'RM09676', readonly=True)
        # currenteditionid - hidden
        # currentmessage - hidden
        cls._defineRESTAttribute('currentstatus', 'RM09677', values=('RM01027','RM01028'))
        cls._defineAttribute('currentstatus_text', 'RM09156', readonly=True)
        cls._defineRESTAttribute('description', 'RM09678', validator=validators.string)
        cls._defineAttribute('environment', cls.Environment.__doc__, readonly=True)
        # execmode - hidden
        cls._defineRESTAttribute('id', 'RM09679', readonly=True)
        # ispublic - hidden
        cls._defineRESTAttribute('label', 'RM09680', readonly=True)
        cls._defineRESTAttribute('location', 'RM09681', validator=validators.string)
        cls._defineRESTAttribute('log', 'RM09682', validator=validators.string)
        # maintenance - hidden
        cls._defineRESTAttribute('name', 'RM09683', validator=validators.noop)
        # resourcetype - hidden
        cls._defineRESTAttribute('timeout', 'RM09684', validator=validators.nonnegativeinteger)
        cls._defineRESTAttribute('type', 'RM09686', readonly=True, values=(cls.DISK_ADDON, cls.NIC_ADDON, cls.USER_ADDON))
        cls._defineRESTAttribute('updated', 'RM09685', readonly=True)
        # version - hidden
        cls._defineRESTAttribute('filename', 'RM09156', readonly=True, defaultToNone=True)

        cls._methodHelp('__contains__', '__delattr__', 'delete', '__eq__',
                        '__hash__', 'isStatusTransient', '__nonzero__',
                        'refresh', '__repr__', '__str__', '__unicode__',
                        'waitFor',
                        'clone', 'isDraft', 'isReadOnly', 'makeReadOnly')


    @utils.classinit
    class Archive(ScriptLike._Archive):
        'RM09660'


        @classmethod
        def _classinit(cls):
            # really should use super() here, but can't because this class
            # won't have a name until AddOn is defined
            ScriptLike._Archive._subclassinit(cls)

            cls._methodHelp('__lshift__', '__rshift__')


        def get(self, f):
            'RM09661'
            super(AddOn.Archive, self).get(f)


        def __lshift__(self, other):
            'RM09662'
            return self.set(other)


        def __rshift__(self, other):
            'RM09663'
            return self.get(other)


        def set(self, f):
            'RM09664'
            super(AddOn.Archive, self).set(f)



    class Environment(ScriptLike._Environment):
        'RM09665'




    def isDraft(self):
        'RM09666'
        return self.currentstatus == 'RM01027'


    def isReadOnly(self):
        'RM09667'
        return self.currentstatus == 'RM01028'


    def makeReadOnly(self):
        'RM09668'
        self.currentstatus = 'RM01028'


    def clone(self, name):
        'RM09669'
        return deployer.addons._create({"name": name, "originalid": self.id})




@utils.classinit
class AddOns(RelatedResourceCollection):
    'RM09670'


    @classmethod
    def _classinit(cls):
        cls._contains(AddOn)
        cls._methodHelp('__contains__', 'create', 'delete', '__delitem__',
                        '__getattr__', '__getitem__', '__iter__',
                        '__len__', 'list', '__lshift__', '__repr__',
                        '__rshift__', '__str__', '__unicode__')


    CREATE_ATTRIBUTES = [
        AddOn._wizardStep('name'),
        AddOn._wizardStep('type')
    ]


    def _create(self, dict):
        return super(AddOns, self)._create(dict, ['resourcetype', 'type', 'originalid'])
