#
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2012. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
#
"""
Licensed Materials - Property of IBM
IBM WebSphere CloudBurst Appliance (9235-72X)
Copyright IBM Corporation 2011. All Rights Reserved.
US Government Users Restricted Rights - Use, duplication or disclosure
restricted by GSA ADP Schedule Contract with IBM Corp.
"""

import deployer.http as http
import deployer.prettify as prettify
import deployer.utils as utils
import deployer.validators as validators
from   commonattrs import CommonAttributes
from   relationships import RelatedResource, RelatedResourceCollection
from   restresource import RESTResource, RESTResourceCollection
import urllib
import purescaleutils

@utils.classinit
class DB2FixPack(RelatedResource, CommonAttributes):
    'RM10043'
    @classmethod
    def _classinit(cls):
        cls._registerURI(r'\A/resources/db2Fixes/(?P<id>[a-zA-Z0-9\.\-\_\/]+)\Z')
        
        cls._defineRESTAttribute('name', 'RM09700', readonly=True, visible=[ lambda application: application.name != None ])
        cls._defineRESTAttribute('id', 'RM09701', readonly=True, visible=[ lambda application: application.id != None ])
        cls._defineRESTAttribute('description', 'RM09702', readonly=True, visible=[ lambda application: application._restattrs.has_key('description') ])
        cls._defineRESTAttribute('platform', 'RM09702', readonly=True, visible=[ lambda application: application._restattrs.has_key('platform') ])
        cls._defineRESTAttribute('db2level', 'RM09702', readonly=True, visible=[ lambda application: application._restattrs.has_key('db2level') ])
        cls._defineRESTAttribute('db2version', 'RM09702', readonly=True, visible=[ lambda application: application._restattrs.has_key('db2version') ])
        cls._defineRESTAttribute('packageFile', 'RM09706', readonly=True, visible=[ lambda application: application._restattrs.has_key('packageFile') ])
        
        cls._methodHelp('delete', 'update')
        
        
    def __init__(self, uri, attrs):
        super(DB2FixPack, self).__init__(uri, attrs)

    def delete(self):
        'RM10044'
        json = http.delete(self.uri)
        return utils.utos(json)

    def update(self, d):
        'RM10045'
        if isinstance(d, dict):
            json = http.putJSON(self.uri, d)
        else:
            purescaleutils.inputTypeErrorIndicator()
       
@utils.classinit
class DB2FixPacks(RelatedResourceCollection):
    'RM10043'
    @classmethod
    def _classinit(cls):
        cls._contains(DB2FixPack)
        cls._methodHelp('create','upload','get', 'getvalidfixpacks', 'getfixpacks')

    def _uriForResource(self, attrs):
        return '%s/%s' % (self.uri, attrs['id'])
        
    def get(self, db2fixpack_id):
        'RM10046'
        db2fixpack_id = purescaleutils.userInputChecker(db2fixpack_id, 'str')
        return RESTResource.resourceForURI('%s/%s' % (self.uri, db2fixpack_id))
        
    @classmethod
    def _restname(cls):
        return 'db2Fixes'

    def create(self, d):
        'RM10047'
        if isinstance(d, dict):
           json = http.postJSON(self.uri, d) 
           '''if(d.has_key('platform')):
               json = http.postJSON(self.uri, d) 
           else:
               d['platform'] = "linux"
               json = http.postJSON(self.uri, d)'''
           return utils.utos(json)
        else:
           purescaleutils.inputTypeErrorIndicator()

    def upload(self, f):
        'RM10048'
        doclose = False
        f = purescaleutils.userInputChecker(f, 'file')
        f = file(f, 'rb')
        doclose = True
        fileName = purescaleutils.getFileBaseName(f)
        #db2fixpackId = self.uri.split("/")[3]
        #db2fixpackUri = "/resources/fixFiles/" + db2fixpackId + "?filename=" + fileName
        db2fixpackUri = "/resources/fixFiles/" + fileName
        #json = http.restChunked('%s/%s' % (db2fixpackUri, fileName), f, 'PUT', 'application/binary')
        json = http.restChunked('%s' % (db2fixpackUri), f, 'PUT', 'application/binary')
        if doclose:
            f.close()
        return utils.utos(json)

    def getvalidfixpacks(self, dbID):
        'RM10049'
        db2fixpackKSUri = "/resources/db2FixesKS?forMetadata=true&dbID=" + dbID
        json=http.get('%s' % db2fixpackKSUri)
        return utils.utos(json)
    
    def getfixpacks(self):    
        'RM10050'
        db2fixpackUri = "/resources/db2Fixes?forUI=true"
        json=http.get('%s' % db2fixpackUri)
        return utils.utos(json)


    def __getitem__(self, key):
        'RM09019'
        # int key -> get by index
        if isinstance(key, int) or isinstance(key, long):
                return self._list()[key]

        raise TypeError('unsupported operand type for __getitem__: %s' % type(key))
