#
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2012. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
#
"""
Licensed Materials - Property of IBM
IBM WebSphere CloudBurst Appliance (9235-72X)
Copyright IBM Corporation 2011. All Rights Reserved.
US Government Users Restricted Rights - Use, duplication or disclosure
restricted by GSA ADP Schedule Contract with IBM Corp.
"""
import deployer
from deployer import utils, validators, http, prettify
import deployer.prettify as prettify
from restresource import RESTResource, RESTResourceCollection
from relationships import RelatedResource, RelatedResourceCollection
from commonattrs import CommonAttributes
from deployer.messages import Helpable
import urllib
import purescaleutils
from monitoring import Monitoring
from envprofile import EnvironmentProfile

@utils.classinit  
class VMInstance(RelatedResource, CommonAttributes):
    @classmethod
    def _classinit(cls):
        cls._registerURI(r'\A/resources/virtualApplications/[\dabcdef\-]+/nodes/(?P<id>[\d\w\-\.]+)\Z')
        cls._defaultRESTAttrs(True)
        cls._getParams({ 'details': True })
        
        cls._defineRESTAttribute('id', '',readonly=True, visible=[ lambda vminstance: vminstance.id != None ])
        cls._defineRESTAttribute('name', '', readonly=True, visible=[ lambda vminstance: vminstance.name != None ])
        cls._defineRESTAttribute('master', '', readonly=True, visible=[ lambda vminstance: vminstance.master != None ])
        cls._defineRESTAttribute('start_time', '',readonly=True, visible=[ lambda vminstance: vminstance.start_time != None ])
        cls._defineRESTAttribute('status', '',readonly=True, visible=[ lambda vminstance: vminstance.status != None ])
        cls._defineRESTAttribute('roles', '',readonly=True, visible=[ lambda vminstance: vminstance.roles != None ])
        cls._defineRESTAttribute('private_ip', '',readonly=True, visible=[ lambda vminstance: vminstance.private_ip != None ])
        cls._defineRESTAttribute('last_update', '',readonly=True, visible=[ lambda vminstance: vminstance.last_update != None ])
        cls._defineRESTAttribute('vmId', '',readonly=True, visible=[ lambda vminstance: vminstance.vmId != None ])
        cls._defineRESTAttribute('public_ip', '',readonly=True, visible=[ lambda vminstance: vminstance.public_ip != None ])
        cls._defineRESTAttribute('volumes', '',readonly=True, visible=[ lambda vminstance: vminstance.volumes != None ])
        cls._defineRESTAttribute('reboot_count', '', restname='reboot.count', readonly=True, visible=[ lambda vminstance: vminstance.reboot_count != None ])
        
        cls._defineRESTAttribute('logging', '', readonly=True)
        
        cls._methodHelp('start','stop')
        
    def start(self):
        'RM09893'
        json = http.postJSON('%s/nodeAction' % self.uri,{'action':'start'})
        return utils.utos(json)
    
    def stop(self):
        'RM09894'
        json = http.postJSON('%s/nodeAction' % self.uri,{'action':'stop'})
        return utils.utos(json)
    
    def _getLogging(self):
        uri = self.uri.replace('nodes/', 'logs/virtualMachines/')
        return RESTResource.resourceForURI(uri, {})
    
    def refresh(self):
        #default refresh will call GET self.uri to refresh data, but now we don't have that REST
        index = self.uri.rfind("/nodes")
        vappUri = self.uri[0:index]
        details = http.get('%s?model' % vappUri)
        if isinstance(details, dict) and details.has_key('instances'):
            instance = utils.find(lambda r: r['id'] == self.id, details['instances'])
            if instance != None:
                super(self._restattrs.__class__, self._restattrs).update(instance)
        return self        
        

@utils.classinit
class VirtualApplication(RelatedResource, CommonAttributes):
    'RM09698'

    @classmethod
    def _classinit(cls):
        cls._registerURI(r'\A/resources/virtualApplications/(?P<id>[\dabcdef\-]+)\Z')
        cls._defaultRESTAttrs(True)
        cls._getParams({ 'details': True })

        cls._defineAttribute('acl', 'RM09831', readonly=True, readonlydoc=False, elided=True)
        cls._defineRESTAttribute('role_error', 'RM09717', readonly=True, visible=[ lambda virtualapplication: virtualapplication.role_error != None ])
        cls._defineRESTAttribute('deployment', 'RM09718', readonly=True, visible=[ lambda virtualapplication: virtualapplication.deployment != None ])
        cls._defineRESTAttribute('appmodel', 'RM09719', readonly=True, visible=[ lambda virtualapplication: virtualapplication.appmodel != None ])
        cls._defineRESTAttribute('deployment_name', 'RM09720', readonly=True, visible=[ lambda virtualapplication: virtualapplication.deployment_name != None ])
        cls._defineRESTAttribute('app_id', 'RM09721', readonly=True, visible=[ lambda virtualapplication: virtualapplication.app_id != None ])
        cls._defineRESTAttribute('app_type', 'RM09759', readonly=True, visible=[ lambda virtualapplication: virtualapplication.app_type != None ])
        cls._defineRESTAttribute('start_time', 'RM09722', readonly=True, visible=[ lambda virtualapplication: virtualapplication.start_time != None ])
        cls._defineRESTAttribute('id', 'RM09723', readonly=True, visible=[ lambda virtualapplication: virtualapplication.id != None ])
        cls._defineRESTAttribute('status', 'RM09892', readonly=True, visible=[ lambda virtualapplication: virtualapplication.status != None ])
        cls._defineRESTAttribute('topology', 'RM09725', readonly=True, visible=[ lambda virtualapplication: virtualapplication.topology != None ])
        cls._defineRESTAttribute('monitoring', 'RM09725', readonly=True, visible=[ lambda virtualapplication: virtualapplication.status == "RUNNING" ])
        cls._defineRESTAttribute('maintenance_mode', 'IWD00040', readonly=True)
        cls._defineRESTAttribute('instances', '', readonly=True, elided=True)
        
        if utils.isIPAS():
           cls._defineRESTAttribute('virtualmachines', 'RM09985', readonly=True, elided=True)
           cls._defineRESTAttribute('priority', 'IWD12224', restname='virtual_system', readonly=True, elided=True)
        
        cls._defineRESTAttribute('environment_profile', 'RM09549', restname='virtual_system', readonly=True, elided=True)
        cls._defineRESTAttribute('cloud', 'RM09072', restname='virtual_system', readonly=True, elided=True)
        cls._defineRESTAttribute('ip_group', 'RM09110', restname='virtual_system', readonly=True, elided=True)
        
        cls._methodHelp('__contains__', '__delattr__', 'delete', '__eq__',
                        '__hash__', 'isStatusTransient', '__nonzero__',
                        'refresh', 'waitFor', '__repr__', '__str__', '__unicode__',
                        'shareuser', 'sharegroup','startvm','stopvm',
                        'vminstances', 'terminate', 'operationroles',
                        'operationmeta','configurationattributes',
                        'upgrade', 'maintain', 'resume', 'commit', 'revert', 'stop')

    def _getInstances(self):       
        instances = self._restattrs['instances']
        return [RESTResource.resourceForURI('%s/nodes/%s' %(self.uri, inst['id']), inst) for inst in instances]
    
    def _getPriority(self):
        if self._restattrs.has_key('virtual_system'):
            vs = self._restattrs['virtual_system']
            if vs.has_key("priority"):
                return vs["priority"]
            else:
                return None
        else:
            return None
    
    def _getEnvironment_profile(self):
        if self._restattrs.has_key('virtual_system'):
            vs = self._restattrs['virtual_system']
            if vs.has_key("environmentProfile") and vs["environmentProfile"] != None:
                return RESTResource.resourceForURI(vs["environmentProfile"])
            else:
                return None
        else:
            return None
    
    def _getCloud(self):
        if self._restattrs.has_key('virtual_system'):
            vs = self._restattrs['virtual_system']
            if vs.has_key("cloud") and vs["cloud"] != None:
                return RESTResource.resourceForURI(vs["cloud"])
            else:
                return None
        else:
            return None
        
    def _getIp_group(self):
        if self._restattrs.has_key('virtual_system'):
            vs = self._restattrs['virtual_system']
            if vs.has_key("ipGroup") and vs["ipGroup"] != None:
                return RESTResource.resourceForURI(vs["ipGroup"])
            else:
                return None
        else:
            return None
   
    def _getVirtualmachines(self):
        
        vmgroups = http.get('/deployment/resources/groups?isMaster=true&name=%s&fuzzy=false&resolvechildren=-1' % urllib.quote(self.deployment_name))
        vmgroups = utils.findAll(lambda r: r['name'] == self.deployment_name, vmgroups)
        vmgroup = None
        for g in vmgroups:
            json = http.get('%s?resolvechildren=1&resolvechildrenlist=members' % g['id'])
            options = json.get('options')
            if options and options.get('deployment_id') == self.id:
                vmgroup = json
                break
        if vmgroup == None:
            return None
        
        instances =[]
        for r in vmgroup.get('members', []):
            if r.get('resource_type') == 'instances':
                instances.append(r)
            elif r.get('resource_type') == 'groups':
                instances.extend(r.get('members', []))
        return [RESTResource.resourceForURI('/admin/resources/instances/%s'% utils.uuid(r['id']), r) for r in  instances]
        
    def _getMaintenance_mode(self):
        if self._restattrs.has_key('maintenance_mode'):
            return self._restattrs['maintenance_mode']
        return False
    
    def _getMonitoring(self):
        try:
           return RESTResource.resourceForURI("%s/monitoring" % self.uri)
        except:
            pass
    
    @classmethod
    def _restname(cls):
        return 'virtualApplications'

    def shareuser(self, accessID, accessRights):
        'RM09793'
        accessID = purescaleutils.userInputChecker(accessID, 'str')
        accessRights = purescaleutils.userInputChecker(accessRights, 'str')
        http.putJSON('%s/accessRights/%s?user' % (self.uri, accessID), {'accessRights': accessRights})
        
    def sharegroup(self, accessID, accessRights):
        'RM09794'
        accessID = purescaleutils.userInputChecker(accessID, 'str')
        accessRights = purescaleutils.userInputChecker(accessRights, 'str')
        http.putJSON('%s/accessRights/%s?group' % (self.uri, accessID), {'accessRights': accessRights})
    
    #deprecated, use VMInstance.start()
    
    def startvm(self, nodeId):
        'RM09893'
        
        nodeId = purescaleutils.userInputChecker(nodeId, 'str')
        http.postJSON('%s/nodes/%s/nodeAction' % (self.uri, nodeId),{'action':'start'})
        return None
    #deprecated, use VMInstance.stop() 
    
    def stopvm(self, nodeId):
        'RM09894'
        
        nodeId = purescaleutils.userInputChecker(nodeId, 'str')
        http.postJSON('%s/nodes/%s/nodeAction' % (self.uri, nodeId),{'action':'stop'})
        return None
    
    def terminate(self):
        'IWD10065'
        json = http.putJSON(self.uri, {"operation": "kill"})
        self.refresh()
        return utils.utos(json)
    
    def stop(self):
        'RM09755'
        json = http.putJSON(self.uri, {"operation": "stop"})
        self.refresh()
        return utils.utos(json)
    
    
    def start(self):
        'RM09973'
        json = http.putJSON(self.uri, {"operation": "start"})
        self.refresh()
        return utils.utos(json)
    
    def vminstances(self):
        'RM09754'
        json = http.get(self.uri)
        return RESTResource.resourceForURI('%s?model' % self.uri, json)
    
    def delete(self,deleteHistory=True):
        'RM09016'
        deleteHistoryInURL = "false"
        if(deleteHistory):
            deleteHistoryInURL = "true"      
        return http.delete("%s?deleteHistory=%s"  % (self.uri , deleteHistoryInURL))
    
    def operationroles(self):
        'RM09895'
        json = http.get("%s/vmRoles" % self.uri)
        return prettify.PrettyList(json)
    
    def operationmeta(self, role):
        'RM09896'
        if isinstance(role, dict):
            roleType = role['type']
        else:
            roleType = purescaleutils.userInputChecker(role, 'str')
        allMetadata = http.get('/resources/operationMetadata/?deploymentId=%s' % self.id)
        return prettify.PrettyList(allMetadata[roleType])
        
    
    def configurationattributes(self, role):
        'RM09897'
        if isinstance(role, dict):
            roleName = role['name']
        else:
            roleName = purescaleutils.userInputChecker(role, 'str')
        configAttributes = http.get('%s/configurationAttributes?roleId=%s' % (self.uri, roleName))
        return utils.utos(configAttributes)
    
    def upgrade(self):
        'IWD00001'
        json = http.putJSON(self.uri, {"operation": "upgrade"})
        self.refresh()
        return utils.utos(json)
    
    def commit(self):
        'IWD00037'
        json = http.putJSON(self.uri, {"operation": "commit"})
        self.refresh()
        return utils.utos(json)
    
    def revert(self):
        'IWD00038'
        json = http.putJSON(self.uri, {"operation": "revert"})
        self.refresh()
        return utils.utos(json)
    
    def maintain(self):
        'IWD00002'
        json = http.putJSON(self.uri, {"operation": "maintain"})
        return utils.utos(json)
    
    def resume(self):
        'IWD00003'
        json = http.putJSON(self.uri, {"operation": "resume"})
        return utils.utos(json)       
    #called by waitFor 
    def isStatusTransient(self):
        finalStates = [
             'RUNNING',
             'ERROR',
             'TERMINATED',
             'STOPPED',
             'FAILED'
         ]
        return not self.status in finalStates
    
    def _statusField(self):
        return 'status' 
 
@utils.classinit
class VirtualApplications(RelatedResourceCollection):
    'RM09694'

    @classmethod
    def _classinit(cls):
        cls._contains(VirtualApplication)
        cls._methodHelp('__contains__', 'create', 'delete', '__delitem__',
                        '__getattr__', '__getitem__', '__iter__',
                        '__len__', 'list', '__lshift__', '__repr__',
                        '__rshift__', '__str__', '__unicode__',
                        'get', 'vminstances', 'terminate')

    @classmethod
    def _restname(cls):
        return 'virtualApplications'

    def _defaultSearch(self, s):
        result = self._list({ 'deployment_name': s })
        result.sort(lambda r1, r2: utils.exactMatchCmp(r1.deployment_name, r2.deployment_name, s))
        return result

    def get(self, depl_id):
        'RM09750'
        depl_id = purescaleutils.userInputChecker(depl_id, 'str')
        return RESTResource.resourceForURI('%s/%s' % (self.uri, depl_id))
    
    #deprecated
    def vminstances(self, depl_id):
        'RM09754'
        depl_id = purescaleutils.userInputChecker(depl_id, 'str')
        json = http.get('%s/%s' % (self.uri, depl_id))
        return RESTResource.resourceForURI('%s/%s?model' % (self.uri, depl_id), json)

    #deprecated
    def terminate(self, depl_id):
        'RM09755'
        depl_id = purescaleutils.userInputChecker(depl_id, 'str')
        json = http.putJSON('%s/%s' % (self.uri, depl_id), {"operation": "stop"})
        return utils.utos(json)

    def delete(self, depl_id):
        'RM09016'
        depl_id = purescaleutils.userInputChecker(depl_id, 'str')
        json = http.delete('%s/%s' % (self.uri, depl_id))
        return utils.utos(json)

    def _uriForResource(self, attrs):
        return '%s/%s' % (self.uri, attrs['id'])
    

#intermediate class for rendering vminstances() as an RelatedResource object ( pretty layout)

@utils.classinit  
class RuntimeInfo(RelatedResource, CommonAttributes):
   
    @classmethod
    def _classinit(cls):
        cls._registerURI(r'\A/resources/virtualApplications/[\dabcdef\-]+\?model\Z')
     
        cls._defineRESTAttribute('instances', '',readonly=True, visible=[ lambda vminstance: vminstance.instances != None ])
        cls._defineRESTAttribute('virtual_system', '', readonly=True, visible=[ lambda vminstance: vminstance.virtual_system != None ])
        cls._defineRESTAttribute('status', '', readonly=True, visible=[ lambda vminstance: vminstance.status != None ])
        cls._defineRESTAttribute('deployment_name', '', readonly=True, visible=[ lambda vminstance: vminstance.deployment_name != None ])
        cls._defineRESTAttribute('app_type', '', readonly=True, visible=[ lambda vminstance: vminstance.app_type != None ])
        cls._defineRESTAttribute('app_id', '', readonly=True, visible=[ lambda vminstance: vminstance.app_id != None ])
        cls._defineRESTAttribute('start_time', '', readonly=True, visible=[ lambda vminstance: vminstance.start_time != None ])
        #cls._defineRESTAttribute('creator_name', '', readonly=True, visible=[ lambda vminstance: vminstance.creator_name != None ])
        cls._defineRESTAttribute('creator', '', readonly=True, visible=[ lambda vminstance: vminstance.creator != None ])
        cls._defineRESTAttribute('role_error', '', readonly=True, visible=[ lambda vminstance: vminstance.role_error != None ])
        
    
    def _getInstances(self):       
        instances = self._restattrs['instances']
        uri = self.uri.split('?')[0]
        return [RESTResource.resourceForURI('%s/nodes/%s' %(uri, inst['id']), inst) for inst in instances]
    
    def _getVirtual_system(self):
         virtualSystem = self._restattrs['virtual_system']
         uri = self.uri.split('?')[0]
         return RESTResource.resourceForURI('%s/virtualSystem' % uri, virtualSystem)

#intermediate class for rendering vminstances() as an RelatedResource object ( pretty layout)

@utils.classinit  
class VirtualSystemForVirtualApplication(RelatedResource, CommonAttributes):

    @classmethod
    def _classinit(cls):
        # no real REST for the URI
        cls._registerURI(r'\A/resources/virtualApplications/[\dabcdef\-]+/virtualSystem\Z')
        
        cls._defineRESTAttribute('id', '', readonly=True, visible=[ lambda vs: vs.id != None ])
        cls._defineRESTAttribute('cloud', '', readonly=True, visible=[ lambda vs: vs.cloud != None ])
        cls._defineRESTAttribute('image', '', readonly=True, visible=[ lambda vs: vs.image != None ], defaultToNone=True)
        
        
