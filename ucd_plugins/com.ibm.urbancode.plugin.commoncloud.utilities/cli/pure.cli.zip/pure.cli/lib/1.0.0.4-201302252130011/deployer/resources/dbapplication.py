#
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2012. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
#
"""
Licensed Materials - Property of IBM
IBM WebSphere CloudBurst Appliance (9235-72X)
Copyright IBM Corporation 2011. All Rights Reserved.
US Government Users Restricted Rights - Use, duplication or disclosure
restricted by GSA ADP Schedule Contract with IBM Corp.
"""

import deployer
from cloud import Cloud
from deployer import utils, validators, http
from restresource import RESTResource, RESTResourceCollection
from relationships import RelatedResource, RelatedResourceCollection
from commonattrs import CommonAttributes
from deployer.messages import Helpable
import urllib
import purescaleutils

@utils.classinit
class DBApplication(RelatedResource, CommonAttributes):
    'RM09697'

    @classmethod
    def _classinit(cls):
        cls._registerURI(r'\A/resources/databasePatterns/(?P<app_id>[\dabcdef\-]+)\Z')
        cls._defaultRESTAttrs(True)
        cls._getParams({ 'details': True })

        cls._defineAttribute('acl', 'RM09830', readonly=True, readonlydoc=False)
        cls._defineRESTAttribute('app_name', 'RM09700', readonly=True, visible=[ lambda dbapplication: dbapplication.app_name != None ])
        cls._defineRESTAttribute('app_id', 'RM09701', readonly=True, visible=[ lambda dbapplication: dbapplication.app_id != None ])
        cls._defineRESTAttribute('content_md5', 'RM09702', readonly=True, visible=[ lambda dbapplication: dbapplication.content_md5 != None ])
        cls._defineRESTAttribute('content_type', 'RM09703', readonly=True, visible=[ lambda dbapplication: dbapplication.content_type != None ])
        cls._defineRESTAttribute('create_time', 'RM09704', readonly=True, visible=[ lambda dbapplication: dbapplication.create_time != None ])
        cls._defineRESTAttribute('creator', 'RM09705', readonly=True, visible=[ lambda dbapplication: dbapplication.creator != None ])
        cls._defineRESTAttribute('last_modifier', 'RM09706', readonly=True, visible=[ lambda dbapplication: dbapplication.last_modifier != None ])
        cls._defineRESTAttribute('last_modified', 'RM09707', readonly=True, visible=[ lambda dbapplication: dbapplication.last_modified != None ])
        cls._defineRESTAttribute('app_type', 'RM09783', readonly=True, visible=[ lambda dbapplication: dbapplication.app_type != None ])
        cls._defineRESTAttribute('access_rights', 'RM09740', readonly=True, visible=[ lambda dbapplication: dbapplication.access_rights != None ])
        cls._defineRESTAttribute('version', 'RM09836', readonly=True, visible=[ lambda dbapplication: dbapplication.version != None ])
        cls._defineRESTAttribute('patterntype', 'RM09887', readonly=True, visible=[ lambda dbapplication: dbapplication.patterntype != None ])

        cls._methodHelp('__contains__', '__delattr__', 'delete', '__eq__',
                        '__hash__', 'isStatusTransient', '__nonzero__',
                        'refresh', '__repr__', '__str__', '__unicode__',
                        'clone','shareuser', 'sharegroup', 'update', 'download', 'deploy')

    @classmethod
    def _restname(cls):
        return 'databasePattern'

    def shareuser(self, accessID, accessRights):
        'RM09746'
        accessID = purescaleutils.userInputChecker(accessID, 'str')
        accessRights = purescaleutils.userInputChecker(accessRights, 'str')
        http.putJSON('%s/accessRights/%s?user' % (self.uri, accessID), {'accessRights': accessRights})
        
    def sharegroup(self, accessID, accessRights):
        'RM09747'
        accessID = purescaleutils.userInputChecker(accessID, 'str')
        accessRights = purescaleutils.userInputChecker(accessRights, 'str')
        http.putJSON('%s/accessRights/%s?group' % (self.uri, accessID), {'accessRights': accessRights})

    def update(self, f):
        'RM09748'
        if isinstance(f, dict):
            json = http.putJSON(self.uri, f)
        else:
            f = purescaleutils.userInputChecker(f, 'file')
            f = file(f, 'rb')
            doclose = True
            updateType = purescaleutils.getFileExt(f)
            if updateType == 'zip':
                http.restChunked(self.uri, f, 'PUT', 'application/zip')
            elif updateType == 'json':
                http.restChunked(self.uri, f, 'PUT', 'application/json')
            else:
                purescaleutils.fileTypeErrorIndicator()
            if doclose:
                f.close()
 

    def deploy(self, db_name, inst_id, default_user=None, password=None, db_description= None):
        'RM32007'    
        inst_id = purescaleutils.userInputChecker(inst_id, 'str')
        db_name = purescaleutils.userInputChecker(db_name, 'str')
        db_description = purescaleutils.userInputChecker(db_description, 'str')
                
        resourceUrl = '/resources/databases' 
        deploymentJson = http.get('%s/%s' % (self.uri, self.app_id))
        #print ' deploymentJson is\n %s' %  deploymentJson
        #print ' deploymentJson.get("attributes") is\n %s' %  deploymentJson.get("attributes")
        
        deploymentAtt = deploymentJson.get("attributes")
        #print "before compose deploymentAtt is %s" % deploymentAtt
        
        if deploymentAtt['source'] != "cloneApproach":
            default_user = purescaleutils.userInputChecker(default_user, 'str')
            password = purescaleutils.userInputChecker(password, 'str')
            
        deploymentAtt['dbname'] = db_name
        deploymentAtt['app_id'] = self.app_id
        if db_description != None:
            deploymentAtt['description'] = db_description
        else:
            deploymentAtt['description'] = ""
        
        if deploymentAtt['source'] == "defaultWorkloadStandardApproach":
            deploymentAtt['defaultUser'] = default_user
            deploymentAtt['password'] = password
            deploymentAtt['pSInstance'] = inst_id
        elif deploymentAtt['source'] == "workloadStandardApproach":
            deploymentAtt['cusdefaultUser'] = default_user
            deploymentAtt['cuspassword'] = password
            deploymentAtt['cuspSInstance'] = inst_id
        elif deploymentAtt['source'] == "cloneApproach":
            deploymentAtt['pSInstance'] = inst_id
        if db_description != None:
            deploymentOptions = {"app_type":"database","patterntype":"dbaas","version":"1.1","attributes":deploymentAtt,
                             'name':db_name, 'description':db_description }
        else:
            deploymentOptions = {"app_type":"database","patterntype":"dbaas","version":"1.1","attributes":deploymentAtt,
                             'name':db_name, 'description':""}
        
        #print 'deploymentOptions is\n %s\n\n' % deploymentOptions
        json = http.postJSON(resourceUrl, deploymentOptions)
        #print 'the json is \n%s' % json
        
    def _deployResponse(self, json):
        depl_id = json["deployment_id"]
        single_depl_uri = '/resources/virtualApplications/?id=%s' % (depl_id)
        depl_json = http.get(single_depl_uri)[0]
        depl_uri = '/resources/virtualApplications/%s' % (depl_id)
        return RESTResource.resourceForURI(depl_uri, depl_json)

    def _getResponseHandler(self, f, resp):
        if resp.status > 299:
            raise IOError(utils.utos(resp.reason))

        s = resp.read(100000)

        while s:
            f.write(s)
            s = resp.read(100000)
            
    def delete(self):
        'RM09016'
        json = http.delete(self.uri)
        return utils.utos(json)
            

@utils.classinit
class DBApplications(RelatedResourceCollection):
    'RM09693'

    @classmethod
    def _classinit(cls):
        cls._contains(DBApplication)
        cls._methodHelp('__contains__', 'create', 'delete', '__delitem__',
                        '__getattr__', '__getitem__', '__iter__',
                        '__len__', 'list', '__lshift__', '__repr__',
                        '__rshift__', '__str__', '__unicode__',
                        'get')

    @classmethod
    def _restname(cls):
        return 'databasePatterns'

    def _list(self, filt = {}):
        utf8filt = filt.copy()
        listUrl = self.uri + '/?app_type=database'
        for k in utf8filt:
            if isinstance(utf8filt[k], str) or isinstance(utf8filt[k], unicode):
                utf8filt[k] = utf8filt[k].encode('utf-8')
        if filt:
            filt = '?' + urllib.urlencode(utf8filt)
        else:
            filt = ''
        if self.options['useListAttrs']:
            return [ RESTResource.resourceForURI(self._uriForResource(json), json) for json in http.get('%s%s' % (listUrl, filt)) ]
        else:
            return [ RESTResource.resourceForURI(self._uriForResource(json)) for json in http.get('%s%s' % (listUrl, filt)) ]
    
    def delete(self, app_id):
        'RM09016'
        app_id = purescaleutils.userInputChecker(app_id, 'str')
        http.delete('%s/%s' % (self.uri, app_id))

    def create(self, d, name = None):
        'RM32008'
        if isinstance(d, dict):
            json = http.postJSON(self.uri, d) 
            return RESTResource.resourceForURI(self._uriForResource(json))

        elif isinstance(d, str): 
            doclose = False
            d = purescaleutils.userInputChecker(d, 'file')
            d = file(d, 'rb')
            doclose = True
            uploadType = purescaleutils.getFileExt(d)
            
            uri = self.uri
            if name != None:
                uri += "?app_name=" + name
            
            if uploadType == 'json':
                json = http.restChunked(uri, d, 'POST', 'application/json')
                return RESTResource.resourceForURI(self._uriForResource(json))
            else:
                purescaleutils.fileTypeErrorIndicator()
            if doclose:
                d.close()
        else:
            purescaleutils.inputTypeErrorIndicator()

    def get(self, app_id):
        'RM09750'
        app_id = purescaleutils.userInputChecker(app_id, 'str')
        return RESTResource.resourceForURI('%s/%s' % (self.uri, app_id))

    def _defaultSearch(self, s):
        result = self._list({ 'app_name': s })
        result.sort(lambda r1, r2: utils.exactMatchCmp(r1.app_name, r2.app_name, s))
        return result

    def _uriForResource(self, attrs):
        return '%s/%s' % (self.uri, attrs['app_id'])

    def __getitem__(self, key):
        'RM09019'

        # int key -> get by index
        if isinstance(key, int) or isinstance(key, long):
            return self._list()[key]

        raise TypeError('unsupported operand type for __getitem__: %s' % type(key))
