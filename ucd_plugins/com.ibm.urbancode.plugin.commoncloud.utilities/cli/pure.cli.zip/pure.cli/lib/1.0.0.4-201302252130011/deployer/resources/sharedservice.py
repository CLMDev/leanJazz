#
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2012. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
#
"""
Licensed Materials - Property of IBM
IBM WebSphere CloudBurst Appliance (9235-72X)
Copyright IBM Corporation 2011. All Rights Reserved.
US Government Users Restricted Rights - Use, duplication or disclosure
restricted by GSA ADP Schedule Contract with IBM Corp.
"""

import deployer
from cloud import Cloud
from deployer import utils, validators, http, mappingutils, prettify, applicationutils
from restresource import RESTResource, RESTResourceCollection
from relationships import RelatedResource, RelatedResourceCollection
from commonattrs import CommonAttributes
from deployer.messages import Helpable
import urllib
import purescaleutils

@utils.classinit
class SharedService(RelatedResource, CommonAttributes):
    'RM09817'

    @classmethod
    def _classinit(cls):
        cls._registerURI(r'\A/resources/sharedServices/(?P<app_id>[\dabcdef\-]+)\Z')
        cls._defaultRESTAttrs(True)

        cls._defineAttribute('acl', 'RM09833', readonly=True, readonlydoc=False, elided=True)
        cls._defineRESTAttribute('app_name', 'RM09820', readonly=True, visible=[ lambda sharedservice: sharedservice.app_name != None ])
        cls._defineRESTAttribute('app_id', 'RM09821', readonly=True, visible=[ lambda sharedservice: sharedservice.app_id != None ])
        cls._defineRESTAttribute('content_md5', 'RM09822', readonly=True, visible=[ lambda sharedservice: sharedservice.content_md5 != None ])
        cls._defineRESTAttribute('content_type', 'RM09823', readonly=True, visible=[ lambda sharedservice: sharedservice.content_type != None ])
        cls._defineRESTAttribute('create_time', 'RM09824', readonly=True, visible=[ lambda sharedservice: sharedservice.create_time != None ])
        cls._defineRESTAttribute('creator', 'RM09825', readonly=True, visible=[ lambda sharedservice: sharedservice.creator != None ])
        cls._defineRESTAttribute('last_modifier', 'RM09826', readonly=True, visible=[ lambda sharedservice: sharedservice.last_modifier != None ])
        cls._defineRESTAttribute('last_modified', 'RM09827', readonly=True, visible=[ lambda sharedservice: sharedservice.last_modified != None ])
        cls._defineRESTAttribute('app_type', 'RM09829', readonly=True, visible=[ lambda sharedservice: sharedservice.app_type != None ])
        cls._defineRESTAttribute('access_rights', 'RM09828', readonly=True, visible=[ lambda sharedservice: sharedservice.access_rights != None ])
        cls._defineRESTAttribute('version', 'RM09836', readonly=True, visible=[ lambda sharedservice: sharedservice.version != None ])
        cls._defineRESTAttribute('patterntype', 'RM09887', readonly=True, visible=[ lambda sharedservice: sharedservice.patterntype != None ])
        cls._defineRESTAttribute('service_type', 'IWD00011', readonly=True, visible=[ lambda sharedservice: sharedservice.service_type != None ])
        cls._defineRESTAttribute('service_name', 'IWD00049', readonly=True, visible=[ lambda sharedservice: sharedservice.service_name != None ])
        cls._defineRESTAttribute('service_version', 'RM09546', readonly=True, visible=[ lambda sharedservice: sharedservice.service_version != None ])
        cls._methodHelp('start', 'download', 'listConfig')
        
    def listConfig(self):
        'RM09993'
        return applicationutils.listConfig(self.uri)
                
    @utils.docstring('RM09819', 'RM09986')  
    def start(self, cloudGroupObj, params = {}, certFile = None):
        
        resourceUrl = '%s/virtualApplications' % (self.uri)
        deploymentOptions = {'deployment_name':self.app_name,'cloud_group':'','ssh_keys':[''] }
        
        if not isinstance(cloudGroupObj, dict):
            cloudGroupObj = mappingutils.getMappingResource(cloudGroupObj)
            
        if isinstance(cloudGroupObj, Cloud):
            cloudGroupID = str(cloudGroupObj.id)
            deploymentOptions['cloud_group'] = cloudGroupID
       
        elif isinstance(cloudGroupObj, dict):
            options = purescaleutils.extractDeployOptions(cloudGroupObj)
            deploymentOptions.update(options)           
        
        else:
            purescaleutils.objTypeErrorIndicator()
            
        if certFile != None:
            deploymentOptions['ssh_keys'] = purescaleutils.getSSHKeys(certFile)
        
        if isinstance(params, dict):
            deploymentOptions['parameters'] = params
            
        json = http.postJSON(resourceUrl, deploymentOptions)
        return purescaleutils.JSON2VirtualAppObj(json)
    
    def download(self, f):
        'IWD00010'
        doclose = False
        f = purescaleutils.userInputChecker(f, 'file')
        f = file(f, 'wb')
        doclose = True
        downloadType = purescaleutils.getFileExt(f)
        if downloadType == 'json':
            http.get('%s?model' % (self.uri), responseHandler=utils.curryMethod(self._getResponseHandler, f))
        else:
            purescaleutils.fileTypeErrorIndicator()
        if doclose:
            f.close()  
    
    def _getResponseHandler(self, f, resp):
        if resp.status > 299:
            raise IOError(utos(resp.reason))
    
        s = resp.read(100000)
    
        while s:
            f.write(s)
            s = resp.read(100000)   

@utils.classinit
class SharedServices(RelatedResourceCollection):
    'RM09818'

    @classmethod
    def _classinit(cls):
        cls._contains(SharedService)
        cls._methodHelp('list','get')

    @classmethod
    def _restname(cls):
        return "sharedServices"
    
    def get(self, app_id):
        'RM09750'
        app_id = purescaleutils.userInputChecker(app_id, 'str')
        return RESTResource.resourceForURI('%s/%s' %(self.uri, app_id))

    def _getDefaultSearchField(self):
        return 'app_name'
    
    def _uriForResource(self, attrs):
        #override the method, because by default, it reads attrs['id']
        return '%s/%s' % (self.uri, attrs['app_id'])
 
