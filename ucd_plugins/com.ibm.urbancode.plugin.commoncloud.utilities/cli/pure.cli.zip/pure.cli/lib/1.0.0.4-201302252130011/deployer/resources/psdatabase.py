#
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2012. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
#
"""
Licensed Materials - Property of IBM
IBM WebSphere CloudBurst Appliance (9235-72X)
Copyright IBM Corporation 2011. All Rights Reserved.
US Government Users Restricted Rights - Use, duplication or disclosure
restricted by GSA ADP Schedule Contract with IBM Corp.
"""

import deployer.http as http
import deployer.prettify as prettify
import deployer.utils as utils
import deployer.validators as validators
from   commonattrs import CommonAttributes
from   relationships import RelatedResource, RelatedResourceCollection
from   restresource import RESTResource
import urllib


@utils.classinit
class PSDatabase(RelatedResource, CommonAttributes):
    'RM31001'
    @classmethod
    def _classinit(cls):
        cls._registerURI(r'\A/resources/pSDatabases/(?P<id>[\dabcdef\-]+)\Z')
        cls._defineRESTAttribute('id', 'RM31007', readonly=True)
        cls._defineRESTAttribute('dbname', 'RM31008', readonly=True, visible=[ lambda application: application._restattrs.has_key('dbname') ])
        cls._defineRESTAttribute('dbName', 'RM31008', readonly=True, visible=[ lambda application: application._restattrs.has_key('dbName') ])
        cls._defineRESTAttribute('database_description', 'RM31009', readonly=True, visible=[ lambda application: application._restattrs.has_key('database_description') ])
        cls._defineRESTAttribute('db2level', 'RM31010', readonly=True, visible=[ lambda application: application._restattrs.has_key('db2level') ])
        cls._defineRESTAttribute('status', 'RM31011', readonly=True, visible=[ lambda application: application._restattrs.has_key('status') ])
        cls._defineRESTAttribute('creator', 'RM31012', readonly=True, visible=[ lambda application: application._restattrs.has_key('creator') ])
        cls._defineRESTAttribute('host', 'RM31013', readonly=True, visible=[ lambda application: application._restattrs.has_key('host') ])
        cls._defineRESTAttribute('port', 'RM31014', readonly=True, visible=[ lambda application: application._restattrs.has_key('port') ])
        cls._defineRESTAttribute('default_user', 'RM31015', readonly=True, visible=[ lambda application: application._restattrs.has_key('default_user') ])
        cls._defineRESTAttribute('jdbc_url', 'RM31016', readonly=True, visible=[ lambda application: application._restattrs.has_key('jdbc_url') ])
        cls._defineRESTAttribute('instance_id', 'RM31017', readonly=True, visible=[ lambda application: application._restattrs.has_key('instance_id') ])
        cls._defineRESTAttribute('instName', 'RM31018', readonly=True, visible=[ lambda application: application._restattrs.has_key('instName') ])
        cls._defineRESTAttribute('instance_status', 'RM31019', readonly=True, visible=[ lambda application: application._restattrs.has_key('instance_status') ])
        cls._methodHelp('__contains__', '__delattr__', 'delete', '__eq__',
                        '__hash__', 'isStatusTransient', '__nonzero__',
                        'refresh', '__repr__', '__str__', '__unicode__')
        
        
    def __init__(self, uri, attrs):
        super(PSDatabase, self).__init__(uri, attrs)
        
        
@utils.classinit
class PSDatabases(RelatedResourceCollection):
    'RM31002'

    @classmethod
    def _classinit(cls):
        cls._contains(PSDatabase)
        cls._methodHelp('list', 'get', 'create')

    @classmethod
    def _restname(cls):
        return 'pSDatabases'
        
    def get(self, db_id):
        'RM31005' 
        db_id = utils.stou(db_id)
        return RESTResource.resourceForURI("%s/%s" % (self.uri, db_id) )
        
    def create(self, db_content):
        'RM31006'
        json = http.postJSON(self.uri, db_content)
        return utils.utos(json)