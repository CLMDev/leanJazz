"""
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2012. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
"""

from deployer import http, messages, prettify, utils, validators
from commonattrs import CommonAttributes
import os
from relationships import RelatedResource, RelatedResourceCollection
from virtualimage import VirtualImage
from plugin import Plugin
from deployer.messages import message
import sys

@utils.classinit
class Fix(RelatedResource, CommonAttributes):
    'RM09437'


    @classmethod
    def _classinit(cls):
        cls._registerURI(r'\A/resources/fixes/(?P<id>\d+)\Z')

        cls._defineAttribute('acl', 'RM09489', readonly=True, readonlydoc=False)
        cls._defineAttribute('archive', cls.Archive.__doc__, readonly=True, elided=True)
        cls._defineRESTAttribute('description', 'RM09448')
        cls._defineRESTAttribute('id', 'RM09443', readonly=True)
        cls._defineRESTAttribute('name', 'RM09444')
        cls._defineAttribute('prereqoptions', 'RM09486', readonly=True, elided=True)
        cls._defineAttribute('prereqpluginoptions', '', readonly=True, elided=True)
        cls._defineAttribute('prereqs', 'RM09449', readonly=True, elided=True)
        cls._defineRESTAttribute('severity', 'RM09445')
        cls._defineRESTAttribute('target', 'RM09446', readonly=True)
        cls._defineRESTAttribute('type', 'RM09447', readonly=True)
    
        cls._methodHelp('__contains__', '__delattr__', 'delete', '__eq__',
                        '__hash__', 'isStatusTransient', '__nonzero__',
                        'refresh', '__repr__', '__str__', '__unicode__',
                        'waitFor')
    

    @utils.classinit
    class Archive(messages.Helpable):
        'RM09438'

        @classmethod
        def _classinit(cls):
            cls._methodHelp('get', '__lshift__', '__rshift__', 'set')

        
        def __init__(self, fix):
            self.fix = fix

    
        def _getResponseHandler(self, f, resp):
            if resp.status > 299:
                raise IOError(utos(resp.reason))
    
            s = resp.read(100000)
    
            while s:
                f.write(s)
                s = resp.read(100000)

                
        def get(self, f):
            'RM09439'
            doclose = False
    
            if isinstance(f, str) or isinstance(f, unicode):
                if not f.lower().endswith('.zip'):
                    f = f + '.zip'
                f = file(f, 'wb')
                doclose = True
    
            http.get('%s/scriptArchive.zip' % self.fix.uri, responseHandler=utils.curryMethod(self._getResponseHandler, f))
    
            if doclose:
                f.close()


        def __lshift__(self, other):
            'RM09440'
            return self.set(other)


        def __rshift__(self, other):
            'RM09441'
            return self.get(other)
                            

        def set(self, f):
            'RM09442'
            doclose = False
    
            if isinstance(f, str) or isinstance(f, unicode):
                f = file(f, 'rb')
                doclose = True
    
            http.postChunked('%s/scriptArchive.zip/%s' % (self.fix.uri, utils.stou(os.path.basename(f.name))), f)
            
            if doclose:
                f.close()
    
    
    class FixPrereqOptions(list):
        def __init__(self, fixid, options):
            self.fixid = fixid
            self.options = options or []


        def __getitem__(self, index):
            return self.options[index]


        def __repr__(self):
            return prettify.prettify(self.options, alwaysBreak=True)


        def __str__(self):
            return self.__repr__()
        
        
    class FixPrereqPluginOptions(list):
       def __init__(self, fixid, options):
           self.fixid = fixid
           self.options = options or []
           
       def __getitem__(self, index):
           return self.options[index]
    

       def __repr__(self):
           return prettify.prettify(self.options, alwaysBreak=True)


       def __str__(self):
           return self.__repr__()


    class FixPrereqs(list):
        URI = '/resources/fixes/%d/fixPrereqs'

        def __init__(self, fixid, prereqs):
            self.fixid = fixid
            self.prereqs = prereqs or []


        def __getitem__(self, index):
            return self.prereqs[index]
        
        def __delitem__(self, index):
            id = self.prereqs[index].get("id");
            http.delete(self.URI % self.fixid + '/%d' % id) 


        def __repr__(self):
            return prettify.prettify(self.prereqs, alwaysBreak=True)


        def __str__(self):
            return self.__repr__()


        def append(self, prereq):
            if isinstance(prereq, VirtualImage):
                http.postJSON(self.URI % self.fixid, {
                    'fixid': self.fixid, 
                    'imagename': prereq.name, 
                    'version': prereq.version,
                    'operatingsystemid': prereq.operatingsystemid, 
                    'operatingsystemversion': prereq.operatingsystemversion 
                })
            
            elif isinstance(prereq, Plugin):
                name = prereq.name
                scopeSeparator = "/" 
                index = name.find(scopeSeparator)
                if(index <1):
                    raise ValueError(utils.utos(message('RM10052', name, scopeSeparator)))
                else:
                    pluginname = name[0:index]
                    pluginvrmf = name[index + 1:]
                    http.postJSON(self.URI % self.fixid, {
                      'fixid': self.fixid, 
                      'pluginname': pluginname, 
                      'imagename': 'plugin%na', 
                      'pluginvrmf': pluginvrmf 
                })
                
            elif isinstance(prereq, dict):
                if('imagename' in prereq.keys()):
                        http.postJSON(self.URI % self.fixid, {
                            'fixid': self.fixid, 
                            'imagename': prereq['imagename'], 
                            'version': prereq['version'],
                            'operatingsystemid': prereq['operatingsystemid'], 
                            'operatingsystemversion': prereq['operatingsystemversion'] 
                        })
                else:
                    if('name' in prereq.keys()):
                        name = prereq['name']
                        scopeSeparator = "/"
                        index = name.find(scopeSeparator)
                        if(index <1):
                             raise ValueError(utils.utos(message('RM10052', name, scopeSeparator)))
                        else:
                             pluginname = name[0:index]
                             pluginvrmf = name[index + 1:]
                             http.postJSON(self.URI % self.fixid, {
                                'fixid': self.fixid, 
                                'pluginname': pluginname, 
                                'imagename': 'plugin%na', 
                                'pluginvrmf': pluginvrmf 
                             })
                        



    def _getArchive(self):
        return self.__class__.Archive(self)

        
    def _getPrereqoptions(self):
        json = http.get('/resources/fixprereqsChoices?count=100&relatedType=fixes&relatedID=%s' % self.id)
        return self.__class__.FixPrereqOptions(self.id, json)
    
    def _getPrereqpluginoptions(self):
        json = http.get('/resources/fixprereqsPluginsChoices?count=100&relatedType=fixes&relatedID=%s' % self.id)
        return self.__class__.FixPrereqPluginOptions(self.id, json)


    def _getPrereqs(self):
        json = http.get('%s/%d/fixPrereqs' % ('/resources/fixes', self.id))
        return self.__class__.FixPrereqs(self.id, json)


@utils.classinit
class Fixes(RelatedResourceCollection):
    'RM09450'


    @classmethod
    def _classinit(cls):
        cls._contains(Fix)
        cls._methodHelp('__contains__', 'create', 'delete', '__delitem__',
                        '__getattr__', '__getitem__', '__iter__',
                        '__len__', 'list', '__lshift__', '__repr__',
                        '__rshift__', '__str__', '__unicode__')


    CREATE_ATTRIBUTES = [
        Fix._wizardStep('name'),
        Fix._wizardStep('description', optional=True)
    ]
