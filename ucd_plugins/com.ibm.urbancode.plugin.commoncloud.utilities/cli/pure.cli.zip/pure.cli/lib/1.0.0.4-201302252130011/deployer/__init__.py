'RM09004'
"""
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2011. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
"""

from climessageresolver import CLIMessageResolver, ExtMessageResolver
import messages

messages.resolvers.append(CLIMessageResolver())
messages.resolvers.append(ExtMessageResolver())


import deployer.cliversion as cliversionx
import deployer.http
import deployer.logging
import deployer.messages
import deployer.resources
import deployer.troubleshooting
import deployer.version as versionx
import java

from deployer.messages import message
from deployer.utils import utos
from deployer.utils import isSparta

# hooks for conceptual doc
from deployer.resources import Resource as resource
from deployer.resources import ResourceCollection as resourcecollection

# If it's Sparta get Sparta help message for deployer
if isSparta():
    deployer.__doc__='RM32004'

# profiles
environmentprofile = deployer.resources.EnvironmentProfile
environmentprofiles = deployer.resources.EnvironmentProfiles()
environmentprofilecloud = deployer.resources.EnvironmentProfileCloud
environmentprofileclouds = deployer.resources.EnvironmentProfileClouds
environmentprofilecloudipgroup = deployer.resources.EnvironmentProfileCloudIPGroup
environmentprofilecloudipgroups = deployer.resources.EnvironmentProfileCloudIPGroups
deployment_priority = deployer.resources.DeploymentPriority
deployment_priorities = deployer.resources.DeploymentPriorities()

# virtual systems
virtualsystem = deployer.resources.VirtualSystem
virtualsystems = deployer.resources.VirtualSystems()
virtualmachine = deployer.resources.VirtualMachine
virtualmachines = deployer.resources.VirtualMachines
snapshot = deployer.resources.Snapshot
snapshots = deployer.resources.Snapshots

# patterns
pattern = deployer.resources.Pattern
patterns = deployer.resources.Patterns()
part = deployer.resources.Part
parts = deployer.resources.Parts(type='conceptual')
pattern_part = deployer.resources.Ppart
pattern_parts = deployer.resources.Pparts
pattern_script = deployer.resources.Pscript
pattern_scripts = deployer.resources.Pscripts

# catalog resources
virtualimage = deployer.resources.VirtualImage
virtualimages = deployer.resources.VirtualImages()
#virtualappliance = deployer.resources.VirtualAppliance
#virtualappliances = deployer.resources.VirtualAppliances()
#virtualapplianceinstance = deployer.resources.VirtualApplianceInstance
#virtualapplianceinstances = deployer.resources.VirtualApplianceInstances()
script = deployer.resources.Script
scripts = deployer.resources.Scripts()
addon = deployer.resources.AddOn
addons = deployer.resources.AddOns()
fix = deployer.resources.Fix
fixes = deployer.resources.Fixes()
maintenance = deployer.resources.Maintenance
maintenances = deployer.resources.Maintenances()

# cloud resources
ipgroup = deployer.resources.IPGroup
ipgroups = deployer.resources.IPGroups()
ip = deployer.resources.IP
ips = deployer.resources.IPs
cloud = deployer.resources.Cloud
clouds = deployer.resources.Clouds()

user = deployer.resources.User
users = deployer.resources.Users()
group = deployer.resources.Group
groups = deployer.resources.Groups()
# appliance stuff
tsam = deployer.resources.Tsam

tsams = deployer.resources.Tsams()

diagnostics = deployer.troubleshooting.Diagnostics()
trace = deployer.troubleshooting.TraceFile()
errors = deployer.troubleshooting.ErrorFile()

#backup = bar.Backup
#backups = bar.Backups()
#restore = bar.restore
 
# wizard
from deployer.wizard import Wizard as wizard

# ACL constants
acl = deployer.resources.ACL
NO_PERMISSIONS = deployer.resources.ACL.NO_PERMISSIONS
READ_PERMISSION = deployer.resources.ACL.READ_PERMISSION
UPDATE_PERMISSION = deployer.resources.ACL.UPDATE_PERMISSION
CREATE_PERMISSION = deployer.resources.ACL.CREATE_PERMISSION
DELETE_PERMISSION = deployer.resources.ACL.DELETE_PERMISSION
ALL_PERMISSIONS = deployer.resources.ACL.ALL_PERMISSIONS

# addon type constants
DISK_ADDON = deployer.resources.AddOn.DISK_ADDON
NIC_ADDON = deployer.resources.AddOn.NIC_ADDON
USER_ADDON = deployer.resources.AddOn.USER_ADDON

# utility method to wait for things to happen
from deployer.utils import waitFor



# shortcuts
from deployer.shortcuts import exit, help



# CLI version
class _CLIVersioner(object):
    'RM09373'

    def __repr__(self):
        return utos(unicode(self))


    def __unicode__(self):
        return cliversionx.CLI_VERSION

cliversion = _CLIVersioner()



# server version
class _Versioner(object):
    'RM09011'

    def __repr__(self):
        return utos(unicode(self))


    def __unicode__(self):
        try:
            host = deployer.http.host
        except AttributeError:
            host = message('RM09133')

        try:
            version = versionx.getVersion()['version']
        except Exception, e:
            version = message('RM09134')

        return message('RM09135', host, version)
#record deployer.version since it is overwritten.
versionClass = versionx
version = _Versioner()



# make data printable
def printable(o):
    """Converts a Python string or unicode object to an equivalent
    object that can be passed to the Python print command.
    """

    return utos(o)

#*===================================================================
# purescale additions
#*===================================================================
if isSparta():
    dbapplication = deployer.resources.DBApplication
    dbapplications = deployer.resources.DBApplications()
    database_operation = deployer.resources.DBOperation
    database_operations = deployer.resources.DBOperations
    dboperation = deployer.resources.DBOperation
    dboperations = deployer.resources.DBOperations()
    dbgroup = deployer.resources.Dbgroup
    dbgroups = deployer.resources.Dbgroups() 
    pureScaleInstance = deployer.resources.pureScaleInstance
    pureScaleInstances = deployer.resources.pureScaleInstances()
    instgroup = deployer.resources.instgroup
    instgroups = deployer.resources.instgroups()
    instuser = deployer.resources.instuser
    instusers = deployer.resources.instusers()
    
application = deployer.resources.Application
applications = deployer.resources.Applications()
application_artifact = deployer.resources.Artifact
application_artifacts = deployer.resources.Artifacts
virtualapplication = deployer.resources.VirtualApplication
virtualapplications = deployer.resources.VirtualApplications()
plugin = deployer.resources.Plugin
plugins = deployer.resources.Plugins()
monitoring = deployer.resources.Monitoring
logging = deployer.resources.Logging
virtualapplication_operation = deployer.resources.Operation
virtualapplication_operations = deployer.resources.Operations
sharedservice = deployer.resources.SharedService
sharedservices = deployer.resources.SharedServices()
sharedservice_artifact = deployer.resources.Artifact
sharedservice_artifacts = deployer.resources.Artifacts
component = deployer.resources.Component
components = deployer.resources.Components()
database = deployer.resources.Database
databases = deployer.resources.Databases()
dbimage = deployer.resources.Dbimage
dbimages = deployer.resources.Dbimages()
dbworkload = deployer.resources.DatabaseWorkload
dbworkloads = deployer.resources.DatabaseWorkloads()
dbworkload_workloadfile = deployer.resources.WorkloadFile
dbworkload_workloadfiles = deployer.resources.WorkloadFiles
if not isSparta():
    db2fixpack = deployer.resources.DB2FixPack
    db2fixpacks = deployer.resources.DB2FixPacks()
    #db2fixpack_db2fixpackfile = deployer.resources.DB2FixpackFile
    #db2fixpack_db2fixpackfiles = deployer.resources.DB2FixpackFiles
else:
    wldfixpack = deployer.resources.wldFixPack
    wldfixpacks = deployer.resources.wldFixPacks()
patterntype = deployer.resources.PatternType
patterntypes = deployer.resources.PatternTypes()
deploysettings = deployer.resources.DeploySettings()
