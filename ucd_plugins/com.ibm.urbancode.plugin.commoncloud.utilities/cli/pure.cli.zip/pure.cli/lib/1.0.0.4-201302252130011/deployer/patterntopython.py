"""
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2012. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
"""

import java
import re
import base64

from messages import message

MSGINSERTRE = re.compile(r'(.*?)\$\{(\d+)\}(.*)')
PASSWORDRE = re.compile(r'(?i)(\A|[^A-Za-z])(p|pass)(w|wd|word)(\Z|[^A-Za-z])')


def _message(key, *inserts):
    genmsg = message(key)

    for i in range(0, len(inserts)):
        if isinstance(inserts[i], list):
            continue
        
        genmsg = genmsg.replace('${%d}' % i, str(inserts[i]))
        
    geninserts = []

    m = MSGINSERTRE.match(genmsg)
    while m:
        i = int(m.group(2))
        geninserts.append(str(inserts[i][0]))
        genmsg = m.group(1) + inserts[i][1] + m.group(3)
        m = MSGINSERTRE.match(genmsg)

    if geninserts:
        return '(' + repr(genmsg) + ' % (' + ','.join(geninserts) + '))'
    else:
        return repr(genmsg)


def _toBoolean(x):
    if x:
        return 'True'
    else:
        return 'False'


def patternToPython(p, f, includePasswords=False):
    # imports
    f.write('''
import java
import base64
import traceback
''')

    
    # utility functions
    f.write('''
def _findAddOn(patternPart, label):
    addons = filter(lambda addon: addon.label == label, deployer.addons)
    assert len(addons) == 1, _utos(%s)
    return addons[0]

''' %  (_message('RM09691', ['patternPart.partCaption', '%s'], ['patternPart.id', '%d'], ['label', '%s'])))

    f.write('''
def _findParameter(patternPart, partScript, key):
    parameter = partScript.getParameter(key, True)
    assert parameter, _utos(%s)
    return parameter

''' % (_message('RM09502', ['patternPart.partCaption', '%s'], ['patternPart.id', '%d'], ['partScript.label', '%s'], ['key', '%s'])))

    f.write('''
def _findPart(virtualImage, label, id):
    parts = filter(lambda part: part.label == label, virtualImage.parts)
    assert len(parts) == 1, _utos(%s)
    return parts[0]

''' % (_message('RM09498', ['label', '%s'], ['id', '%d'])))

    f.write('''
def _findPartScript(patternPart, type, label):
    patternScripts = filter(lambda ps: ps.type == type and ps.label == label, patternPart.scripts)
    assert len(patternScripts) == 1, _utos(%s)
    return patternScripts[0]

''' % (_message('RM09504', ['patternPart.partCaption', '%s'], ['patternPart.id', '%d'], ['label', '%s'])))

    f.write('''
def _findProperty(patternPart, pclass, key):
    property = patternPart.getProperty(pclass, key, True)
    assert property, _utos(%s)
    return property

''' % (_message('RM09499', ['patternPart.partCaption', '%s'], ['patternPart.id', '%d'], ['pclass', '%s'], ['key', '%s'])))

    f.write('''
def _findScript(patternPart, label):
    scripts = filter(lambda script: script.label == label, deployer.scripts)
    assert len(scripts) == 1, _utos(%s)
    return scripts[0]

''' %  (_message('RM09501', ['patternPart.partCaption', '%s'], ['patternPart.id', '%d'], ['label', '%s'])))

    f.write('''
def _findVirtualImage(name, version, build):
    matches = filter(lambda vi: vi.build == build and vi.version == version, deployer.virtualimages[name])
    assert len(matches) == 1 and matches[0].name == name, %s
    assert matches[0].licenseaccepted == 'T', _utos(%s)
    return matches[0]

''' % (_message('RM09496', ['name', '%s']), _message('RM09757', ['name', '%s'])))

    f.write('''
def _updateParameter(patternPart, partScript, key, defaultvalue, userConfigurable):
    try:
       parameter = _findParameter(patternPart, partScript, key)

       if (userConfigurable and not parameter['userConfigurable']) or \\
          (not userConfigurable and parameter['userConfigurable']) or \\
          parameter['defaultvalue'] != defaultvalue:
          partScript.setParameter(key, defaultvalue, userConfigurable=userConfigurable)
    except:
       traceback.print_exc()

''')

    f.write('''
def _updateProperty(patternPart, pclass, key, value, userConfigurable):
    try:
       property = _findProperty(patternPart, pclass, key)
    
       if (userConfigurable and not property['userConfigurable']) or \\
          (not userConfigurable and property['userConfigurable']) or \\
          property['value'] != value:
          patternPart.setProperty(pclass, key, value, userConfigurable=userConfigurable)
    except:
       traceback.print_exc()

''')

    f.write('''
def _utos(u):
    if isinstance(u, unicode):
        s = ''
        for b in java.lang.String(u).getBytes():
            s += chr(b & 0xff)
    else:
        s = str(u)

    return s

''')


    # ensure recreators locale matches exporters locale
    l = java.util.Locale.getDefault()
    if l.getCountry() != '':
        if l.getVariant():
            reqdLocale = 'java.util.Locale(%r,%r,%r)' % (l.getLanguage(), l.getCountry(), l.getVariant())
        else:
            reqdLocale = 'java.util.Locale(%r,%r)' % (l.getLanguage(), l.getCountry())
    else:
        reqdLocale = 'java.util.Locale(%r)' % (l.getLanguage())
      
    f.write('''
requiredLocale = %s
if not java.util.Locale.getDefault().equals(requiredLocale):
    print _utos(%s)
    java.util.Locale.setDefault(requiredLocale)
''' % (reqdLocale, _message('RM09497', ['requiredLocale.toString()', '%s'])))


    # ensure the pattern name is unique
    f.write('''
patternName = %r

patterns = deployer.patterns[patternName]
assert not patterns or patterns[0].name != patternName, _utos(%s)
''' % (p.name, _message('RM09495', ['patternName', '%s'])))


    # find the virtual images for the pattern
    vis = []
    for ppart in p.parts:
        vi = ppart.virtualimage
        if vi not in vis:
            vis.append(vi)

    f.write('''
virtualImages = [''')

    f.write(','.join([ '''
    _findVirtualImage(%r, %r, %r)''' % (vi.name, vi.version, vi.build) for vi in vis ]))

    f.write('''
]
''')


    # create the pattern
    f.write('''
pattern = deployer.patterns << {
    "name": patternName''')

    if p.description is not None:
        f.write(''',
    "description": %r''' % (p.description))

    f.write('''
}
''')


    # process each part
    for ppart in p.parts:
        # generate a unique variable name for each ppart
        ppname = 'patternPart_%d' % ppart.id

        
        # find matching conceptual part and create ppart
        viIndex = vis.index(ppart.virtualimage)

        f.write('''
%s = pattern.parts << _findPart(virtualImages[%d], %r, %d)
''' % (ppname, viIndex, ppart.partCaption, ppart.id))


        # set count
        if ppart.count > 0:
            f.write('''%s.count = %d
''' % (ppname, ppart.count))


        # process properties
        for prop in ppart.properties:
            value = prop['value']

            # skip passwords
            if not includePasswords and PASSWORDRE.search(prop['key']):
                f.write('''# password value omitted for %s.%s
''' % (prop['pclass'], prop['key']))
                value = ''
            
            if includePasswords and PASSWORDRE.search(prop['key']):
                # base 64 encode
                f.write('''_updateProperty(%s, %r, %r, base64.b64decode(%r), %s)
''' % (ppname, prop['pclass'], prop['key'], base64.b64encode(value), _toBoolean(prop['userConfigurable'])))
            else:
                # update property
                f.write('''_updateProperty(%s, %r, %r, %r, %s)
''' % (ppname, prop['pclass'], prop['key'], value, _toBoolean(prop['userConfigurable'])))


        # process scripts
        for pscript in ppart.scripts:
            # application scripts
            if pscript.type == 'APPLICATION':
                findfunc = '_findScript'

            # addon scripts
            elif pscript.type.startswith('ADDON_'):
                findfunc = '_findAddOn'

            # skip facet scripts -- we'll get them after we set up
            # advanced options
            else:
                continue


            # generate a unique variable name for each pscript
            psname = 'partScript_%d_%d' % (ppart.id, pscript.id)

            
            # find matching script and create pscript
            f.write('''
%s = %s.scripts << %s(%s, %r)
''' % (psname, ppname, findfunc, ppname, pscript.label))


            # process parameters
            for parm in pscript.parameters:
                defaultvalue = parm['defaultvalue']

                # skip passwords
                if not includePasswords and PASSWORDRE.search(parm['key']):
                    f.write('''# password value omitted for %s
''' % (parm['key']))
                    defaultvalue = ''

                # update parameter
                f.write('''_updateParameter(%s, %s, %r, %r, %s)
''' % (ppname, psname, parm['key'], defaultvalue, _toBoolean(parm['userConfigurable'])))


    # set part/script ordering constraints
    for ppart in p.parts:
        ppname = 'patternPart_%d' % ppart.id
        afterparts = [ 'patternPart_%d' % otherppart.id for otherppart in ppart.startsafter ]

        if afterparts:
            f.write('''
%s.startsafter += [ %s ]
''' % (ppname, ','.join(afterparts)))

        for pscript in ppart.scripts:
            psname = 'partScript_%d_%d' % (ppart.id, pscript.id)
            afterscripts = [ 'partScript_%d_%d' % (otherscript.part.id, otherscript.id) for otherscript in pscript.startsafter ]

            if afterscripts:
                f.write('''%s.startsafter += [ %s ]
''' % (psname, ','.join(afterscripts)))


    # set advanced options
    if p.advancedoptions:
        f.write('''
pattern.advancedoptions = %r
''' % (list(p.advancedoptions)))


    # set parameters on any scripts added by advanced options
    for ppart in p.parts:
        # reference ppart name from above
        ppname = 'patternPart_%d' % ppart.id


        # process scripts
        for pscript in ppart.scripts:
            if pscript.type != 'CONFIGURATION':
                continue


            # generate a unique variable name for each pscript
            psname = 'partScript_%d_%d' % (ppart.id, pscript.id)


            # find matching pscript
            f.write('''
%s = _findPartScript(%s, 'CONFIGURATION', %r)
''' % (psname, ppname, pscript.label))


            # process parameters
            for parm in pscript.parameters:
                defaultvalue = parm['defaultvalue']

                # skip passwords
                if not includePasswords and PASSWORDRE.search(parm['key']):
                    f.write('''# password value omitted for %s
''' % (parm['key']))
                    defaultvalue = ''


                # update parameter
                f.write('''_updateParameter(%s, %s, %r, %r, %s)
''' % (ppname, psname, parm['key'], defaultvalue, _toBoolean(parm['userConfigurable'])))


    # copy publish status
    if p.isReadOnly():
        f.write('''
pattern.makeReadOnly()
''')
