"""
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2012. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
"""

from commonattrs import CommonAttributes
from deployer import http, utils, validators,messages
from relationships import RelatedResource, RelatedResourceCollection
from restresource import RESTResource
from storage import Storage
from network import Network

@utils.classinit
class Hypervisor(RelatedResource, CommonAttributes):
    'RM09074'


    @classmethod
    def _classinit(cls):
        cls._registerURI(r'\A/resources/hypervisors/(?P<id>\d+)\Z')
        cls._registerURI(r'\A/resources/hypervisors/(?P<id>PM-\d+)\Z')

        # MJB - acl.bnd says hypervisors have acls, but GUI doesn't show them
        # cls._defineAttribute('acl', "Access control list for this hypervisor.", readonly=True)
        cls._defineRESTAttribute('address', 'RM09149', validator=validators.string, visible=[ lambda hyp: hyp._restattrs.has_key('address') ])
        cls._defineAttribute('certificate', 'RM09150', readonly=True, elided=True)
        cls._defineRESTAttribute('certified', 'RM09151', values=('T','F','I'), visible=[ lambda hyp: hyp._restattrs.has_key('certified') ])
        cls._defineRESTAttribute('created', 'RM09152', readonly=True)
        cls._defineRESTAttribute('currentmessage', 'RM09153', readonly=True)
        cls._defineRESTAttribute('currentmessage_text', 'RM09154', readonly=True)
        cls._defineRESTAttribute('currentstatus', 'RM09155', readonly=True)
        cls._defineRESTAttribute('currentstatus_text', 'RM09156', readonly=True)
        cls._defineRESTAttribute('desiredstatus', 'RM09157', values=('RM01025','RM01006', 'RM01009'))
        cls._defineRESTAttribute('desiredstatus_text', 'RM09158', readonly=True)
        cls._defineAttribute('id', 'RM09159', readonly=True)
        cls._defineRESTAttribute('uuid', 'RM09875', readonly=True)
        cls._defineRESTAttribute('name', 'RM09160', validator=validators.string)
        cls._defineRESTAttribute('password', 'RM09161', validator=validators.string, writeonly=True)
        cls._defineRESTAttribute('type', 'RM09162', values=('ESX','zVM'))
        cls._defineRESTAttribute('updated', 'RM09163', readonly=True)
        cls._defineRESTAttribute('userid', 'RM09164', validator=validators.string)
        cls._defineRESTAttribute('pvuscore', 'RM09545', validator=validators.integer, elided=True)
        cls._defineRESTAttribute('version', 'RM09546', readonly=True, elided=True)
        cls._defineAttribute('virtualmachines', 'RM09853', readonly=True, elided=True)

        cls._methodHelp('__contains__', '__delattr__', 'delete', '__eq__',
                        '__hash__', 'isStatusTransient', '__nonzero__',
                        'refresh', '__repr__', '__str__', '__unicode__',
                        'waitFor',
                        'acceptCertificate', 'discover', 'isMaintenance',
                        'isQuiesced', 'isStarted', 'maintenance',
                        'quiesce', 'start','isStorageInUse','setStorageInUse',
                        'isNetworkInUse','setNetworkInUse')

    def _getId(self):
        # If the hypervisor is a PM, ensure return of a 'PM-' id
        hypid = self._restattrs['id'];
        if not self._restattrs.get('hypervisormachineid') or isinstance(hypid, str) or isinstance(hypid, unicode):
            return hypid
        else:
            return 'PM-%d' % hypid

    # certificate attribute

    def _getCertificate(self):
        json = http.get('%s?certificate=true' % self.uri)
        return '\n'.join(json['certificates'])


    # pvuscore attribute

    def _getPvuscore(self):
        return http.get('%s/hypervisorpvuscore' % self.uri)


    def _setPvuscore(self, pvuscore):
        return http.putJSON('%s/hypervisorpvuscore' % self.uri, pvuscore)


    # version attribute

    def _getVersion(self):
        return http.get('%s/hypervisorversion' % self.uri)


    # UUID attribute

    def _getUuid(self):
        return http.get('%s/hypervisoruuid' % self.uri)


    # virtualmachines attribute
    def _getVirtualmachines(self):
        return [ RESTResource.resourceForURI('/resources/instances/%d/virtualMachines/%d' % (vm['instanceid'], vm['id']), vm) for vm in http.get('%s/virtualMachines' % self.uri) ]


    # private methods

    def _getMigrationTargets(self):
        return http.get('%s/migrate' % self.uri) if self.isQuiesced() else {}


    # TODO - consider making this public
    def _migrateVirtualMachines(self, migrations):
        idmap = {}
        for vm, hyp in migrations:
            validators.instance(deployer.virtualmachine, vm, 'virtualmachine')
            if hyp:
                validators.instance(self.__class__, hyp, 'hypervisor')

            idmap[str(vm.id)] = str(hyp.id) if hyp else 'RM01077' # Status.MIGRATE_WCA_CHOOSE

        http.putJSON('%s/migrate' % self.uri, idmap)
    

    # public methods
    def acceptCertificate(self,  optin='T'):
        'RM09744'
        if optin == 'T':
            http.putJSON(self.uri, { 'certified': 'T' })
        else:
            http.putJSON(self.uri, { 'certified': 'T', 'nooptin': 'T' })

        self.refresh()


    def discover(self, optin='T'):
        'RM09076'
        if optin == 'T':
            http.get(self.uri + '?discover=true')
        else:
            http.get(self.uri + '?discover=true&nooptin=true')


    def isMaintenance(self):
        'RM09077'
        return self.currentstatus == 'RM01025'


    def isQuiesced(self):
        'RM09849'
        return self.currentstatus == 'RM01009'


    def isStarted(self):
        'RM09078'
        return self.currentstatus == 'RM01006'


    def maintenance(self):
        'RM09079'
        self.desiredstatus = 'RM01025'


    def quiesce(self):
        'RM09850'
        self.desiredstatus = 'RM01009'


    def start(self):
        'RM09080'
        self.desiredstatus = 'RM01006'
        
    def isStorageInUse(self, storage):
         'RM09656'
         if not isinstance(storage, Storage):
             raise ValueError(utils.utos(messages.message('RM09900')))
         rela = http.get('/resources/hypervisorsstorage?hypervisorsid=%s&storageid=%d' % (self.id, storage.id))
         if (rela and rela[0] and rela[0].get('currentstatus') and rela[0].get('currentstatus')=='RM01016'):
             return 'T'
         else:
             return 'F'

    def setStorageInUse(self, storage, value):
        'RM09898'
        if not isinstance(storage, Storage):
            raise ValueError(utils.utos(messages.message('RM09900')))
        hypid = self.id
        if (value=='T'):
            nooptin = 'F'
        else:
            nooptin = 'T'
        return http.putJSON('/resources/hypervisorsstorage/%s-%d' % (hypid, storage.id), {'nooptin': nooptin})

    def isNetworkInUse(self, network):
         'RM09658'
         if not isinstance(network, Network):
             raise ValueError(utils.utos(messages.message('RM09901')))
         if (network.currentstatus=='RM01016'):
             return 'T'
         else:
             return 'F'

    def setNetworkInUse(self, network, value):
        'RM09899'
        if not isinstance(network, Network):
            raise ValueError(utils.utos(messages.message('RM09901')))
        hypid = self.id
        if (value=='T'):
            nooptin = 'F'
        else:
            nooptin = 'T'
        return http.putJSON('/resources/hypervisorsnetworks/%s-%d' % (hypid, network.id), {'nooptin': nooptin})
    # TODO - dependencies like this are bad -- if we want to do this it needs
    # to be set up as a contains relationship
    # def getVirtualMachines(self):
    #     return VirtualMachines('%s/virtualMachines' % self.uri)




@utils.classinit
class Hypervisors(RelatedResourceCollection):
    'RM09031'

    @classmethod
    def _classinit(cls):
        cls._contains(Hypervisor)
        cls._methodHelp('__contains__', 'create', 'delete', '__delitem__',
                        '__getattr__', '__getitem__', '__iter__',
                        '__len__', 'list', '__lshift__', '__repr__',
                        '__rshift__', '__str__', '__unicode__')


    CREATE_ATTRIBUTES = [
        Hypervisor._wizardStep('name'),
        Hypervisor._wizardStep('type'),
        Hypervisor._wizardStep('address'),
        Hypervisor._wizardStep('userid'),
        Hypervisor._wizardStep('password')
    ]
