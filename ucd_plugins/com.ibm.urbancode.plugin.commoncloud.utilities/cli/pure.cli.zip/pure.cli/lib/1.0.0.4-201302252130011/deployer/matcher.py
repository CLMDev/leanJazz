"""
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2012. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
"""
import utils

class MultiPartMatcher(object):
    def _keyComparator(a, b):
        i = -1
        while True:
            if -i > len(a):
                if -i > len(b):
                    # same length, same contents
                    return 0
                else:
                    # try to match longer sequences first
                    return 1
            elif -i > len(b):
                # try to match longer sequences first
                return -1
                

            if a[i] == b[i]:
                i -= 1
                continue
            elif a[i] == '*':
                return 1
            elif b[i] == '*':
                return -1
            else:
                return cmp(a[i], b[i])

    _keyComparator = staticmethod(_keyComparator)


    # values {object: object, ...} if parser is supplied, or
    #        [([string,...], object),...] if not
    # parser callable that turns keys in d into [string,...]
    def __init__(self, values, parser=None):
        self.parser = parser

        if isinstance(values, list):
            self.sorted = [ x for x in values ]
        else:
            self.sorted = [ (parser(k), values[k]) for k in values.keys() ]

        self.sorted.sort(lambda x, y: MultiPartMatcher._keyComparator(x[0], y[0]))


    def valueFor(self, check):
        if isinstance(check, list) or isinstance(check, tuple):
            pass
        elif self.parser:
            check = self.parser(check)

        if isinstance(check, list) or isinstance(check, tuple):
            pass
        else:
            raise ValueError, 'check'

        for s in self.sorted:
            if utils.all(map(None, s[0], check), lambda x: x[0] == x[1] or x[0] == '*'):
                return s[1]

        return None
