#
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2012. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
#
# classes for working with the cloud and IP group data associated with
# an environment profile

from deployer import http, messages, prettify, utils, mappingutils
from deployer.utils import utos
from restresource import RESTResource


@utils.classinit
class EnvironmentProfileCloud(messages.Helpable):
    'RM09589'


    @classmethod
    def _classinit(cls):
        cls._methodHelp('__eq__', '__nozero__', '__repr__', '__str__',
                        '__unicode__')
        cls._propertyHelp('alias', 'ipgroups')


    def __init__(self, epcs, json):
        self._epcs = epcs
        self._parse(json)


    def _getAlias(self):
        return self._json['alias']


    def _setAlias(self, alias):
        http.putJSON('/resources/environmentprofilesclouds/%d' % self._epcs._ep.id, {
            'alias': alias,
            'cloudid': self._json['id']
        })
        self._refresh()


    def _delAlias(self):
        self._setAlias(None)

    alias = property(_getAlias, _setAlias, _delAlias, doc='RM09590')


    def _getIPGroups(self):
        return self._ipgroups

    ipgroups = property(_getIPGroups, doc='RM09594')


    # private methods

    def _getCloudId(self):
        return self._json['id']


    def _parse(self, json):
        self._json = json

        if hasattr(self, '_ipgroups'):
            self._ipgroups._parse(self._json['ip_groups'])
        else:
            self._ipgroups = EnvironmentProfileCloudIPGroups(self, self._json['ip_groups'])


    def _refresh(self):
        self._epcs._refresh()


    # public methods

    def __eq__(self, other):
        'RM09591'

        return isinstance(other, EnvironmentProfileCloud) and self._epcs == other._epcs and self._json['id'] == other._json['id']


    def __nonzero__(self):
        'RM09592'
        return True


    def __repr__(self):
        'RM09593'
        return utos(unicode(self))


    def __str__(self):
        'RM09593'
        return repr(self)


    def __unicode__(self):
        'RM09593'

        result = {
            'alias': self._json['alias'],
            'ipgroups': prettify.UnquotedString(unicode(self.ipgroups))
        }

        if prettify.enabled:
            return prettify.prettify(result)
        else:
            return unicode(result)




@utils.classinit
class EnvironmentProfileClouds(messages.Helpable):
    'RM09572'


    @classmethod
    def _classinit(cls):
        cls._methodHelp('addCloud', 'clear', '__contains__', '__delitem__',
                        'get', '__getitem__', 'has_key', 'items', '__iter__',
                        'iteritems', 'iterkeys', 'itervalues', 'keys',
                        '__len__', '__repr__', '__setitem__', '__str__',
                        '__unicode__', 'values')


    def __init__(self, ep, json):
        self._ep = ep
        self._parse(json)


    # private methods

    def _parse(self, json):
        self._json = json
        oldcs = self.__dict__.get('_clouds', {})
        self._clouds = {}

        for newcj in json:
            c = RESTResource.resourceForURI('/resources/epclouds/%d' % newcj['id'], newcj)
            epc = oldcs.get(c)

            if epc:
                del oldcs[c]
                epc._parse(newcj)
            else:
                epc = EnvironmentProfileCloud(self, newcj)

            self._clouds[c] = epc


    def _refresh(self):
        self._parse(http.get(self._ep.uri)['clouds'])


    # public methods

    def addCloud(self, cloud, alias=None):
        'RM09573'
        cloud = mappingutils.getEPMappingResource(cloud)
        
        http.postJSON('/resources/environmentprofilesclouds', {
            'environmentprofileid': self._ep.id,
            'cloudid': cloud.id
        })

        self._refresh()

        if alias != None:
            self[cloud].alias = alias


    def clear(self):
        'RM09574'

        for cloud in self.keys():
            del self[cloud]

        self._refresh()


    def __contains__(self, item):
        'RM09588'
        return self._clouds.has_key(item)


    def __delitem__(self, cloud):
        'RM09575'
        cloud = mappingutils.getEPMappingResource(cloud)
        http.delete('/resources/environmentprofilesclouds/%d?cloudid=%d' % (self._ep.id, cloud.id))
        del self._clouds[cloud]


    def get(self, key, default=None):
        'RM09576'
        key = mappingutils.getEPMappingResource(key)
        if key in self:
            return self[key]
        else:
            return default


    def __getitem__(self, key):
        'RM09577'
        key = mappingutils.getEPMappingResource(key)
        return self._clouds[key]


    def has_key(self, key):
        'RM09578'
        return self._clouds.has_key(key)


    def items(self):
        'RM09579'
        return self._clouds.items()


    def __iter__(self):
        'RM09580'
        return self.iterkeys()


    def iteritems(self):
        'RM09581'
        return self._clouds.iteritems()


    def iterkeys(self):
        'RM09580'
        return self._clouds.iterkeys()


    def itervalues(self):
        'RM09582'
        return self._clouds.itervalues()


    def keys(self):
        'RM09583'
        return self._clouds.keys()


    def __len__(self):
        'RM09584'
        return len(self._clouds)


    def __repr__(self):
        'RM09585'
        return utos(unicode(self))


    def __setitem__(self, key, value):
        'RM09586'
        self.addCloud(key, value)


    def __str__(self):
        'RM09585'
        return repr(self)


    def __unicode__(self):
        'RM09585'

        result = {}

        for cloud, epc in self.iteritems():
            result[prettify.UnquotedString(u'(' + cloud.__class__.__name__ + u' ' + cloud.name + u')')] = prettify.UnquotedString(unicode(epc))

        if prettify.enabled:
            return prettify.prettify(result)
        else:
            return unicode(result)


    def values(self):
        'RM09587'
        return self._clouds.values()




@utils.classinit
class EnvironmentProfileCloudIPGroup(messages.Helpable):
    'RM09612'


    @classmethod
    def _classinit(cls):
        cls._methodHelp('__eq__', '__nonzero__', '__repr__', '__str__', '__unicode__')
        cls._propertyHelp('alias')


    def __init__(self, epcipgs, json):
        self._epcipgs = epcipgs
        self._parse(json)


    def _getAlias(self):
        return self._json['alias']

    def _setAlias(self, alias):
        http.putJSON('/resources/environmentprofilescloudsipgroups/%d' % self._epcipgs._epc._epcs._ep.id, {
            'cloudid': self._epcipgs._epc._getCloudId(),
            'ipgroupid': self._json['id'],
            'alias': alias
        })
        self._refresh()

    def _delAlias(self):
        self._setAlias(None)

    alias = property(_getAlias, _setAlias, _delAlias, doc='RM09613')


    # private methods

    def _parse(self, json):
        self._json = json


    def _refresh(self):
        self._epcipgs._refresh()


    # public methods

    def __eq__(self, other):
        'RM09614'

        return isinstance(other, EnvironmentProfileCloudIPGroup) and self._epcipgs == other._epcipgs and self._json['id'] == other._json['id']


    def __nonzero__(self):
        'RM09615'
        return True


    def __repr__(self):
        'RM09616'
        return utos(unicode(self))


    def __str__(self):
        'RM09616'
        return repr(self)


    def __unicode__(self):
        'RM09616'

        result = { 'alias': self._json['alias'] }
        if prettify.enabled:
            return prettify.prettify(result)
        else:
            return unicode(result)



@utils.classinit
class EnvironmentProfileCloudIPGroups(messages.Helpable):
    'RM09595'


    @classmethod
    def _classinit(cls):
        cls._methodHelp('addIPGroup', 'clear', '__contains__', '__delitem__', 'get',
                        '__getitem__', 'has_key', 'items', '__iter__', 'iteritems',
                        'iterkeys', 'itervalues', 'keys', '__len__', '__repr__',
                        '__setitem__', '__str__', '__unicode__', 'values')


    def __init__(self, epc, json):
        self._epc = epc
        self._parse(json)


    # private methods

    def _parse(self, json):
        self._json = json
        oldipgs = self.__dict__.get('_ipgroups', {})
        self._ipgroups = {}

        for newipgj in json:
            if not newipgj['inuse']:
                continue
            ipg = RESTResource.resourceForURI('/resources/epipgroups/%d' % newipgj['id'], newipgj)
            epcipg = oldipgs.get(ipg)

            if epcipg:
                del oldipgs[ipg]
                epcipg._parse(newipgj)
            else:
                epcipg = EnvironmentProfileCloudIPGroup(self, newipgj)

            self._ipgroups[ipg] = epcipg


    def _refresh(self):
        self._epc._refresh()


    # public methods

    def addIPGroup(self, ipg, alias=None):
        'RM09596'
        ipg = mappingutils.getEPMappingResource(ipg)
        
        http.postJSON('/resources/environmentprofilescloudsipgroups', {
            'environmentprofileid': self._epc._epcs._ep.id,
            'cloudid': self._epc._getCloudId(),
            'ipgroupid': ipg.id,
            'inuse': 1
        })

        self._refresh()

        if alias != None:
            self[ipg].alias = alias

        
    def clear(self):
        'RM09597'

        for ipg in self.keys():
            del self[ipg]

        self._refresh()


    def __contains__(self, item):
        'RM09598'
        return self._ipgroups.has_key(item)


    def __delitem__(self, ipg):
        'RM09599'
        ipg = mappingutils.getEPMappingResource(ipg)
        
        http.postJSON('/resources/environmentprofilescloudsipgroups', {
            'environmentprofileid': self._epc._epcs._ep.id,
            'cloudid': self._epc._getCloudId(),
            'ipgroupid': ipg.id,
            'inuse': 0
        })

        del self._ipgroups[ipg]


    def get(self, key, default=None):
        'RM09600'

        if key in self:
            return self[key]
        else:
            return default


    def __getitem__(self, key):
        'RM09601'
        key = mappingutils.getEPMappingResource(key)
        return self._ipgroups[key]


    def has_key(self, key):
        'RM09602'
        return self._ipgroups.has_key(key)


    def items(self):
        'RM09603'
        return self._ipgroups.items()


    def __iter__(self):
        'RM09604'
        return self.iterkeys()


    def iteritems(self):
        'RM09605'
        return self._ipgroups.iteritems()


    def iterkeys(self):
        'RM09604'
        return self._ipgroups.iterkeys()


    def itervalues(self):
        'RM09606'
        return self._ipgroups.itervalues()


    def keys(self):
        'RM09607'
        return self._ipgroups.keys()


    def __len__(self):
        'RM09608'
        return len(self._ipgroups)


    def __repr__(self):
        'RM09609'
        return utos(unicode(self))


    def __setitem__(self, key, value):
        'RM09610'
        self.addIPGroup(key, value)


    def __str__(self):
        'RM09609'
        return repr(self)


    def __unicode__(self):
        'RM09609'

        result = {}

        for ipgroup, epcipg in self.iteritems():
            result[prettify.UnquotedString(u'(' + ipgroup.__class__.__name__ + u' ' + ipgroup.name + u')')] = prettify.UnquotedString(unicode(epcipg))

        if prettify.enabled:
            return prettify.prettify(result)
        else:
            return unicode(result)


    def values(self):
        'RM09611'
        return self._ipgroups.values()

 
@utils.classinit
class EPCloud(RESTResource):
    
    @classmethod
    def _classinit(cls):
        #fake uri
        cls._registerURI(r'\A/resources/epclouds/(?P<id>\d+)\Z')
        
        cls._defineRESTAttribute('id', 'RM09140', readonly=True)
        cls._defineRESTAttribute('name', 'RM09141', readonly=True)

@utils.classinit
class EPIPGroup(RESTResource):
    
    @classmethod
    def _classinit(cls):
        #fake uri
        cls._registerURI(r'\A/resources/epipgroups/(?P<id>\d+)\Z')
        
        cls._defineRESTAttribute('id', 'RM09246', readonly=True)
        cls._defineRESTAttribute('name', 'RM09248', readonly=True)