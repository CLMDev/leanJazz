"""
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2012. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
"""

from commonattrs import CommonAttributes
import deployer
from deployer import utils, validators
from epclouds import EnvironmentProfileCloud, EnvironmentProfileClouds, EnvironmentProfileCloudIPGroup, EnvironmentProfileCloudIPGroups
from relationships import RelatedResource, RelatedResourceCollection
from deployer import http, utils, validators
from deployer.resources.restresource import RESTResource
from deployer import mappingutils

@utils.classinit
class EnvironmentProfile(RelatedResource, CommonAttributes):
    'RM09549'


    @classmethod
    def _classinit(cls):
        cls._registerURI(r'\A/resources/environmentProfiles/(?P<id>\d+)\Z')

        cls._defineAttribute('acl', 'RM09569', readonly=True, readonlydoc=False, elided=True)
        cls._defineAttribute('clouds', 'RM09571', readonly=True, readonlydoc=False, elided=True)
        cls._defineRESTAttribute('created', 'RM09570', readonly=True)
        cls._defineRESTAttribute('currentmessage', 'RM09568', readonly=True)
        cls._defineAttribute('currentmessage_text', 'RM09154', readonly=True)
        cls._defineRESTAttribute('currentstatus', 'RM09550', readonly=True)
        cls._defineAttribute('currentstatus_text', 'RM09156', readonly=True)
        cls._defineRESTAttribute('description', 'RM09552', validator=utils.curryFunction(validators.optional, validators.string))
        cls._defineRESTAttribute('environment', 'RM09553', values=(0,1,2,3,4,5,6,7))
        cls._defineRESTAttribute('id', 'RM09555', readonly=True)
        cls._defineRESTAttribute('ipsource', 'RM09556', values=(0,1))
        cls._defineRESTAttribute('name', 'RM09551', validator=validators.string)
        
        if utils.isIPAS():
            cls._defineRESTAttribute('platform', 'IWD12210', readonly=True, readonlydoc=False, values=['PureSystems_ESX','PureSystems_PowerVM'])
        else:
            cls._defineRESTAttribute('platform', 'RM09563', readonly=True, readonlydoc=False, values=['ESX','PowerVM','zVM'])
            
        cls._defineRESTAttribute('updated', 'RM09557', readonly=True)
        cls._defineRESTAttribute('vmname_pattern', 'RM09554', validator=utils.curryFunction(validators.optional, validators.string))
        cls._defineRESTAttribute('vcpu_cap', 'RM09649', readonly=False)
        cls._defineRESTAttribute('vcpu_reserved', 'RM09650', readonly=True)
        cls._defineRESTAttribute('vcpu_inuse', 'RM09651', readonly=True)
        cls._defineRESTAttribute('pcpu_cap', 'RM09640', readonly=False)
        cls._defineRESTAttribute('pcpu_reserved', 'RM09641', readonly=True)
        cls._defineRESTAttribute('pcpu_inuse', 'RM09642', readonly=True)
        cls._defineRESTAttribute('memory_cap', 'RM09643', readonly=False)
        cls._defineRESTAttribute('memory_reserved', 'RM09644', readonly=True)
        cls._defineRESTAttribute('memory_inuse', 'RM09645', readonly=True)
        cls._defineRESTAttribute('storage_cap', 'RM09646', readonly=False)
        cls._defineRESTAttribute('storage_reserved', 'RM09647', readonly=True)
        cls._defineRESTAttribute('storage_inuse', 'RM09648', readonly=True)
        cls._defineRESTAttribute('licenses_limits', 'RM09653', readonly=False)
        #IPAS only
        if utils.isIPAS():
            cls._defineRESTAttribute('deployment_priority', 'IWD12217', restname='maxpriority', readonly=False, elited=True)
        

        cls._methodHelp('__contains__', '__delattr__', 'delete', '__eq__',
                        '__hash__', 'isStatusTransient', '__nonzero__',
                        'refresh', '__repr__', '__str__', '__unicode__',
                        'waitFor',
                        'clone', 'getLicenseLimitTotalAllocation', 'setLicenseLimitTotalAllocation')

    ALL_ENVIRONMENT = 0
    DEVELOPMENT_ENVIRONMENT = 1
    TEST_ENVIRONMENT = 2
    QUALITY_ASSURANCE_ENVIRONMENT = 3
    PERFORMANCE_ENVIRONMENT = 4
    RESEARCH_ENVIRONMENT = 5
    PRODUCTION_ENVIRONMENT = 6
    PRE_PRODUCTION_ENVIRONMENT = 7

    # deprecated
    WEBSPHERE_CLOUDBURST_IPSOURCE = 0
    WORKLOAD_DEPLOYER_IPSOURCE = 0
    PATTERN_DEPLOYER_IPSOURCE = 1


    def refresh(self):
        if hasattr(self, '_clouds'):
            del self._clouds
        super(EnvironmentProfile, self).refresh()

    def _getDeployment_priority(self):
        if self._restattrs.has_key('maxpriority'):
            return RESTResource.resourceForURI('/resources/deploymentPriorities/%s' % self._restattrs['maxpriority'])
        return None
    
    def _setDeployment_priority(self, sla):
        id = sla.id
        http.putJSON(self.uri, { 'maxpriority': id })
        self.refresh()
        
    def _getClouds(self):
        try:
            return self._clouds
        except AttributeError:
            self._clouds = EnvironmentProfileClouds(self, self._restattrs['clouds'])
            return self._clouds


    def clone(self, name):
        'RM09560'
        return deployer.environmentprofiles._create({"name": name, "platform": self.platform, "environment": self.environment, "originalid": str(self.id)})

    def getLicenseLimitTotalAllocation(self, productid, license_type):
        'RM09886'
        
        prop = utils.find(lambda p: p['productid'] == productid and p['type'] == license_type, self.licenses_limits)

        return prop['totalallocation']


    def setLicenseLimitTotalAllocation(self, productid, license_type, value=0):
        'RM09885'

        prop = utils.find(lambda p: p['productid'] == productid and p['type'] == license_type, self.licenses_limits)

        prop['totalallocation'] = value;

        http.putJSON(self.uri, { 'licenses_limits': [ prop ] })
        self.refresh()



@utils.classinit
class EnvironmentProfiles(RelatedResourceCollection):
    'RM09548'


    @classmethod
    def _classinit(cls):
        cls._contains(EnvironmentProfile)
        cls._methodHelp('__contains__', 'create', 'delete', '__delitem__',
                        '__getattr__', '__getitem__', '__iter__',
                        '__len__', 'list', '__lshift__', '__repr__',
                        '__rshift__', '__str__', '__unicode__')


    CREATE_ATTRIBUTES = [
        EnvironmentProfile._wizardStep('name'),
        EnvironmentProfile._wizardStep('description', optional=True),
        EnvironmentProfile._wizardStep('platform'),
        EnvironmentProfile._wizardStep('environment', fromString=int)
    ]
    
    if utils.isIPAS():
        CREATE_ATTRIBUTES.append(EnvironmentProfile._wizardStep('deployment_priority', optional=True))


    @classmethod
    def _restname(cls):
        return 'environmentProfiles'


    def _create(self, dict):
        if utils.isIPAS() and dict.has_key('deployment_priority'):
            slaId = dict['deployment_priority'].id
            del dict['deployment_priority']
            dict['maxpriority'] = slaId
            return super(EnvironmentProfiles, self)._create(dict, ['originalid', 'maxpriority'])
        else:
            return super(EnvironmentProfiles, self)._create(dict, ['originalid'])

    def _list(self, filt = {}):
        # REST API doesn't support some queries, do that in CLI side
        result = super(EnvironmentProfiles, self)._list(filt)
        return utils.filterRestResult(result, filt)