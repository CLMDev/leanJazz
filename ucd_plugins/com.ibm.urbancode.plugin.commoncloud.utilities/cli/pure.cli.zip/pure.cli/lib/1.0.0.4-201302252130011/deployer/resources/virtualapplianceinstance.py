"""
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2012. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
"""

from commonattrs import CommonAttributes
import deployer
from deployer import http, utils, validators
from deployer.messages import message
import os
import part
from relationships import RelatedResource, RelatedResourceCollection
from restresource import RESTResource


@utils.classinit
class VirtualApplianceInstance(RelatedResource, CommonAttributes):
    'RM09950'


    @classmethod
    def _classinit(cls):
        cls._registerURI(r'\A/resources/virtualApplianceInstances/(?P<id>\d+)\Z')

        cls._defineAttribute('acl', 'RM09951', readonly=True, readonlydoc=False)
        cls._defineRESTAttribute('created', 'RM09952', readonly=True)
        cls._defineRESTAttribute('currentmessage', 'RM09953', readonly=True)
        cls._defineAttribute('currentmessage_text', 'RM09154', readonly=True)
        cls._defineRESTAttribute('currentstatus', 'RM09954', readonly=True)
        cls._defineAttribute('currentstatus_text', 'RM09156', readonly=True)
        cls._defineRESTAttribute('description', 'RM09955', readonly=True)
        cls._defineRESTAttribute('id', 'RM09956', readonly=True)
        cls._defineRESTAttribute('name', 'RM09957', readonly=True)
        #cls._defineRESTAttribute('operatingsystemdescription', '', readonly=True)
        #cls._defineRESTAttribute('operatingsystemid', '', readonly=True)
        #cls._defineRESTAttribute('operatingsystemversion', '', readonly=True)
        #cls._defineRESTAttribute('pmtype', 'RM09958', readonly=True)
        #cls._defineRESTAttribute('updated', 'RM09959', readonly=True)

        cls._methodHelp()


    @classmethod
    def _restname(cls):
        return 'virtualApplianceInstance'



@utils.classinit
class VirtualApplianceInstances(RelatedResourceCollection):
    'RM09960'


    @classmethod
    def _classinit(cls):
        cls._contains(VirtualApplianceInstance)
        cls._methodHelp('create')


    CREATE_ATTRIBUTES = [
        { 'name': 'virtualapplianceid', 'help': message('RM09961'), 'validator': validators.string },
        { 'name': 'name', 'help': message('RM09962'), 'validator': validators.string },
        { 'name': 'cloudid', 'help': message('RM09963'), 'validator': validators.string },
        { 'name': 'properties', 'help': message('RM09964'), 'validator': validators.string, 'optional': True },
    ]

    _PROPERTYHELP_ = [
        'progressIndicators'
    ]


    def _getLicense(self):

        return NULL

    def __init__(self):
        super(VirtualApplianceInstances, self).__init__()

        self.progressIndicators = False
        self.progressIndicators_ = property(doc=message('RM09539'))


    @classmethod
    def _restname(cls):
        return 'virtualApplianceInstances'



    # public methods

    def create(self, other):
        'RM09965'

        parms = None

        # <virtualapplianceinstances>.create("<url>")
        if (isinstance(other, str) or isinstance(other, unicode)) and not os.path.isfile(other):
            parms = { 'url': utils.stou(other) }

        # <virtualapplianceinstances>.create("<filename.ova>")
        elif (isinstance(other, str) or isinstance(other, unicode)) and os.path.isfile(other) and other.lower().endswith('.ovf'):
            if self.progressIndicators:
                f = progressindicators.ReadProgressFile(other, 'rb')
            else:
                f = file(other, 'rb')

            try:
                return self.create(f)
            finally:
                f.close()

        # <virtualapplianceinstances>.create(<file>)
        elif isinstance(other, file):
            if self.progressIndicators and not isinstance(other, progressindicators.ReadProgressFile):
                other = progressindicators.ReadProgressFile(other.name, other.mode)

            json = http.postChunked(self.uri, other)
            return RESTResource.resourceForURI('%s/%s' % (self.uri, json['id']))

        # <virtualapplianceinstances>.create({...})
        elif isinstance(other, dict):
            parms = utils.stou(other)

        if parms:
            return self._create(parms)
        else:
            return super(VirtualApplianceInstances, self).create(other)

