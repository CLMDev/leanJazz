"""
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2012. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
"""
import http, prettify

def listConfig(uri):
    #get appmodel
    model = http.get('%s?model' % uri)['model']
    
    #get metadata
    shortname = model['patterntype']
    version = model['version']
    plugins = http.get('/resources/patternTypes/%s/%s/plugins?status=avail&simple' % (shortname, version))
    allmetadata = http.postJSON('/resources/ApplicationModelMetadata', plugins)
    componentsmeta = []
    linksmeta = []
    if 'components' in allmetadata:
        componentsmeta = allmetadata['components']
    if 'links' in allmetadata:
        linksmeta = allmetadata['links']
        
    #generate config json
    config = {}
    nodes = model['nodes']
    links = model['links']

    for node in nodes:
        _listComponentConfig(node, config, componentsmeta)
    
    for link in links:
        _listComponentConfig(link, config, linksmeta)
            
    return prettify.PrettyDict(config);


def _listComponentConfig(component, config, allmetadata):
    id = component['id']
    type = component['type']
        
    if type in allmetadata:
        metadata = allmetadata[type]
    else:
        raise IOError('related pattern type or plugin of %s is not enabled' % nodetype)
        
    attrs = {}
    groups = {}
    if 'attributes' in component:
        attrs = component['attributes']
    if 'groups' in component:
        groups = component['groups']
        
    #attributes in node
    if 'attributes' in metadata:
        for attr in metadata['attributes']:
            attrid = attr['id']
            if attrid in attrs:
                config[id + '.' + attrid] = attrs[attrid]
            else:
                config[id + '.' + attrid] = None
    #groups in node
    if 'groups' in metadata:
        _listGroupsConfig(id, groups, metadata['groups'], config)

    
#recursive method to parse group in metadata     
def _listGroupsConfig(nodeid, nodegroups, groupsmetadata, configJson):
    for group in groupsmetadata:
        if not "groups" in configJson:
            configJson['groups'] = {}
            
        groupid = group['id']
        if groupid in nodegroups:
            configJson['groups'][nodeid + '.' + groupid] = nodegroups[groupid]
        else:
            configJson['groups'][nodeid + '.' + groupid] = False
        if 'groups' in group:
            _listGroupsConfig(nodeid, nodegroups, group['groups'], configJson)
    