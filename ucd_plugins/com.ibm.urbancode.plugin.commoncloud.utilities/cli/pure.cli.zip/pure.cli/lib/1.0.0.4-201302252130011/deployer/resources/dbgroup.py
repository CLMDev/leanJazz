#
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2012. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
#
"""
Licensed Materials - Property of IBM
IBM WebSphere CloudBurst Appliance (9235-72X)
Copyright IBM Corporation 2011. All Rights Reserved.
US Government Users Restricted Rights - Use, duplication or disclosure
restricted by GSA ADP Schedule Contract with IBM Corp.
"""

import deployer.http as http
import deployer.prettify as prettify
import deployer.utils as utils
import deployer.validators as validators
from   commonattrs import CommonAttributes
from   relationships import RelatedResource, RelatedResourceCollection
from   restresource import RESTResource, RESTResourceCollection 
from deployer.messages import message
from deployer.utils import utos
import urllib


@utils.classinit
class Dbgroup(RelatedResource, CommonAttributes):
    'RM32045'
    @classmethod
    def _classinit(cls):        
        cls._registerURI(r'\A/resources/databases/[a-zA-Z0-9\-]+/databaseGroups/(?P<userName>[a-zA-Z0-9\.\_\-]+)\Z')

        cls._methodHelp()
        
        
    def __init__(self, uri, attrs):
        super(Dbgroup, self).__init__(uri, attrs)

        
        
@utils.classinit
class Dbgroups(RelatedResourceCollection):
    'RM32046'

    @classmethod
    def _classinit(cls):
        cls._contains(Dbgroup)
        cls._methodHelp('getlist')

    @classmethod
    def _restname(cls):
        return 'databaseGroups'
    
    def _list(self, filt = {}):
        'RM32047'
        utf8filt = filt.copy()
        subfilt = ''
        for k in utf8filt:
            if isinstance(utf8filt[k], str) or isinstance(utf8filt[k], unicode):
                utf8filt[k] = utf8filt[k].encode('utf-8')
                subfilt = utf8filt[k]
        if filt:
            filt = '?' + urllib.urlencode(utf8filt)
        else:
            filt = ''
        json=http.get('%s/%s' % (self.uri, subfilt))
        return utils.utos(json)

    def _uriForResource(self, attrs):
        return '%s/%s' % (self.uri, attrs['userName'])
    
    def __getitem__(self, key):
        'RM09019'

        # int key -> get by index
        if isinstance(key, int) or isinstance(key, long):
            return self._list()[key]

        raise TypeError('unsupported operand type for __getitem__: %s' % type(key))