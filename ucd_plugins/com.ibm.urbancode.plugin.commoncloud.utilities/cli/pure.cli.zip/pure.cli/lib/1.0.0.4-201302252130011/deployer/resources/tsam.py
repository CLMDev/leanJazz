"""
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2012. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
"""

from commonattrs import CommonAttributes
from deployer import http, utils, validators
from relationships import RelatedResource, RelatedResourceCollection
from restresource import RESTResource


@utils.classinit
class Tsam(RelatedResource, CommonAttributes):
    'RM09111'


    @classmethod
    def _classinit(cls):
        cls._registerURI(r'\A/resources/tsams/(?P<id>\d+)\Z')

        cls._defineRESTAttribute('currentmessage', 'RM09254', readonly=True)
        cls._defineAttribute('currentmessage_text', 'RM09154', readonly=True)
        cls._defineRESTAttribute('currentstatus', 'RM09255', readonly=True)
        cls._defineAttribute('currentstatus_text', 'RM09156', readonly=True)
        cls._defineRESTAttribute('id', 'RM09257', readonly=True)
        cls._defineRESTAttribute('password', 'RM09259', writeonly=True, validator=validators.string)
        cls._defineRESTAttribute('username', 'RM09260', validator=validators.string)

        cls._methodHelp('__contains__', '__delattr__', 'delete', '__eq__',
                        '__hash__', 'isStatusTransient', '__nonzero__',
                        'refresh', '__repr__', '__str__', '__unicode__',
                        'waitFor')



    def __init__(self, uri, attrs):
        super(Tsam, self).__init__(uri, attrs)
        self._roles = self.__class__.Roles(self)



@utils.classinit
class Tsams(RelatedResourceCollection):
    'RM09045'

    @classmethod
    def _classinit(cls):
        cls._contains(Tsam)
        cls._methodHelp('__contains__', 'create', 'delete', '__delitem__',
                        '__getattr__', '__getitem__', '__iter__',
                        '__len__', 'list', '__lshift__', '__repr__',
                        '__rshift__', '__str__', '__unicode__',
                        'admin', 'self')


    def self(self):
        'RM09046'

        json = http.get('%s/current' % self.uri)
        return RESTResource.resourceForURI('%s/%s' % (self.uri, json['id']), json)
