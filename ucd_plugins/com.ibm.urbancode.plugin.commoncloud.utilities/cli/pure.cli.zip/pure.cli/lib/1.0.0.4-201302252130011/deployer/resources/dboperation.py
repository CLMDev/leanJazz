#
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2012. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
#
"""
Licensed Materials - Property of IBM
IBM WebSphere CloudBurst Appliance (9235-72X)
Copyright IBM Corporation 2011. All Rights Reserved.
US Government Users Restricted Rights - Use, duplication or disclosure
restricted by GSA ADP Schedule Contract with IBM Corp.
"""

import deployer
from deployer import utils, validators, http, prettify
from restresource import RESTResource, RESTResourceCollection
from relationships import RelatedResource, RelatedResourceCollection
from commonattrs import CommonAttributes
from deployer.messages import Helpable
import urllib
import purescaleutils
import os

@utils.classinit
class DBOperation(RelatedResource, CommonAttributes):
    'RM32032'

    @classmethod
    def _classinit(cls):
        #cls._registerURI(r'\A/resources/databaseOperations/(?P<statusType>[\dabcdefo\-]+)\Z')
        cls._registerURI(r'\A/resources/databases/[\dabcdef\-]+/databaseOperations/(?P<operation_id>[\dabcdefo\-]+)\Z')

        cls._defaultRESTAttrs(True)
        cls._getParams({ 'details': True })

        cls._defineRESTAttribute('operation_id', 'RM32034', readonly=True, visible=[ lambda operation: operation.operation_id != None ])
        cls._defineRESTAttribute('name', 'RM32035', readonly=True, visible=[ lambda operation: operation.name != None ])
        cls._defineRESTAttribute('parameters', 'RM32036', readonly=True, visible=[ lambda operation: operation.parameters != None ])
        cls._defineRESTAttribute('status', 'RM32037', readonly=True, visible=[ lambda operation: operation.status != None ])
        cls._defineRESTAttribute('result', 'RM32038', readonly=True, visible=[ lambda operation: operation.result != None ])
        cls._defineRESTAttribute('role', '', readonly=True, visible=[ lambda operation: operation.role != None ])


        cls._methodHelp('__contains__', '__delattr__', 'delete', '__eq__',
                        '__hash__', 'isStatusTransient', '__nonzero__',
                        'refresh', '__repr__', '__str__', '__unicode__')
    def delete(self):
        'RM32039'
        json = http.delete(self.uri)
        return utils.utos(json)
    
@utils.classinit
class DBOperations(RelatedResourceCollection):
    'RM32033'

    @classmethod
    def _classinit(cls):
        cls._contains(DBOperation)
        cls._methodHelp('__contains__', 'create', 'delete', '__delitem__',
                        '__getattr__', '__getitem__', '__iter__',
                        '__len__', 'list', '__lshift__', '__repr__',
                        '__rshift__', '__str__', '__unicode__',
                        'get','uploadArtifact')

    @classmethod
    def _restname(cls):
        return 'databaseOperations'
        
    CREATE_ATTRIBUTES = [
        DBOperation._wizardStep('operation_id')
    ]

    def delete(self, operation_id):
        'RM32039'
        operation_id = purescaleutils.userInputChecker(operation_id, 'str')
        json = http.delete('%s/%s' % (self.uri, operation_id))
        return utils.utos(json)
    
    def getfreq(self):
        ''
        uri=self.uri.replace(self.uri.split("/")[4], 'databaseBackupFrequency')
        json = http.get(uri)
        return utils.utos(json)
    
    def create(self, d, role = None):
        'RM32040'
        if isinstance(d, dict):
            if isinstance(role, dict):
                d['role'] = role['name']
            
            elif role != None:
                purescaleutils.inputTypeErrorIndicator()
            dbID = self.uri.split("/")[3]
            json = http.postJSON(self.uri, d)
            return utils.utos(json)
        else:
            purescaleutils.inputTypeErrorIndicator()

    def getInstance(self, dbID):
        ''
        databaseList = http.get('/resources/databaseProvisionT1DB/')
        #print 'databaseList is \n%s' % databaseList
        for instance in databaseList:
            if instance['id']== dbID:
                  return instance
        return None
    
    def uploadArtifact(self, f):
        'RM32025'
        doclose = False
        f = purescaleutils.userInputChecker(f, 'file')
        f = file(f, 'rb')
        doclose = True
        fileNameAndExt = utils.stou(os.path.basename(f.name))
        index = self.uri.rfind('/')
        uri = self.uri[0 : index]
        json = http.restChunked('%s/operationArtifacts/%s' % (uri, fileNameAndExt), f, 'PUT', 'application/binary')
        if doclose:
            f.close()
        return utils.utos(json)
    
    def get(self, operation_id):
        'RM32041'
        operation_id = purescaleutils.userInputChecker(operation_id, 'str')
        return RESTResource.resourceForURI('%s/%s' % (self.uri, operation_id))


    def _defaultSearch(self, s):
        result = self._list({ 'operation_id': s })
        result.sort(lambda r1, r2: utils.exactMatchCmp(r1.name, r2.name, s))
        return result

    def _uriForResource(self, attrs):
        return '%s/%s' % (self.uri, attrs['operation_id'])

    def __getitem__(self, key):
        'RM09019'

        # int key -> get by index
        if isinstance(key, int) or isinstance(key, long):
            return self._list()[key]

        raise TypeError('unsupported operand type for __getitem__: %s' % type(key))