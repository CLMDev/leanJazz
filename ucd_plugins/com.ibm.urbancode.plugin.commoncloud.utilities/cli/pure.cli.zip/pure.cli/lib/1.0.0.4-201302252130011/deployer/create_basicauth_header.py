#!/usr/bin/env python

#
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2012. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
#

# =======================================================================
# create_basicauth_header.py - Utility to construct a security HTTP header
#		 that contains a signed time stamp and basic authentication
#                data so as to authenticate to Store House and Kernel Services. 
# =======================================================================

import base64
import json
import os
import subprocess
import sys
import time
from time import gmtime, strftime, sleep


def getenv(name):
    return os.getenv( name )

def loadkeys(filename):
    keys = json.load(open(filename))
    return keys

def save_priv_key(key):
    decoded_key = base64.b64decode(key)
    proc = subprocess.Popen(['openssl', 'pkcs8', '-nocrypt', '-inform', 'DER', '-outform', 'PEM', '-out', 'bootstrap_tmp_key.pem', '-passout', 'pass:PS'], stdin=subprocess.PIPE)
    proc.stdin.write( decoded_key )
    num=1
    while True:
        rc = proc.poll()
        if rc is not None:
            break
        sleep(0.1)
        if num < 200:
            num+=1
        else:
            break

def create_hash(data):
    proc = subprocess.Popen(['openssl', 'dgst', '-sha1', '-out', 'test_dgst.dat'], stdin=subprocess.PIPE)
    proc.stdin.write( data )
    return

def sign(data):
    proc = subprocess.Popen(['openssl', 'dgst', '-sha1', '-sign', 'bootstrap_tmp_key.pem', '-passin', 'pass:PS'], stdin=subprocess.PIPE, stdout=subprocess.PIPE)
    proc.stdin.write( data )
    sig = proc.communicate()[0]
    num=1
    while True:
        rc = proc.poll()
        if rc is not None:
            break
        sleep(0.1)
        if num < 200:
            num+=1
        else:
            break
    signature = base64.b64encode( sig )
    return signature

def remove_tmp_key_file():
    os.remove('bootstrap_tmp_key.pem')

def construct_userdata(timestamp, username, password, privateKey):
    BASIC_AUTHORIZATION_HEADER_SIGNATURE = "signature"
    BASIC_AUTHORIZATION_HEADER_USERID = "username"
    BASIC_AUTHORIZATION_HEADER_PASSWORD = "password"
    BASIC_AUTHORIZATION_HEADER_DATE = "date"
    date     = '"' + BASIC_AUTHORIZATION_HEADER_DATE + '":"' + timestamp + '"'
    user     = '"' + BASIC_AUTHORIZATION_HEADER_USERID + '":"' + username + '"'
    pswd     = '"' + BASIC_AUTHORIZATION_HEADER_PASSWORD + '":"' + password + '"'
    save_priv_key(privateKey)
    signature=sign(timestamp+username+password) 
    remove_tmp_key_file()
    sig      = '"' + BASIC_AUTHORIZATION_HEADER_SIGNATURE + '":"' + signature + '"'
    userdata =  '{' + date + ',' + user + ','+ pswd + ','+ sig + '}'   
    return userdata


def encrypt(data, key, algorithm):
    decoded_key = base64.b64decode(key)
    iv = bytearray(16)
    ivstr = iv.decode("utf-8")
    proc = subprocess.Popen(['openssl', 'enc', '-e', algorithm, '-K', decoded_key.encode("hex"), '-iv', ivstr.encode("hex")], stdin=subprocess.PIPE, stdout=subprocess.PIPE)
    proc.stdin.write( data )
    cipherText = proc.communicate()[0]
    num=1
    while True:
        rc = proc.poll()
        if rc is not None:
            break
        sleep(0.1)
        if num < 200:
            num+=1
        else:
            break
    cipherText = base64.b64encode( cipherText )
    return cipherText

def construct_authz_header(userdata, username, encKey, keyName):
    BASIC_AUTHORIZATION_HEADER_ENCRYPTION_ALGORITHM = "encryption_algorithm"
    BASIC_AUTHORIZATION_HEADER_CIPHER_TEXT = "cipher_text"
    BASIC_AUTHORIZATION_HEADER_USERID = "username";
    
    algorithm = '-aes-256-cbc'
    if keyName == "AES128":
         algorithm = '-aes-128-cbc'
    cipherText = encrypt(userdata, encKey, algorithm)
    user     = '"' + BASIC_AUTHORIZATION_HEADER_USERID + '":"' + username + '"'
    cdata    = '"' + BASIC_AUTHORIZATION_HEADER_CIPHER_TEXT + '":"' + cipherText + '"'
    algo     = '"' + BASIC_AUTHORIZATION_HEADER_ENCRYPTION_ALGORITHM + '":"' + keyName + '"'
    authzHdr =  '{' + cdata + ',' + user + ',' + algo + '}'   
    return authzHdr


# Construct a HTTP Header that contains a signed and encrypted timestamp, user id, and password
def create_basicauth_header():

    # Usage: Environment variables KEYSFILE, KEYNAME, USERNAME, and PASSWORD must exist.
    keys = loadkeys(getenv("KEYSFILE"))
    for key in keys:
        if key == "privateKey":
            privateKey = keys[key]
        elif key == "sharedKey":
            sharedKey = keys[key]
        elif key == "fallbackSharedKey":
            fallbackSharedKey = keys[key] 

    encKey = sharedKey
    keyName = getenv("KEYNAME")
    if keyName == "AES128":
         encKey = fallbackSharedKey

    # get current time(RFC 1123  Example:  Mon, 07 Mar 2011 03:39:49 GMT)
    timestamp = strftime("%a, %d %b %Y %H:%M:%S GMT", gmtime())
    username = getenv("USERNAME")

    userdata = construct_userdata(timestamp, username, getenv("PASSWORD"), privateKey)

    authzHdr = construct_authz_header(userdata, username, encKey, keyName)

    return authzHdr

if __name__ == "__main__":
    security_header = create_basicauth_header()
    print security_header

