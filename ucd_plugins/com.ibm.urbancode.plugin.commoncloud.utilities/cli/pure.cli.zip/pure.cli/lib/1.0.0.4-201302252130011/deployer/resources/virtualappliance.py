"""
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2012. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
"""

from commonattrs import CommonAttributes
import deployer
from deployer import http, utils, validators
from deployer.messages import message
import os
import part
from relationships import RelatedResource, RelatedResourceCollection
from restresource import RESTResource


@utils.classinit
class VirtualAppliance(RelatedResource, CommonAttributes):
    'RM09916'


    @classmethod
    def _classinit(cls):
        cls._registerURI(r'\A/resources/virtualAppliances/(?P<id>\d+)\Z')

        cls._defineAttribute('acl', 'RM09926', readonly=True, readonlydoc=False)
        cls._defineRESTAttribute('created', 'RM09917', readonly=True)
        cls._defineRESTAttribute('currentmessage', 'RM09918', readonly=True)
        cls._defineAttribute('currentmessage_text', 'RM09154', readonly=True)
        cls._defineRESTAttribute('currentstatus', 'RM09919', readonly=True)
        cls._defineAttribute('currentstatus_text', 'RM09156', readonly=True)
        cls._defineRESTAttribute('description', 'RM09920', readonly=True)
        cls._defineRESTAttribute('id', 'RM09921', readonly=True)
        cls._defineRESTAttribute('name', 'RM09922', readonly=True)
        cls._defineRESTAttribute('operatingsystemdescription', '', readonly=True)
        cls._defineRESTAttribute('operatingsystemid', '', readonly=True)
        cls._defineRESTAttribute('operatingsystemversion', '', readonly=True)
        cls._defineRESTAttribute('pmtype', 'RM09923', readonly=True)
        cls._defineRESTAttribute('updated', 'RM09924', readonly=True)
        cls._defineRESTAttribute('url', 'RM09925', readonly=True)

        cls._methodHelp()


    @classmethod
    def _restname(cls):
        return 'virtualAppliance'



@utils.classinit
class VirtualAppliances(RelatedResourceCollection):
    'RM09914'


    @classmethod
    def _classinit(cls):
        cls._contains(VirtualAppliance)
        cls._methodHelp('create')


    CREATE_ATTRIBUTES = [
        { 'name': 'name', 'help': message('RM09910'), 'validator': validators.string },
        { 'name': 'url', 'help': message('RM09911'), 'validator': validators.string },
        { 'name': 'userid', 'help': message('RM09912'), 'validator': validators.string, 'optional': True },
        { 'name': 'password', 'help': message('RM09913'), 'validator': validators.string, 'optional': True }
    ]

    def _getLicense(self):

        return NULL

    def __init__(self):
        super(VirtualAppliances, self).__init__()

        self.progressIndicators = False
        self.progressIndicators_ = property(doc=message('RM09539'))


    @classmethod
    def _restname(cls):
        return 'virtualAppliances'



    # public methods

    def create(self, other):
        'RM09915'

        parms = None

        # <virtualappliances>.create("<url>")
        if (isinstance(other, str) or isinstance(other, unicode)) and not os.path.isfile(other):
            parms = { 'url': utils.stou(other) }

        # <virtualappliances>.create("<filename.ova>")
        elif (isinstance(other, str) or isinstance(other, unicode)) and os.path.isfile(other) and other.lower().endswith('.ovf'):
            if self.progressIndicators:
                f = progressindicators.ReadProgressFile(other, 'rb')
            else:
                f = file(other, 'rb')

            try:
                return self.create(f)
            finally:
                f.close()

        # <virtualappliances>.create(<file>)
        elif isinstance(other, file):
            if self.progressIndicators and not isinstance(other, progressindicators.ReadProgressFile):
                other = progressindicators.ReadProgressFile(other.name, other.mode)

            json = http.postChunked(self.uri, other)
            return RESTResource.resourceForURI('%s/%s' % (self.uri, json['id']))

        # <virtualappliances>.create({...})
        elif isinstance(other, dict):
            parms = utils.stou(other)

        if parms:
            return self._create(parms)
        else:
            return super(VirtualAppliances, self).create(other)

