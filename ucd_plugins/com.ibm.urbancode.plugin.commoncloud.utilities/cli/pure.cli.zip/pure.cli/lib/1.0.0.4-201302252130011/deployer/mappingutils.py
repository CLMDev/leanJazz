#
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2012. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
#
from deployer import utils
from deployer.resources.restresource import RESTResource
import deployer


if utils.isIPAS():
    import admin
   
    
    
    # This method maps resources in system console to ones in workload console          
def getMappingResource(o):
    
    if not utils.isIPAS():
        return o
    
    if isinstance(o, admin.cloud):
        resources = deployer.clouds[o.name]
        return utils.find(lambda r: r.name == o.name, resources)
    
    elif isinstance(o, admin.ipgroup):
        resources = deployer.ipgroups[o.name]
        return utils.find(lambda r: r.name == o.name, resources)
    
    elif isinstance(o, admin.group):
        resources = deployer.groups[o.name]
        return utils.find(lambda r: r.name == o.name, resources)
    
    elif isinstance(o, admin.user):
        resources = deployer.users[o.user_id]
        return utils.find(lambda r: r.username == o.user_id, resources)

    elif isinstance(o, dict): 
        d = None
        
        for k, v in o.items():
            newValue = getMappingResource(v)
            if newValue != v:
               if d == None:
                  d = o.copy()
               d[k] = newValue
        
        return o if d == None else d
    
    elif isinstance(o, list):    
       l = None
       
       for idx, v in enumerate(o):
           newValue = getMappingResource(v)
           if newValue != v:
               if l == None:
                   l = o[:]
               l[idx] = newValue
    
       return o if l == None else l

    return o

#only used in epclouds
def getEPMappingResource(o):
    
    if not utils.isIPAS():
        return o
    
    o = getMappingResource(o)
    

    if isinstance(o, deployer.cloud):
        return deployer.resources.restresource.RESTResource.resourceForURI('/resources/epclouds/%d' % o.id, o._restattrs)
    
    if isinstance(o, deployer.ipgroup):
        return deployer.resources.restresource.RESTResource.resourceForURI('/resources/epipgroups/%d' % o.id, o._restattrs)
    
    return o