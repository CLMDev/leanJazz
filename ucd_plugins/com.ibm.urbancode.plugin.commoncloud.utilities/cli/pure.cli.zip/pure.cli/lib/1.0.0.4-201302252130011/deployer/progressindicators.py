"""
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2012. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
"""

import os.path
from sys import stdout
from time import time
from utils import humanSizeBytes


class Spinner(object):
    def __init__(self, **options):
        defaults = {
            'interval': 0.5,
            'display': [ '(  ', ' " ', '  )', ' _ ' ]
        }
        
        self.options = defaults.copy()
        self.options.update(options)

        self.lastUpdate = time()
        self.i = 0
        stdout.write(self.options['display'][self.i])


    def done(self):
        stdout.write('\b' * self.options['display'][self.i])
        
            
    def progress(self, n):
        now = time()

        if now - self.lastUpdate > self.options['interval']:
            self.lastUpdate = now
            stdout.write('\b' * len(self.options['display'][self.i]))
            self.i = (self.i + 1) % len(self.options['display'])
            stdout.write(self.options['display'][self.i])



class ProgressBar(object):
    def __init__(self, max, **options):
        defaults = {
            'prefix': '   ',
            'startbracket': '[',
            'endbracket': ']',
            'done': '=',
            'notdone': ' ',
            # TODO - need to doc that spinner must be single-char
            'spinner': ['|', '/', '-', '\\'],
            'interval': 0.5,
            'width': 60,
            'percentformat': ' %3.0f%%'
        }

        self.max = max
        self.options = defaults.copy()
        self.options.update(options)

        self.backspaces = self.options['width'] + len(self.options['endbracket'])
        if self.options['percentformat']:
            self.backspaces = self.backspaces + len(self.options['percentformat'] % 100)

        self.count = 0
        self.percent = ''
        self.lastUpdate = time()
        self.i = 0
        
        stdout.write(self.options['prefix'] + self.options['startbracket'])

        if self.options['spinner']:
            stdout.write(self.options['spinner'][self.i])
        else:
            stdout.write(self.options['notdone'])

        stdout.write(self.options['notdone'] * (self.options['width'] - 1) + self.options['endbracket'])

        if self.options['percentformat']:
            self.percent = self.options['percentformat'] % 0.0
            stdout.write(self.percent)


    def done(self):
        self.progress(self.max)
        stdout.write('\n')
        
            
    def progress(self, n):
        if n > self.max:
            n = self.max
            
        newcount = n * self.options['width'] / self.max

        if self.options['percentformat']:
            newpercent = self.options['percentformat'] % (n * 100.0 / self.max)
        else:
            newpercent = self.percent

        now = time()
        if now - self.lastUpdate > self.options['interval']:
            newi = (self.i + 1) % len(self.options['spinner'])
            self.lastUpdate = now
        else:
            newi = self.i
            
        if newcount != self.count or newpercent != self.percent or newi != self.i:
            stdout.write('\b' * self.backspaces)
            stdout.write(self.options['done'] * newcount)

            if self.options['spinner']:
                if newcount < self.options['width']:
                    stdout.write(self.options['spinner'][self.i])
            else:
                stdout.write(self.options['notdone'])
                
            stdout.write(self.options['notdone'] * (self.options['width'] - newcount - 1))
            stdout.write(self.options['endbracket'])

            if self.options['percentformat']:
                stdout.write(newpercent)
                
            self.count = newcount
            self.percent = newpercent
            self.i = newi

            

class ReadProgressFile(file):
    def __init__(self, filename, mode='r', bufsize=-1):
        super(ReadProgressFile, self).__init__(filename, mode, bufsize)
        
        size = os.path.getsize(filename)
        self.progress = ProgressBar(size, prefix=filename + ' (' + humanSizeBytes(size) + ')\n  ', width=65)


    def read(self, size=-1):
        s = super(ReadProgressFile, self).read(size)
        if len(s) == 0:
            self.progress.done()
        else:
            self.progress.progress(self.tell())
        return s
