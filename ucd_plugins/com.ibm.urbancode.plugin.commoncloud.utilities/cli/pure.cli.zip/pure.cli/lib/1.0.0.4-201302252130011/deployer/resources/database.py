#
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2012. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
#
"""
Licensed Materials - Property of IBM
IBM WebSphere CloudBurst Appliance (9235-72X)
Copyright IBM Corporation 2011. All Rights Reserved.
US Government Users Restricted Rights - Use, duplication or disclosure
restricted by GSA ADP Schedule Contract with IBM Corp.
"""

import deployer.http as http
import deployer.prettify as prettify
import deployer.utils as utils
import deployer.validators as validators
from   commonattrs import CommonAttributes
from   relationships import RelatedResource, RelatedResourceCollection
from   restresource import RESTResource
import urllib
import purescaleutils


@utils.classinit
class Database(RelatedResource, CommonAttributes):
    'RM09968'
    @classmethod
    def _classinit(cls):
        if utils.isSparta():
            cls._registerURI(r'\A/resources/databases/(?P<id>[\dabcdef\-]+)\Z')
            cls._defineRESTAttribute('dbName', 'RM32009', readonly=True, visible=[ lambda application: application._restattrs.has_key('dbName') ])
            cls._defineRESTAttribute('id', 'RM32010', readonly=True, visible=[ lambda application: application._restattrs.has_key('id') ])
            cls._defineRESTAttribute('instance_id', 'RM32011', readonly=True, visible=[ lambda application: application._restattrs.has_key('instance_id') ])
            cls._defineRESTAttribute('instName', 'RM32012', readonly=True, visible=[ lambda application: application._restattrs.has_key('instName') ])
            cls._defineRESTAttribute('database_description', 'RM32013', readonly=True, visible=[ lambda application: application._restattrs.has_key('database_description') ])
            cls._defineRESTAttribute('status', 'RM32014', readonly=True, visible=[ lambda application: application._restattrs.has_key('status') ])
            cls._defineRESTAttribute('start_time', 'RM32015', readonly=True, visible=[ lambda application: application._restattrs.has_key('start_time') ])
            cls._defineRESTAttribute('creator', 'RM32016', readonly=True, visible=[ lambda application: application._restattrs.has_key('creator') ]) 
            cls._defineRESTAttribute('host', 'RM32017', readonly=True,visible=[ lambda application: application._restattrs.has_key('host') ])
            cls._defineRESTAttribute('port', 'RM32018', readonly=True, visible=[ lambda application: application._restattrs.has_key('port') ])
            cls._defineRESTAttribute('database_level', 'RM32019', readonly=True, visible=[ lambda application: application._restattrs.has_key('database_level') ])
        else:
            cls._registerURI(r'\A/resources/databases/(?P<id>[\dabcdef\-]+)\Z')
            cls._defineRESTAttribute('dbid', 'RM09741', readonly=True)
        cls._methodHelp('__contains__', '__delattr__', 'delete', '__eq__',
                        '__hash__', 'isStatusTransient', '__nonzero__',
                        'refresh', '__repr__', '__str__', '__unicode__')
        
        
    def __init__(self, uri, attrs):
        super(Database, self).__init__(uri, attrs)
        
    if utils.isSparta():
        def delete(self):
            'RM32020'
            #print '%s?deploymentId=%s&instName=%s&dbName=%s' % (self.uri, self.instance_id, self.instName, self.dbName)
            json = http.delete('%s?deploymentId=%s&instName=%s&dbName=%s' % (self.uri, self.instance_id, self.instName, self.dbName))
            return utils.utos(json)

        def getLogs(self):
            ''
            json = http.get('%s?log' % (self.uri))
            return utils.utos(json)

        def downloadLog(self, sourceFile, targetFile):
            'RM09816'
            f = purescaleutils.userInputChecker(targetFile, 'file')
            doclose = False
            f = file(f, 'wb')
            doclose = True  
            node = sourceFile.split("/")[7]
            uri = '/resources/virtualApplications/%s/logs/virtualMachines/%s%s?action=download' % (self.instance_id, node, sourceFile)
            #/resources/virtualApplications/d-a8743876-6e5d-4cb3-84f1-780f57a92f25/logs/virtualMachines/transactionalDatabase-RegularNode.11344851561096/opt/IBM/maestro/agent/usr/servers/transactionalDatabase-RegularNode.11344851561096/logs/transactionalDatabase-RegularNode.11344851561096.RegularNode/62bb8166-0696-4cb1-87cd-570c67ab26fd/trace.log?action=download
            http.getWithSpecHeader(uri, {'Accept': 'text/plain'}, responseHandler=purescaleutils.curryMethod(self._getLogResponseHandler, f))
            if doclose:
               f.close()
    
        def _getLogResponseHandler(self, f, resp):
            if resp.status > 299:
                raise IOError(utils.utos(resp.reason))
    
            s = resp.read(100000)
    
            while s:
                f.write(s)
                s = resp.read(100000)
    
@utils.classinit
class Databases(RelatedResourceCollection):
    'RM09969'

    @classmethod
    def _classinit(cls):
        cls._contains(Database)
        cls._methodHelp('__contains__', 'create', 'delete', '__delitem__',
                        '__getattr__', '__getitem__', '__iter__',
                        '__len__', 'list', '__lshift__', '__repr__',
                        '__rshift__', '__str__', '__unicode__',
                        'admin', 'self')

    if utils.isSparta():
        def _uriForResource(self, attrs):
            return '%s/%s' % (self.uri, attrs['id'])
            
        def get(self, dbID):
            'RM32021' 
            dbID = purescaleutils.userInputChecker(dbID, 'str')
            json = http.get('%s/%s' % (self.uri,dbID))
            return RESTResource.resourceForURI('%s/%s' % (self.uri, dbID), json)
    
        def getInstance(self, dbID):
            ''
            databases = self.list()
            for instance in databases:
                if instance.id == dbID:
                      return instance
            return None
            
        @classmethod
        def _restname(cls):
            return 'databases'
    
        def create(self, d):
            'RM32022' 
            if isinstance(d, dict):
               json = http.postJSON(self.uri, d)
               return utils.utos(json)
            else:
               purescaleutils.inputTypeErrorIndicator()
               
        def __getitem__(self, key):
            'RM09019'
    
            # int key -> get by index
            if isinstance(key, int) or isinstance(key, long):
                return self._list()[key]
    
            raise TypeError('unsupported operand type for __getitem__: %s' % type(key))
    else:
        def getlist(self):
            json=http.get('%s' % self.uri)
            return utils.utos(json)


        
        def get(self,db_id):
            db_id = utils.stou(db_id)
            json=http.get('%s/%s' % (self.uri, db_id))
            return utils.utos(json)
           