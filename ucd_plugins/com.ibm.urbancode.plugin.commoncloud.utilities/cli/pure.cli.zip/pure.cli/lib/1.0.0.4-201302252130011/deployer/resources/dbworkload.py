#
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2012. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
#
"""
Licensed Materials - Property of IBM
IBM WebSphere CloudBurst Appliance (9235-72X)
Copyright IBM Corporation 2011. All Rights Reserved.
US Government Users Restricted Rights - Use, duplication or disclosure
restricted by GSA ADP Schedule Contract with IBM Corp.
"""

import deployer.http as http
import deployer.prettify as prettify
import deployer.utils as utils
import deployer.validators as validators
from   commonattrs import CommonAttributes
from   relationships import RelatedResource, RelatedResourceCollection
from   restresource import RESTResource, RESTResourceCollection
import urllib
import purescaleutils

@utils.classinit
class DatabaseWorkload(RelatedResource, CommonAttributes):
    'RM10035'
    @classmethod
    def _classinit(cls):
        cls._registerURI(r'\A/resources/databaseWorkloads/(?P<id>[a-zA-Z0-9\.\-\_\/]+)\Z')
        
        if utils.isSparta():
            cls._defineRESTAttribute('name', 'RM32000', readonly=True, visible=[ lambda application: application.name != None ])
            cls._defineRESTAttribute('id', 'RM32001', readonly=True, visible=[ lambda application: application.id != None ])
            cls._defineRESTAttribute('description', 'RM32002', readonly=True, visible=[ lambda application: application.description != None ])
            cls._defineRESTAttribute('compatibility_mode', 'RM32003', readonly=True, visible=[ lambda application: application.compatibility_mode != None ])
            cls._defineRESTAttribute('is_system', 'RM32074', readonly=True, visible=[ lambda application: application.is_system != None ])
            cls._defineRESTAttribute('version', 'RM32005', readonly=True, visible=[ lambda application: application.version != None ])
            cls._defineRESTAttribute('workload_file', 'RM32006', readonly=True, visible=[ lambda application: application.workload_file != None ])
        else:
            cls._defineRESTAttribute('name', 'RM09700', readonly=True, visible=[ lambda application: application.name != None ])
            cls._defineRESTAttribute('id', 'RM09701', readonly=True, visible=[ lambda application: application.id != None ])
            cls._defineRESTAttribute('description', 'RM09702', readonly=True, visible=[ lambda application: application.description != None ])
            cls._defineRESTAttribute('workload_type', 'RM09702', readonly=True, visible=[ lambda application: application.workload_type != None ])
            cls._defineRESTAttribute('rate', 'RM09701', readonly=True, visible=[ lambda application: application.rate != None ])
            cls._defineRESTAttribute('initial_disk_size', 'RM09703', readonly=True, visible=[ lambda application: application.initial_disk_size != None ])
            cls._defineRESTAttribute('is_system', 'RM09704', readonly=True, visible=[ lambda application: application.is_system != None ])
            cls._defineRESTAttribute('version', 'RM09705', readonly=True, visible=[ lambda application: application.version != None ])
            #cls._defineRESTAttribute('shortname_file', 'RM09705', readonly=True, visible=[ lambda application: application.shortname_file != None ])
            #shortname_file should not be retrieved as for system database workload standard, there is no shortname_file
            cls._defineRESTAttribute('workload_file', 'RM09706', readonly=True, visible=[ lambda application: application.workload_file != None ])
        cls._methodHelp('delete', 'update')
        
        
    def __init__(self, uri, attrs):
        super(DatabaseWorkload, self).__init__(uri, attrs)

    def delete(self):
        'RM10036'
        json = http.delete(self.uri)
        return utils.utos(json)

    def update(self, d):
        'RM10037'
        if isinstance(d, dict):
            json = http.putJSON(self.uri, d)
        else:
            purescaleutils.inputTypeErrorIndicator()
    
@utils.classinit
class DatabaseWorkloads(RelatedResourceCollection):
    'RM10035'
    @classmethod
    def _classinit(cls):
        cls._contains(DatabaseWorkload)
        cls._methodHelp('create', 'get')

    def _uriForResource(self, attrs):
        return '%s/%s' % (self.uri, attrs['id'])
        
    def get(self, dbworkload_id):
        'RM10038'
        dbworkload_id = purescaleutils.userInputChecker(dbworkload_id, 'str')
        return RESTResource.resourceForURI('%s/%s' % (self.uri, dbworkload_id))
        
    @classmethod
    def _restname(cls):
        return 'databaseWorkloads'

    def create(self, d):
        'RM10039'
        if isinstance(d, dict):
           json = http.postJSON(self.uri, d)
           return utils.utos(json)
        else:
           purescaleutils.inputTypeErrorIndicator()
           
    if utils.isSparta():       
        def __getitem__(self, key):
            'RM09019'
            # int key -> get by index
            if isinstance(key, int) or isinstance(key, long):
                return self._list()[key]
            raise TypeError('unsupported operand type for __getitem__: %s' % type(key))