#
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2012. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
#
"""
Licensed Materials - Property of IBM
IBM WebSphere CloudBurst Appliance (9235-72X)
Copyright IBM Corporation 2011. All Rights Reserved.
US Government Users Restricted Rights - Use, duplication or disclosure
restricted by GSA ADP Schedule Contract with IBM Corp.
"""

import deployer
from deployer import utils, validators, http, messages
from restresource import RESTResource, RESTResourceCollection
from relationships import RelatedResource, RelatedResourceCollection
from virtualapplication import VirtualApplication
from commonattrs import CommonAttributes
from deployer.messages import Helpable
import deployer.prettify as prettify
import urllib
import purescaleutils

@utils.classinit
class Logging(RelatedResource, CommonAttributes):
    'RM09814'

    @classmethod
    def _classinit(cls):
        cls._registerURI(r'\A/resources/virtualApplications/(?P<id>[\dabcdef\-]+)/logs/virtualMachines/[\d\w\-\.]+\Z')
        cls._defaultRESTAttrs(True)
        cls._getParams({ 'details': True })

        cls._methodHelp('getLogs', 'download')
        
    def getLogs(self):
        'IWD00006'
        return utils.utos(http.get(self.uri)) 
    
    def download(self, sourceFile, targetFile):
        'RM09816'
        f = purescaleutils.userInputChecker(targetFile, 'file')
        doclose = False
        f = file(f, 'wb')
        doclose = True
        uri = '%s%s?action=download' % (self.uri, sourceFile)
        http.getWithSpecHeader(uri, {'Accept': 'text/plain'}, responseHandler=purescaleutils.curryMethod(self._getResponseHandler, f))
        if doclose:
           f.close()
           
    def _getResponseHandler(self, f, resp):
        if resp.status > 299:
            raise IOError(utils.utos(resp.reason))

        s = resp.read(100000)

        while s:
            f.write(s)
            s = resp.read(100000)
