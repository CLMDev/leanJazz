#
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2012. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
#
"""
Licensed Materials - Property of IBM
IBM WebSphere CloudBurst Appliance (9235-72X)
Copyright IBM Corporation 2011. All Rights Reserved.
US Government Users Restricted Rights - Use, duplication or disclosure
restricted by GSA ADP Schedule Contract with IBM Corp.
"""

import deployer.http as http
import deployer.prettify as prettify
import deployer.utils as utils
import deployer.validators as validators
from   commonattrs import CommonAttributes
from   relationships import RelatedResource, RelatedResourceCollection
from   restresource import RESTResource, RESTResourceCollection 
from deployer.messages import message
from deployer.utils import utos
import urllib
import purescaleutils

@utils.classinit
class Dbimage(RelatedResource, CommonAttributes):
    'RM32028'
    @classmethod
    def _classinit(cls):
        if utils.isSparta():
            cls._registerURI(r'\A/resources/databaseImages/(?P<id>[a-zA-Z0-9\.\-\_\/]+)\Z')
            #cls._defineRESTAttribute('dbaasversion', 'RM09700', readonly=True, visible=[ lambda dbimage: dbimage.dbaasversion != None ])
            cls._defineRESTAttribute('imagename', '', readonly=True, visible=[ lambda application: application.imagename != None ])
            cls._defineRESTAttribute('imagedescription', '', readonly=True, visible=[ lambda application: application.imagedescription != None ])
            cls._defineRESTAttribute('timestamp', '', readonly=True, visible=[ lambda application: application.timestamp != None ])
            cls._defineRESTAttribute('imageflag', '', readonly=True, visible=[ lambda application: application.imageflag != None ])
            cls._defineRESTAttribute('id', '', readonly=True, visible=[ lambda application: application.id != None ])
            cls._defineRESTAttribute('tsmnodename', '', readonly=True, visible=[ lambda application: application.tsmnodename != None ])
            cls._defineRESTAttribute('platformtype', '', readonly=True, visible=[ lambda application: application.platformtype != None ])
            cls._defineRESTAttribute('ostype', '', readonly=True, visible=[ lambda application: application.ostype != None ])     
            cls._defineRESTAttribute('dbName', '', readonly=True, visible=[ lambda application: application.dbName != None ])
            cls._defineRESTAttribute('host', '', readonly=True, visible=[ lambda application: application.host != None ])    
        else:
            cls._registerURI(r'\A/resources/dbimages/(?P<id>[\dabcdef\-]+)\Z')
            # cls._defineRESTAttribute('dbaasversion', 'RM09700', readonly=True, visible=[ lambda dbimage: dbimage.dbaasversion != None ])    
        cls._methodHelp('__contains__', '__delattr__', 'delete', '__eq__',
                        '__hash__', 'isStatusTransient', '__nonzero__',
                        'refresh', '__repr__', '__str__', '__unicode__')
        
        
    def __init__(self, uri, attrs):
        super(Dbimage, self).__init__(uri, attrs)
  
@utils.classinit
class Dbimages(RelatedResourceCollection):
    'RM32029'

    @classmethod
    def _classinit(cls):
        cls._contains(Dbimage)
        cls._methodHelp('__contains__', 'create', 'delete', '__delitem__',
                        '__getattr__', '__getitem__', '__iter__',
                        '__len__', 'list', '__lshift__', '__repr__',
                        '__rshift__', '__str__', '__unicode__',
                        'admin', 'self')
    if utils.isSparta():    
        def _uriForResource(self, attrs):
            return '%s/%s' % (self.uri, attrs['id'])
    
        @classmethod
        def _restname(cls):
            return 'databaseImages'
 
        def get(self, image_id):
            'RM32030'
            image_id = purescaleutils.userInputChecker(image_id, 'str')
            json = http.get('%s/%s' % (self.uri, image_id))
            return RESTResource.resourceForURI('%s/%s' % (self.uri, image_id), json)

        def __getitem__(self, key):
            'RM09019'
            # int key -> get by index
            if isinstance(key, int) or isinstance(key, long):
                return self._list()[key]
            raise TypeError('unsupported operand type for __getitem__: %s' % type(key))
    else:
        def getlist(self,filt = {}):
            utf8filt = filt.copy()
            for k in utf8filt:
                if isinstance(utf8filt[k], str) or isinstance(utf8filt[k], unicode):
                    utf8filt[k] = utf8filt[k].encode('utf-8')
            if filt:
                filt = '?' + urllib.urlencode(utf8filt)
            else:
                filt = ''
            json=http.get('%s/%s' % (self.uri, filt))
            return utils.utos(json)

        def get(self,image_id):
            image_id = utils.stou(image_id)
            json=http.get('%s/%s' % (self.uri, image_id))
            return utils.utos(json)