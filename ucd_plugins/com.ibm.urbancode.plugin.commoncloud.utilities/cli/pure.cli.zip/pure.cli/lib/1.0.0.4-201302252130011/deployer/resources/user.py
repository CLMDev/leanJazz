"""
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2011. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
"""

from commonattrs import CommonAttributes
from deployer import http, utils, validators
from relationships import RelatedResource, RelatedResourceCollection
from restresource import RESTResource


@utils.classinit
class User(RelatedResource, CommonAttributes):
    'RM09111'


    @classmethod
    def _classinit(cls):
        cls._registerURI(r'\A/resources/users/(?P<id>\d+)\Z')

        cls._defineRESTAttribute('currentmessage', 'RM09254', readonly=True)
        cls._defineAttribute('currentmessage_text', 'RM09154', readonly=True)
        cls._defineRESTAttribute('currentstatus', 'RM09255', readonly=True)
        cls._defineAttribute('currentstatus_text', 'RM09156', readonly=True)
        cls._defineRESTAttribute('email', 'RM09256', validator=validators.string, readonly=True)
        cls._defineRESTAttribute('fullname', 'RM09258', restname='name', validator=validators.string, readonly=True)
        cls._defineRESTAttribute('id', 'RM09257', readonly=True)
        # name -> fullname
        cls._defineRESTAttribute('password', 'RM09259', writeonly=True, validator=validators.string, readonly=True)
        cls._defineAttribute('roles', cls.Roles.__doc__, validator=validators.noop, readonly=True)
        cls._defineRESTAttribute('username', 'RM09260', validator=validators.string, readonly=True)
        cls._defineRESTAttribute('deploymentoptions', 'RM09654', values=(0,1,2,3,4,5,6,7), readonly=True)

        cls._methodHelp('refresh')

    ALL_DEPLOYMENT_OPTIONS = 0
    CLOUD_ONLY_DEPLOYMENT_OPTION = 1
    ENVIRONMENT_PROFILE_ONLY_DEPLOYMENT_OPTION = 2

    class Roles(object):
        'RM09112'

        ROLES = [ object(), object(), 'CLOUD_USER', 'CLOUD_ADMIN',
                  'APPLIANCE_ADMIN', 'CATALOG_CREATOR', 'PATTERN_CREATOR', 'ILMT_USER',
                  'CLOUD_ADMIN_READONLY', 'APPLIANCE_ADMIN_READONLY' ,'PROFILE_CREATOR',
                  'REPORT_READONLY', object(), 'AUDIT_READONLY', 'AUDIT', 'HARDWARE']

        def __init__(self, user):
            self.user = user


        def __iter__(self):
            'RM09115'
            json = http.get('%s/roles' % self.user.uri)
            return iter([ self.ROLES[r] for r in range(0, len(self.ROLES)) if r in json and isinstance(self.ROLES[r], str)])


        def __repr__(self):
            'RM09119'
            return utils.utos(unicode(self))

        def __str__(self):
            'RM09118'
            return repr(self)


        def __unicode__(self):
            'RM09118'
            return unicode(list(self))


    def __init__(self, uri, attrs):
        super(User, self).__init__(uri, attrs)
        self._roles = self.__class__.Roles(self)


    def _getRoles(self):
        return self._roles

    def delete(self, id):
        raise NotImplementedError('delete')


@utils.classinit
class Users(RelatedResourceCollection):
    'RM09045'

    @classmethod
    def _classinit(cls):
        cls._contains(User)
        cls._methodHelp(' list',  'admin', 'self')


    def _defaultSearch(self, s):
        result = self._list({ 'username': s })
        result.sort(lambda r1, r2: utils.exactMatchCmp(r1.username, r2.username, s))
        return result

    def create(self, dict):
        raise NotImplementedError('create')
    
    def delete(self, id):
        raise NotImplementedError('delete')