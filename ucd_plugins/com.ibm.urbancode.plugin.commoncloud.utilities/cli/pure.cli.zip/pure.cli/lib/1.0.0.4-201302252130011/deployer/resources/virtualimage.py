"""
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2012. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
"""

from commonattrs import CommonAttributes
import deployer
from deployer import http, utils, validators, progressindicators, mappingutils
from deployer.messages import message
import os
import part
import re
import urlparse

from relationships import RelatedResource, RelatedResourceCollection
from restresource import RESTResource

@utils.classinit
class VirtualImage(RelatedResource, CommonAttributes):
    'RM09120'


    @classmethod
    def _classinit(cls):
        cls._registerURI(r'\A/resources/templates/(?P<id>\d+)\Z')

        cls._defineAttribute('acl', 'RM09262', readonly=True, readonlydoc=False)
        cls._defineRESTAttribute('advancedoptionsaccepted', 'RM09542', values=('T','F'))
        cls._defineRESTAttribute('build', 'RM09263', readonly=True)
        cls._defineRESTAttribute('created', 'RM09264', readonly=True)
        cls._defineRESTAttribute('currentmessage', 'RM09265', readonly=True)
        cls._defineAttribute('currentmessage_text', 'RM09154', readonly=True)
        cls._defineRESTAttribute('currentstatus', 'RM09266', readonly=True)
        cls._defineAttribute('currentstatus_text', 'RM09156', readonly=True)
        cls._defineRESTAttribute('description', 'RM09267', readonly=True)
        cls._defineRESTAttribute('hardware', 'RM09506', readonly=True)
        cls._defineRESTAttribute('id', 'RM09268', readonly=True)
        cls._defineAttribute('license', 'RM09619', readonly=True, readonlydoc=False, elided=True)
        cls._defineRESTAttribute('licenseaccepted', 'RM09460', values=('T','F'))
        cls._defineRESTAttribute('name', 'RM09269', readonly=True)
        cls._defineRESTAttribute('operatingsystemdescription', '', readonly=True)
        cls._defineRESTAttribute('operatingsystemid', '', readonly=True)
        cls._defineRESTAttribute('operatingsystemversion', '', readonly=True)
        cls._defineAttribute('parts', 'RM09505', readonly=True, elided=True)
        cls._defineRESTAttribute('pmtype', 'RM09270', readonly=True)
        cls._defineAttribute('productids', 'RM09524', readonly=True, elided=True)
        cls._defineRESTAttribute('servicelevel', 'RM09271', readonly=True)
        cls._defineRESTAttribute('updated', 'RM09272', readonly=True)
        cls._defineRESTAttribute('version', 'RM09273', readonly=True)

        cls._methodHelp('__contains__', '__delattr__', 'delete', '__eq__',
                        '__hash__', 'isStatusTransient', '__nonzero__',
                        'refresh', '__repr__', '__str__', '__unicode__',
                        'waitFor',
                        'acceptLicense', 'capture', 'clone',
                        'enableAdvancedOptions', 'export', 'extend',
                        'addProductid', 'deleteProductid', 'makeReadOnly')


    def _getLicense(self):
        json = http.get('%s/licenses' % self.uri)

        result = {}

        for groupj in json.items():
            group = { 'label': groupj[1]['title'], 'licenses': [] }

            for licensej in groupj[1]['licenses']:
                group['licenses'].append({
                    'licenseid': licensej['value'],
                    'label': licensej['title'],
                    'text': licensej['text']
                })

            result[groupj[0]] = group

        return result


    def _getParts(self):
        return part.Parts(virtualimage=self, type='concrete')


    def _getProductids(self):
        return http.get('%s/productids' % self.uri)


    def _findConcretePart(self, conceptual):
        for concrete in http.get('/resources/part2s?id=%d&realizes' % conceptual.id):
            if concrete['templateid'] == self.id:
                return RESTResource.resourceForURI('/resources/part2s/%d' % concrete['id'], concrete)

        return None


    @classmethod
    def _restname(cls):
        return 'template'


    def acceptLicense(self, licenses=None, accept='T'):
        'RM09459'

        if accept != 'T':
            http.putJSON(self.uri, { 'licenseaccepted': accept })

        else:
            legit = self._getLicense()

            # select arbitrary licenses if user didn't indicate any
            if licenses == None:
                licenses = {}

                for coll in legit.keys():
                    licenses[coll] = legit[coll]['licenses'][0]['licenseid']

            for coll in licenses.keys():
                if not legit.has_key(coll):
                    raise ValueError, message('RM09620', coll)

                if not utils.find(lambda l: l['licenseid'] == licenses[coll], legit[coll]['licenses']):
                    raise ValueError, message('RM09622', coll, licenses[coll])

                del legit[coll]

            if len(legit) > 0:
                raise ValueError, message('RM09621', legit.keys()[0])

            http.putJSON(self.uri, { 'licenseaccepted': accept, 'licenses': utils.stou(licenses) })

        self.refresh()


    def capture(self):
        'RM09228'
        self._restattrs['desiredstatus'] = 'RM01030' # Status.CAPTURED


    def clone(self, d):
        'RM09991'

        d = utils.stou(d)

        validators.string(d.get('name'), 'name')
        validators.string(d.get('version'), 'version')

        newattrs = {
            'name': d['name'],
            'version': d['version'],
            'desiredstatus': 'RM01027',
            'id': self.id
        }

        if d.has_key('description'):
            validators.string(d.get('description'), 'description')
            newattrs['description'] = d['description']

        if d.has_key('hardware'):
            newattrs['hardware'] = d['hardware']

        json = http.postJSON('/resources/templates', newattrs)
        return RESTResource.resourceForURI('/resources/templates/%s' % json['id'])


    def enableAdvancedOptions(self, accept = 'T'):
        'RM09543'
        self.advancedoptionsaccepted = accept


    def export(self, d):
        'RM09544'

        if isinstance(d, unicode) or isinstance(d, str):
            if not os.path.exists(d):
                os.mkdir(d)
            if not os.path.isdir(d):
                raise ValueException(utils.utos(message('IWD00029', d)))
            self._parseHeader = False
            self._file = None
            try:
                http.get('%s?download' % (self.uri), responseHandler=utils.curryMethod(self._getResponseHandler, d))
            finally:
                if self._file:
                   self._file.close()
                   self._file = None
            return self._fileName
                
        elif isinstance(d, dict):
            d = utils.stou(d)
    
            json = {
                'host': d['host'],
                'path': d['path'],
                'userid': d['userid'],
                'password': d['password']
            }
    
            # TODO - these checks are not terribly useful since Python already
            # raised KeyErrors when we referenced missing keys above
            for field in json:
                if json[field] == None:
                    raise ValueError('missing argument \'%s\' for method export()' % field)
    
            http.postJSON('/resources/templates/%s/remoteCopy' % self.id, json)
    
    def _getImageName(self, resp):
           header = resp.getheader('Content-Disposition')
           if not header:
              return None
           fileReg = re.compile(r'.*filename=\"(.*)\".*')
           m = fileReg.match(header)
           if m:
              f = m.group(1)
              return f
           return None
       
    def _getResponseHandler(self, dest, resp):
        
        if resp.status > 299:
            raise IOError(utils.utos(resp.reason))
        
        if not self._parseHeader:
           self._parseHeader = True
           self._fileName = self._getImageName(resp) or "%s.ova" % self.name
           self._file = file(os.path.join(dest, self._fileName), 'wb')
        
        buffer_size = 4 * 1024
        s = resp.read(buffer_size)

        while s:
            self._file.write(s)
            s = resp.read(buffer_size)
            
    def extend(self, d):
        'RM09230'
        d = mappingutils.getMappingResource(d)
        d = utils.stou(d)

        # TODO - would be good if we supported wizard for this call

        validators.string(d.get('name'), 'name')
        validators.string(d.get('version'), 'version')
        validators.instance(deployer.cloud, d.get('cloud'), 'cloud')
        validators.string(d.get('password'), 'password')
        
        if not d.has_key('iptype'):
           d['iptype'] = 'IPv4'
        validators.enum(['IPv4', 'IPv6'], d['iptype'], 'iptype')
            
        newattrs = {
            'name': d['name'],
            'version': d['version'],
            # TODO - should localize 'Copy of'
            'instancename': 'Copy of ' + d['name'],
            'cloudid': d['cloud'].id,
            'iptype': d['iptype'],
            'password': d['password'],
            'desiredstatus': 'RM01027',
            'id': self.id
        }
        
        #for IPAS
        if utils.isIPAS() or d.has_key('environmentprofile'):
            validators.instance(deployer.environmentprofile, d.get('environmentprofile'), 'environmentprofile')
            validators.instance(deployer.ipgroup, d.get('ipgroup'), 'ipgroup')
            newattrs['environment_profile_id'] = d['environmentprofile'].id
            newattrs['ip_group'] = d['ipgroup'].id
        
        if d.has_key('hardware'):
            newattrs['hardware'] = d['hardware']

        if d.has_key('description'):
            validators.string(d.get('description'), 'description')
            newattrs['description'] = d['description']

        json = http.postJSON('/resources/templates', newattrs)
        return RESTResource.resourceForURI('/resources/templates/%s' % json['id'])


    def addProductid(self, productid, licensetype='PVU', licensecpu=0, licensememory=0):
        'RM09735'

        json = {'productid': productid, 'licensetype': licensetype, 'licensecpu': licensecpu, 'licensememory': licensememory}
        return http.putJSON('%s/productids' % self.uri, json)


    def deleteProductid(self, productid, licensetype='PVU'):
        'RM09736'

        return http.delete('%s/productids?productid=%s&licensetype=%s' % (self.uri, productid, licensetype))
    #TODO: add message for this method
    def makeReadOnly(self):
        self._restattrs['desiredstatus'] = 'RM01028'


@utils.classinit
class VirtualImages(RelatedResourceCollection):
    'RM09047'


    @classmethod
    def _classinit(cls):
        cls._contains(VirtualImage)
        cls._methodHelp('__contains__', 'create', 'delete', '__delitem__',
                        '__getattr__', '__getitem__', '__iter__',
                        '__len__', 'list', '__lshift__', '__repr__',
                        '__rshift__', '__str__', '__unicode__',
                        'import')


    CREATE_ATTRIBUTES = [
        { 'name': 'url', 'help': message('RM09368'), 'validator': validators.string },
        { 'name': 'userid', 'help': message('RM09369'), 'validator': validators.string, 'optional': True },
        { 'name': 'password', 'help': message('RM09370'), 'validator': validators.string, 'optional': True }
    ]

    _PROPERTYHELP_ = [
        'progressIndicators'
    ]


    def __init__(self):
        super(VirtualImages, self).__init__()

        self.progressIndicators = False
        self.progressIndicators_ = property(doc=message('RM09539'))


    @classmethod
    def _restname(cls):
        return 'templates'



    # public methods

    def create(self, other):
        'RM09048'

        parms = None
        
        isUStr = isinstance(other, str) or isinstance(other, unicode)
        
        # <virtualimages>.create("<file://path>")
        if (isUStr and other.startswith('file://')):
            other = other[7:]

        # <virtualimages>.create("<filename.ova>")
        if (isUStr and os.path.isfile(other) and other.lower().endswith('.ova')):
            if self.progressIndicators:
                f = progressindicators.ReadProgressFile(other, 'rb')
            else:
                f = file(other, 'rb')

            try:
                return self.create(f)
            finally:
                f.close()
 
        # <virtualimages>.create("<url>")
        elif (isUStr and ('://' in other) and urlparse.urlparse(other).scheme != ''):
            parms = { 'url': utils.stou(other) }
                
        # <virtualimages>.create("<string that is not a valid local .ova file or remote url>")
        elif (isUStr):
            raise ValueError, message('RM09234', other)

        # <virtualimages>.create(<file>)
        elif isinstance(other, file):
            if self.progressIndicators and not isinstance(other, progressindicators.ReadProgressFile):
                other = progressindicators.ReadProgressFile(other.name, other.mode)

            json = http.postChunked(self.uri, other)
            return RESTResource.resourceForURI('%s/%s' % (self.uri, json['id']))

        # <virtualimages>.create({...})
        elif isinstance(other, dict):
            parms = utils.stou(other)

        if parms:
            return self._create(parms)
        else:
            return super(VirtualImages, self).create(other)


    def import_(self, other):
        'RM09048'
        return self.create(other)
    
    def _list(self, filt = {}):
        # REST API doesn't support some queries, do that in CLI side
        result = super(VirtualImages, self)._list(filt)
        return utils.filterRestResult(result, filt)
VirtualImages.import = VirtualImages.import_