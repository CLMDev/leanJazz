"""
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* (C) Copyright IBM Corporation 2012. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#* Author: ankai@cn.ibm.com (Kai An)
#*
#*===================================================================
"""
import deployer
from deployer import utils, validators, http
from restresource import RESTResource, RESTResourceCollection
from relationships import RelatedResource, RelatedResourceCollection
from commonattrs import CommonAttributes
from deployer.messages import Helpable
import urllib
import purescaleutils

class ADDON_UI(object):
    'ADDON10000'       
    
    _METHODHELP_ = ['install']
    
    URI = '/resources/UIAddon' 

    def install(self, f, name = None):
        'ADDON10001' 
        self.upload(f,name) 
        f = file(f, 'rb')
        self.enable(purescaleutils.getFileName(f))  

    def upload(self, f, name = None):
        'ADDON10002'
        doclose = False
        f = purescaleutils.userInputChecker(f, 'file')
        f = file(f, 'rb')
        doclose = True
        uploadType = purescaleutils.getFileExt(f)        
        uri = self.URI               
        if uploadType == 'zip':
            json = http.restChunked(uri, f, 'POST', 'application/zip')     
            print(utils.utos(json))
        else:
            purescaleutils.fileTypeErrorIndicator()
        if doclose:
            f.close()   
            
    def enable(self, name = None):
        'ADDON10003' 
        uri = self.URI       
        json = http.putJSON(uri, {'status': 'enable','addonName': name})
        print(utils.utos(json))

    def uninstall(self, name):
        'ADDON10004' 
        self.delete(name) 

    def delete(self, name):
        'ADDON10005'
        uri = self.URI               
        json = http.delete(uri + '?addonName=' + name)
        print(utils.utos(json))
                                