"""
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2012. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
"""

from deployer import utils
from resource import Resource


class LocalResource(Resource):
    """Internal class used to get Resource-like behavior with attributes
    backed by a local dict.
    """

    @classmethod
    def _defineAttribute(cls, name, doc, **options):
        """Defines an attribute based on a local dict

        The parameters for this method are the same as
        Resource._defineAttribute except as noted below.

        This method accepts the following keyword arguments in
        addition to those accepted by Resource._defineAttribute:

        localname - name used for the attribute in the dict.  Default
           is to use attribute's name.
        """

        if options.has_key('fget'):
            pass
        elif options.get('writeonly', False):
            pass
        elif hasattr(cls, '_get' + utils.capitalize(name)):
            pass
        else:
            options['fget'] = utils.curryMethod(cls._localGetAttr, name)

        if options.has_key('fset'):
            pass
        elif options.get('readonly', False):
            pass
        elif hasattr(cls, '_set' + utils.capitalize(name)):
            pass
        else:
            options['fset'] = utils.curryMethod(cls._localSetAttr, name)

        if options.has_key('fdel'):
            pass
        elif options.get('readonly', False):
            pass
        elif hasattr(cls, '_del' + name.capitalize()):
            pass
        else:
            options['fdel'] = utils.curryMethod(cls._localDelAttr, name)


        # remember localname for later
        localname = options.get('localname', name)
        try:
            cls._LOCALNAMES_[name] = localname
        except AttributeError:
            cls._LOCALNAMES_ = { name: localname }

            
        super(LocalResource, cls)._defineAttribute(name, doc, **options)



    def _localGetAttr(self, name):
        return self._localattrs[self.__class__._LOCALNAMES_[name]]


    def _localSetAttr(self, name, value):
        self._validate(name, value)
        self._localattrs[self.__class__._LOCALNAMES_[name]] = value


    def _localDelAttr(self, name):
        self._localSetAttr(name, None)


    def __init__(self, attrs=None):
        self._localattrs = {}
        self._localattrs.update(attrs or {})
