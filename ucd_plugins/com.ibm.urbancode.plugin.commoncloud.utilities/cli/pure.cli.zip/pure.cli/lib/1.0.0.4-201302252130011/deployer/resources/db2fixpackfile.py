#
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2012. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
#
"""
Licensed Materials - Property of IBM
IBM WebSphere CloudBurst Appliance (9235-72X)
Copyright IBM Corporation 2011. All Rights Reserved.
US Government Users Restricted Rights - Use, duplication or disclosure
restricted by GSA ADP Schedule Contract with IBM Corp.
"""

import deployer.http as http
import deployer.prettify as prettify
import deployer.utils as utils
import deployer.validators as validators
from   commonattrs import CommonAttributes
from   relationships import RelatedResource, RelatedResourceCollection
from   restresource import RESTResource
import purescaleutils
import urllib


@utils.classinit
class DB2FixpackFile(RelatedResource, CommonAttributes):
    @classmethod
    def _classinit(cls):
        cls._registerURI(r'\A/resources/db2Fixes/[a-zA-Z0-9\-]+/fixFiles/(?P<name>[a-zA-Z0-9\.\_\-]+)\Z')
        cls._methodHelp('__contains__', '__delattr__', 'delete', '__eq__',
                        '__hash__', 'isStatusTransient', '__nonzero__',
                        'refresh','upload', '__repr__', '__str__', '__unicode__')
        
        
    def __init__(self, uri, attrs):
        super(DB2FixpackFile, self).__init__(uri, attrs)
        
        
@utils.classinit
class DB2FixpackFiles(RelatedResourceCollection):

    @classmethod
    def _classinit(cls):
        cls._contains(DB2FixpackFile)
        cls._methodHelp('__contains__', 'create', 'delete', '__delitem__',
                        '__getattr__', '__getitem__', '__iter__',
                        '__len__', 'list', '__lshift__', '__repr__',
                        '__rshift__', '__str__', '__unicode__',
                        'admin', 'self','upload')
    @classmethod
    def _restname(cls):
        return 'fixFiles'
                  
    def upload(self, f):
        doclose = False
        f = purescaleutils.userInputChecker(f, 'file')
        f = file(f, 'rb')
        doclose = True
        fileName = purescaleutils.getFileBaseName(f)
        db2fixpackId = self.uri.split("/")[3]
        db2fixpackUri = "/resources/fixFiles/" + db2fixpackId + "?filename=" + fileName
        #json = http.restChunked('%s/%s' % (db2fixpackUri, fileName), f, 'PUT', 'application/binary')
        json = http.restChunked('%s' % (db2fixpackUri), f, 'PUT', 'application/binary')
        if doclose:
            f.close()
        return utils.utos(json)

    #def _getResponseHandler(self, f, resp):
    def _getResponseHandler(self, resp, f):
        if resp.status > 299:
            raise IOError(utos(resp.reason))

        s = resp.read(100000)

        while s:
            f.write(s)
            s = resp.read(100000)
    
    def _list(self):
    	return []