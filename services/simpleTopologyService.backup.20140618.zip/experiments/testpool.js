var privatevar = "Private";
var publicvar = "Public";

oPool = {
	publicvar: publicvar
};

exports.oPool = function(){
	return oPool;
};



